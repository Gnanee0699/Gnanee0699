package com.carecentrix.api.setup;

import static net.serenitybdd.rest.SerenityRest.setDefaultRequestSpecification;

import com.carecentrix.utilities.PropLoader;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;

public class SetupHeaders {
	
	

	public void initialSetup(String hostname) throws InterruptedException {
		RestAssured.useRelaxedHTTPSValidation();
		setDefaultRequestSpecification((new RequestSpecBuilder())
				.setContentType("application/json")
				.setAccept("application/json")
				.setBaseUri(PropLoader.props.apply(hostname))
				.build());
	}

}
