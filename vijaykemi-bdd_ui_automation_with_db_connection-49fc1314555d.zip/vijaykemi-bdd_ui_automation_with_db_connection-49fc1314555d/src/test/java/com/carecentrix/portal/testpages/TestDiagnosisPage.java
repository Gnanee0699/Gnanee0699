package com.carecentrix.portal.testpages;

import com.carecentrix.portal.pages.DiagnosisPage;
import com.carecentrix.utilities.BasePage;
import com.carecentrix.utilities.PropLoader;

/**
 * @author KJ
 *
 */

public class TestDiagnosisPage extends BasePage {

	DiagnosisPage objDiagnosisPage;

	String searchICDCode;
	String description;
	String invalid_ICDCode;
	String invalid_description;
	String description_MoreResult;

	public void readPropertyFile() {
		try {
			searchICDCode = PropLoader.props.apply("searchICDCode");
			description = PropLoader.props.apply("description");
			invalid_ICDCode = PropLoader.props.apply("invalid_ICDCode");
			invalid_description = PropLoader.props.apply("invalid_description");
			description_MoreResult = PropLoader.props.apply("description_MoreResult");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean isDiagnosisTabEnabled() {
		objDiagnosisPage = new DiagnosisPage(driver);
		return objDiagnosisPage.isDiagnosisTabAvailable();

	}

	//Updated for external test data.
	public boolean searchICDCode(String ICDCode) {
		//readPropertyFile();
		objDiagnosisPage = new DiagnosisPage(driver);
		return objDiagnosisPage.enterICDCode(ICDCode);

	}

	public void clickSearchButton() {
		objDiagnosisPage = new DiagnosisPage(driver);
		objDiagnosisPage.clickSearchButton();

	}
	//Updated for external test data.
	public void verifySearchResult(String ICDCode) {
		//readPropertyFile();
		objDiagnosisPage = new DiagnosisPage(driver);
		objDiagnosisPage.verifySearchResult(ICDCode);
	}

	public void clickAddButton() {
		objDiagnosisPage = new DiagnosisPage(driver);
		objDiagnosisPage.clickAddButton();
	}
	
	public void clickNextAvailableAddButton() {
		objDiagnosisPage = new DiagnosisPage(driver);
		objDiagnosisPage.clickAvailableAddButton();
	}

	public void searchByDescription(String strdescription) {
//		readPropertyFile();
		objDiagnosisPage = new DiagnosisPage(driver);
		objDiagnosisPage.searchByDescription(strdescription);

	}
//Updated for external test data.
	public void searchByICDCodeAndDescription(String ICDCode, String ICDDescription) {
		readPropertyFile();
		objDiagnosisPage = new DiagnosisPage(driver);
		objDiagnosisPage.searchByICDCodeAndDescription(ICDCode, ICDDescription);

	}

	public void clickPrimaryButton() {
		objDiagnosisPage = new DiagnosisPage(driver);
		objDiagnosisPage.clickPrimaryButton();
	}

	public boolean isPrimaryOptionAdded() {
		objDiagnosisPage = new DiagnosisPage(driver);
		return objDiagnosisPage.isPrimaryOptionAdded();

	}

	public void isSecondaryOptionAdded() {
		objDiagnosisPage = new DiagnosisPage(driver);
		objDiagnosisPage.isSecondaryOptionAdded();
	}

	public void isTertiaryOptionAdded() {
		objDiagnosisPage = new DiagnosisPage(driver);
		objDiagnosisPage.isTertiaryOptionAdded();

	}

	public void clickSecondaryButton() {
		objDiagnosisPage = new DiagnosisPage(driver);
		objDiagnosisPage.clickSecondaryButton();
	}

	public void clickTertiaryButton() {
		objDiagnosisPage = new DiagnosisPage(driver);
		objDiagnosisPage.clickTertiaryButton();
	}

	public void isOtherOptionAdded() {
		objDiagnosisPage = new DiagnosisPage(driver);
		objDiagnosisPage.isOtherOptionAdded();
	}

	public void clickOtherButton() {
		objDiagnosisPage = new DiagnosisPage(driver);
		objDiagnosisPage.clickOtherButton();
	}

	public void clickNextButton() {
		objDiagnosisPage = new DiagnosisPage(driver);
		objDiagnosisPage.clickNextButton();
	}

	public void checkErrorMessage() {
		objDiagnosisPage = new DiagnosisPage(driver);
		objDiagnosisPage.checkErrorMessage();
	}

	public void closebrowser() {
		objDiagnosisPage = new DiagnosisPage(driver);
		objDiagnosisPage.quitBrowser();

	}

	public void verifyDiagnosisTypes(String diagnosisNamePrim, String diagnosisNameSecond, String diagnosisNameTert,
			String diagnosisNameOther) {
		try {
			objDiagnosisPage = new DiagnosisPage(driver);
			objDiagnosisPage.verifyDiagnosisTypes(diagnosisNamePrim, diagnosisNameSecond, diagnosisNameTert,
					diagnosisNameOther);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void searchByInvalidICDCodeAndDescription() {
		readPropertyFile();
		objDiagnosisPage = new DiagnosisPage(driver);
		objDiagnosisPage.searchByInvalidICDCodeAndDescription(invalid_ICDCode, invalid_description);
	}

	public boolean verifyErrorMessageToUpdateSearchCriteria() {
		objDiagnosisPage = new DiagnosisPage(driver);
		return objDiagnosisPage.verifyErrorMessageToUpdateSearchCriteria();
	}

	public void enterDetailsToGetMoreRecords() {
		readPropertyFile();
		objDiagnosisPage = new DiagnosisPage(driver);
		objDiagnosisPage.enterDetailsToGetMoreRecords(description_MoreResult);
	}

	public boolean verifyErrorMessageForMoreRecords() {
		objDiagnosisPage = new DiagnosisPage(driver);
		return objDiagnosisPage.verifyErrorMessageForMoreRecords();
	}

	public void chooseDiagType(String digType) {
		objDiagnosisPage = new DiagnosisPage(driver);
		objDiagnosisPage.chooseDiagType(digType);
	}

	public boolean checkPrimaryOptionDisabled() {
		objDiagnosisPage = new DiagnosisPage(driver);
		return objDiagnosisPage.checkPrimaryOptionDisabled();
	}

}
