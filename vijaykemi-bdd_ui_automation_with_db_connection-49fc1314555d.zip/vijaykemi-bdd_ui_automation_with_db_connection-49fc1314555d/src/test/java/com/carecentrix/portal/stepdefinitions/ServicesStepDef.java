package com.carecentrix.portal.stepdefinitions;

import java.io.IOException;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;

import com.carecentrix.portal.testUtils.ExcelReader;
import com.carecentrix.portal.testpages.TestDiagnosisPage;
import com.carecentrix.portal.testpages.TestMemberInfoPage;
import com.carecentrix.portal.testpages.TestServicesPage;
import com.carecentrix.utilities.Constant;
import com.carecentrix.utilities.SeleniumMethods;

import cucumber.api.java.en.Then;

/**
 * @author KJ
 *
 */

public class ServicesStepDef {

	MemberInfoStepDef memberInfoStepDef = new MemberInfoStepDef();
	DiagnosisStepDef diagnosisStepDef = new DiagnosisStepDef();
	TestMemberInfoPage testMemberInfoPage = new TestMemberInfoPage();
	TestDiagnosisPage testDiagnosisPage = new TestDiagnosisPage();
	TestServicesPage testServicesPage = new TestServicesPage();
	Map<String, Object> dataMap;
	private static final Logger log = LogManager.getLogger(ServicesStepDef.class);
	
	Constant constant = new Constant();

	@Then("^Check availability of Services tab$")
	public boolean checkavailabilityofServicestab() throws IOException, InterruptedException {
		

		
		String lastName = (String) constant.dataMap.get("lastName"); 
		String firstName = (String) constant.dataMap.get("firstName");
		String dob = (String) constant.dataMap.get("dob");
		String healthPlan = (String) constant.dataMap.get("healthPlan");
		String subscriberId = (String) constant.dataMap.get("subscriberId");
		String referralType = (String) constant.dataMap.get("referralType");
		String earlierRequestedStartDate = (String) constant.dataMap.get("earlierRequestedStartDate");
		String ICDCode = (String) constant.dataMap.get("ICDCode");
		
		boolean serviceTabAvailability = false;
		if (testMemberInfoPage.isMemberInfoTabAvailable()) {
			log.info("Inside member info loop");
			memberInfoStepDef.fillmemberInfodetails(lastName, firstName, dob, healthPlan, subscriberId, referralType, earlierRequestedStartDate);
		}
		if (testDiagnosisPage.isDiagnosisTabEnabled()) {
						diagnosisStepDef.filldiagnosisdetails(ICDCode);
			
		}
		if (testServicesPage.isServicesTabEnabled()) {
			log.info("Services Tab available for testing");
			serviceTabAvailability = true;
		}
		return serviceTabAvailability;
	}

	@Then("^Click Services DropDown$")
	public void clickServicesDropDown() {
		Assert.assertEquals(true, testServicesPage.clickServicesDropDown());
	}

	//Updated for external test data.
	@Then("^Select services from dropdown$")
	public void selectfromdropdown() {
		try {
		//	dataMap = ExcelReader.readAllRow("EPE2EData", scenario);
		//	String selectServices = (String) dataMap.get("services");
			String serviceType = (String) constant.dataMap.get("services");
			testServicesPage.selectSpecificServices(serviceType);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Then("^Click search button$")
	public void clicksearchbutton() {
		testServicesPage.clickSearchButton();
	}

	@Then("^User can able to select services from list$")
	public void usercanabletoservicesfromlist() {
		if (testServicesPage.isUserCanSelectService())
			log.info("Services are Available in dropdown");
		else
			log.info("Services are not available in dropdown");
	}

	@Then("^Select services from list$")
	public void selectservicesfromlist() {
		testServicesPage.selectServiceFromList();
	}

	//MD - Updated for external test data.
	@Then("^Select requestType Request Type$")
	public void selectRequestType() {
		try {
	//	dataMap = ExcelReader.readAllRow("EPE2EData", scenario);
		String serviceRequestType = (String) constant.dataMap.get("RequestType");
		testServicesPage.selectRequestType(serviceRequestType);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Then("^Enter Request StartDate \"([^\"]*)\"$")
	public void enterrequeststartDate(String scenario) throws IOException, InterruptedException {
		String RQstartdate = (String) Constant.dataMap.get("Requeststartdate");
		int Requeststartdate = Integer.parseInt(RQstartdate);
		testServicesPage.enterRequestStartDate(Requeststartdate);
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Services page01");
		log.info(Constant.SCRLOGSHT_MSG, "Services page01");
	}

	@Then("^Close Browser$")
	public void closeBrowser() {
		testServicesPage.quitBrowser();
	}

	@Then("^Refresh Browser$")
	public void refreshBrowser() {
		testServicesPage.refreshBrowser();
	}

	//MD - Updated for external test data.
	@Then("^Select Service Initiated option$")
	public void selectServiceInitiatedoption() throws IOException, InterruptedException {
		try {
		//	dataMap = ExcelReader.readAllRow("EPE2EData", scenario);
			String serviceInitiated = (String) Constant.dataMap.get("Option1");
			testServicesPage.isServiceInitiated(serviceInitiated);
			} catch (Exception e) {
				e.printStackTrace();
			}
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Services page02");
		log.info(Constant.SCRLOGSHT_MSG, "Services page02");
	}

	//MD - Updated for external test data.
	@Then("^Select Physicians Order option$")
	public void selectPhysiciansOrderoption() {
		try {
			//dataMap = ExcelReader.readAllRow("EPE2EData", scenario);
			String physiciansOrder = (String) Constant.dataMap.get("Option2");
			//String physiciansOrder = (String) dataMap.get("question2");
			testServicesPage.isPhysicianOrderSelected(physiciansOrder);
			} catch (Exception e) {
				e.printStackTrace();
			}
		
	}

	//MD - Updated for external test data.
	@Then("^Select Discharging Facility option$")
	public void selectDischargingFacilityoption() throws IOException, InterruptedException {
		try {
			//dataMap = ExcelReader.readAllRow("EPE2EData", scenario);
			String dischargingFacility = (String) Constant.dataMap.get("Option3");
			String servicesCity = (String) Constant.dataMap.get("Dischargingfacilitycity");
			String servicesState = (String) Constant.dataMap.get("Dischargingfacilityst");
			testServicesPage.isDischargingFacilitySelected(dischargingFacility,servicesCity, servicesState);
			} catch (Exception e) {
				e.printStackTrace();
			}
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Services page03");
		log.info(Constant.SCRLOGSHT_MSG, "Services page03");
	}

	@Then("^Verify Discharge Facility search page$")
	public void verifyDischargeFacilitysearchpage() {
		Assert.assertEquals(true, testServicesPage.verifyDischargeFacilitySearchPage());
	}

	@Then("^Search Facility using NPI and Zip code$")
	public void searchfacilityusingNPIandZipcode() {
		String PhysicianNPI = (String) Constant.dataMap.get("PhysicianNPI");
		String PhysicianZipCode = (String) Constant.dataMap.get("PhysicianZipCode");
		testServicesPage.searchFacilityUsingNPIAndZipCode(PhysicianNPI,PhysicianZipCode);
	}
	
	@Then("^Search Facility using NPI and Facility name$")
	public void searchfacilityusingNPIandFacilityname() {
		String PhysicianNPI = (String) Constant.dataMap.get("PhysicianNPI");
		String PhysicianName = (String) Constant.dataMap.get("PhysicianName");
		testServicesPage.searchFacilityUsingNPIAndName(PhysicianNPI,PhysicianName);
	}

	@Then("^Search Facility using City and State$")
	public void searchfacilityusingCityandState() {
		testServicesPage.searchFacilityUsingCityAndState();
	}

	@Then("^Select discharging facility$")
	public void selectdischargingfacility() {
		testServicesPage.selectDischargingFacility();
	}

	@Then("^Choose AdmitDate and DischargeDate$")
	public void chooseAdmitDateandDischargeDate() {
		testServicesPage.chooseAdmitDateAndDischargeDate();
	}

	@Then("^Check AdmitDate and DischargeDate is selected$")
	public void checkAdmitDateandDischargeDateisselected() {
		Assert.assertEquals(true, testServicesPage.isAdmitDateAndDischargeDateSelected());
	}

	@Then("^Click on Next$")
	public void clickonNext() {
		testServicesPage.clickOnNext();
	}

	@Then("^Facility should be selected$")
	public void facilityshouldbeselected() {
		Assert.assertEquals(true, testServicesPage.isFacilitySelected());
	}

	@Then("^Verify search result fields$")
	public void verifysearchresultfields() {
		Assert.assertEquals(true, testServicesPage.isRequiredFieldsDisplayed());
	}

	@Then("^Request type changed to Urgent$")
	public void requesttypechangedtoUrgent() {
		Assert.assertEquals(true, testServicesPage.isRequestTypeChanged());
		log.info("Request Type Changed to Urgent");
	}

	@Then("^Request type should not be editable$")
	public void requesttypeshouldnotbeeditable() {
		Assert.assertEquals(true, testServicesPage.isRequestTypeNotEnabled());
		log.info("Request Type is not editable");
	}

	@Then("^Verify Service details in search result \"([^\"]*)\"$")
	public void verifyServicedetailsinsearchresult(String serviceType) {
		Assert.assertEquals(true, testServicesPage.isServiceDetailsDisplayed(serviceType));
		log.info("Verified Search result");
	}

	@Then("^Click next button in Services tab$")
	public void clickNextButtonInServicesTab() {
		testServicesPage.clickOnNextButton();
	}
	
	@Then("^Answer clinical template questions$")
	public void Answerclinicaltemplatequestions() throws InterruptedException {
		String Planid = (String) Constant.dataMap.get("Planid");
		
		if(Planid.equals("16571"))
		{
		String Ans_Doestpathavacuhosneeds = (String) Constant.dataMap.get("Does_the_patient_have_acute_hospital_needs");
		String Ans_DoestpathavensecomcathamakeSkilnursfaccare = (String) Constant.dataMap.get("Does_the_patient_have_acute_hospital_needs");
		String Ans_Doesthecareincludemultiplecomptsdelidbyskilledprofnals = (String) Constant.dataMap.get("Does_the_care_include_multiple_components_delivered_by_skilled_professionals");
		String Ans_IsthereaplantoprovideALLofthefollowing = (String) Constant.dataMap.get("Is_there_a_plan_to_provide_ALL_of_the_following");
		String Ans_Isskilledtreatmentneededdailyormorefrequent = (String) Constant.dataMap.get("Is_skilled_treatment_needed_daily_or_more_frequent");
		String Ans_Whattypeofskilledtreatmentsareneeded = (String) Constant.dataMap.get("What_type_of_skilled_treatments_are_needed");
		String Ans_Whatarethenursinginterventionsbeingrequested = (String) Constant.dataMap.get("What_are_the_nursing_interventions_being_requested");
		String Ans_Doyouhaveclinicaldocumentationtosupportthisrequest = (String) Constant.dataMap.get("Do_you_have_clinical_documentation_to_support_this_request");
		testServicesPage.selectclinicaltemplateDoes_the_patient_have_acute_hospital_needs(Ans_Doestpathavacuhosneeds);
		testServicesPage.clickOnNextButtonforques_Does_the_patient_have_acute_hospital_needs();
		testServicesPage.selectclinicaltemplateDoes_the_patient_have_intense_and_complex_care_needs_that_make_skilled_nursing_facility_care(Ans_DoestpathavensecomcathamakeSkilnursfaccare);
		testServicesPage.clickOnNextButtonforques_Does_the_patient_have_intense_and_complex_care_needs_that_make_skilled_nursing_facility_care();
		testServicesPage.selectclinicaltemplateDoes_the_care_include_multiple_components_delivered_by_skilled_professionals(Ans_Doesthecareincludemultiplecomptsdelidbyskilledprofnals);
		testServicesPage.clickOnNextButtonforques_Does_the_care_include_multiple_components_delivered_by_skilled_professionals();
		testServicesPage.selectclinicaltemplateIs_there_a_plan_to_provide_ALL_of_the_following(Ans_IsthereaplantoprovideALLofthefollowing);
		testServicesPage.clickOnNextButtonforques_Is_there_a_plan_to_provide_ALL_of_the_following();
		testServicesPage.selectclinicaltemplateIs_skilled_treatment_needed_daily_or_more_frequent(Ans_Isskilledtreatmentneededdailyormorefrequent);
		testServicesPage.clickOnNextButtonforques_Is_skilled_treatment_needed_daily_or_more_frequent();
		testServicesPage.selectclinicaltemplateWhat_type_of_skilled_treatments_are_needed(Ans_Whattypeofskilledtreatmentsareneeded);
		testServicesPage.clickOnNextButtonforques_What_type_of_skilled_treatments_are_needed();
		testServicesPage.selectclinicaltemplateWhat_are_the_nursing_interventions_being_requested(Ans_Whatarethenursinginterventionsbeingrequested);
		testServicesPage.clickOnNextButtonforques_What_are_the_nursing_interventions_being_requested();
		testServicesPage.selectclinicaltemplateDo_you_have_clinical_documentation_to_support_this_request(Ans_Doyouhaveclinicaldocumentationtosupportthisrequest);
		testServicesPage.clickOnNextButtonforques_Do_you_have_clinical_documentation_to_support_this_request();
		testServicesPage.clickOnSaveButton();
		}else if (Planid.equals("16556")){
			String Ans_Doestpathavacuhosneeds = (String) Constant.dataMap.get("Does_the_patient_have_acute_hospital_needs");
			String Ans_DoestpathavensecomcathamakeSkilnursfaccare = (String) Constant.dataMap.get("Does_the_patient_have_acute_hospital_needs");
			String Ans_Doesthecareincludemultiplecomptsdelidbyskilledprofnals = (String) Constant.dataMap.get("Does_the_care_include_multiple_components_delivered_by_skilled_professionals");
			String Ans_IsthereaplantoprovideALLofthefollowing = (String) Constant.dataMap.get("Is_there_a_plan_to_provide_ALL_of_the_following");
			String Ans_Isskilledtreatmentneededdailyormorefrequent = (String) Constant.dataMap.get("Is_skilled_treatment_needed_daily_or_more_frequent");
			String Ans_Whattypeofskilledtreatmentsareneeded = (String) Constant.dataMap.get("What_type_of_skilled_treatments_are_needed");
			String Ans_Whatarethenursinginterventionsbeingrequested = (String) Constant.dataMap.get("What_are_the_nursing_interventions_being_requested");
			String Ans_Doyouhaveclinicaldocumentationtosupportthisrequest = (String) Constant.dataMap.get("Do_you_have_clinical_documentation_to_support_this_request");
			testServicesPage.selectclinicaltemplateDoes_the_patient_have_acute_hospital_needs(Ans_Doestpathavacuhosneeds);
			testServicesPage.clickOnNextButtonforques_Does_the_patient_have_acute_hospital_needs();
			testServicesPage.selectclinicaltemplateDoes_the_patient_have_intense_and_complex_care_needs_that_make_skilled_nursing_facility_care_for_16556(Ans_DoestpathavensecomcathamakeSkilnursfaccare);
			testServicesPage.clickOnNextButtonforques_Does_the_patient_have_intense_and_complex_care_needs_that_make_skilled_nursing_facility_care();
			testServicesPage.selectclinicaltemplateDoes_the_care_include_multiple_components_delivered_by_skilled_professionals_for_16556(Ans_Doesthecareincludemultiplecomptsdelidbyskilledprofnals);
			testServicesPage.clickOnNextButtonforques_Does_the_care_include_multiple_components_delivered_by_skilled_professionals();
			testServicesPage.selectclinicaltemplateIs_there_a_plan_to_provide_ALL_of_the_following_For_16556(Ans_IsthereaplantoprovideALLofthefollowing);
			testServicesPage.clickOnNextButtonforques_Is_there_a_plan_to_provide_ALL_of_the_following();
			testServicesPage.selectclinicaltemplateIs_skilled_treatment_needed_daily_or_more_frequent_For_16556(Ans_Isskilledtreatmentneededdailyormorefrequent);
			testServicesPage.clickOnNextButtonforques_Is_skilled_treatment_needed_daily_or_more_frequent();
			testServicesPage.selectclinicaltemplateWhat_type_of_skilled_treatments_are_needed(Ans_Whattypeofskilledtreatmentsareneeded);
			testServicesPage.clickOnNextButtonforques_What_type_of_skilled_treatments_are_needed();
			testServicesPage.selectclinicaltemplateWhat_are_the_nursing_interventions_being_requested(Ans_Whatarethenursinginterventionsbeingrequested);
			testServicesPage.clickOnNextButtonforques_What_are_the_nursing_interventions_being_requested();
			testServicesPage.selectclinicaltemplateDo_you_have_clinical_documentation_to_support_this_request(Ans_Doyouhaveclinicaldocumentationtosupportthisrequest);
			testServicesPage.clickOnNextButtonforques_Do_you_have_clinical_documentation_to_support_this_request();
			testServicesPage.clickOnSaveButton();
		}else if (Planid.equals("16549")) {
			String Ans_Doestpathavacuhosneeds = (String) Constant.dataMap.get("Does_the_patient_have_acute_hospital_needs");
			String Ans_DoestpathavensecomcathamakeSkilnursfaccare = (String) Constant.dataMap.get("Does_the_patient_have_acute_hospital_needs");
			String Ans_Doesthecareincludemultiplecomptsdelidbyskilledprofnals = (String) Constant.dataMap.get("Does_the_care_include_multiple_components_delivered_by_skilled_professionals");
			String Ans_IsthereaplantoprovideALLofthefollowing = (String) Constant.dataMap.get("Is_there_a_plan_to_provide_ALL_of_the_following");
			String Ans_Isskilledtreatmentneededdailyormorefrequent = (String) Constant.dataMap.get("Is_skilled_treatment_needed_daily_or_more_frequent");
			String Ans_Whattypeofskilledtreatmentsareneeded = (String) Constant.dataMap.get("What_type_of_skilled_treatments_are_needed");
			String Ans_Whatarethenursinginterventionsbeingrequested = (String) Constant.dataMap.get("What_are_the_nursing_interventions_being_requested");
			String Ans_Doyouhaveclinicaldocumentationtosupportthisrequest = (String) Constant.dataMap.get("Do_you_have_clinical_documentation_to_support_this_request");
			testServicesPage.selectclinicaltemplateDoes_the_patient_have_acute_hospital_needs(Ans_Doestpathavacuhosneeds);
			testServicesPage.clickOnNextButtonforques_Does_the_patient_have_acute_hospital_needs();
			testServicesPage.selectclinicaltemplateDoes_the_patient_have_intense_and_complex_care_needs_that_make_skilled_nursing_facility_care(Ans_DoestpathavensecomcathamakeSkilnursfaccare);
			testServicesPage.clickOnNextButtonforques_Does_the_patient_have_intense_and_complex_care_needs_that_make_skilled_nursing_facility_care();
			testServicesPage.selectclinicaltemplateDoes_the_care_include_multiple_components_delivered_by_skilled_professionals(Ans_Doesthecareincludemultiplecomptsdelidbyskilledprofnals);
			testServicesPage.clickOnNextButtonforques_Does_the_care_include_multiple_components_delivered_by_skilled_professionals();
			testServicesPage.selectclinicaltemplateIs_there_a_plan_to_provide_ALL_of_the_following(Ans_IsthereaplantoprovideALLofthefollowing);
			testServicesPage.clickOnNextButtonforques_Is_there_a_plan_to_provide_ALL_of_the_following();
			testServicesPage.selectclinicaltemplateIs_skilled_treatment_needed_daily_or_more_frequent(Ans_Isskilledtreatmentneededdailyormorefrequent);
			testServicesPage.clickOnNextButtonforques_Is_skilled_treatment_needed_daily_or_more_frequent();
			testServicesPage.selectclinicaltemplateWhat_type_of_skilled_treatments_are_needed(Ans_Whattypeofskilledtreatmentsareneeded);
			testServicesPage.clickOnNextButtonforques_What_type_of_skilled_treatments_are_needed();
			testServicesPage.selectclinicaltemplateWhat_are_the_nursing_interventions_being_requested(Ans_Whatarethenursinginterventionsbeingrequested);
			testServicesPage.clickOnNextButtonforques_What_are_the_nursing_interventions_being_requested();
			testServicesPage.selectclinicaltemplateDo_you_have_clinical_documentation_to_support_this_request(Ans_Doyouhaveclinicaldocumentationtosupportthisrequest);
			testServicesPage.clickOnNextButtonforques_Do_you_have_clinical_documentation_to_support_this_request();
			testServicesPage.clickOnSaveButton();
			}
		
	}

	@Then("^Verify search criteria message$")
	public void verifySearchCriteriaMessage() {
		Assert.assertEquals(true, testServicesPage.verifySearchCriteriaMessage());
	}

	@Then("^Verify required fields are displayed$")
	public void verifyRequiredFieldsAreDisplayed() {
		Assert.assertEquals(true, testServicesPage.verifyRequiredFieldsAreDisplayed());
	}

	@Then("^Search Facility using any two options$")
	public void searchFacilityusinganytwooptions() {
		String PhysicianNPI = (String) Constant.dataMap.get("PhysicianNPI");
		String PhysicianName = (String) Constant.dataMap.get("PhysicianName");
		String physicianZipCode = (String) Constant.dataMap.get("PhysicianZipCode");
		String physicianCity = (String) Constant.dataMap.get("PhysicianCity");
		String physicianState = (String) Constant.dataMap.get("PhysicianState");
		testServicesPage.searchFacilitydetailsWithTwoOptions(PhysicianNPI,PhysicianName,physicianZipCode,physicianCity,physicianState);
	}

	@Then("^Search Facility using all options$")
	public void searchFacilityusingAllOptions() {
		testServicesPage.searchFacilityusingAllOptions();
	}


	@Then("^Verify discharging facility search result$")
	public void verifydischargingfacilitysearchresult() {
		Assert.assertEquals(true, testServicesPage.verifyDischargeFacilityDetails());
		log.info("Discharge facility details verified");
	}

	@Then("^Search Facility to get no result$")
	public void searchFacilityTogetNoResult() {
		String physicianname = (String) Constant.dataMap.get("PhysicianName");
		String physiciannpi = (String) Constant.dataMap.get("PhysicianNPI");
		Assert.assertEquals(true, testServicesPage.searchFacilityTogetNoResult(physicianname, physiciannpi));
		log.info("No Results found as expected");
	}

	@Then("^Search Facility to get more records$")
	public void searchFacilityTogetmoreResults() {
		String physicianname = (String) Constant.dataMap.get("PhysicianName");
		String physiciannpi = (String) Constant.dataMap.get("PhysicianNPI");
		testServicesPage.searchFacilityTogetmoreResults(physicianname, physiciannpi);
	}

	@Then("^Verify message for more records$")
	public void verifyMessageFormoreResults() {
		Assert.assertEquals(true, testServicesPage.verifyMessageFormoreResults());
		log.info("More recodes displayed");
	}

	@Then("^Verify message for no result$")
	public void verifyMessageForNoResult() {
		Assert.assertEquals(true, testServicesPage.verifyMessageForNoResult());
		log.info("No records displayed");
	}

	@Then("^Verify State dropdown present in Discharge Page$")
	public void verifyStateDropdownPresentInDischargePage() {
		Assert.assertEquals(true, testServicesPage.verifyStateDropdownPresent());
		log.info("State Dropdown is present");
	}

	@Then("^Click State dropdown in Discharge Page$")
	public void clickStateDropdownInDischargePage() {
		testServicesPage.clickStateDropdown();
		log.info("State dropdown is clicked");
	}

	@Then("^Verify State list is present in Discharge Page$")
	public void verifyStateListIsPresentInDischargePage() {
		Assert.assertEquals(true, testServicesPage.verifyStateListPresent());
		log.info("State list is Present");
	}

	@Then("^Verify State list is in sort order in Discharge Page$")
	public void verifyStateListisInSortOrderInDischargePage() {
		Assert.assertEquals(false, testServicesPage.verifyStateListOrder());
		log.info("State list is in Sort Order");
	}

	@Then("^Check State dropdown values in Discharge Page$")
	public void checkStateDropdownvaluesinDischargePage() {
		String Statelist = (String) Constant.dataMap.get("Statelist");
		try {
			Assert.assertEquals(true, testServicesPage.checkStateDropdownValues(Statelist));
			log.info("State List is equal");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Then("^Go To Services Tab$")
	public void goToServicesTab() {
		testServicesPage.goToServicesTab();
	}

	@Then("^Click Edit Discharging Facility Button$")
	public void clickEditDischargingFacilityBtn() {
		testServicesPage.clickEditDischargingFacilityBtn();
	}

	public void fillservicesdetails(String serviceType, String serviceRequestType, String serviceInitiated,String PhysiciansOrder,String Dischargefacility) throws IOException, InterruptedException {
		log.info("Services Tab not completed so entering details in Services Tab");
		//clickServicesDropDown();
		testServicesPage.clickServicesDropDown();
		Thread.sleep(2000);
		System.out.println("serviceType");
		testServicesPage.selectSpecificServices(serviceType);
		//selectfromdropdown(serviceType);
	//	clicksearchbutton();
	//	selectservicesfromlist();
		testServicesPage.selectRequestType(serviceRequestType);
		//selectRequestType(serviceRequestType);
//		testServicesPage.enterRequestStartDate(Requeststartdate);
		testServicesPage.isServiceInitiated(serviceInitiated);
		testServicesPage.isPhysicianOrderSelected(PhysiciansOrder);
//		testServicesPage.isDischargingFacilitySelected(dischargingFacility,servicesCity, servicesState);
		clickNextButtonInServicesTab();
	}

	@Then("^Choose Referral Type as Discharging Facility$")
	public boolean chooseReferralType() throws IOException, InterruptedException {
		boolean serviceTabAvailability = false;
		if (testMemberInfoPage.isMemberInfoTabAvailable()) {
			log.info("Inside member info loop");
			memberInfoStepDef.fillMemberDetailsDisFac();
		}
		if (testDiagnosisPage.isDiagnosisTabEnabled()) {
			//diagnosisStepDef.filldiagnosisdetails(); //Due to Externalisation impact.
		}
		if (testServicesPage.isServicesTabEnabled()) {
			log.info("Services Tab available for testing");
			serviceTabAvailability = true;
		}
		return serviceTabAvailability;
	}

	@Then("^Select Request Type \"([^\"]*)\"$")
	public void selectRequestTyp(String reqTyp) {
		testServicesPage.selectRequestType(reqTyp);
	}

}
