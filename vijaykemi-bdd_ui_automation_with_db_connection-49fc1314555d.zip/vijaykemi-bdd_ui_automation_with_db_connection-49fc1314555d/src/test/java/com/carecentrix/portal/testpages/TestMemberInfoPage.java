package com.carecentrix.portal.testpages;

import java.util.List;

import com.carecentrix.portal.pages.MemberInfoPage;
import com.carecentrix.utilities.BasePage;
import com.carecentrix.utilities.Constant;
import com.carecentrix.utilities.PropLoader;

/**
 * @author KJ
 *
 */

public class TestMemberInfoPage extends BasePage {

	MemberInfoPage objMemberInfoPage;

	String lastName;
	String firstName;
	String dob;
	String healthPlan;
	String subscriberId;
	String referralType;
	String blankLastName;
	String blankFirstName;
	String blankDob;
	String blankHealthPlan;
	String blankSubscriberID;
	String earlierRequestedStartDate;
	String inCorrectRequestStartDate;
	String dobValidation;
	String lName;
	String fName;
	String wrongLName;
	String wrongFName;
	String wrongDOB;
	String wrongSubID;
	String wrongEarlierDate;
	String invalidDate;
	String blankValue;
	String referralSourceList;
	String referralTypeDisFac;

	public void readPropertyFile() {
		try {

			lastName = PropLoader.props.apply("lastName");
			firstName = PropLoader.props.apply("firstName");
			dob = PropLoader.props.apply("dob");
			healthPlan = PropLoader.props.apply("healthPlan");
			subscriberId = PropLoader.props.apply("subscriberId");
			referralType = PropLoader.props.apply("referralType");
			blankLastName = PropLoader.props.apply("blankLastName");
			blankFirstName = PropLoader.props.apply("blankFirstName");
			blankDob = PropLoader.props.apply("blankDob");
			blankHealthPlan = PropLoader.props.apply("blankHealthPlan");
			earlierRequestedStartDate = PropLoader.props.apply("earlierRequestedStartDate");
			inCorrectRequestStartDate = PropLoader.props.apply("inCorrectRequestStartDate");
			dobValidation = PropLoader.props.apply("DOBValidation");
			lName = PropLoader.props.apply("lName");
			fName = PropLoader.props.apply("fName");
			wrongLName = PropLoader.props.apply("wrongLName");
			wrongFName = PropLoader.props.apply("wrongFName");
			wrongDOB = PropLoader.props.apply("wrongDOB");
			wrongSubID = PropLoader.props.apply("wrongSubID");
			wrongEarlierDate = PropLoader.props.apply("wrongEarlierDate");
			invalidDate = PropLoader.props.apply("inValidDate");
			blankValue = PropLoader.props.apply("BlankValue");
			referralSourceList = PropLoader.listProps.apply("ReferralSourceList");
			referralTypeDisFac = PropLoader.props.apply("referralTypeDisFac");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean clickCreateRequest() {
		objMemberInfoPage = new MemberInfoPage(driver);
		return objMemberInfoPage.clickCreateRequestButton();

	}

	/*public void enterMemberDetails() {
		readPropertyFile();
		objMemberInfoPage = new MemberInfoPage(driver);
		objMemberInfoPage.enterMemberInfoDetails(lastName, firstName, dob, healthPlan, subscriberId, referralType,
				earlierRequestedStartDate);
	}*/
	public void enterMemberDetails(String lastName, String firstName, String dob, String healthPlan, String subscriberId, String referralType,
			String earlierRequestedStartDate) {
		//readPropertyFile();
		objMemberInfoPage = new MemberInfoPage(driver);
		objMemberInfoPage.enterMemberInfoDetails(lastName, firstName, dob, healthPlan, subscriberId, referralType,
				earlierRequestedStartDate);
	}

	public void clickVerifyMemberBtn() {
		objMemberInfoPage = new MemberInfoPage(driver);
		objMemberInfoPage.clickVerifyMemberBtn();
	}
	
	public void clickConfirmBtn() {
		objMemberInfoPage = new MemberInfoPage(driver);
		objMemberInfoPage.clickConfirmBtn();
	}

	public void clickConfirmInfoButton() {
		objMemberInfoPage = new MemberInfoPage(driver);
		objMemberInfoPage.clickConfirmInfo();
	}

	public void verifyAutoPopulatedFields() {
		objMemberInfoPage = new MemberInfoPage(driver);
		objMemberInfoPage.clickAutoPopulatedFieldVerification();
	}

	public void clickSignoutButton() {
		objMemberInfoPage = new MemberInfoPage(driver);
		objMemberInfoPage.signoutFromApplication();
	}

	public void quitBrowser() {
		objMemberInfoPage = new MemberInfoPage(driver);
		objMemberInfoPage.closeBrowser();
	}

	public void enterIncorrectMemberDetails() {
		readPropertyFile();
		objMemberInfoPage = new MemberInfoPage(driver);
		objMemberInfoPage.incorrectMemberDetails(wrongLName, firstName, dob, healthPlan, subscriberId, referralType,
				earlierRequestedStartDate);
	}

	public boolean verfiyAlertMessage() {
		objMemberInfoPage = new MemberInfoPage(driver);
		return objMemberInfoPage.verifyMessage();
	}

	public void clickReviewInfoButton() {
		objMemberInfoPage = new MemberInfoPage(driver);
		objMemberInfoPage.clickReviewButton();
	}

	public void clickContinueButton() {
		objMemberInfoPage = new MemberInfoPage(driver);
		enterIncorrectMemberDetails();
		clickVerifyMemberBtn();
		objMemberInfoPage.clickOnContinueButton();
	}

	public void clickCloseButton() {
		objMemberInfoPage = new MemberInfoPage(driver);
		clickCreateRequest();
		enterIncorrectMemberDetails();
		clickVerifyMemberBtn();
		objMemberInfoPage.clickCloseButton();
	}

	public void checkMandatoryfieldsAvailability() {
		objMemberInfoPage = new MemberInfoPage(driver);
		objMemberInfoPage.checkAvailabilityofFields();
	}

	public void enterBlankInUserDetails() {
		readPropertyFile();
		objMemberInfoPage = new MemberInfoPage(driver);
		objMemberInfoPage.incorrectMemberDetails(blankLastName, firstName, dob, healthPlan, subscriberId, referralType,
				earlierRequestedStartDate);
	}

	public boolean checkErrorMessage() {
		objMemberInfoPage = new MemberInfoPage(driver);
		return objMemberInfoPage.mandatoryFieldMissingErrorMsg();
	}

	public void enterCorrectDataAndContinue(String lastName,String firstName,String dob,String healthPlan,String subscriberId,String referralType,String earlierRequestedStartDate) {
		objMemberInfoPage = new MemberInfoPage(driver);
		objMemberInfoPage.pageRefresh();
		enterMemberDetails(lastName, firstName, dob, healthPlan, subscriberId, referralType,
				earlierRequestedStartDate);
		clickVerifyMemberBtn();
	}

	public void enterBlankValuesOnAllFields() {
		objMemberInfoPage = new MemberInfoPage(driver);
		objMemberInfoPage.blankValuetoUserDetails();
	}

	public boolean checkVerifyButtonDisabled() {
		objMemberInfoPage = new MemberInfoPage(driver);
		return objMemberInfoPage.checkVerifyButton();
	}

	public void checkReferralTypeDropdownValues(String strRefferalList) {
		objMemberInfoPage = new MemberInfoPage(driver);
		//readPropertyFile();
		objMemberInfoPage.checkReferralTypeDropdownValues(strRefferalList);
	}

	public boolean isReferralSourceDDAvailable() {
		objMemberInfoPage = new MemberInfoPage(driver);
		return objMemberInfoPage.isReferralSourceDDAvailable();
	}

	public boolean isReferralSourceInAscendingOrder() {
		objMemberInfoPage = new MemberInfoPage(driver);
		return objMemberInfoPage.isReferralSourceInAscendingOrder();
	}

	public void enterMemberDetailstoCheckErrorMessage(String strblanklastName,String firstName,String dob,String healthPlan,String subscriberId,String referralType) {
		//readPropertyFile();
		objMemberInfoPage = new MemberInfoPage(driver);
		objMemberInfoPage.enterMemberDetailstoCheckErrorMessage(strblanklastName, firstName, dob, healthPlan, subscriberId, referralType);
	}

	public boolean isMemberInfoTabAvailable() {
		objMemberInfoPage = new MemberInfoPage(driver);
		return objMemberInfoPage.isMemberInfoTabAvailable();
	}

	public void enterDetailsToCheckDOB() {
		readPropertyFile();
		objMemberInfoPage = new MemberInfoPage(driver);
		objMemberInfoPage.enterDetailsToCheckDOB(lastName, firstName, dobValidation);
	}

	public void enterDetailsToChecReqStartDate() {
		readPropertyFile();
		objMemberInfoPage = new MemberInfoPage(driver);
		objMemberInfoPage.enterDetailsToChecReqStartDate(lastName, firstName, dob, healthPlan, subscriberId,
				referralType, dobValidation);
	}

	public boolean checkDateValidationErrMsg() {
		objMemberInfoPage = new MemberInfoPage(driver);
		return objMemberInfoPage.checkDateValidationErrMsg();
	}

	public void enterUserNameInLowerCase() {
		readPropertyFile();
		objMemberInfoPage = new MemberInfoPage(driver);
		objMemberInfoPage.enterUserNameInLowerCase(lastName, firstName, dob, healthPlan, subscriberId, referralType,
				earlierRequestedStartDate);
	}

	public boolean validateUserNameDisplayed() {
		readPropertyFile();
		objMemberInfoPage = new MemberInfoPage(driver);
		return objMemberInfoPage.validateUserNameDisplayed(lName, fName);
	}

	public boolean verifyReviewInfoErrMsgContent() {
		objMemberInfoPage = new MemberInfoPage(driver);
		return objMemberInfoPage.verifyReviewInfoErrMsgContent();
	}

	public boolean verifyMemberEligibleMsg() {
		objMemberInfoPage = new MemberInfoPage(driver);
		return objMemberInfoPage.verifyMemberEligibleMsg();
	}

	public void enterUserDetailsToValidateErrMsg(String lastName,String firstName,String dob,String healthPlan,String subscriberId,String referralType,String earlierRequestedStartDate,String fieldName, String strinvalid) {
		objMemberInfoPage = new MemberInfoPage(driver);
		passIncorrectDetails(lastName, firstName, dob, healthPlan, subscriberId, referralType,
				earlierRequestedStartDate,fieldName, strinvalid);		
	}

	public void passIncorrectDetails(String lastName,String firstName,String dob,String healthPlan,String subscriberId,String referralType,String earlierRequestedStartDate,String fieldName,String strinvalid) {
		//readPropertyFile();
		switch (fieldName) {
		case Constant.MEMBER_INFO_LNAME: {
			objMemberInfoPage.enterMemberInfoDetails(strinvalid, firstName, dob, healthPlan, subscriberId, referralType,
					earlierRequestedStartDate);
			break;
		}
		case Constant.MEMBER_INFO_FNAME: {
			objMemberInfoPage.enterMemberInfoDetails(lastName, strinvalid, dob, healthPlan, subscriberId, referralType,
					earlierRequestedStartDate);
			break;
		}
		case Constant.MEMBER_INFO_DOB: {
			objMemberInfoPage.enterMemberInfoDetails(lastName, firstName, strinvalid, healthPlan, subscriberId,
					referralType, earlierRequestedStartDate);
			break;
		}
		case Constant.MEMBER_INFO_SUBID: {
			objMemberInfoPage.enterMemberInfoDetails(lastName, firstName, dob, healthPlan, strinvalid, referralType,
					earlierRequestedStartDate);
			break;
		}
		case Constant.MEMBER_INFO_EARLIERDATE: {
			objMemberInfoPage.enterMemberInfoDetails(lastName, firstName, dob, healthPlan, subscriberId, referralType,
					strinvalid);
			break;
		}
		default:
			break;
		}
	}

	public void editOnlyWrongDetail(String fieldName, String strValue) {
		objMemberInfoPage = new MemberInfoPage(driver);
		passCorrectDetails(fieldName,strValue);
	}

	public void passCorrectDetails(String fieldName, String strValue) {
		//readPropertyFile();
		switch (fieldName) {
		case Constant.MEMBER_INFO_LNAME: {
			objMemberInfoPage.editLastName(strValue);
			break;
		}
		case Constant.MEMBER_INFO_FNAME: {
			objMemberInfoPage.editFirstName(strValue);
			break;
		}
		case Constant.MEMBER_INFO_DOB: {
			System.out.println("newdob "+strValue);
			objMemberInfoPage.editDOB(strValue);
			break;
		}
		case Constant.MEMBER_INFO_SUBID: {
			objMemberInfoPage.editSubscriberID(strValue);
			break;
		}
		case Constant.MEMBER_INFO_EARLIERDATE: {
			objMemberInfoPage.editEarlierStartDate(strValue);
			break;
		}
		default:
			break;
		}
	}

	public void enterInvalidDateFormat(String fieldName, String strValue) {
		//readPropertyFile();
		objMemberInfoPage = new MemberInfoPage(driver);
		objMemberInfoPage.enterInvalidDateFormat(fieldName, strValue);
	}

	public void enterDetailsInMemberInfoMandatoryFields(String fieldName, String lastName,String firstName,String dob,String healthPlan,String subscriberId,String referralType,String earlierRequestedStartDate) {
		//readPropertyFile();
		objMemberInfoPage = new MemberInfoPage(driver);
		String strblankValue ="";
		objMemberInfoPage.enterDetailsInMemberInfoMandatoryFields(fieldName, strblankValue, lastName, firstName, dob,
				healthPlan, subscriberId, referralType, earlierRequestedStartDate);
	}

	public void enterMemberDetailsReferralType() {
		readPropertyFile();
		objMemberInfoPage = new MemberInfoPage(driver);
		objMemberInfoPage.enterMemberInfoDetails(lastName, firstName, dob, healthPlan, subscriberId, referralTypeDisFac,
				earlierRequestedStartDate);
		clickVerifyMemberBtn();
	}

	public boolean verifyAllLabelsInMemberInfoTab(String memLblDetails) {
		objMemberInfoPage = new MemberInfoPage(driver);
		return objMemberInfoPage.verifyAllLabelsInMemberInfoTab(memLblDetails);
	}

	public boolean verifyHPNamePrePopulated() {
		objMemberInfoPage = new MemberInfoPage(driver);
		return objMemberInfoPage.verifyHPNamePrePopulated();
	}

}
