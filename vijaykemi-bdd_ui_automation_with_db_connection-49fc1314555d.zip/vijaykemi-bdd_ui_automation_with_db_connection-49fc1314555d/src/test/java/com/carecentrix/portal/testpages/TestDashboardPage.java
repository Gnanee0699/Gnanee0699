package com.carecentrix.portal.testpages;

import com.carecentrix.portal.pages.DashboardPage;
import com.carecentrix.utilities.BasePage;
import com.carecentrix.utilities.PropLoader;
import com.carecentrix.utilities.SeleniumMethods;

/**
 * @author KKJANAK
 *
 */

public class TestDashboardPage extends BasePage {

	DashboardPage dashboardPage;
	String dashboardURL;
	String settingsURL;
	String secutiryQandA;
	String securityAccVerifyURL;
	String securityQues;
	String addInfoPwd;

	public void readDashboardPropertyFile() {
		try {
			dashboardURL = PropLoader.props.apply("QA_ENHANCEPORTAL_DASHBOARD_URL");
			settingsURL = PropLoader.props.apply("Settings_URL");
			secutiryQandA = PropLoader.props.apply("Secutiry_QandA");
			securityAccVerifyURL = PropLoader.props.apply("Security_AccountVerifyURL");
			securityQues = PropLoader.listProps.apply("Security_QuesList");
			addInfoPwd = PropLoader.listProps.apply("ReferralInfoUserPassword");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean verifyUserInDashboardPage() {
		readDashboardPropertyFile();
		dashboardPage = new DashboardPage(driver);
		return dashboardPage.verifyUserInDashboardPage(dashboardURL);
	}

	public boolean verifyRequiredOptionsAreInDashboardPage() {
		dashboardPage = new DashboardPage(driver);
		return dashboardPage.verifyRequiredOptionsAreInDashboardPage();
	}

	public boolean clickOnSettings() {
		readDashboardPropertyFile();
		dashboardPage = new DashboardPage(driver);
		return dashboardPage.clickOnSettings(settingsURL);
	}
	
	public boolean clickOnSecurity() {
		dashboardPage = new DashboardPage(driver);
		return dashboardPage.clickOnSecurity();
	}

	public boolean clickSecurityQuestionsLink() {
		dashboardPage = new DashboardPage(driver);
		return dashboardPage.clickSecurityQuestionsLink(securityAccVerifyURL);
	}

	public boolean verifyAccount(String strPassword) {
		dashboardPage = new DashboardPage(driver);
		return dashboardPage.providePWD(strPassword);
	}

	public boolean verifySaveButtonDisabled() {
		dashboardPage = new DashboardPage(driver);
		return dashboardPage.verifySaveButtonDisabled();
	}

	public boolean verifySecurityQuesDrpdwn(String strsecurityQues) {
		//readDashboardPropertyFile();
		dashboardPage = new DashboardPage(driver);
		return dashboardPage.verifySecurityQuesDrpdwn(strsecurityQues);
	}

	public void selectSecurityQandA(String strSecurityQandA) {
		//readDashboardPropertyFile();
		dashboardPage = new DashboardPage(driver);
		dashboardPage.selectSecurityQandA(strSecurityQandA);

	}

	public boolean verifySaveButtonAndSave() {
		dashboardPage = new DashboardPage(driver);
		return dashboardPage.verifySaveButtonAndSave();
	}

	public boolean clickMyPasswordLink() {
		dashboardPage = new DashboardPage(driver);
		return dashboardPage.clickMyPasswordLink();
	}

	public void providePWDWithoutReq(String pwd) {
		dashboardPage = new DashboardPage(driver);
		dashboardPage.providePWDWithoutReq(pwd);
	}

	public boolean validatePasswordReq(String req) {
		dashboardPage = new DashboardPage(driver);
		return dashboardPage.validatePasswordReq(req);
	}

	public boolean clearPasswordField() {
		dashboardPage = new DashboardPage(driver);
		return dashboardPage.clearPasswordField();
	}

	public void providePWDWithoutUppercase(String pwd) {
		dashboardPage = new DashboardPage(driver);
		dashboardPage.providePWDWithoutUppercase(pwd);
	}

	public void providePWDWithoutLowercase(String pwd) {
		dashboardPage = new DashboardPage(driver);
		dashboardPage.providePWDWithoutLowercase(pwd);
	}

	public void providePWDWithoutNumbers(String pwd) {
		dashboardPage = new DashboardPage(driver);
		dashboardPage.providePWDWithoutNumbers(pwd);
	}

	public void providePWDWithoutSpecialChar(String pwd) {
		dashboardPage = new DashboardPage(driver);
		dashboardPage.providePWDWithoutSpecialChar(pwd);
	}

	public void providePasswords(String newPwd, String cnfPwd) {
		dashboardPage = new DashboardPage(driver);
		dashboardPage.providePasswords(newPwd, cnfPwd);
	}

	public void clickSavePasswordBtn() {
		dashboardPage = new DashboardPage(driver);
		dashboardPage.clickSavePwdBtn();
	}

	public boolean verifyAlertMsgForReqMatch() {
		dashboardPage = new DashboardPage(driver);
		return dashboardPage.validateReqAlertMsg();
	}

	public boolean validatePwdMatchAlertMsg() {
		dashboardPage = new DashboardPage(driver);
		return dashboardPage.validatePwdMatchAlertMsg();
	}

	public void provideCurrentPwd(String strpwd) {
		dashboardPage = new DashboardPage(driver);
		dashboardPage.provideCurrentPwd(strpwd);
	}

	public void provideNewPasswords(String pwd) {
		readDashboardPropertyFile();
		dashboardPage = new DashboardPage(driver);
		dashboardPage.providePasswords(pwd, addInfoPwd);
	}

	public void provideUsedPwd(String strPwd) {
		dashboardPage = new DashboardPage(driver);
		dashboardPage.providePasswords(strPwd, strPwd);
	}

	public boolean validatePreviousPwdMatchAlertMsg() {
		readDashboardPropertyFile();
		dashboardPage = new DashboardPage(driver);
		return dashboardPage.validatePreviousPwdMatchAlertMsg();
	}

	public void clickOutsideToChkErrMsg() {
		dashboardPage = new DashboardPage(driver);
		dashboardPage.clickOutsideToChkErrMsg();
	}

}
