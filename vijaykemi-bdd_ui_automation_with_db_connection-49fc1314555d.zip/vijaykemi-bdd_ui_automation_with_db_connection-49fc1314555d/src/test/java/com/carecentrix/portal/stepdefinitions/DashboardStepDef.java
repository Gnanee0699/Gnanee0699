package com.carecentrix.portal.stepdefinitions;

import java.io.IOException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;

import com.carecentrix.portal.testpages.TestDashboardPage;
import com.carecentrix.utilities.Constant;
import com.carecentrix.utilities.SeleniumMethods;

import cucumber.api.DataTable;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 * @author KKJANAK
 *
 */

public class DashboardStepDef {

	TestDashboardPage testDashboardPage = new TestDashboardPage();
	
	Constant constant = new Constant();

	private static final Logger log = LogManager.getLogger(DashboardStepDef.class);

	@When("^Verify user is landed in Dashboard page$")
	public void verifyUserInDashboardPage() throws IOException, InterruptedException {
		Assert.assertEquals(true, testDashboardPage.verifyUserInDashboardPage());
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Dashboard page");
		log.info("User is in Dashboard page");
	}

	@When("^Verify required options are in Dashboard page$")
	public void verifyRequiredOptionsAreInDashboardPage() {
		Assert.assertEquals(true, testDashboardPage.verifyRequiredOptionsAreInDashboardPage());
		log.info("Required options are in Dashboard page");
	}

	@Then("^Click on Settings$")
	public void clickOnSettings() throws IOException, InterruptedException {
		Assert.assertEquals(true, testDashboardPage.clickOnSettings());
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Settings page");
		log.info("User navigated to Settings Page");
	}
	
	@Then("^Click on Security$")
	public void clickOnSecurity() throws IOException, InterruptedException {
		Assert.assertEquals(true, testDashboardPage.clickOnSecurity());
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Security page");
		log.info("User navigated to Security Page");
	}

	@Then("^Click Security questions link$")
	public void clickSecurityQuestionsLink() throws IOException, InterruptedException {
		Assert.assertEquals(true, testDashboardPage.clickSecurityQuestionsLink());
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Security page");
		log.info("User navigated to Security Questions");
	}

	@Then("^Verify Account$")
	public void verifyAccount() throws IOException, InterruptedException {
		String strPassword = (String) constant.dataMap.get("Password");
		Assert.assertEquals(true, testDashboardPage.verifyAccount(strPassword));
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Account Verification");
		log.info("Account Verified successfully");
	}

	@Then("^Verify Save button disabled$")
	public void verifySaveButtonDisabled() {
		Assert.assertEquals(true, testDashboardPage.verifySaveButtonDisabled());
		log.info("Save button is disabled");
	}

	@Then("^Verify Security Questions dropdown$")
	public void verifySecurityQuesDrpdwn() {
		String strSecurityQuestions = (String) constant.dataMap.get("Security_QuesList");
		Assert.assertEquals(true, testDashboardPage.verifySecurityQuesDrpdwn(strSecurityQuestions));
		log.info("Dropdown values are same");
	}

	@Then("^Select questions and provide answers$")
	public void selectSecurityQandA() throws IOException, InterruptedException {
		String strSecurityQandA = (String) constant.dataMap.get("Secutiry_QandA");
		testDashboardPage.selectSecurityQandA(strSecurityQandA);
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Select Security Questions");
		log.info("Select Security Questions");
	}

	@Then("^Verify Save button and proceed to Save$")
	public void verifySaveButtonAndSave() {
		Assert.assertEquals(true, testDashboardPage.verifySaveButtonAndSave());
		log.info("Security Questions are saved successfully");
	}

	@Then("^Click My Password link$")
	public void clickMyPasswordLink() {
		Assert.assertEquals(true, testDashboardPage.clickMyPasswordLink());
		log.info("Password link clicked successfully");
	}

//	@Then("^Provide password without req min char \"([^\"]*)\"$")
//	public void providePWDWithoutReqMinChar(String pwd) {
//		testDashboardPage.providePWDWithoutReqMinChar(pwd);
//	}
	
	@Then("^Provide password without \"([^\"]*)\"$")
	public void providePWDWithoutReq(String pwd) {
		String strpwd = (String) constant.dataMap.get("Newpassword");
		testDashboardPage.providePWDWithoutReq(strpwd);
	}

	@Then("^Validate password requirements \"([^\"]*)\"$")
	public void validatePasswordReq(String req) throws IOException, InterruptedException {
		String strReq = (String) constant.dataMap.get("PasswordReq");
		Assert.assertEquals(true, testDashboardPage.validatePasswordReq(strReq));
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Validate password requirements" + req);
		log.info("Validate password requirements" + req);
	}

	@Then("^Clear password field$")
	public void clearPasswordField() {
		Assert.assertEquals(true, testDashboardPage.clearPasswordField());
	}

	@Then("^Provide password without Uppercase \"([^\"]*)\"$")
	public void providePWDWithoutUppercase(String pwd) {
		testDashboardPage.providePWDWithoutUppercase(pwd);
	}

	@Then("^Provide password without Lowercase \"([^\"]*)\"$")
	public void providePWDWithoutLowercase(String pwd) {
		testDashboardPage.providePWDWithoutLowercase(pwd);
	}

	@Then("^Provide Password without Numbers \"([^\"]*)\"$")
	public void providePWDWithoutNumbers(String pwd) {
		testDashboardPage.providePWDWithoutNumbers(pwd);
	}

	@Then("^Provide Password without Special Characters \"([^\"]*)\"$")
	public void providePWDWithoutSpecialChar(String pwd) {
		testDashboardPage.providePWDWithoutSpecialChar(pwd);
	}

	@Then("^Provide Current Password$")
	public void provideCurrentPwd() {
		String strpwd = (String) constant.dataMap.get("Password");
		testDashboardPage.provideCurrentPwd(strpwd);
	}

	@Then("^Provide new passwords")
	public void provideNewPasswords() {
		String strNewpwd = (String) constant.dataMap.get("Newpassword");
		String strpwd = (String) constant.dataMap.get("Password");
		testDashboardPage.providePasswords(strNewpwd, strpwd);
	}

	@Then("^Provide passwords")
	public void providePasswords() {
		String strNewpwd = (String) constant.dataMap.get("Newpassword");
		String strConfPwd = (String) constant.dataMap.get("ConfirmPassword");
		testDashboardPage.providePasswords(strNewpwd, strConfPwd);
	}

	@Then("^Click outside to check the error message$")
	public void clickOutsideToChkErrMsg() {
		testDashboardPage.clickOutsideToChkErrMsg();
	}

	@Then("^Click Save Password Button$")
	public void clickSavePasswordBtn() {
		testDashboardPage.clickSavePasswordBtn();
	}

	@Then("^Verify alert message for req match$")
	public void verifyAlertMsgForReqMatch() throws IOException, InterruptedException {
		Assert.assertEquals(true, testDashboardPage.verifyAlertMsgForReqMatch());
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Alert message Req match");
		log.info(Constant.LOG_ALERT);
	}

	@Then("^Validate Password Match Alert Message$")
	public void validatePwdMatchAlertMsg() throws IOException, InterruptedException {
		Assert.assertEquals(true, testDashboardPage.validatePwdMatchAlertMsg());
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Alert message pwd match");
		log.info(Constant.LOG_ALERT);
	}

	@Then("^Provide used passwords$")
	public void provideUsedPwd() {
		String strpwd = (String) constant.dataMap.get("Password");
		testDashboardPage.provideUsedPwd(strpwd);
	}

	@Then("^Validate previous Password Match Alert Message$")
	public void validatePreviousPwdMatchAlertMsg() throws IOException, InterruptedException {
		Assert.assertEquals(true, testDashboardPage.validatePreviousPwdMatchAlertMsg());
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Alert message previous pwd match");
		log.info(Constant.LOG_ALERT);
	}

}
