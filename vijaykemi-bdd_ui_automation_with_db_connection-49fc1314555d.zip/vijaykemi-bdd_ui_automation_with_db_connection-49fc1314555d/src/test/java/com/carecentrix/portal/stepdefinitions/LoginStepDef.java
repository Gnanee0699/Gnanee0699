package com.carecentrix.portal.stepdefinitions;

import java.io.IOException;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;

import com.carecentrix.portal.testUtils.ExcelReader;
import com.carecentrix.portal.testpages.TestLoginPage;
import com.carecentrix.utilities.BasePage;
import com.carecentrix.utilities.Constant;
import com.carecentrix.utilities.DatabaseTool;
import com.carecentrix.utilities.SeleniumMethods;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 * @author KJ
 *
 */

public class LoginStepDef {

	private static final Logger log = LogManager.getLogger(LoginStepDef.class);

	TestLoginPage testLoginPage = new TestLoginPage();
	
	Constant constant = new Constant();
	//Map<String, Object> dataMap;

/*	@Given("^Launch EP application$")
	public void launchapplication(DataTable browserDetails) {

		try {
			List<List<String>> data = browserDetails.raw();
			String application = data.get(0).get(0);
			String environment = data.get(0).get(1);
			String testcase = data.get(0).get(2);

			testLoginPage.launchBrowser(application, environment, testcase);
			log.info("Application launched successfully");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
*/
	
	
	
	@Given("^Launch EP application \"([^\"]*)\" and \"([^\"]*)\"$")
	public void launchapplication(String scenario, String sheetname) {

		try {
			
			constant.dataMap = ExcelReader.readAllRow(sheetname, scenario);	
		//dataMap = ExcelReader.readAllRow("EPE2EData", scenario);
			
			System.out.println("map is --- "+constant.dataMap);
			
		//	List<List<String>> data = browserDetails.raw();
			String application = (String) constant.dataMap.get("application");
			String environment = (String) constant.dataMap.get("environment");
			//String testcase = (String) dataMap.get("testcase");
			String testcase = (String) constant.dataMap.get("TestScenario");
			String ContactName = (String) constant.dataMap.get("ContactName");
			String browser = "chrome";
			
			SeleniumMethods.startTest(environment, testcase, browser, testcase);
			testLoginPage.launchBrowser(application, environment, testcase);
			
			//System.out.println(dataMap.get("Username"));
			
			log.info("Application launched successfully");
			
			//SeleniumMethods.captureScreenShot("screenshot of "+ "Launch page");
			SeleniumMethods.captureScreenShot(Constant.SCRSHT_MSG+ "Launch page");
			log.info(Constant.SCRLOGSHT_MSG, "Launch page");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@When("^Click on SignIn link$")
	public void clickonSignInlink() {
		log.info("Sign In Page click action");
		testLoginPage.logIntoPortal();
	}

	@When("^Enter user email and password details \"([^\"]*)\"$")
	public void enterEmailIDandPassword(String Scenario) throws IOException, InterruptedException {
	//	List<List<String>> data = page.raw();
	//	String pageName = data.get(0).get(0);
		String Username = (String) constant.dataMap.get("Username");
		String Password = (String) constant.dataMap.get("Password");
		
		log.info("Username is {} ", Username);
		log.info("Password is {} ", Password);
		testLoginPage.setEmailIDAndPassword(Username,Password);
	//	SeleniumMethods.captureScreenShot("screenshot of "+"Login page");
	//	log.info("Captured screenshot of ", "Login page");
		SeleniumMethods.captureScreenShot(Constant.SCRSHT_MSG+ "Login page");
		log.info(Constant.SCRLOGSHT_MSG, "Login page");
	}

	@When("^Click on SignIn button$")
	public void clickonSignInbutton() {
		testLoginPage.clickSignInButton();
	}

	@Then("^User logged into the application$")
	public static boolean userloggedintotheapplication() {
		log.info("Successfully Logged in");
		return true;
	}

	@Then("^Click on SignOut button$")
	public void clickonSignOutbutton() {
		testLoginPage.clickSignoutButton();
		log.info("Signout Button is clicked");
	}

	@Then("^Sign-in page should be shown$")
	public void signinpageshouldbeshown() throws IOException, InterruptedException {
		Assert.assertEquals(true, testLoginPage.checkNavigatedPage());
		SeleniumMethods.captureScreenShot(Constant.SCRSHT_MSG+ "Sign-in Page");
		log.info("User navigated to Sign-in Page");
	}

	@Then("^Verify user error message \"([^\"]*)\"$")
	public void verifiedTermedUserErrMsg(String userType) throws IOException, InterruptedException {
		Assert.assertEquals(true, testLoginPage.verifiedUserErrMsg(userType));
		SeleniumMethods.captureScreenShot(Constant.SCRSHT_MSG+ "Login Error Message");
		log.info(Constant.SCRLOGSHT_MSG, "Login Error Message");
	}
}
