package com.carecentrix.portal.testpages;

import com.carecentrix.portal.pages.LoginPage;
import com.carecentrix.utilities.BasePage;
import com.carecentrix.utilities.PropLoader;
import com.carecentrix.utilities.SeleniumMethods;

/**
 * @author KJ
 */

public class TestLoginPage extends BasePage {

	LoginPage objPortalLoginPage;

	String URL_signIn;

	public void readPropertyFile_LoginPage() {
		try {
			URL_signIn = PropLoader.props.apply("QA_ENHANCEPORTAL_LOGIN_URL_SIGNOUT");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void launchBrowser(String application, String environment, String testcase) {

		try {
			SeleniumMethods.openBrowserAndNavigateToBasePage(application, environment, testcase);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void logIntoPortal() {
		try {
			objPortalLoginPage = new LoginPage(driver);
			objPortalLoginPage.clickSignInLink();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void setEmailIDAndPassword(String Username,String Password) {
		try {
		//	String[] userDetails = SeleniumMethods.readPropertyFile(page);
			objPortalLoginPage = new LoginPage(driver);
		//	objPortalLoginPage.setEmailIDAndPassword(userDetails[0], userDetails[1]);
			objPortalLoginPage.setEmailIDAndPassword(Username, Password);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void clickSignInButton() {
		try {
			objPortalLoginPage = new LoginPage(driver);
			objPortalLoginPage.clickSignInBTN();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void clickSignoutButton() {
		objPortalLoginPage = new LoginPage(driver);
		objPortalLoginPage.clickSignoutBTN();
	}

	public boolean checkNavigatedPage() {
		readPropertyFile_LoginPage();
		objPortalLoginPage = new LoginPage(driver);
		return objPortalLoginPage.checkNavigatedPage(URL_signIn);
	}

	public boolean verifiedUserErrMsg(String userType) {
		objPortalLoginPage = new LoginPage(driver);
		return objPortalLoginPage.verifiedUserErrMsg(userType);
	}
}
