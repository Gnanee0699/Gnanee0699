package com.carecentrix.portal.testpages;

import com.carecentrix.portal.pages.PhysicianPage;
import com.carecentrix.utilities.BasePage;
import com.carecentrix.utilities.PropLoader;

/**
 * @author KJ
 *
 */

public class TestPhysicianPage extends BasePage {

	PhysicianPage objPhysicianPage;

	String physicianLastName;
	String physicianFirstName;
	String physicianNPI;
	String physicianPhoneNumber;
	String physicianCity;
	String physicianState;
	String physicianZipCode;
	String physicianStreetAddress;
	String physicianFax;
	String physicianCity1;
	String stateList;

	public void readPropertyFilePhysicianTab() {
		try {
			physicianLastName = PropLoader.props.apply("PhysicianTab_PhysicianLastName");
			physicianFirstName = PropLoader.props.apply("PhysicianTab_PhysicianFirstName");
			physicianNPI = PropLoader.props.apply("PhysicianTab_PhysicianNPI");
			physicianPhoneNumber = PropLoader.props.apply("PhysicianTab_PhysicianPhoneNumber");
			physicianCity = PropLoader.props.apply("PhysicianTab_PhysicianCity");
			physicianState = PropLoader.props.apply("PhysicianTab_PhysicianState");
			physicianZipCode = PropLoader.props.apply("PhysicianTab_PhysicianZipCode");
			physicianStreetAddress = PropLoader.props.apply("PhysicianTab_PhysicianStreetAddress");
			physicianFax = PropLoader.props.apply("PhysicianTab_PhysicianFax");
			stateList = PropLoader.listProps.apply("StateList");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean checkAvailabilityOfPhysicianTab() {
		objPhysicianPage = new PhysicianPage(driver);
		return objPhysicianPage.isPhysicianTabAvailable();

	}

	public void enterValidInfoSeachfields(String physicianLastName, String physicianFirstName, String physicianNPI,
			String physicianPhoneNumber, String physicianCity, String physicianState, String physicianZipCode) {
		//readPropertyFilePhysicianTab();
		objPhysicianPage = new PhysicianPage(driver);
		objPhysicianPage.enterValidInfoSeachfields(physicianLastName, physicianFirstName, physicianNPI,
				physicianPhoneNumber, physicianCity, physicianState, physicianZipCode);
	}

	public boolean clickSearchButton() {
		objPhysicianPage = new PhysicianPage(driver);
		return objPhysicianPage.clickSearchButton();
	}

	public void verifyResultWithSearchDetails(String physicianLastName, String physicianFirstName, String physicianNPI,
			String physicianPhoneNumber, String physicianCity, String physicianState, String physicianZipCode) {
		//readPropertyFilePhysicianTab();
		objPhysicianPage = new PhysicianPage(driver);
		objPhysicianPage.verifyResultWithSearchDetails(physicianLastName, physicianFirstName, physicianNPI,
				physicianPhoneNumber, physicianCity, physicianState, physicianZipCode);
	}

	public void enterInvalidInformation() {
		objPhysicianPage = new PhysicianPage(driver);
		objPhysicianPage.enterInvalidInformation();
	}

	public void checkAddedPhysicianDetails() {
		objPhysicianPage = new PhysicianPage(driver);
		verifyResultWithSearchDetails(physicianLastName, physicianFirstName, physicianNPI,
				physicianPhoneNumber, physicianCity, physicianState, physicianZipCode);
	}

	public void clickAddBottonToChoosePhysicianType() {
		objPhysicianPage = new PhysicianPage(driver);
		objPhysicianPage.clickAddBottonToChoosePhysicianType();
	}

	public void choosePhysiciantype(String physicianType) {
		objPhysicianPage = new PhysicianPage(driver);
		objPhysicianPage.choosePhysiciantype(physicianType);
	}

	public boolean isPhysicianAdded() {
		objPhysicianPage = new PhysicianPage(driver);
		return objPhysicianPage.isPhysicianAdded();

	}

	//Updated for external test data.
	public void enterInformationToSearch(String physicianZipCode, String physicianCity, String physicianState, String physicianNPI,String physicianLastname,String physicianFirstname) {
		//readPropertyFilePhysicianTab();
		objPhysicianPage = new PhysicianPage(driver);
		objPhysicianPage.enterInformationToSearch(physicianZipCode, physicianCity, physicianState, physicianNPI,physicianLastname,physicianFirstname);
	}

	public boolean selectMoreThanOnePhysician() {
		objPhysicianPage = new PhysicianPage(driver);
		return objPhysicianPage.selectMoreThanOnePhysician();
	}

	public void clickNextButton() {
		objPhysicianPage = new PhysicianPage(driver);
		objPhysicianPage.clickNextButton();
	}

	public boolean verifyErrorMessage() {
		objPhysicianPage = new PhysicianPage(driver);
		return objPhysicianPage.verifyErrorMessage();
	}

	public boolean verifyErrorMessageForOrderingPhysician() {
		objPhysicianPage = new PhysicianPage(driver);
		return objPhysicianPage.verifyErrorMessageForOrderingPhysician();
	}

	public boolean verifyErrorMessageToUpdateSearchCriteria() {
		objPhysicianPage = new PhysicianPage(driver);
		return objPhysicianPage.verifyErrorMessageToUpdateSearchCriteria();
	}

	public boolean checkDetailsOfSelectedPhysician(String physicianType) {
		objPhysicianPage = new PhysicianPage(driver);
		return objPhysicianPage.checkDetailsOfSelectedPhysician(physicianType);
	}

	public boolean unSelectChoosenPhysician() {
		objPhysicianPage = new PhysicianPage(driver);
		return objPhysicianPage.unSelectChoosenPhysician();
	}

	public boolean isSearchResultsDisplayed() {
		objPhysicianPage = new PhysicianPage(driver);
		return objPhysicianPage.isSearchResultsDisplayed();
	}

	public boolean selectOrderingAndPrimaryPhysicianInOneOption() {
		objPhysicianPage = new PhysicianPage(driver);
		return objPhysicianPage.selectOrderingAndPrimaryPhysicianInOneOption();
	}

	public boolean checkOrderingAndPrimaryPhysicianAdded() {
		objPhysicianPage = new PhysicianPage(driver);
		return objPhysicianPage.checkOrderingAndPrimaryPhysicianAdded();
	}

	public boolean checkOrderingAndPrimaryPhysicianAddedInDiffOption() {
		objPhysicianPage = new PhysicianPage(driver);
		return objPhysicianPage.checkOrderingAndPrimaryPhysicianAddedInDiffOption();
	}

	public boolean chooseDiffPhysiciantypes(String physician) {
		objPhysicianPage = new PhysicianPage(driver);
		return objPhysicianPage.chooseDiffPhysiciantypes(physician);
	}

	public boolean verifyStateDropdownPresent() {
		objPhysicianPage = new PhysicianPage(driver);
		return objPhysicianPage.verifyStateDropdownPresent();
	}

	public void clickStateDropdown() {
		objPhysicianPage = new PhysicianPage(driver);
		objPhysicianPage.clickStateDropdown();
	}

	public boolean verifyStateListPresent() {
		objPhysicianPage = new PhysicianPage(driver);
		return objPhysicianPage.verifyStateListPresent();
	}

	public boolean verifyStateListOrder() {
		objPhysicianPage = new PhysicianPage(driver);
		return objPhysicianPage.verifyStateListSortorder();
	}

	public boolean checkStateDropdownValues() {
		readPropertyFilePhysicianTab();
		objPhysicianPage = new PhysicianPage(driver);
		return objPhysicianPage.checkStateDropdownvalues(stateList);
	}

}
