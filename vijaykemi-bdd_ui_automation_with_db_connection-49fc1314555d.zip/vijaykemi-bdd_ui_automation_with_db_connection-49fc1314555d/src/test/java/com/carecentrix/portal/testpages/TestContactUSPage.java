package com.carecentrix.portal.testpages;

import com.carecentrix.portal.pages.ContactUSPage;
import com.carecentrix.utilities.BasePage;

/**
 * @author MMVADAG
 */

public class TestContactUSPage extends BasePage {
	ContactUSPage objContatUSPage;

	String strContactName;
	String strEmail;
	String strContactPhone;
	String strInquiryType;
	String strInquiryReasson;
	String strInquiryMessage;

	public void clickContactUS() {
		objContatUSPage = new ContactUSPage(driver);
		objContatUSPage.clickContatUSlnk();

	}

	public void clickSubmit() {
		objContatUSPage = new ContactUSPage(driver);
		objContatUSPage.clickSubmit();

	}

	public void enterContactName(String strContactName) {
		objContatUSPage = new ContactUSPage(driver);
		objContatUSPage.enterContactName(strContactName);
	}

	public void enterContactPhone(String strContactPhone) {
		objContatUSPage = new ContactUSPage(driver);
		objContatUSPage.enterContactPhone(strContactPhone);
	}

	public void enterContactUSDetails() {
		objContatUSPage = new ContactUSPage(driver);
		objContatUSPage.enterContactDetails(strContactName, strEmail, strContactPhone, strInquiryType,
				strInquiryReasson, strInquiryMessage);

	}

	public void enterEmail(String strEmail) {
		objContatUSPage = new ContactUSPage(driver);
		objContatUSPage.enterEmail(strEmail);
	}

	public void enterInquiryMessage(String strInquiryMessage) {
		objContatUSPage = new ContactUSPage(driver);
		objContatUSPage.enterInquiryMessage(strInquiryMessage);
	}

	public void quitBrowser() {
		objContatUSPage = new ContactUSPage(driver);
		objContatUSPage.quitBrowser();
	}

	public void selectInquiryReason(String strInquiryReason) {
		objContatUSPage = new ContactUSPage(driver);
		objContatUSPage.selectInquiryReason(strInquiryReason);
	}

	public void selectInquiryType(String strInquiryType) {
		objContatUSPage = new ContactUSPage(driver);
		objContatUSPage.selectInquiryType(strInquiryType);
	}

	public boolean verifyAlertMessage() {
		objContatUSPage = new ContactUSPage(driver);
		return objContatUSPage.verifyAlertMessage();
	}

	public boolean verifyDefaultOptionSelected(String inquiryReason) {
		objContatUSPage = new ContactUSPage(driver);
		return objContatUSPage.verifyDefaultOptionSelected(inquiryReason);
	}

	public boolean verifyInfoMsgSent() {
		objContatUSPage = new ContactUSPage(driver);
		return objContatUSPage.verifyInfoMsgSent();

	}
}
