package com.carecentrix.portal.stepdefinitions;

import java.io.IOException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;

import com.carecentrix.portal.testpages.TestDiagnosisPage;
import com.carecentrix.portal.testpages.TestLocationPage;
import com.carecentrix.portal.testpages.TestMemberInfoPage;
import com.carecentrix.portal.testpages.TestPhysicianPage;
import com.carecentrix.portal.testpages.TestServicesPage;
import com.carecentrix.utilities.Constant;
import com.carecentrix.utilities.SeleniumMethods;

import cucumber.api.DataTable;
import cucumber.api.java.en.Then;

public class LocationStepDef {

	MemberInfoStepDef memberInfoStepDef = new MemberInfoStepDef();
	DiagnosisStepDef diagnosisStepDef = new DiagnosisStepDef();
	ServicesStepDef servicesStepDef = new ServicesStepDef();
	PhysicianStepDef physicianStepDef = new PhysicianStepDef();

	TestMemberInfoPage testMemberInfoPage = new TestMemberInfoPage();
	TestDiagnosisPage testDiagnosisPage = new TestDiagnosisPage();
	TestServicesPage testServicesPage = new TestServicesPage();
	TestPhysicianPage testPhysicianPage = new TestPhysicianPage();
	TestLocationPage testRenderingPage = new TestLocationPage();
	
	//Map<String, Object> dataMap;
Constant constant = new Constant();

	private static final Logger log = LogManager.getLogger(LocationStepDef.class);

	@Then("^Check availability of Location tab$")
	public boolean checkavailabilityofLocationtab() throws IOException, InterruptedException {
		//List<List<String>> data = details.raw();

		//String dataphysicianType = data.get(0).get(3);

		String dataserviceType = (String) constant.dataMap.get("services");
		String dataserviceRequestType = (String) constant.dataMap.get("RequestType");
		String dataserviceOption = (String) constant.dataMap.get("Option1");
		String PhysiciansOrder = (String) constant.dataMap.get("Option2");
		String Dischargefacility = (String) constant.dataMap.get("Option3");
		String lastName = (String) constant.dataMap.get("LastName");
		String firstName = (String) constant.dataMap.get("FirstName");
		String dob = (String) constant.dataMap.get("Dob");
		String healthPlan = (String) constant.dataMap.get("HealthPlan");
		String subscriberId = (String) constant.dataMap.get("SubscriberId");
		String referralType = (String) constant.dataMap.get("ReferralType");
		String earlierRequestedStartDate = (String) constant.dataMap.get("EarlierRequestedStartDate");
		String ICDCode = (String) constant.dataMap.get("ICDCode");
		
		
		boolean locationTabAvailability = false;
		if (testMemberInfoPage.isMemberInfoTabAvailable()) {
			memberInfoStepDef.fillmemberInfodetails(lastName,firstName,dob,healthPlan,subscriberId,referralType,earlierRequestedStartDate);
			//memberInfoStepDef.enteralltherequireddatacorrectlyandcontinue( lastName, firstName, dob, healthPlan, subscriberId, referralType, earlierRequestedStartDate);
		}
		if (testDiagnosisPage.isDiagnosisTabEnabled()) {
			diagnosisStepDef.filldiagnosisdetails(ICDCode);
		}
		if (testServicesPage.isServicesTabEnabled()) {
			servicesStepDef.fillservicesdetails(dataserviceType, dataserviceRequestType, dataserviceOption,PhysiciansOrder,Dischargefacility);
		}
		if (testPhysicianPage.checkAvailabilityOfPhysicianTab()) {
			physicianStepDef.fillphysiciandetails();
		}
		if (testRenderingPage.checkAvailabilityOfLocationTab()) {
			log.info("Location Tab available for testing");
			locationTabAvailability = true;
		}
		return locationTabAvailability;

	}

	@Then("^Add Button should be enabled$")
	public void addButtonshouldbeenabled() {
		Assert.assertEquals(true, testRenderingPage.isAddLocationButtonEnabled());
		log.info("Add Location Button is Displayed");
	}

	@Then("^Check if search result Displayed$")
	public void checkifsearchresultdisplayed() throws IOException, InterruptedException {
		Assert.assertEquals(true, testRenderingPage.isSearchResultDisplayed());
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Location page");
		log.info("Location details displayed");
	}

	@Then("^Select location from search result$")
	public void selectlocationfromsearchresult() throws IOException, InterruptedException {
		testRenderingPage.selectLocationFromResult();
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Rendering provider page");
		log.info(Constant.SCRLOGSHT_MSG, "Rendering provider page");
	}

	@Then("^Click Next$")
	public void clicknextbuttoninLocationTab() {
		testRenderingPage.clickNextButtonInLocationTab();
	}

	@Then("^Fill Clinical Template$")
	public void fillclinicaltemplateinLocationTab() {
		testRenderingPage.fillClinicalTemplateinLocationTab();
	}

	@Then("^Verify State dropdown present in Rendering Page$")
	public void verifyStateDropdownPresentInRenderingPage() {
		Assert.assertEquals(true, testRenderingPage.verifyStateDropdownPresent());
		log.info("State Dropdown is present");
	}

	@Then("^Click State dropdown in Rendering Page$")
	public void clickStateDropdownInRenderingPage() {
		testRenderingPage.clickStateDropdown();
		log.info("State dropdown is clicked");
	}

	@Then("^Verify State list is present in Rendering Page$")
	public void verifyStateListIsPresentInRenderingPage() {
		Assert.assertEquals(true, testRenderingPage.verifyStateListPresent());
		log.info("State list is Present");
	}

	@Then("^Verify State list is in sort order in Rendering Page$")
	public void verifyStateListisInSortOrderInRenderingPage() {
		Assert.assertEquals(true, testRenderingPage.verifyStateListOrder());
		log.info("State list is in Sort Order");
	}

	@Then("^Check State dropdown values in Rendering Page$")
	public void checkStateDropdownvaluesinRenderingPage() throws IOException, InterruptedException {
		String strStateList = (String) constant.dataMap.get("StateList");
		try {
			Assert.assertEquals(true, testRenderingPage.checkStateDropdownValues(strStateList));
			log.info("State List is equal");
		} catch (Exception e) {
			e.printStackTrace();
		}
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Verify State List Values");

	}

}
