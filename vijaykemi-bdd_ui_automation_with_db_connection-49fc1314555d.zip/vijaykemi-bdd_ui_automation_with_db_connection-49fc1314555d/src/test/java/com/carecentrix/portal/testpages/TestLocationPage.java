package com.carecentrix.portal.testpages;

import com.carecentrix.portal.pages.LocationPage;
import com.carecentrix.utilities.BasePage;
import com.carecentrix.utilities.PropLoader;

public class TestLocationPage extends BasePage {

	LocationPage objLocationPage;

	String stateList;
	public void readPropertyFileRenderingTab() {
		try {
			stateList = PropLoader.listProps.apply("StateList");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean checkAvailabilityOfLocationTab() {
		objLocationPage = new LocationPage(driver);
		return objLocationPage.isLocationTabAvailable();
	}

	public boolean isAddLocationButtonEnabled() {
		objLocationPage = new LocationPage(driver);
		return objLocationPage.isAddLocationButtonEnabled();
	}

	public void selectLocationFromResult() {
		objLocationPage = new LocationPage(driver);
		objLocationPage.selectLocationFromResult();
	}

	public void clickNextButtonInLocationTab() {
		objLocationPage = new LocationPage(driver);
		objLocationPage.clickNextButtonInLocationTab();
	}

	public boolean isSearchResultDisplayed() {
		objLocationPage = new LocationPage(driver);
		return objLocationPage.isSearchResultDisplayed();
	}

	public void fillClinicalTemplateinLocationTab() {
		objLocationPage = new LocationPage(driver);
		objLocationPage.fillClinicalTemplate();
	}

	public boolean verifyStateDropdownPresent() {
		objLocationPage = new LocationPage(driver);
		return objLocationPage.verifyStateDropdownPresent();
	}

	public void clickStateDropdown() {
		objLocationPage = new LocationPage(driver);
		objLocationPage.clickStateDropdown();
	}

	public boolean verifyStateListPresent() {
		objLocationPage = new LocationPage(driver);
		return objLocationPage.verifyStateListPresent();
	}

	public boolean verifyStateListOrder() {
		objLocationPage = new LocationPage(driver);
		return objLocationPage.verifyStateListSortorder();
	}

	public boolean checkStateDropdownValues( String strStateList) {
		//readPropertyFileRenderingTab();
		objLocationPage = new LocationPage(driver);
		return objLocationPage.checkStateDropdownvalues(strStateList);
	}

}
