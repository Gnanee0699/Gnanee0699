package com.carecentrix.portal.stepdefinitions;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;

import com.carecentrix.portal.testUtils.ExcelReader;
import com.carecentrix.portal.testpages.TestDiagnosisPage;
import com.carecentrix.portal.testpages.TestLocationPage;
import com.carecentrix.portal.testpages.TestMemberInfoPage;
import com.carecentrix.portal.testpages.TestPhysicianPage;
import com.carecentrix.portal.testpages.TestServicesPage;
import com.carecentrix.utilities.Constant;
import com.carecentrix.utilities.SeleniumMethods;

import cucumber.api.DataTable;
import cucumber.api.java.en.Then;

public class PhysicianStepDef {

	MemberInfoStepDef memberInfoStepDef = new MemberInfoStepDef();
	DiagnosisStepDef diagnosisStepDef = new DiagnosisStepDef();
	ServicesStepDef servicesStepDef = new ServicesStepDef();

	TestMemberInfoPage testMemberInfoPage = new TestMemberInfoPage();
	TestDiagnosisPage testDiagnosisPage = new TestDiagnosisPage();
	TestServicesPage testServicesPage = new TestServicesPage();
	TestPhysicianPage testPhysicianPage = new TestPhysicianPage();
	TestLocationPage testLocationPage = new TestLocationPage();
	// MD - Using map to get the test data
		//Map<String, Object> dataMap;
	Constant constant = new Constant();
	
	private static final Logger log = LogManager.getLogger(PhysicianStepDef.class);

	@Then("^Check availability of Physician tab$")
	public boolean checkavailabilityofPhysiciantab() throws IOException, InterruptedException {
//		List<List<String>> data = details.raw();
//		String dataserviceType = data.get(0).get(0);
//		String dataserviceRequestType = data.get(0).get(1);
//		String dataserviceOption = data.get(0).get(2);
		
		String dataserviceType = (String) constant.dataMap.get("DataserviceType");
		String dataserviceRequestType = (String) constant.dataMap.get("DataserviceRequestType");
		String dataserviceOption = (String) constant.dataMap.get("DataserviceOption");
		String PhysiciansOrder = (String) constant.dataMap.get("PhysiciansOrder");
		String Dischargefacility = (String) constant.dataMap.get("Dischargefacility");
		String lastName = (String) constant.dataMap.get("LastName");
		String firstName = (String) constant.dataMap.get("FirstName");
		String dob = (String) constant.dataMap.get("Dob");
		String healthPlan = (String) constant.dataMap.get("HealthPlan");
		String subscriberId = (String) constant.dataMap.get("SubscriberId");
		String referralType = (String) constant.dataMap.get("ReferralType");
		String earlierRequestedStartDate = (String) constant.dataMap.get("EarlierRequestedStartDate");
		String ICDCode = (String) constant.dataMap.get("ICDCode");

		boolean physicianTabCompleted = false;

		if (testMemberInfoPage.isMemberInfoTabAvailable()) {
			memberInfoStepDef.fillmemberInfodetails(lastName,firstName,dob,healthPlan,subscriberId,referralType,earlierRequestedStartDate);
		}
		if (testDiagnosisPage.isDiagnosisTabEnabled()) {
			diagnosisStepDef.filldiagnosisdetails(ICDCode);// Externalisation impact
		}
		if (testServicesPage.isServicesTabEnabled()) {
			servicesStepDef.fillservicesdetails(dataserviceType, dataserviceRequestType, dataserviceOption,PhysiciansOrder,Dischargefacility);
		}
		if (!testPhysicianPage.checkAvailabilityOfPhysicianTab()) {
			log.info("Physician Tab is completed");
			physicianTabCompleted = true;
		}
		return physicianTabCompleted;
	}

	@Then("^Enter valid information in all the fields$")
	public void entervalidinformationinallthefields() {
		
		String physicianLastName = (String) constant.dataMap.get("PhysicianLastName"); 
		String physicianFirstName = (String) constant.dataMap.get("PhysicianFirstName");
		String physicianNPI = (String) constant.dataMap.get("PhysicianNPI");
		String physicianPhoneNumber = (String) constant.dataMap.get("PhysicianPhoneNumber");
		String physicianCity = (String) constant.dataMap.get("PhysicianCity");
		String physicianState = (String) constant.dataMap.get("PhysicianState");
		String physicianZipCode = (String) constant.dataMap.get("PhysicianZipCode");
		testPhysicianPage.enterValidInfoSeachfields(physicianLastName, physicianFirstName, physicianNPI,
				physicianPhoneNumber, physicianCity, physicianState, physicianZipCode);
	}

	@Then("^Click on search button$")
	public void clickonsearchbutton() throws IOException, InterruptedException {
		
		testPhysicianPage.clickSearchButton();
		//Assert.assertEquals(true, testPhysicianPage.clickSearchButton());
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Physician page");
		log.info(Constant.SCRLOGSHT_MSG, "Physician page");
	}

	@Then("^Click search button to verify error msg$")
	public void clickSearchBtnToVerifyErrMsg() {
		Assert.assertEquals(false, testPhysicianPage.clickSearchButton());
	}

	@Then("^Check search result for required details$")
	public void checksearchresultforrequireddetails() {
		String physicianLastName = (String) constant.dataMap.get("PhysicianLastName"); 
		String physicianFirstName = (String) constant.dataMap.get("PhysicianFirstName");
		String physicianNPI = (String) constant.dataMap.get("PhysicianNPI");
		String physicianPhoneNumber = (String) constant.dataMap.get("PhysicianPhoneNumber");
		String physicianCity = (String) constant.dataMap.get("PhysicianCity");
		String physicianState = (String) constant.dataMap.get("PhysicianState");
		String physicianZipCode = (String) constant.dataMap.get("PhysicianZipCode");
		
		testPhysicianPage.verifyResultWithSearchDetails(physicianLastName, physicianFirstName, physicianNPI,
				 physicianPhoneNumber, physicianCity, physicianState,  physicianZipCode);
	}

	@Then("^Enter invalid information$")
	public void enterinvalidinformation() {
		testPhysicianPage.enterInvalidInformation();
	}

	@Then("^Check Added Physician details$")
	public void checkAddedPhysiciandetails() {
		testPhysicianPage.checkAddedPhysicianDetails();
	}

	@Then("^Click Add Botton to choose Physician type$")
	public void clickAddBottontochoosePhysiciantype() {
		testPhysicianPage.clickAddBottonToChoosePhysicianType();
	}

	//MD - Updated for external test data.
	@Then("^Choose Physician type as$")
	public void choosePhysiciantype() {
		try {
			//dataMap = ExcelReader.readAllRow("EPE2EData", scenario);
			//String physicianType = (String) dataMap.get("physicianType");
			String physicianType =(String) constant.dataMap.get("physicianType");
		testPhysicianPage.choosePhysiciantype(physicianType);
	} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Then("^Check Physician Type is added$")
	public void checkPhysicianTypeisadded() {
		Assert.assertEquals(true, testPhysicianPage.isPhysicianAdded());
	}

	//MD - Updated for external test data.
		@Then("^Enter information to search$")
		public void enterinformationtosearch() {
			try {
				//dataMap = ExcelReader.readAllRow("EPE2EData", scenario);
				String physicianZipCode = (String) constant.dataMap.get("physicianZipCode");
				String physicianCity = (String) constant.dataMap.get("physicianCity");
				String physicianState = (String) constant.dataMap.get("physicianState");
				String physicianNpi = (String) constant.dataMap.get("physicianNPI");
				String physicianLastname = (String) constant.dataMap.get("physicianLastname");
				String physicianFirstname = (String) constant.dataMap.get("physicianFirstname");
				testPhysicianPage.enterInformationToSearch(physicianZipCode, physicianCity, physicianState, physicianNpi,physicianLastname,physicianFirstname);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}

	@Then("^Select more than one Physician$")
	public void selectmorethanonePhysician() {
		Assert.assertEquals(true, testPhysicianPage.selectMoreThanOnePhysician());
	}

	@Then("^Click Next button$")
	public void clickonNextbutton() {
		testPhysicianPage.clickNextButton();
	}

	@Then("^Verify Error message$")
	public void verifyErrormessage() {
		Assert.assertEquals(true, testPhysicianPage.verifyErrorMessage());
	}

	@Then("^Verify Error message to select Ordering Physician$")
	public void verifyErrormessagetoselectOrderingPhysician() {
		Assert.assertEquals(true, testPhysicianPage.verifyErrorMessageForOrderingPhysician());
	}

	@Then("^Verify Error message to update search criteria$")
	public void verifyErrormessagetoupdatesearchcriteria() {
		Assert.assertEquals(true, testPhysicianPage.verifyErrorMessageToUpdateSearchCriteria());
	}

	@Then("^Check details of selected Physician$")
	public void checkdetailsofselectedphysician() {
		String physicianType =(String) constant.dataMap.get("physicianType");
		Assert.assertEquals(true, testPhysicianPage.checkDetailsOfSelectedPhysician(physicianType));
	}

	@Then("^User should able to unselect choosen Physician$")
	public void usershouldabletounselectchoosenPhysician() {
		Assert.assertEquals(true, testPhysicianPage.unSelectChoosenPhysician());
	}

	@Then("^Search results will be displayed$")
	public void searchresultswillbedisplayed() {
		Assert.assertEquals(true, testPhysicianPage.isSearchResultsDisplayed());
	}

	@Then("^Select Ordering and Primary Physician in One option$")
	public void selectOrderingandPrimaryPhysicianinOneoption() {
		Assert.assertEquals(true, testPhysicianPage.selectOrderingAndPrimaryPhysicianInOneOption());
	}

	@Then("^Check Ordering and Primary Physician added$")
	public void checkOrderingandPrimaryPhysicianadded() {
		Assert.assertEquals(true, testPhysicianPage.checkOrderingAndPrimaryPhysicianAdded());
		log.info("Ordering and Primary Physician Added Successfully");
	}

	@Then("^Check Ordering and Primary Physician added in different option$")
	public void checkOrderingandPrimaryPhysicianaddedindifferentoption() {
		Assert.assertEquals(true, testPhysicianPage.checkOrderingAndPrimaryPhysicianAddedInDiffOption());
	}

	@Then("^Choose different Physician types \"([^\"]*)\" and \"([^\"]*)\"$")
	public void chooseDiffphysiciantypes(String orderingPhysician, String primaryPhysician) {
		Assert.assertEquals(true, testPhysicianPage.chooseDiffPhysiciantypes(orderingPhysician));
		testPhysicianPage.chooseDiffPhysiciantypes(primaryPhysician);
	}

	@Then("^Verify State dropdown present in Physician Page$")
	public void verifyStateDropdownPresentInPhysicianPage() {
		Assert.assertEquals(true, testPhysicianPage.verifyStateDropdownPresent());
		log.info("State Dropdown is present");
	}

	@Then("^Click State dropdown in Physician Page$")
	public void clickStateDropdownInPhysicianPage() {
		testPhysicianPage.clickStateDropdown();
		log.info("State dropdown is clicked");
	}

	@Then("^Verify State list is present in Physician Page$")
	public void verifyStateListIsPresentInPhysicianPage() {
		Assert.assertEquals(true, testPhysicianPage.verifyStateListPresent());
		log.info("State list is Present");
	}

	@Then("^Verify State list is in sort order in Physician Page$")
	public void verifyStateListisInSortOrderInPhysicianPage() {
		Assert.assertEquals(false, testPhysicianPage.verifyStateListOrder());
		log.info("State list is in Sort Order");
	}

	@Then("^Check State dropdown values in Physician Page$")
	public void checkStateDropdownvaluesinPhysicianPage() {
		try {
			Assert.assertEquals(true, testPhysicianPage.checkStateDropdownValues());
			log.info("State List is equal");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	//Updated for externalisation.
	public void fillphysiciandetails() throws IOException, InterruptedException {
		
		enterinformationtosearch();
		clickonsearchbutton();
		clickAddBottontochoosePhysiciantype();
		choosePhysiciantype();
		checkPhysicianTypeisadded();
		clickonNextbutton();
		
	}

}
