package com.carecentrix.portal.testpages;

import java.util.List;

import com.carecentrix.portal.pages.DiagnosisPage;
import com.carecentrix.portal.pages.LocationPage;
import com.carecentrix.portal.pages.PhysicianPage;
import com.carecentrix.portal.pages.ReferralInfoPage;
import com.carecentrix.portal.pages.ServicesPage;
import com.carecentrix.utilities.BasePage;
import com.carecentrix.utilities.PropLoader;

public class TestReferralInfoPage extends BasePage {

	DiagnosisPage objDiagnosisPage;
	ReferralInfoPage objReferralInfoPage;
	ServicesPage objServicesPage;
	PhysicianPage objPhysicianPage;
	LocationPage objLocationPage;

	String lastName;
	String firstName;
	String dob;
	String healthPlan;
	String subscriberId;
	String referralType;
	String earlierRequestedStartDate;
	String lineOfBusiness = null;
	String MemberInfoBar_Name;
	String MemberInfoBar_SubscriberID;
	String MemberInfoBar_HealthPlan;
	String MemberInfoBar_LineofBusiness;
	String MemberInfoBar_DOB;
	String phoneNumber;
	String fullName;
	String careGiverName;
	String careGiverPhone;
	String knownAllergies;
	String notesTextMsg;
	String attachmentType;
	String blankValue;

	public void readPropertyFile() {
		try {

			lastName = PropLoader.props.apply("lastName");
			firstName = PropLoader.props.apply("firstName");
			dob = PropLoader.props.apply("dob");
			healthPlan = PropLoader.props.apply("healthPlan");
			blankValue = PropLoader.props.apply("BlankValue");
			subscriberId = PropLoader.props.apply("subscriberId");
			referralType = PropLoader.props.apply("referralType");
			earlierRequestedStartDate = PropLoader.props.apply("earlierRequestedStartDate");
			MemberInfoBar_Name = PropLoader.props.apply("MemberInfoBar_Name");
			MemberInfoBar_SubscriberID = PropLoader.props.apply("MemberInfoBar_SubscriberID");
			MemberInfoBar_HealthPlan = PropLoader.props.apply("MemberInfoBar_HealthPlan");
			MemberInfoBar_LineofBusiness = PropLoader.props.apply("MemberInfoBar_LineofBusiness");
			MemberInfoBar_DOB = PropLoader.props.apply("MemberInfoBar_DOB");
			phoneNumber = PropLoader.props.apply("phoneNumber");
			fullName = firstName + " " + lastName;
			careGiverName = PropLoader.props.apply("CareGiverName");
			careGiverPhone = PropLoader.props.apply("CareGiverPhone");
			knownAllergies = PropLoader.props.apply("KnownAllergies");
			notesTextMsg = PropLoader.props.apply("NotesTextMsg");
			attachmentType = PropLoader.props.apply("AttachmentType");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean isUserMovedToDiagnosisPage() {
		objDiagnosisPage = new DiagnosisPage(driver);
		return objDiagnosisPage.isDiagnosisTabAvailable();
	}

	public boolean verifyMemberInfoDetails(String tabName) {
		objReferralInfoPage = new ReferralInfoPage(driver);
		readPropertyFile();
		return objReferralInfoPage.verifyMemberInfoDetails(tabName, MemberInfoBar_Name, fullName,
				MemberInfoBar_SubscriberID, subscriberId, MemberInfoBar_HealthPlan, healthPlan, blankValue,
				MemberInfoBar_LineofBusiness, lineOfBusiness, blankValue, MemberInfoBar_DOB, dob);
	}

	public boolean isUserMovedToServicesPage() {
		objServicesPage = new ServicesPage(driver);
		return objServicesPage.isServicesTabAvailable();
	}

	public boolean isUserMovedToPhysicianPage() {
		objPhysicianPage = new PhysicianPage(driver);
		return objPhysicianPage.isPhysicianTabAvailable();
	}

	public boolean isUserMovedToLocationPage() {
		objLocationPage = new LocationPage(driver);
		return objLocationPage.isLocationTabAvailable();
	}

	public boolean isUserMovedToReferralInfoPage() {
		objReferralInfoPage = new ReferralInfoPage(driver);
		return objReferralInfoPage.isReferralInfoTabAvailable();
	}

	public void fillMandatoryDetailsInReferralPage(List<String> contactMethd) {
		readPropertyFile();
		objReferralInfoPage = new ReferralInfoPage(driver);
		objReferralInfoPage.fillMandatoryDetailsInReferralPage(lastName, firstName, phoneNumber, contactMethd);
	}

	public void chooseContactDetail() {
		readPropertyFile();
		objReferralInfoPage = new ReferralInfoPage(driver);
		objReferralInfoPage.chooseContactDetail(lastName, firstName, phoneNumber);
	}

	public void enterContactInfoDetails(String lastName, String firstName, String phoneNumber, String contactMethod) {
		readPropertyFile();
		objReferralInfoPage = new ReferralInfoPage(driver);
		objReferralInfoPage.contactDetails(lastName, firstName, phoneNumber, contactMethod);
	}

	public boolean clickReviewRequestButton() {
		objReferralInfoPage = new ReferralInfoPage(driver);
		return objReferralInfoPage.clickReviewRequestButton();
	}

	public boolean clickSubmitButton() {
		objReferralInfoPage = new ReferralInfoPage(driver);
		return objReferralInfoPage.clickSubmitButton();
	}

	public boolean isStatusNotCompleted(String tabName) {
		objReferralInfoPage = new ReferralInfoPage(driver);
		return objReferralInfoPage.isStatusNotCompleted(tabName);
	}

	public boolean isStatusCompleted(String tabName) {
		objReferralInfoPage = new ReferralInfoPage(driver);
		return objReferralInfoPage.isStatusCompleted(tabName);
	}

	// MD - Updated for external test data
	public void enterAdditionalInfoDetails(String careGiverName, String careGiverPhone, String knownAllergies, String notesTextMsg) {
		readPropertyFile();
		objReferralInfoPage = new ReferralInfoPage(driver);
		objReferralInfoPage.enterAdditionalInfoDetails(careGiverName, careGiverPhone, knownAllergies, notesTextMsg);
	}

	//MD - Updated for external test data
	public void selectAttachementTyAndUploadDoc(String attachmentType) {
		//readPropertyFile();
		objReferralInfoPage = new ReferralInfoPage(driver);
		objReferralInfoPage.selectAttachementTyAndUploadDoc(attachmentType);
	}

	public void clickBrowseButtonToAddAttachement() {
		readPropertyFile();
		objReferralInfoPage = new ReferralInfoPage(driver);
		objReferralInfoPage.clickBrowseButtonToAddAttachement();
	}

	public boolean verifyDocumentUploaded() {
		objReferralInfoPage = new ReferralInfoPage(driver);
		return objReferralInfoPage.verifyDocumentUploaded();
	}

	public boolean verifySuccessMsgDisplayed() {
		objReferralInfoPage = new ReferralInfoPage(driver);
		return objReferralInfoPage.verifySuccessMsgDisplayed();
	}

	public boolean clickGoToHomeButton() {
		objReferralInfoPage = new ReferralInfoPage(driver);
		return objReferralInfoPage.clickGoToHomeButton();
	}

	public boolean verifySuccMsgDetails() {
		objReferralInfoPage = new ReferralInfoPage(driver);
		return objReferralInfoPage.verifySuccMsgDetails();
	}

	public boolean verifyDiagnosisDetails() {
		objReferralInfoPage = new ReferralInfoPage(driver);
		return objReferralInfoPage.verifyDiagnosisDetails();
	}

	public boolean verifyServicesDetails() {
		objReferralInfoPage = new ReferralInfoPage(driver);
		return objReferralInfoPage.verifyServicesDetails();
	}

	public boolean verifyPhysicianDetails() {
		objReferralInfoPage = new ReferralInfoPage(driver);
		return objReferralInfoPage.verifyPhysicianDetails();
	}

	public boolean verifyDateFormatInTopPanel(String tabName) {
		objReferralInfoPage = new ReferralInfoPage(driver);
		return objReferralInfoPage.verifyDateFormatInTopPanel(tabName);
	}

	public boolean verifyUserTypeListOrder() {
		objReferralInfoPage = new ReferralInfoPage(driver);
		return objReferralInfoPage.verifyUserTypeListOrder();
	}

	public boolean goToMemberInfoPage() {
		objReferralInfoPage = new ReferralInfoPage(driver);
		return objReferralInfoPage.goToMemberInfoPage();
	}

	public boolean goToDiagnosisPage() {
		objReferralInfoPage = new ReferralInfoPage(driver);
		return objReferralInfoPage.goToDiagnosisPage();
	}

	public boolean goToServicesPage() {
		objReferralInfoPage = new ReferralInfoPage(driver);
		return objReferralInfoPage.goToServicesPage();
	}

	public boolean goToPhysicianPage() {
		objReferralInfoPage = new ReferralInfoPage(driver);
		return objReferralInfoPage.goToPhysicianPage();
	}

	public boolean goToRederingProvPage() {
		objReferralInfoPage = new ReferralInfoPage(driver);
		return objReferralInfoPage.goToRederingProvPage();
	}

	public boolean goToAdditionalInfoPage() {
		objReferralInfoPage = new ReferralInfoPage(driver);
		return objReferralInfoPage.goToAdditionalInfoPage();
	}
	
	public String getReqID() {
		objReferralInfoPage = new ReferralInfoPage(driver);
		return objReferralInfoPage.getRequestID();
	}

}
