package com.carecentrix.portal.stepdefinitions;

import java.io.IOException;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;

import com.carecentrix.portal.testUtils.ExcelReader;
import com.carecentrix.portal.testpages.TestRequestStatusPage;
import com.carecentrix.utilities.Constant;
import com.carecentrix.utilities.SeleniumMethods;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import net.serenitybdd.core.Serenity;


public class RequestStatusStepDef {

	private static final Logger log = LogManager.getLogger(RequestStatusStepDef.class);
	TestRequestStatusPage testrequestStatusPage = new TestRequestStatusPage();
	//Using map to get the test data
	Map<String, Object> dataMap;
	

	@Given("^Click on Request Status$")
	public void clickonrequestStatus() {
		Assert.assertEquals(true, testrequestStatusPage.clickRequestStatus());
		log.info("Create Request Button is clicked");
	}
	
	@Given("^Click on Manage Request$")
	public void clickonmanageRequest() {
		Assert.assertEquals(true, testrequestStatusPage.clickManageRequest());
		log.info("Manage Request Link is clicked");
	}
	
	@Given("^Click on Search Button$")
	public void enterRequestData() {
		Assert.assertEquals(true, testrequestStatusPage.clickSearchButton());
		log.info("Search Request Button is clicked");
	}

	@Then("^Enter Request information to search \"([^\"]*)\"$")
	public void enterRequestinfotosearch(String scenario) {
		try {
			dataMap = ExcelReader.readAllRow("EPE2EData", scenario);
			String subscriberId = (String) dataMap.get("subscriberId");
			String membfirstName = (String) dataMap.get("firstName");
			String memmblastName = (String) dataMap.get("lastName");
			String membdob = (String) dataMap.get("dob");
			testrequestStatusPage.enterInformationToSearch(subscriberId, membfirstName, memmblastName, membdob);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Then("^Get the Parentauthids$")
	public void GettheParentauthids() {
		try {
			testrequestStatusPage.getparenauthid();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Then("^Capture Service Line Number \"([^\"]*)\"$")
	public void saveSAID(String strFlag) throws IOException, InterruptedException {
		String strTempOld = (String) Serenity.getCurrentSession().get(Constant.SERVICELINE_NUMBER);
		Assert.assertEquals(true, testrequestStatusPage.saveServiceLineNumber(strFlag));
		String strTempNew = (String) Serenity.getCurrentSession().get(Constant.SERVICELINE_NUMBER);
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Case id search results page");
		log.info(Constant.SCRLOGSHT_MSG, "Case id search results page");
		if (strTempOld != null) 
		{ Assert.assertNotEquals("New Service Line Not Created", strTempOld, strTempNew); }
		
	}


}
