package com.carecentrix.portal.testpages;

import com.carecentrix.portal.pages.RequestStatusPage;
import com.carecentrix.utilities.BasePage;


public class TestRequestStatusPage extends BasePage {

	RequestStatusPage objRequestStatusPage;

			
	public String getparenauthid(){
		objRequestStatusPage = new RequestStatusPage(driver);
		try {
			return objRequestStatusPage.getParentauthid();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public boolean clickRequestStatus() {
		objRequestStatusPage = new RequestStatusPage(driver);
		return objRequestStatusPage.clickRequestStatus();

	}
	
	public boolean clickManageRequest() {
		objRequestStatusPage = new RequestStatusPage(driver);
		return objRequestStatusPage.clickManageRequest();

	}
	
	public boolean clickSearchButton() {
		objRequestStatusPage = new RequestStatusPage(driver);
		return objRequestStatusPage.searchRequest();

	}
	
	public void enterInformationToSearch(String subscriberId, String membfirstName, String memmblastName, String membdob) {
		
		objRequestStatusPage = new RequestStatusPage(driver);
		objRequestStatusPage.enterInformationToSearch(subscriberId, membfirstName, memmblastName, membdob);
		
	}
	
	public boolean saveServiceLineNumber(String strFlag) {
		objRequestStatusPage = new RequestStatusPage(driver);
		return objRequestStatusPage.getServiceLine(strFlag);

	}


}
