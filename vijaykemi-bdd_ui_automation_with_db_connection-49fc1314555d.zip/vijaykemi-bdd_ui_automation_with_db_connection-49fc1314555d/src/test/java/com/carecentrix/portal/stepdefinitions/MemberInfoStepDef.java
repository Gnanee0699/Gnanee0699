package com.carecentrix.portal.stepdefinitions;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;

import com.carecentrix.portal.testUtils.ExcelReader;
import com.carecentrix.portal.testpages.TestLoginPage;
import com.carecentrix.portal.testpages.TestMemberInfoPage;
import com.carecentrix.utilities.Constant;
import com.carecentrix.utilities.SeleniumMethods;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 * @author KJ
 *
 */

public class MemberInfoStepDef {

	private static final Logger log = LogManager.getLogger(MemberInfoStepDef.class);
	TestLoginPage testLoginPage = new TestLoginPage();
	TestMemberInfoPage testMemberInfoPage = new TestMemberInfoPage();
	//Using map to get the test data
	//Map<String, Object> dataMap;
Constant constant = new Constant();
	

	@Given("^Click on Create Request button$")
	public void clickonCreateRequestbutton() throws IOException, InterruptedException {
		Assert.assertEquals(true, testMemberInfoPage.clickCreateRequest());
		log.info("Create Request Button is clicked");
		SeleniumMethods.captureScreenShot(Constant.SCRSHT_MSG+ "Home page");
		log.info(Constant.SCRLOGSHT_MSG, "Home page");
	}

	@Then("^Check availability of MemberInfo tab$")
	public void checkavailabilityofMemberInfotab() {
		Assert.assertEquals(true, testMemberInfoPage.isMemberInfoTabAvailable());
		log.info("Member Info Tab is enabled");
	}
//Updated for extrernal test data.
	@When("^Enter user details$")
	public void enteruserdetails() {
	try {
		//dataMap = ExcelReader.readAllRow("EPE2EData", scenario);
		String lastName = (String) Constant.dataMap.get("lastName");
		String firstName = (String) Constant.dataMap.get("firstName");
		String dob = (String) Constant.dataMap.get("dob");
		String healthPlan = (String) Constant.dataMap.get("healthPlan");
		String subscriberId = (String) Constant.dataMap.get("subscriberId");
		String referralType = (String) Constant.dataMap.get("referralType");
		String earlierRequestedStartDate = (String) Constant.dataMap.get("earlierRequestedStartDate");		
		//testMemberInfoPage.enterMemberDetails();
		testMemberInfoPage.enterMemberDetails(lastName, firstName, dob, healthPlan, subscriberId, referralType,
				earlierRequestedStartDate);
		log.info("Member details are entered");
	} catch (Exception e) {
		e.printStackTrace();
	}
	}
	
//	@Then("^Enter user details \"([^\"]*)\"$")
//	public void enteruserdetails(String scenario) {
//		try {
//			dataMap = ExcelReader.readAllRow("EPE2EData", scenario);
//			String lastName = (String) dataMap.get("lastName");
//			String firstName = (String) dataMap.get("firstName");
//			String dob = (String) dataMap.get("dob");
//			String healthPlan = (String) dataMap.get("healthPlan");
//			String subscriberId = (String) dataMap.get("subscriberId");
//			String referralType = (String) dataMap.get("referralType");
//			String earlierRequestedStartDate = (String) dataMap.get("earlierRequestedStartDate");		
//			//testMemberInfoPage.enterMemberDetails();
//			testMemberInfoPage.enterMemberDetails(lastName, firstName, dob, healthPlan, subscriberId, referralType,
//					earlierRequestedStartDate);
//			log.info("Member details are entered");
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}

	@Then("^Click on Verify button$")
	public void clickVerifyMemberBtn() throws IOException, InterruptedException {
		
		
		String environment = (String) constant.dataMap.get("environment");
		
		if(environment.equalsIgnoreCase("Q4")){
		
		testMemberInfoPage.clickVerifyMemberBtn();
		}else
		{
			testMemberInfoPage.clickConfirmBtn();
		}
		log.info("Verify Member button is clicked");
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "MemberInfo page");
		log.info(Constant.SCRLOGSHT_MSG, "MemberInfo page");
	}

	@Then("^Enter user details to check DOB$")
	public void enterDetailsToCheckDOB() {
		testMemberInfoPage.enterDetailsToCheckDOB();
		log.info("Details entered successfully");
	}

	@Then("^Enter user details to check RequestStartDate$")
	public void enterDetailsToChecReqStartDate() {
		testMemberInfoPage.enterDetailsToChecReqStartDate();
		log.info("Details entered successfully");
	}

	@Then("^Verify auto populated fields$")
	public void verifyautopopulatedfields() {
		testMemberInfoPage.verifyAutoPopulatedFields();
		log.info("verify auto populated fields are verfied");
	}

	@Then("^Click on ConfirmInfo button$")
	public void clickonConfirmInfobutton() throws IOException, InterruptedException {
		testMemberInfoPage.clickConfirmInfoButton();
		log.info("Confirm Information Button is clicked");
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "MemberInfo confirmation page");
		log.info(Constant.SCRLOGSHT_MSG, "MemberInfo confirmation page");
	}

	@Then("^Click on Signout button$")
	public void clickonSignoutbutton() {
		testMemberInfoPage.clickSignoutButton();
		log.info("Signout Button is clicked");
	}

	@Then("^Close browser$")
	public void closebrowser() {
		testMemberInfoPage.quitBrowser();
	}

	@When("^Enter incorrect user details$")
	public void enterincorrectuserdetails() {
		testMemberInfoPage.enterIncorrectMemberDetails();
		log.info("User entered incorrect member details");
	}

	@Then("^User should get message to review details$")
	public void verifyReviewDetailsMsgBox() throws IOException, InterruptedException {
		Assert.assertEquals(true, testMemberInfoPage.verfiyAlertMessage());
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "MemberReview Message");
		log.info(Constant.SCRLOGSHT_MSG, "MemberReview Message");
	}

	@Then("^Click Review Information button$")
	public void clickReviewInformationbutton() {
		testMemberInfoPage.clickReviewInfoButton();
	}

	@Then("^Click on Continue button$")
	public void clickonContinuebutton() {
		testMemberInfoPage.clickContinueButton();
	}

	@Then("^Click on close button$")
	public void clickonclosebutton() {
		testMemberInfoPage.clickCloseButton();
	}

	@When("^All fields should available to user$")
	public void allfieldsshouldavailabletouser() {
		testMemberInfoPage.checkMandatoryfieldsAvailability();
	}

	@When("^Enter blank user details$")
	public void enterblankuserdetails() {
		//testMemberInfoPage.enterBlankInUserDetails();
	}

	@Then("^User should get error message for mandatory fields$")
	public void verifyerrormessageformandatoryfields() throws IOException, InterruptedException {
		Assert.assertEquals(true, testMemberInfoPage.checkErrorMessage());
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Mandatory fields Error");
		log.info("Error message displayed");
	}

	@Then("^Enter all the required data correctly and continue$")
	public void enteralltherequireddatacorrectlyandcontinue(String lastName,String firstName,String dob,String healthPlan,String subscriberId,String referralType,String earlierRequestedStartDate) {
		testMemberInfoPage.enterCorrectDataAndContinue( lastName, firstName, dob, healthPlan, subscriberId, referralType, earlierRequestedStartDate);
	}

	@When("^Enter blank values on all fields$")
	public void enterblankvaluesonallfields() {
		testMemberInfoPage.enterBlankValuesOnAllFields();
	}

	@Then("^Check Verify button is disabled$")
	public void checkVerifybuttonisdisabled() throws IOException, InterruptedException {
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Verify Member button");
		if (testMemberInfoPage.checkVerifyButtonDisabled())
			log.info("Verify Member button is enabled");
		else
			log.info("Verify Member button is disabled");
	}

	@Then("^Check Referral type dropdown values$")
	public void checkReferraltypedropdownvalues() throws IOException, InterruptedException {
		String strRefferalList = (String) Constant.dataMap.get("ReferralSourceList");
		testMemberInfoPage.checkReferralTypeDropdownValues(strRefferalList);
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Referral type dropdown");
		log.info(Constant.SCRLOGSHT_MSG, "Referral type dropdown");
	}

	@Then("^Check Referral source dropdown availability$")
	public void checkReferralSourceDropdownAvailability() {
		Assert.assertEquals(true, testMemberInfoPage.isReferralSourceDDAvailable());
		log.info("Referral Source dropdown present");
	}

	@Then("^Check dropdown values in Ascending Order$")
	public void checkDropdownValuesInAscendingOrder() throws IOException, InterruptedException {
		Assert.assertEquals(true, testMemberInfoPage.isReferralSourceInAscendingOrder());
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Referral type dropdown Order");
		log.info("Dropdown values are in Ascending Order");
	}

	@Then("^Enter user details to check mandatory fields$")
	public void enteruserdetailstocheckmandatoryfields() throws IOException, InterruptedException {
		String strblanklastName = "";
		String firstName = (String) Constant.dataMap.get("firstName");
		String dob = (String) Constant.dataMap.get("dob");
		String healthPlan = (String) Constant.dataMap.get("healthPlan");
		String subscriberId = (String) Constant.dataMap.get("subscriberId");
		String referralType = (String) Constant.dataMap.get("referralType");
		testMemberInfoPage.enterMemberDetailstoCheckErrorMessage(strblanklastName, firstName, dob, healthPlan, subscriberId, referralType);
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Member Details");
		log.info("All details should be entered");
	}

	@Then("^Check Date validation error message$")
	public void checkDateValidationErrMsg() throws IOException, InterruptedException {
		Assert.assertEquals(true, testMemberInfoPage.checkDateValidationErrMsg());
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Date Validation error message");
		log.info("Date Validation error message displayed");
	}

	@Then("^Enter user name in lowercase$")
	public void enterUserNameInLowerCase() {
		testMemberInfoPage.enterUserNameInLowerCase();
	}

	@Then("^Validate User name displayed$")
	public void validateUserNameDisplayed() {
		Assert.assertEquals(true, testMemberInfoPage.validateUserNameDisplayed());
		log.info("User Name displayed as expected");
	}

	@Then("^Verify Review Info error message content$")
	public void verifyReviewInfoErrMsgContent() throws IOException, InterruptedException {
		Assert.assertEquals(true, testMemberInfoPage.verifyReviewInfoErrMsgContent());
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Verify Review Info");
		log.info("Review Info error message verified");
	}

	@Then("^Verify Member Eligible message$")
	public void verifyMemberEligibleMsg() {
		Assert.assertEquals(true, testMemberInfoPage.verifyMemberEligibleMsg());
		log.info("Member Eligible message verified");
	}

	@Then("^Enter user detail to validate \"([^\"]*)\"$")
	public void enterUserDetailsToValidateErrMsg(String fieldName) throws IOException, InterruptedException {
		String lastName = (String) Constant.dataMap.get("lastName");
		String firstName = (String) Constant.dataMap.get("firstName");
		String dob = (String) Constant.dataMap.get("dob");
		String healthPlan = (String) Constant.dataMap.get("healthPlan");
		String subscriberId = (String) Constant.dataMap.get("subscriberId");
		String referralType = (String) Constant.dataMap.get("referralType");
		String earlierRequestedStartDate = (String) Constant.dataMap.get("earlierRequestedStartDate");
		String strInvalidValue = (String) Constant.dataMap.get("InvalidFieldValue");
		testMemberInfoPage.enterUserDetailsToValidateErrMsg(lastName, firstName, dob, healthPlan, subscriberId, referralType,
				earlierRequestedStartDate,fieldName, strInvalidValue);
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Invalid Field: "+fieldName);
	}

	@Then("^Change only \"([^\"]*)\"$")
	public void editOnlyWrongDetail(String fieldName) throws IOException, InterruptedException {
		String strValidValue = (String) Constant.dataMap.get("ValidFieldValue");
		testMemberInfoPage.editOnlyWrongDetail(fieldName, strValidValue);
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Change Field: "+fieldName);
	}

	@Then("^Enter invalid date format \"([^\"]*)\"$")
	public void enterInvalidDateFormat(String fieldName) {
		String strinvalidDate = (String) Constant.dataMap.get("InvalidFieldValue");
		testMemberInfoPage.enterInvalidDateFormat(fieldName, strinvalidDate);
	}

	@Then("^Enter details in MemberInfo mandatory fields \"([^\"]*)\"$")
	public void enterDetailsInMemberInfoMandatoryFields(String fieldName) {
		String lastName = (String) Constant.dataMap.get("lastName");
		String firstName = (String) Constant.dataMap.get("firstName");
		String dob = (String) Constant.dataMap.get("dob");
		String healthPlan = (String) Constant.dataMap.get("healthPlan");
		String subscriberId = (String) Constant.dataMap.get("subscriberId");
		String referralType = (String) Constant.dataMap.get("referralType");
		String earlierRequestedStartDate = (String) Constant.dataMap.get("earlierRequestedStartDate");
		testMemberInfoPage.enterDetailsInMemberInfoMandatoryFields(fieldName,lastName, firstName, dob, healthPlan, subscriberId, referralType,
				earlierRequestedStartDate);
	}

	@Then("^Verify all Labels in Member Info Tab$")
	public void verifyAllLabelsInMemberInfoTab() throws IOException, InterruptedException {
		//List<List<String>> memLblDetails = memLbl.raw();
		String memLblDetails = (String) Constant.dataMap.get("MembInfoLabel");
		Assert.assertEquals(true, testMemberInfoPage.verifyAllLabelsInMemberInfoTab(memLblDetails));
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Verify all Labels");
	}

	public void fillmemberInfodetails(String lastName,String firstName,String dob,String healthPlan,String subscriberId,String referralType,String earlierRequestedStartDate) throws IOException, InterruptedException {
		log.info("Member info details are not filled so entering details in MemberInfo Tab");
		enteralltherequireddatacorrectlyandcontinue(lastName, firstName, dob, healthPlan, subscriberId, referralType, earlierRequestedStartDate);
		clickonConfirmInfobutton();
	}

	public void fillMemberDetailsDisFac() throws IOException, InterruptedException {
		log.info("Member info details are not filled so entering details in MemberInfo Tab");
		testMemberInfoPage.enterMemberDetailsReferralType();
		clickonConfirmInfobutton();
	}
	
	@Then("^Verify HealthPlan name is pre populated$")
	public void verifyHPNamePrePopulated() throws IOException, InterruptedException {
		Assert.assertEquals(true,testMemberInfoPage.verifyHPNamePrePopulated());
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Verify HealthPlan Name");
	}

}
