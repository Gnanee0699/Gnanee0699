package com.carecentrix.portal.testpages;

import java.util.List;

import com.carecentrix.portal.pages.DiagnosisPage;
import com.carecentrix.portal.pages.LocationPage;
import com.carecentrix.portal.pages.MemberInfoPage;
import com.carecentrix.portal.pages.PhysicianPage;
import com.carecentrix.portal.pages.ReferralInfoPage;
import com.carecentrix.portal.pages.ServicesPage;
import com.carecentrix.utilities.BasePage;
import com.carecentrix.utilities.PropLoader;

public class TestEnd2end extends BasePage {

	MemberInfoPage objMemberPage;
	DiagnosisPage objDiagnosisPage;
	ReferralInfoPage objReferralInfoPage;
	ServicesPage objServicesPage;
	PhysicianPage objPhysicianPage;
	LocationPage objLocationPage;
	 

	String lastName;
	String firstName;
	String dob;
	String healthPlan;
	String subscriberId;
	String referralType;
	String earlierRequestedStartDate;
	String lineOfBusiness = null;
	String MemberInfoBar_Name;
	String MemberInfoBar_SubscriberID;
	String MemberInfoBar_HealthPlan;
	String MemberInfoBar_LineofBusiness;
	String MemberInfoBar_DOB;
	String phoneNumber;
	String fullName;
	String careGiverName;
	String careGiverPhone;
	String knownAllergies;
	String notesTextMsg;
	String attachmentType;
	String blankValue;

	
}
