package com.carecentrix.portal.testpages;

import java.util.List;

import com.carecentrix.portal.pages.SignUpPage;
import com.carecentrix.utilities.BasePage;
import com.carecentrix.utilities.PropLoader;

/**
 * @author KKJANAK
 *
 */

public class TestSignUpPage extends BasePage {

	SignUpPage signUpPage;

	String firstNm;
	String lastNm;
	String email;
	String location;
	String npi;
	String address;
	String city;
	String zip;
	String phone;
	String fax;
	String inValidEmail;
	String alertTitle;
	String alertCnt;
	String newEmail;
	String blankValue;
	String registrationLabels;
	String registrationAddressLabels;

	public void readPropFileMainPage() {
		firstNm = PropLoader.props.apply("Registration_FirstName");
		lastNm = PropLoader.props.apply("Registration_LastName");
		email = PropLoader.props.apply("Registration_Email");
		location = PropLoader.props.apply("Registration_LocationName");
		npi = PropLoader.props.apply("Registration_NPI");
		address = PropLoader.props.apply("Registration_Address");
		city = PropLoader.props.apply("Registration_City");
		zip = PropLoader.props.apply("Registration_Zip");
		phone = PropLoader.props.apply("Registration_Phone");
		fax = PropLoader.props.apply("Registration_Fax");
		inValidEmail = PropLoader.props.apply("Registration_InValidEmail");
		alertTitle = PropLoader.props.apply("Registration_Alert_Title");
		alertCnt = PropLoader.props.apply("Registration_Alert_Content");
		newEmail = PropLoader.props.apply("Registration_NewEmail");
		blankValue = PropLoader.props.apply("BlankValue");
		registrationLabels = PropLoader.listProps.apply("RegistrationLabel");
		registrationAddressLabels = PropLoader.listProps.apply("RegistrationAddressLabel");
	}

	public boolean clickRegisterButton() {
		signUpPage = new SignUpPage(driver);
		return signUpPage.clickRegisterButton();
	}

	public boolean verifyUserTypeDropdownPresent() {
		signUpPage = new SignUpPage(driver);
		return signUpPage.verifyUserTypeDropdownPresent();
	}

	public void clickUserTypeDropdown() {
		signUpPage = new SignUpPage(driver);
		signUpPage.clickUserTypeDropdown();
	}

	public boolean verifyUserTypeListPresent() {
		signUpPage = new SignUpPage(driver);
		return signUpPage.verifyUserTypeListPresent();
	}

	public boolean verifyUserTypeListOrder() {
		signUpPage = new SignUpPage(driver);
		return signUpPage.verifyUserTypeListOrder();
	}

	public void checkUserTypeDropdownValuesUserType(String userType) {
		signUpPage = new SignUpPage(driver);
		signUpPage.checkUserTypeDropdownValuesUserType(userType);
	}

	public boolean verifyPortalProviderTypeDropdownPresent() {
		signUpPage = new SignUpPage(driver);
		return signUpPage.verifyPortalProviderTypeDropdownPresent();
	}

	public void clickPortalProviderTypeDropdown() {
		signUpPage = new SignUpPage(driver);
		signUpPage.clickPortalProviderTypeDropdown();
	}

	public boolean verifyPortalProviderTypeListPresent() {
		signUpPage = new SignUpPage(driver);
		return signUpPage.verifyPortalProviderTypeListPresent();
	}

	public boolean verifyPortalProviderTypeListSortorder() {
		signUpPage = new SignUpPage(driver);
		return signUpPage.verifyPortalProviderTypeListSortorder();
	}

	public void checkPortalProviderTypeDropdownvalues(String portalProviderType) {
		signUpPage = new SignUpPage(driver);
		signUpPage.checkPortalProviderTypeDropdownvalues(portalProviderType);
	}

	public boolean verifyHealthPlanDropdownPresent() {
		signUpPage = new SignUpPage(driver);
		return signUpPage.verifyHealthPlanDropdownPresent();
	}

	public void clickHealthPlanDropdown() {
		signUpPage = new SignUpPage(driver);
		signUpPage.clickHealthPlanDropdown();
	}

	public boolean verifyHealthPlanListPresent() {
		signUpPage = new SignUpPage(driver);
		return signUpPage.verifyHealthPlanListPresent();
	}

	public boolean verifyHealthPlanListOrder() {
		signUpPage = new SignUpPage(driver);
		return signUpPage.verifyHealthPlanListOrder();
	}

	public boolean verifyNoDefaultValueSelected() {
		signUpPage = new SignUpPage(driver);
		return signUpPage.verifyNoDefaultValueSelected();
	}

	public void checkHealthPlanDropdownValuesHealthPlan(String healthPlan) {
		signUpPage = new SignUpPage(driver);
		signUpPage.checkHealthPlanDropdownValuesHealthPlan(healthPlan);
	}

	public boolean verifyStateDropdownPresent() {
		signUpPage = new SignUpPage(driver);
		return signUpPage.verifyStateDropdownPresent();
	}

	public void clickStateDropdown() {
		signUpPage = new SignUpPage(driver);
		signUpPage.clickStateDropdown();
	}

	public boolean verifyStateListPresent() {
		signUpPage = new SignUpPage(driver);
		return signUpPage.verifyStateListPresent();
	}

	public boolean verifyStateListOrder() {
		signUpPage = new SignUpPage(driver);
		return signUpPage.verifyStateListSortorder();
	}

	public void checkStateDropdownValues(List<List<String>> stateDetails) {
		signUpPage = new SignUpPage(driver);
		signUpPage.checkStateDropdownvalues(stateDetails);
	}

	public void selectOptionFromHealthPlan(String option) {
		signUpPage = new SignUpPage(driver);
		signUpPage.selectOptionFromHealthPlan(option);
	}

	public boolean verifyAlertMessage() {
		signUpPage = new SignUpPage(driver);
		return signUpPage.verifyAlertMessage();
	}

	public boolean goToMainPage() {
		signUpPage = new SignUpPage(driver);
		return signUpPage.goToMainPage();
	}

	public void enterDetailsInAllFields(String firstName,String  lastName, String Email, String Location, String NPI, String Address, String City, String Zip, String Phone, String Fax) {
		//readPropFileMainPage();
		signUpPage = new SignUpPage(driver);
		signUpPage.enterDetailsInAllFields(firstName, lastName, Email, Location, NPI, Address, City, Zip, Phone, Fax);
	}

	public boolean verifyLocationDetailsFetched(String Location, String NPI, String Address, String City, String Zip, String Phone) {
		//readPropFileMainPage();
		signUpPage = new SignUpPage(driver);
		return signUpPage.verifyLocationDetailsFetched(Location, NPI, Address, City, Zip, Phone);
	}

	public void selectLocationDetails() {
		signUpPage = new SignUpPage(driver);
		signUpPage.selectLocationDetails();
	}

	public void enterIncorrectEmail(String firstName,String lastName, String InvalidEmail, String Location, String NPI, String Address, String City, String Zip, String Phone,String Fax) {
		//readPropFileMainPage();
		signUpPage = new SignUpPage(driver);
		signUpPage.enterDetailsInAllFields(firstName, lastName, InvalidEmail, Location, NPI, Address, City, Zip, Phone,Fax);
	}

	public boolean verifyAlertErrMsg() {
		readPropFileMainPage();
		signUpPage = new SignUpPage(driver);
		return signUpPage.verifyAlertErrMsg(alertTitle, alertCnt);
	}

	public void clickVerifyBtn() {
		signUpPage = new SignUpPage(driver);
		signUpPage.clickVerifyBtn();
	}

	public boolean verifyEmailValidationMsg() {
		signUpPage = new SignUpPage(driver);
		return signUpPage.verifyEmailValidationMsg();
	}

	public void enterDetailsInAllFieldsWithNewEmailID() {
		readPropFileMainPage();
		signUpPage = new SignUpPage(driver);
		signUpPage.enterDetailsInAllFields(firstNm, lastNm, newEmail, location, npi, address, city, zip, phone, fax);

	}

	public void enterDetailsInMandatoryFields(String fieldName,String blankValue,String firstName,String lastName,String Email,String Location,String NPI) {
		//readPropFileMainPage();
		signUpPage = new SignUpPage(driver);
		signUpPage.enterDetailsInMandatoryFields(fieldName, blankValue, firstName, lastName, Email, Location, NPI);
	}

	public boolean verifyMissingFieldsErrMsg(String fieldName) {
		signUpPage = new SignUpPage(driver);
		return signUpPage.verifyMissingFieldsErrMsg(fieldName);
	}

	public boolean verifyRegisterPageLabels() {
		readPropFileMainPage();
		signUpPage = new SignUpPage(driver);
		return signUpPage.verifyRegisterPageLabels(registrationLabels);
	}

	public boolean verifyRegisterPageAddressLabels() {
		readPropFileMainPage();
		signUpPage = new SignUpPage(driver);
		return signUpPage.verifyRegisterPageAddressLabels(registrationAddressLabels);
	}

	public void clickSinguUplnk() {
		signUpPage = new SignUpPage(driver);
		signUpPage.clickSinguUplnk();

	}

	public boolean verifylnkEFTERACAQH() {
		signUpPage = new SignUpPage(driver);
		return signUpPage.verifylnkEFTERACAQH();
	}

	public boolean verifylnkERAEnrollmentFAQ() {
		signUpPage = new SignUpPage(driver);
		return signUpPage.verifylnkERAEnrollmentFAQ();
	}

	public boolean verifylnkERAPaperEnrollment() {
		signUpPage = new SignUpPage(driver);
		return signUpPage.verifylnkERAPaperEnrollment();
	}

	public boolean clickEFTERACAQHVerifyCAQHRegisterisDisplayed() {
		signUpPage = new SignUpPage(driver);
		return signUpPage.clickEFTERACAQHVerifyCAQHRegisterisDisplayed();
	}

	public void clicklnkERAEnrollmentFAQ() {
		signUpPage = new SignUpPage(driver);
		signUpPage.clicklnkERAEnrollmentFAQ();

	}

	public void clicklnkERAPaperEnrollment() {
		signUpPage = new SignUpPage(driver);
		signUpPage.clicklnkERAPaperEnrollment();

	}

	public void verifyFileDownloaded(String fileName) {
		signUpPage = new SignUpPage(driver);
		signUpPage.verifyFileDownloaded(fileName);
	}

	public void enterUserTypeDetails(String userType, String portalProviderType, String healthPlan) {
		signUpPage = new SignUpPage(driver);
		signUpPage.enterUserTypeDetails(userType, portalProviderType, healthPlan);
	}

	public void enterUserContactDetails() {
		readPropFileMainPage();
		signUpPage = new SignUpPage(driver);
		signUpPage.enterUserContactDetails(firstNm, lastNm, newEmail, location, npi);
	}

	public void enterUserAddressDetails() {
		readPropFileMainPage();
		signUpPage = new SignUpPage(driver);
		signUpPage.enterUserAddressDetails(address, city, zip, phone, fax);
	}
}
