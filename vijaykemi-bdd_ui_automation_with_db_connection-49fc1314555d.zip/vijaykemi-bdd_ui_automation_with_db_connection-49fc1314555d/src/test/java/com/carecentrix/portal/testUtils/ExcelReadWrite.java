package com.carecentrix.portal.testUtils;

import java.io.FileInputStream;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.Predicate;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class ExcelReadWrite {

	int rowNumber;
	private String path;
	XSSFWorkbook myExcelBook = null;
	public final Logger log = LogManager.getLogger(ExcelReadWrite.class);

	public ExcelReadWrite(String spath) {
		path = spath;
	}

	public int findColNumber(final String columnName, String sheetName) throws IOException {
		myExcelBook = new XSSFWorkbook(new FileInputStream(path));
		XSSFSheet sheet = myExcelBook.getSheet(sheetName);
		XSSFRow row = sheet.getRow(0);
		final List<String> cellValues = new ArrayList<String>();
		String cellValue = "";
		row.forEach(new Consumer<Cell>() {
			@Override
			public void accept(Cell r) {
				cellValues.add(r.getStringCellValue());
			}
		});
		Optional<String> value = cellValues.stream().filter(new Predicate<String>() {
			@Override
			public boolean test(String e) {
				return e.equals(columnName);
			}
		}).findFirst();
		if (value.isPresent()) {
			cellValue = value.get();
		}
		return cellValues.indexOf(cellValue);
	}

	public int findRow(final String mapValue, String sheetName) throws IOException {
		myExcelBook = new XSSFWorkbook(new FileInputStream(path));
		XSSFSheet sheet = myExcelBook.getSheet(sheetName);
		final List<String> rows = new ArrayList<String>();
		sheet.forEach(new Consumer<Row>() {
			@Override
			public void accept(Row sh) {
				rows.clear();
				sh.forEach(new Consumer<Cell>() {
					@Override
					public void accept(Cell r) {
						rows.add(r.getStringCellValue());
					}
				});
				if (rows.stream().anyMatch(new Predicate<String>() {
					@Override
					public boolean test(String e) {
						return e.equals(mapValue);
					}
				})) {
					rowNumber = sh.getRowNum();
				}
			}
		});
		return rowNumber;
	}
	
	public int findRow1(String mapValue, String sheetName) throws IOException {
		
	
		FileInputStream fis = new FileInputStream(path);
		Workbook workbook = WorkbookFactory.create(fis);
		Sheet sheet = workbook.getSheet(sheetName);
		DataFormatter formatter = new DataFormatter();
		
		int rowTotal = sheet.getLastRowNum();
		log.info("Row Total {}",rowTotal);
		for(int i=0;i<=rowTotal;i++) {
		String val = formatter.formatCellValue(sheet.getRow(i).getCell(1));
		if(val.equals(mapValue)) {
			rowNumber=i;
			break;
		}
		}
		return rowNumber;
		
	}
	
	public int findLastcolumn(String mapValue, String sheetName) throws IOException {
	    int noOfColumns=0;
		myExcelBook = new XSSFWorkbook(new FileInputStream(path));
		XSSFSheet sheet = myExcelBook.getSheet(sheetName);
		noOfColumns = sheet.getRow(0).getLastCellNum();
		log.info("mapValue {}",mapValue);
		return noOfColumns;
	}
	
	//############################# Utility Methods#################################
	
	public String getTestcaseType(String scenario) {
	   	
	      
        String[] arrSplit = scenario.split("_");
        for (int i=0; i < arrSplit.length; i++)
        {
          log.info("TestScenario sections {}" ,arrSplit[i]);
      			         
        }
        log.info("TestScenario {}" ,arrSplit[2]);
     	
	return arrSplit[2];
}
	
	public int getRndNumber() throws NoSuchAlgorithmException {
	    Random random = SecureRandom.getInstanceStrong();  // SecureRandom is preferred to Random
	    int randomNumber=0;
	    boolean loop=true;
	    while(loop) {
	        randomNumber=random.nextInt();
	        if(Integer.toString(randomNumber).length()==10 && !Integer.toString(randomNumber).startsWith("-")) {
	            loop=false;
	        }
	        }
	    return randomNumber;

}
	
	public String getRandomGenerate(int len) {
		return UUID.randomUUID().toString().replaceAll("[-+.^:,]", "").substring(0, len).toUpperCase();
		}
}