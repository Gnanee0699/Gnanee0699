package com.carecentrix.portal.stepdefinitions;

import java.io.IOException;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;

import com.carecentrix.portal.testUtils.ExcelReader;
import com.carecentrix.portal.testpages.TestContactUSPage;
import com.carecentrix.portal.testpages.TestLoginPage;
import com.carecentrix.utilities.BasePage;
import com.carecentrix.utilities.Constant;
import com.carecentrix.utilities.SeleniumMethods;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 * @author MMVADAG
 */

public class ContactUSStepDef extends BasePage{
	
	private static final Logger log = LogManager.getLogger(LoginStepDef.class);

	TestContactUSPage testContactUSPage = new TestContactUSPage();
	
	TestLoginPage testLoginPage = new TestLoginPage();
	
	Constant constant = new Constant();

	@When("^Click on ContactUS link$")
	public void clickContactUSlnk() {
		testContactUSPage.clickContactUS();
	}

	@When("^Click on Submit$")
	public void clickSubmit() {
		testContactUSPage.clickSubmit();
	}

	
	
	@Then("^Enter Contact Name$" )
	public void enterContactName() throws IOException {
		

		String ContactName = (String) constant.dataMap.get("ContactName");
		testContactUSPage.enterContactName(ContactName);
	}

	@Then("^Enter Contact Phone$")
	public void enterContactPhone() {
		String strContactPhone = (String) constant.dataMap.get("ContactPhone");
		testContactUSPage.enterContactPhone(strContactPhone);
	}

	@When("^Enter ContactUS Details$")
	public void enterContactUSPageDetails() {
		testContactUSPage.enterContactUSDetails();
	}

	@Then("^Enter Email$")
	public void enterEmail() {
		String strEmail = (String) constant.dataMap.get("Email");
		testContactUSPage.enterEmail(strEmail);
	}

	@Then("^Enter Inquiry Message$")
	public void enterInquiryMessage() throws IOException, InterruptedException {
		String strInquiryMessage = (String) constant.dataMap.get("InquiryMessage");
		testContactUSPage.enterInquiryMessage(strInquiryMessage);
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "ContactUs page");
		log.info(Constant.SCRLOGSHT_MSG, "ContactUs page");
	}

	@Then("^Select Inquiry Reason$")
	public void selectInquiryReason() {
		String strInquiryReason = (String) constant.dataMap.get("InquiryReason");
		testContactUSPage.selectInquiryReason(strInquiryReason);
	}

	@Then("^Select Inquiry Type$")
	public void selectInquiryType() {
		String strInquiryType = (String) constant.dataMap.get("InquiryType");
		testContactUSPage.selectInquiryType(strInquiryType);
	}

	@Then("^Verify HIPPAA Alert Message$")
	public boolean verifyAlertMessage() throws IOException, InterruptedException {
		return testContactUSPage.verifyAlertMessage();
	}

	@Then("Verify default option selected$")
	public void verifyDefaultOptionSelected() throws IOException, InterruptedException {
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "ContactUs page");
		log.info(Constant.SCRLOGSHT_MSG, "ContactUs page");
		String inquiryReason = (String) constant.dataMap.get("InquiryReason");
		Assert.assertEquals(true, testContactUSPage.verifyDefaultOptionSelected(inquiryReason));
	}

	@Then("^Verify Information Sent Message displayed successfully$")
	public boolean verifyInfoMsgSent() {
		return testContactUSPage.verifyInfoMsgSent();
	}
}
