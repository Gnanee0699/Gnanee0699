package com.carecentrix.portal.stepdefinitions;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;

import com.carecentrix.portal.testUtils.ExcelReader;
import com.carecentrix.portal.testpages.TestDiagnosisPage;
import com.carecentrix.portal.testpages.TestLoginPage;
import com.carecentrix.portal.testpages.TestMemberInfoPage;
import com.carecentrix.utilities.Constant;
import com.carecentrix.utilities.SeleniumMethods;

import cucumber.api.DataTable;
import cucumber.api.java.en.Then;

public class DiagnosisStepDef {

	TestLoginPage testLoginPage = new TestLoginPage();
	MemberInfoStepDef memberInfoStepDef = new MemberInfoStepDef();
	TestDiagnosisPage testDiagnosisPage = new TestDiagnosisPage();
	TestMemberInfoPage testMemberInfoPage = new TestMemberInfoPage();
	//Map<String, Object> dataMap;
	private static final Logger log = LogManager.getLogger(DiagnosisStepDef.class);
	
	Constant constant = new Constant();

	@Then("^Click Create Request button$")
	public void clickCreateRequestbutton() throws IOException, InterruptedException {
		memberInfoStepDef.clickonCreateRequestbutton();
	}

	@Then("^Check availability of Diagnosis tab$")
	public boolean checkavailabilityofDiagnosistab() throws IOException, InterruptedException {
		boolean diagnosisTabAvailable = false;
		String strfirstName = (String) constant.dataMap.get("firstName");
		String strlastName = (String) constant.dataMap.get("lastName");
		String strdob = (String) constant.dataMap.get("dob");
		String strhealthPlan = (String) constant.dataMap.get("healthPlan");
		String strsubscriberId = (String) constant.dataMap.get("subscriberId");
		String strreferralType = (String) constant.dataMap.get("referralType");
		String strearlierRequestedStartDate = (String) constant.dataMap.get("earlierRequestedStartDate");
		if (testMemberInfoPage.isMemberInfoTabAvailable()) {
			memberInfoStepDef.fillmemberInfodetails(strlastName,strfirstName,strdob,strhealthPlan,strsubscriberId,strreferralType,strearlierRequestedStartDate);
		} else if (testDiagnosisPage.isDiagnosisTabEnabled()) {
			log.info("Diagnosis Page is enabled");
			diagnosisTabAvailable = true;
		}
		return diagnosisTabAvailable;
	}
	//Updated for external test data.
	@Then("^Enter searchICDCode$")
	public void entersearchICDCode() {
		try {
		//dataMap = ExcelReader.readAllRow("EPE2EData", scenario);
		String ICDCode = (String) constant.dataMap.get("ICDCode");
		Assert.assertEquals(true, testDiagnosisPage.searchICDCode(ICDCode));
	} catch (Exception e) {
		e.printStackTrace();
	}
	}

	@Then("^Click on Search button$")
	public void clickonSearchbutton() throws IOException, InterruptedException {
		testDiagnosisPage.clickSearchButton();
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Diagnosis page");
		log.info(Constant.SCRLOGSHT_MSG, "Diagnosis page");
	}
	//Updated for external test data.
	@Then("^Verify search result \"([^\"]*)\"$")
	public void verifysearchresult(String scenario) {
		try {
		//	dataMap = ExcelReader.readAllRow("EPE2EData", scenario);
			String ICDCode = (String) Constant.dataMap.get("ICDCode");
		testDiagnosisPage.verifySearchResult(ICDCode);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Then("^Enter Description$")
	public void enterDescription() {
		String strdescription = (String) constant.dataMap.get("ICDDescription");
		testDiagnosisPage.searchByDescription(strdescription);
	}
	//Updated for external test data.
	
	@Then("^Enter searchICDCode and Description \"([^\"]*)\"$")
	public void entersearchICDCodeandDescription(String scenario) {
		
		try {
		//	dataMap = ExcelReader.readAllRow("EPE2EData", scenario);
			
			String ICDCode = (String) constant.dataMap.get("ICDCode");
			String ICDDescription = (String) constant.dataMap.get("ICDDescription");
			testDiagnosisPage.searchByICDCodeAndDescription(ICDCode, ICDDescription);
			SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Diagnosis Sear");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Then("^Click Add button from result$")
	public void clickAddbuttonfromresult() {
		testDiagnosisPage.clickAddButton();
	}
	
	@Then("^Click Next Available Add button from result$")
	public void clickNextAddbuttonfromresult() throws IOException, InterruptedException {
		testDiagnosisPage.clickNextAvailableAddButton();
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Add Button");
		log.info(Constant.SCRLOGSHT_MSG, "Add Button");
	}

	@Then("^Click Primary button$")
	public void clickPrimarybutton() {
		testDiagnosisPage.clickPrimaryButton();
	}

	@Then("^Check Primary option added$")
	public void checkprimaryoptionadded() throws IOException, InterruptedException {
		Assert.assertEquals(true, testDiagnosisPage.isPrimaryOptionAdded());
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Primary option");
		log.info(Constant.SCRLOGSHT_MSG, "Primary option");
	}

	@Then("^Click Secondary button$")
	public void clickSecondarybutton() {
		testDiagnosisPage.clickSecondaryButton();
	}

	@Then("^Check Secondary option added$")
	public void checksecondaryoptionadded() throws IOException, InterruptedException {
		testDiagnosisPage.isSecondaryOptionAdded();
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Secondary option");
		log.info(Constant.SCRLOGSHT_MSG, "Secondary option");
	}

	@Then("^Click Tertiary button$")
	public void clickTertiarybutton() {
		testDiagnosisPage.clickTertiaryButton();
	}

	@Then("^Check Tertiary option added$")
	public void checktertiaryoptionadded() throws IOException, InterruptedException {
		testDiagnosisPage.isTertiaryOptionAdded();
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Tertiary option");
		log.info(Constant.SCRLOGSHT_MSG, "Tertiary option");
	}

	@Then("^Click Other button$")
	public void clickOtherbutton() {
		testDiagnosisPage.clickOtherButton();
	}

	@Then("^Check Other option added$")
	public void checkotheroptionadded() throws IOException, InterruptedException {
		testDiagnosisPage.isOtherOptionAdded();
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Other option");
		log.info(Constant.SCRLOGSHT_MSG, "Other option");
	}

	@Then("^Close the browser$")
	public void closethebrowser() {
		testDiagnosisPage.closebrowser();
	}

	@Then("^Click Next Button$")
	public void clickNextButton() {
		testDiagnosisPage.clickNextButton();
	}

	@Then("^Check error message to add Primary$")
	public void checkerrormessagetoaddPrimary() throws IOException, InterruptedException {
		testDiagnosisPage.checkErrorMessage();
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Error Msg Primary");
		log.info(Constant.SCRLOGSHT_MSG, "Error Msg Primary");
	}

	@Then("^Verify Diagnosis Types$")
	public void verifyDiagnosisType() throws IOException, InterruptedException {
		String diagnosisType = (String) constant.dataMap.get("DiagnosisType");
		String[] data = diagnosisType.split(":");
		String diagnosisNamePrimary = data[0];
		String diagnosisNameSecondary = data[1];
		String diagnosisNameTertiary = data[2];
		String diagnosisNameOther = data[3];
		testDiagnosisPage.verifyDiagnosisTypes(diagnosisNamePrimary, diagnosisNameSecondary, diagnosisNameTertiary,
				diagnosisNameOther);
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Verify Diagnosis Types");
		log.info(Constant.SCRLOGSHT_MSG, "Verify Diagnosis Types");
	}

	@Then("^Enter invalid ICDCode and Description$")
	public void enterinvalidICDCodeDescription() {
		testDiagnosisPage.searchByInvalidICDCodeAndDescription();
	}

	@Then("^Verify error message to update search criteria$")
	public void verifyerrormessagetoupdatesearchcriteria() throws IOException, InterruptedException {
		Assert.assertEquals(true, testDiagnosisPage.verifyErrorMessageToUpdateSearchCriteria());
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Verifyerror message");
		log.info(Constant.SCRLOGSHT_MSG, "Verify error message");
	}

	@Then("^Enter ICDCode or Description to get more records$")
	public void enterDetailsToGetMoreRecords() {
		testDiagnosisPage.enterDetailsToGetMoreRecords();
	}

	@Then("^Verify error message for more than 50 records$")
	public void verifyerrormessageformorerecords() throws IOException, InterruptedException {
		Assert.assertEquals(true, testDiagnosisPage.verifyErrorMessageForMoreRecords());
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Verify error morethan50");
		log.info(Constant.SCRLOGSHT_MSG, "Verify error message");
	}

	public void filldiagnosisdetails(String ICDCode) {
		try {
		//	dataMap = ExcelReader.readAllRow("EPE2EData", scenario);
			//ICDCode = (String) dataMap.get("ICDCode");
			log.info("Diagnosis Tab not filled so entering details in Diagnosis Tab");
			testDiagnosisPage.searchICDCode(ICDCode);
		//entersearchICDCode(ICDCode);
		clickonSearchbutton();
		clickAddbuttonfromresult();
		clickPrimarybutton();
		checkprimaryoptionadded();
		clickNextButton();
	} catch (Exception e) {
		e.printStackTrace();
	}
	}

	@Then("^Choose Diagnosis Type \"([^\"]*)\"$")
	public void chooseDiagType(String digTyp) {
		testDiagnosisPage.chooseDiagType(digTyp);
	}

	@Then("^Check Primary option disabled$")
	public void checkPrimaryOptionDisabled() {
		Assert.assertEquals(true, testDiagnosisPage.checkPrimaryOptionDisabled());
	}
	
	
}
