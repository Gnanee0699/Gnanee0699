package com.carecentrix.portal.testrunner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;

/**
 * @author KJ
 *
 */

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(glue = { "com/carecentrix/portal/stepdefinitions/" }, features = "src/test/resources/feature/",

		plugin = { "pretty",
				"html:target/cucumber-html-report" }, monochrome = true, strict = false, dryRun = false, tags = {
					"@001_EP-CAR785_Services" })

public class ServicesTestRunner {

}
