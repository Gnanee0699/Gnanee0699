	package com.carecentrix.portal.stepdefinitions;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;

import com.carecentrix.portal.testUtils.ExcelReader;
import com.carecentrix.portal.testpages.TestEnd2end;
import com.carecentrix.portal.testpages.TestReferralInfoPage;

import cucumber.api.DataTable;
import cucumber.api.java.en.Then;

/**
 * @author MD
 *
 */

public class End2endStepDef {

	TestEnd2end testEnd2end = new TestEnd2end();
	
	private static final Logger log = LogManager.getLogger(End2endStepDef.class);
	
	// MD - Using map to get the test data
			Map<String, Object> dataMap;

	
}
