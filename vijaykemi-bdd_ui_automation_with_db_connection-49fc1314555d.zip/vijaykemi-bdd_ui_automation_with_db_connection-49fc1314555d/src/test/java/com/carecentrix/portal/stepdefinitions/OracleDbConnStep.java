package com.carecentrix.portal.stepdefinitions;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;

import com.carecentrix.portal.testUtils.ExcelReader;
import com.carecentrix.portal.testpages.TestLoginPage;
import com.carecentrix.utilities.BasePage;
import com.carecentrix.utilities.Constant;
import com.carecentrix.utilities.DatabaseTool;
import com.carecentrix.utilities.PropLoader;
import com.carecentrix.utilities.SeleniumMethods;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 * @author KJ
 *
 */

public class OracleDbConnStep {

	private static final Logger log = LogManager.getLogger(OracleDbConnStep.class);

	Constant constant = new Constant();

	
		
	
	@Then("^Get the serviceauthdetails using the requestid \"([^\"]*)\" and \"([^\"]*)\"$")
	public void getCorrelationId(String scenario, String sheetname) throws SQLException {
		
	
		try {
			
			constant.dataMap = ExcelReader.readAllRow(sheetname, scenario);	
			//System.out.println("map is --- "+constant.dataMap);
						
			String env = (String) constant.dataMap.get("environment");
			
//			String epRequestID="a3af8879-4563-471e-916e-de68e37468b5";
			String epRequestID=Constant.RequestID;
			
//			String env ="Q1";
			String databaseType=PropLoader.props.apply("databaseType");
			String correlationId = "";

//			String sqlQuery1= "select json_value(SRFSVC.AUTH_PAYLOAD_DHS_FINAL, '$.payload.caseDetails.caseId' RETURNING VARCHAR2(100)) as caseid,"
//					+ "json_value(SRFSVC.AUTH_PAYLOAD_UM_FINAL, '$.header.eventCorrelationId' RETURNING VARCHAR2(100)) as correlation_id,"
//					+"SRFSVC.* from SRFSVC.DHS_SERVICE_AUTH SRFSVC where "
//					+"json_value(SRFSVC.AUTH_PAYLOAD_DHS_FINAL, '$.payload.caseDetails.caseId'"
//					+ " RETURNING VARCHAR2(100))IN( "
//					+"SELECT SUBSTR(json_value(CASE_DETAILS, '$[0].case_service_line_number'"
//					+ " RETURNING VARCHAR2(100)),1,15) as CASELine "
//					+"FROM "
//					+"ENHANCEDPORTAL.referral_cases where REQUEST_ID IN('"+epRequestID+"'))"
//					+"";

			String sqlQuery1= "select json_value(SRFSVC.AUTH_PAYLOAD_DHS_FINAL, '$.payload.caseDetails.caseId' RETURNING VARCHAR2(100)) as caseid,json_value(SRFSVC.AUTH_PAYLOAD_UM_FINAL, '$.header.eventCorrelationId' RETURNING VARCHAR2(100)) as correlation_id,SRFSVC.* from SRFSVC.DHS_SERVICE_AUTH SRFSVC where json_value(SRFSVC.AUTH_PAYLOAD_DHS_FINAL, '$.payload.caseDetails.caseId' RETURNING VARCHAR2(100))IN(SELECT SUBSTR(json_value(CASE_DETAILS, '$[0].case_service_line_number' RETURNING VARCHAR2(100)),1,15) as CASELine FROM ENHANCEDPORTAL.referral_cases where REQUEST_ID IN('"+epRequestID+"'))";
			Map<Integer, Map<String, String>> lMap = new LinkedHashMap<Integer, Map<String, String>>();
			
			lMap = (Map<Integer, Map<String, String>>) DatabaseTool.getData(env, databaseType, sqlQuery1);
			log.info("Map size id "+lMap.size());

			for(int i1=1;i1<lMap.size()+1;i1++)
			{
//				correlationId= lMap.get(i1).get("CORRELATION_ID");
				System.out.println("SQL OP : "+lMap);
				Constant.NewCaseID= lMap.get(i1).get("CASEID");
				Constant.correlationId= lMap.get(i1).get("CORRELATION_ID");
//				System.out.println("CORR Id: "+correlationId);
//				log.info("Map size id "+lMap.size());
			}
			
//			System.out.println(" correlation id is " + correlationId);
			log.info("case id is : "+Constant.NewCaseID);
			log.info("correlation id is : "+Constant.correlationId);
			
//************************To check whether the request loaded successfully in coretable**********************************************************
//			String sqlQuery2= "select json_value(PAYLOAD_INCMG_OBJ, '$.payload.caseServiceLine[0].referralAndReauthRequest[0].patientLastName' RETURNING VARCHAR2(100)) as patientLastName, json_value(PAYLOAD_INCMG_OBJ, '$.payload.caseServiceLine[0].referralAndReauthRequest[0].patientFirstName' RETURNING VARCHAR2(100)) as patientFirstName,json_value(PAYLOAD_INCMG_OBJ, '$.payload.caseServiceLine[0].referralAndReauthRequest[0].patientDob' RETURNING VARCHAR2(100)) as patientDob,json_value(PAYLOAD_INCMG_OBJ, '$.payload.caseServiceLine[0].referralAndReauthRequest[0].patientSubscriberId' RETURNING VARCHAR2(100)) as patientSubscriberId,json_value(PAYLOAD_INCMG_OBJ, '$.payload.caseServiceLine[0].referralAndReauthRequest[0].patientPlanId' RETURNING VARCHAR2(100)) as patientPlanId,EVTHE.* from DHUB_ORCH.ep_event_tracking_header EVTHE where EVENT_CORL_GUID IN('de67ce84-d4d5-4646-a2fb-2fd472ddec4f')";
			String sqlQuery2= "select json_value(PAYLOAD_INCMG_OBJ, '$.payload.caseServiceLine[0].referralAndReauthRequest[0].patientLastName' RETURNING VARCHAR2(100)) as patientLastName, json_value(PAYLOAD_INCMG_OBJ, '$.payload.caseServiceLine[0].referralAndReauthRequest[0].patientFirstName' RETURNING VARCHAR2(100)) as patientFirstName,json_value(PAYLOAD_INCMG_OBJ, '$.payload.caseServiceLine[0].referralAndReauthRequest[0].patientDob' RETURNING VARCHAR2(100)) as patientDob,json_value(PAYLOAD_INCMG_OBJ, '$.payload.caseServiceLine[0].referralAndReauthRequest[0].patientSubscriberId' RETURNING VARCHAR2(100)) as patientSubscriberId,json_value(PAYLOAD_INCMG_OBJ, '$.payload.caseServiceLine[0].referralAndReauthRequest[0].patientPlanId' RETURNING VARCHAR2(100)) as patientPlanId,EVTHE.* from DHUB_ORCH.ep_event_tracking_header EVTHE where EVENT_CORL_GUID IN('"+Constant.correlationId+"')";
			
			log.info("sqlQuery2 is "+sqlQuery2);
			
			Map<Integer, Map<String, String>> lMap2 = new LinkedHashMap<>();
			
			lMap2 = (Map<Integer, Map<String, String>>) DatabaseTool.getData(env, databaseType, sqlQuery2);
			log.info("Map size id "+lMap2);
			log.info("Map size id "+lMap2.size());
			
			for(int i1=1;i1<lMap2.size()+1;i1++)
			{
//				correlationId= lMap.get(i1).get("CORRELATION_ID");
				System.out.println("SQL OP : "+lMap2);
				Constant.ERROR_MSG_TXT= lMap2.get(i1).get("ERROR_MSG_TXT");
				System.out.println("ERROR_MSG_TXT: "+Constant.ERROR_MSG_TXT);
				log.info("ERROR_MSG_TXT: "+Constant.ERROR_MSG_TXT);
			}
//************************To Get the REF_REQUEST_ID**********************************************************

			String sqlQuery3= "select RFPAT.REF_REQUEST_ID,RFPAT.CREATEDTIMESTAMP, RFPAT.* from networx_owner.referral_patient RFPAT where RFPAT.REF_PATIENT_FNAME=(select json_value(PAYLOAD_INCMG_OBJ, '$.payload.caseServiceLine[0].referralAndReauthRequest[0].patientFirstName' RETURNING VARCHAR2(100)) as patientFirstName from DHUB_ORCH.ep_event_tracking_header where EVENT_CORL_GUID IN('"+Constant.correlationId+"')) and RFPAT.REF_PATIENT_LNAME=(select json_value(PAYLOAD_INCMG_OBJ, '$.payload.caseServiceLine[0].referralAndReauthRequest[0].patientLastName' RETURNING VARCHAR2(100)) as patientFirstName from DHUB_ORCH.ep_event_tracking_header where EVENT_CORL_GUID IN('"+Constant.correlationId+"')) and RFPAT.REF_PATIENT_SUBSCRIBER_ID=(select json_value(PAYLOAD_INCMG_OBJ, '$.payload.caseServiceLine[0].referralAndReauthRequest[0].patientSubscriberId' RETURNING VARCHAR2(100)) as patientFirstName from DHUB_ORCH.ep_event_tracking_header where EVENT_CORL_GUID IN('"+Constant.correlationId+"')) and RFPAT.REF_PATIENT_PLAN_ID=(select json_value(PAYLOAD_INCMG_OBJ, '$.payload.caseServiceLine[0].referralAndReauthRequest[0].patientPlanId' RETURNING VARCHAR2(100)) as patientFirstName from DHUB_ORCH.ep_event_tracking_header where EVENT_CORL_GUID IN('"+Constant.correlationId+"')) order by RFPAT.CREATEDTIMESTAMP desc fetch first 1 rows only";
			
			log.info("sqlQuery3 is "+sqlQuery3);
			
			Map<Integer, Map<String, String>> lMap3 = new LinkedHashMap<>();
			
			lMap3 = (Map<Integer, Map<String, String>>) DatabaseTool.getData(env, databaseType, sqlQuery3);
			log.info("Map size id "+lMap3);
			log.info("Map size id "+lMap3.size());
			
			for(int i1=1;i1<lMap3.size()+1;i1++)
			{				
				System.out.println("SQL OP : "+lMap3);
				Object k = lMap3.get(i1).get("REF_REQUEST_ID");		
				Constant.REF_REQUEST_ID=k.toString();
				Object kpln = lMap3.get(i1).get("REF_PATIENT_PLAN_ID");		
				Constant.REF_PATIENT_PLAN_ID=kpln.toString();
				
				log.info("REF_REQUEST_ID : "+Constant.REF_REQUEST_ID);
				log.info("REF_PATIENT_PLAN_ID : "+Constant.REF_PATIENT_PLAN_ID);
			}
//************************To Get the INTAKEID**********************************************************

String sqlQuery4= "select QMA.INTAKEID,QMA.CREATEDATE,QMA.* from QUEUEMANAGER.activity QMA where APPTX_ID = '"+Constant.REF_REQUEST_ID+"' order by QMA.CREATEDATE desc fetch first 1 rows only";
			
			log.info("sqlQuery4 is "+sqlQuery4);
			
			Map<Integer, Map<String, String>> lMap4 = new LinkedHashMap<>();
			
			lMap4 = (Map<Integer, Map<String, String>>) DatabaseTool.getData(env, databaseType, sqlQuery4);
			log.info("Map size id "+lMap4);
			log.info("Map size id "+lMap4.size());
			
			for(int i1=1;i1<lMap4.size()+1;i1++)
			{				
				System.out.println("SQL OP : "+lMap4);
				Object k = lMap4.get(i1).get("INTAKEID");		
				Constant.INTAKEID=k.toString();
				Object l = lMap4.get(i1).get("CREATEDATE");
				Constant.INTAKEID_CREATED_TIME=l.toString();
				
				log.info("INTAKEID : "+Constant.INTAKEID);
				log.info("INTAKEID_CREATED_TIME : "+Constant.INTAKEID_CREATED_TIME);
			}
			
//*****************************To Get the Parent_Authid*******************************************************************************
String sqlQuery5= "select RFL.PLCHLDR_PARENTAUTHID,RFL.* from NETWORX_OWNER.REFERRAL_SERVICES RFL where REF_REQUEST_ID = '"+Constant.REF_REQUEST_ID+"'";
			
			log.info("sqlQuery4 is "+sqlQuery5);
			
			Map<Integer, Map<String, String>> lMap5 = new LinkedHashMap<>();
			
			lMap5 = (Map<Integer, Map<String, String>>) DatabaseTool.getData(env, databaseType, sqlQuery5);
			log.info("Map size id "+lMap5);
			log.info("Map size id "+lMap5.size());
			
			for(int i1=1;i1<lMap5.size()+1;i1++)
			{				
				System.out.println("SQL OP : "+lMap5);
				Object m = lMap5.get(i1).get("PLCHLDR_PARENTAUTHID");		
				Constant.Parent_Auth_ID=m.toString();
				
				
				log.info("Parent_Auth_ID : "+Constant.Parent_Auth_ID);
				
			}
//************************************************************************************************************************************			
			
			log.info("********* Auth Details below : **********************");
			log.info("Constant.RequestID : "+Constant.RequestID);
			log.info("Constant.NewCaseID : "+Constant.NewCaseID);
			log.info("Constant.correlationId : "+Constant.correlationId);
			log.info("REF_PATIENT_PLAN_ID : "+Constant.REF_PATIENT_PLAN_ID);
			log.info("Constant.REF_REQUEST_ID : "+Constant.REF_REQUEST_ID);
			log.info("Constant.INTAKEID : "+Constant.INTAKEID);
			log.info("Constant.INTAKEID_CREATED_TIME : "+Constant.INTAKEID_CREATED_TIME);
			log.info("Constant.Parent_Auth_ID : "+Constant.Parent_Auth_ID);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	
		

	
	}
	
	
	
	
}
