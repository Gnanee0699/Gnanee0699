	package com.carecentrix.portal.stepdefinitions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;

import com.carecentrix.portal.pages.ReferralInfoPage;
import com.carecentrix.portal.testUtils.ExcelReader;
import com.carecentrix.portal.testpages.TestReferralInfoPage;
import com.carecentrix.utilities.Constant;
import com.carecentrix.utilities.SeleniumMethods;

import cucumber.api.DataTable;
import cucumber.api.java.en.Then;

/**
 * @author KJ
 *
 */

public class ReferralInfoStepDef {

	TestReferralInfoPage testReferralInfoPage = new TestReferralInfoPage();
	
	private static final Logger log = LogManager.getLogger(ReferralInfoStepDef.class);
	// MD - Using map to get the test data
			Map<String, Object> dataMap;

	@Then("^User should moved to Diagnosis$")
	public void userShouldMovedToDiagnosis() {
		testReferralInfoPage.isUserMovedToDiagnosisPage();
		log.info("User is moved to Diagnosis Tab");
	}

	@Then("^Verify MemberInfo details displayed in \"([^\"]*)\" top panel$")
	public void verifyMemberInfoDetailsDisplayedInTopPanel(String tabName) {
		Assert.assertEquals(true, testReferralInfoPage.verifyMemberInfoDetails(tabName));
		log.info("Member details are present in {} top Panel", tabName);
	}

	@Then("^Verify Date format in top panel \"([^\"]*)\"$")
	public void verifyDateFormatInTopPanel(String tabName) {
		Assert.assertEquals(true, testReferralInfoPage.verifyDateFormatInTopPanel(tabName));
		log.info("Date Format is validated");
	}

	@Then("^User should moved to Services Tab$")
	public void userShouldMovedToServicesTab() {
		testReferralInfoPage.isUserMovedToServicesPage();
		log.info("User is moved to Services Tab");
	}

	@Then("^User should moved to Physician Tab$")
	public void userShouldMovedToPhysicianTab() {
		testReferralInfoPage.isUserMovedToPhysicianPage();
		log.info("User is moved to Physician Tab");
	}

	@Then("^User should moved to Location Tab$")
	public void userShouldMovedToLocationTab() {
		testReferralInfoPage.isUserMovedToLocationPage();
		log.info("User is moved to Location Tab");
	}

	@Then("^User should moved to ReferralInfo Tab$")
	public void userShouldMovedToReferralInfoTab() {
		testReferralInfoPage.isUserMovedToReferralInfoPage();
		log.info("User is moved to Additional Information Tab");
	}

	@Then("^Fill Referral Page Mandatory details$")
	public void fillReferralPageMandatoryDetails(DataTable contactMthd) {
		List<List<String>> contact = contactMthd.raw();
		testReferralInfoPage.fillMandatoryDetailsInReferralPage(contactTypes(contact));
		log.info("Referral Page info filled successfully");
	}

	@Then("^Choose contact detail$")
	public void chooseContactDetail() {
		testReferralInfoPage.chooseContactDetail();
		log.info("Contact information entered successfully");
	}

	//MD - Updated for external test data.
	@Then("^Enter Contact Info details$")
	public void enterContactInfoDetails() throws IOException, InterruptedException {
		//List<List<String>> contact = contactMthd.raw();
		try {
			//dataMap = ExcelReader.readAllRow("EPE2EData", scenario);
			String contactLastName = (String) Constant.dataMap.get("contactLastName");
			String contactFirstName = (String) Constant.dataMap.get("contactFirstName");
			String contactPhoneNumber = (String) Constant.dataMap.get("contactPhoneNumber");
			String contactMethod = (String) Constant.dataMap.get("contactMethod");
			testReferralInfoPage.enterContactInfoDetails(contactLastName, contactFirstName, contactPhoneNumber, contactMethod);
			log.info("Contact information entered successfully");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Additional information page01");
		log.info(Constant.SCRLOGSHT_MSG, "Additional information page01");
	}

	@Then("^Verify Contact list is in sort order$")
	public void verifyContactListOrder() {
		Assert.assertEquals(true, testReferralInfoPage.verifyUserTypeListOrder());
		log.info("Contact list is in Sort Order");
	}

	//MD - Updated for external test data
	@Then("^Enter Additional Info details$")
	public void enterAdditionalInfoDetails() throws IOException, InterruptedException {
		try {
			//dataMap = ExcelReader.readAllRow("EPE2EData", scenario);
			String careGiverName = (String) Constant.dataMap.get("careGiverName");
			String careGiverPhone = (String) Constant.dataMap.get("careGiverPhone");
			String allAllergies = (String) Constant.dataMap.get("allAllergies");
			String noteTextMsg = (String) Constant.dataMap.get("noteTextMsg");
			testReferralInfoPage.enterAdditionalInfoDetails(careGiverName, careGiverPhone, allAllergies, noteTextMsg);
			log.info("Additional information entered successfully");
		} catch (Exception e) {
			e.printStackTrace();
		}
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Additional information page02");
		log.info(Constant.SCRLOGSHT_MSG, "Additional information page02");
	}

	//MD - Updated for external test data
	@Then("^Select Attachment type \"([^\"]*)\" and upload document$")
	public void selectAttachementTyAndUploadDoc(String scenario) {
		try {
			dataMap = ExcelReader.readAllRow("EPE2EData", scenario);
			String attachmentType = (String) dataMap.get("attachmentType");
		testReferralInfoPage.selectAttachementTyAndUploadDoc(attachmentType);
		log.info("Attached document successfully");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Then("^Click Browse button to add attachement$")
	public void clickBrowseButtonToAddAttachement() {
		testReferralInfoPage.clickBrowseButtonToAddAttachement();
		log.info("Browse button clicked");
	}

	@Then("^Verify the document uploaded$")
	public void verifyDocumentUploaded() {
		Assert.assertEquals(true, testReferralInfoPage.verifyDocumentUploaded());
		log.info("Document uploaded successfully!");
	}

	public List<String> contactTypes(List<List<String>> contact) {
		List<String> contactMethd = new ArrayList<String>();
		contactMethd.add(contact.get(0).get(0));
		contactMethd.add(contact.get(0).get(1));
		return contactMethd;
	}

	@Then("^Click Review Request Button$")
	public void clickReviewRequestButton() throws IOException, InterruptedException {
		Thread.sleep(20000);
		Assert.assertEquals(true, testReferralInfoPage.clickReviewRequestButton());
		log.info("Review Request Button Clicked");
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Review page");
		log.info(Constant.SCRLOGSHT_MSG, "Review page");		
	}

	@Then("^Click Submit Button$")
	public void clickSubmitButton() {
		Assert.assertEquals(true, testReferralInfoPage.clickSubmitButton());
		log.info("Referral Request submitted successfully");
	}

	@Then("^Verify not completed status for \"([^\"]*)\"$")
	public void verifyNotCompletedStatus(String tabName) {
		Assert.assertEquals(true, testReferralInfoPage.isStatusNotCompleted(tabName));
		log.info("{} Status is not completed", tabName);
	}

	@Then("^Verify completed status for \"([^\"]*)\"$")
	public void verifyCompletedStatus(String tabName) {
		Assert.assertEquals(true, testReferralInfoPage.isStatusCompleted(tabName));
		log.info("{} Status is completed", tabName);
	}

	@Then("^Verify Success message displayed$")
	public void verifySuccessMsgDisplayed() {
		Assert.assertEquals(true, testReferralInfoPage.verifySuccessMsgDisplayed());
		log.info("Success message verified");
	}

	@Then("^Verify Success message details$")
	public void verifySuccMsgDetails() throws IOException, InterruptedException {
		
		Constant.RequestID=testReferralInfoPage.getReqID();
		log.info("Request id is "+ Constant.RequestID);
		Assert.assertEquals(true, testReferralInfoPage.verifySuccMsgDetails());
		log.info("Success message details are verified");
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Success page");
		log.info(Constant.SCRLOGSHT_MSG, "Success page");
	}

	@Then("^Click GoToHome Button$")
	public void clickGoToHomeButton() {
		Assert.assertEquals(true, testReferralInfoPage.clickGoToHomeButton());
		log.info("Go To Home button clicked");
	}

	@Then("^Verify Diagnosis Details$")
	public void verifyDiagnosisDetails() {
		Assert.assertEquals(true, testReferralInfoPage.verifyDiagnosisDetails());
		log.info("Diagnosis details are displayed as expected");
	}

	@Then("^Verify Services Details$")
	public void verifyServicesDetails() {
		Assert.assertEquals(true, testReferralInfoPage.verifyServicesDetails());
		log.info("Services details are displayed as expected");
	}

	@Then("^Verify Physician Details$")
	public void verifyPhysicianDetails() {
		Assert.assertEquals(true, testReferralInfoPage.verifyPhysicianDetails());
		log.info("Physician details are displayed as expected");
	}

	@Then("^Go to MemberInfo Page$")
	public void goToMemberInfoPage() {
		Assert.assertEquals(true, testReferralInfoPage.goToMemberInfoPage());
		log.info("Member Info Page Clicked");
	}

	@Then("^Go to Diagnosis Page$")
	public void goToDiagnosisPage() {
		Assert.assertEquals(true, testReferralInfoPage.goToDiagnosisPage());
		log.info("Diagnosis Page Clicked");
	}

	@Then("^Go to Services Page$")
	public void goToServicesPage() {
		Assert.assertEquals(true, testReferralInfoPage.goToServicesPage());
		log.info("Services Page Clicked");
	}

	@Then("^Go to Physician Page$")
	public void goToPhysicianPage() {
		Assert.assertEquals(true, testReferralInfoPage.goToPhysicianPage());
		log.info("Physician Page Clicked");
	}

	@Then("^Go to RederingProv Page$")
	public void goToRederingProvPage() {
		Assert.assertEquals(true, testReferralInfoPage.goToRederingProvPage());
		log.info("RederingProv Page Clicked");
	}

	@Then("^Go to AdditionalInfo Page$")
	public void goToAdditionalInfoPage() {
		Assert.assertEquals(true, testReferralInfoPage.goToAdditionalInfoPage());
		log.info("AdditionalInfo Page Clicked");
	}

	
	
}
