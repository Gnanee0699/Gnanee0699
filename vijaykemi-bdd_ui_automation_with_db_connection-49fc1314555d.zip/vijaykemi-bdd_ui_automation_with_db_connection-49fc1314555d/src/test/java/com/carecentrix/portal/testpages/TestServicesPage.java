package com.carecentrix.portal.testpages;

import com.carecentrix.portal.pages.ServicesPage;
import com.carecentrix.utilities.BasePage;
import com.carecentrix.utilities.PropLoader;

/**
 * @author KJ
 *
 */

public class TestServicesPage extends BasePage {
	ServicesPage objServicesPage;

	String skilledNursingFacility;
	String inpatientRehabilitationFacility;
	String longTermAcuteCare;
	String physicianName;
	String physicianNPI;
	String physicianZipCode;
	String physicianCity;
	String physicianState;
	String skilledNursingFacilityRevCode;
	String skilledNursingFacilityDesc;
	String inpatientRehabilitationFacilityRevCode;
	String inpatientRehabilitationFacilityDesc;
	String longTermAcuteCareRevCode;
	String longTermAcuteCareDesc;
	String physicianName1;
	String physicianNPI1;
	String physicianName2;
	String physicianNPI2;
	String stateList;

	public void readPropertyFileServicesTab() {
		try {
			skilledNursingFacility = PropLoader.props.apply("ServicesTab_SkilledNursingFacility");
			inpatientRehabilitationFacility = PropLoader.props.apply("ServicesTab_InpatientRehabilitationFacility");
			longTermAcuteCare = PropLoader.props.apply("ServicesTab_LongTermAcuteCare");
			physicianName = PropLoader.props.apply("PhysicianTab_PhysicianName");
			physicianNPI = PropLoader.props.apply("PhysicianTab_PhysicianNPI");
			physicianZipCode = PropLoader.props.apply("PhysicianTab_PhysicianZipCode");
			physicianCity = PropLoader.props.apply("PhysicianTab_PhysicianCity");
			physicianState = PropLoader.props.apply("PhysicianTab_PhysicianState");
			skilledNursingFacilityRevCode = PropLoader.props.apply("ServicesTab_SkilledNursingFacility_RevCode");
			skilledNursingFacilityDesc = PropLoader.props.apply("ServicesTab_SkilledNursingFacility_Description");
			inpatientRehabilitationFacilityRevCode = PropLoader.props
					.apply("ServicesTab_InpatientRehabilitationFacility_RevCode");
			inpatientRehabilitationFacilityDesc = PropLoader.props
					.apply("ServicesTab_InpatientRehabilitationFacility_Description");
			longTermAcuteCareRevCode = PropLoader.props.apply("ServicesTab_LongTermAcuteCare_RevCode");
			longTermAcuteCareDesc = PropLoader.props.apply("ServicesTab_LongTermAcuteCare_Description");
			physicianName1 = PropLoader.props.apply("ServicesTab_physicianName1");
			physicianNPI1 = PropLoader.props.apply("ServicesTab_physicianNPI1");
			physicianName2 = PropLoader.props.apply("ServicesTab_physicianName2");
			physicianNPI2 = PropLoader.props.apply("ServicesTab_physicianNPI2");
			stateList = PropLoader.listProps.apply("StateList");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void selectServices(String selectService) {
		objServicesPage = new ServicesPage(driver);
		readPropertyFileServicesTab();
		objServicesPage.selectSerivces(selectService, skilledNursingFacility, inpatientRehabilitationFacility,
				longTermAcuteCare);

	}
	
	//MD-Selected service selection. New function added.
	public void selectSpecificServices(String selectService) {
		objServicesPage = new ServicesPage(driver);
		//readPropertyFileServicesTab();
		objServicesPage.selectSpecificService(selectService);

	}

	public boolean isUserCanSelectService() {
		readPropertyFileServicesTab();
		return objServicesPage.isUserCanSelectService();

	}

	public boolean isServicesTabEnabled() {
		objServicesPage = new ServicesPage(driver);
		return objServicesPage.isServicesTabAvailable();

	}

	public boolean clickServicesDropDown() {
		objServicesPage = new ServicesPage(driver);
		return objServicesPage.clickServicesDropDown();

	}

	public void clickSearchButton() {
		objServicesPage = new ServicesPage(driver);
		objServicesPage.clickSearchButton();
	}

	public void quitBrowser() {
		objServicesPage = new ServicesPage(driver);
		objServicesPage.quitBrowser();
	}

	public void refreshBrowser() {
		objServicesPage = new ServicesPage(driver);
		objServicesPage.refreshBrowser();
	}

	public void selectServiceFromList() {
		objServicesPage = new ServicesPage(driver);
		objServicesPage.selectServiceFromList();

	}

	public void selectRequestType(String requestTypOption) {
		objServicesPage = new ServicesPage(driver);
		objServicesPage.selectRequestType(requestTypOption);

	}

	public void enterRequestStartDate(int Requeststartdate) {
		objServicesPage = new ServicesPage(driver);
		objServicesPage.enterRequestStartDate(Requeststartdate);
	}

	public void isServiceInitiated(String serviceInitiated) {
		objServicesPage = new ServicesPage(driver);
		objServicesPage.isServiceInitiated(serviceInitiated);

	}

	public void isPhysicianOrderSelected(String physicianOrderOption) {
		objServicesPage = new ServicesPage(driver);
		objServicesPage.isPhysicianOrderSelected(physicianOrderOption);
	}

	public void isDischargingFacilitySelected(String dischargingFacilityOption,String servicesCity, String servicesState) throws InterruptedException {
		objServicesPage = new ServicesPage(driver);
		objServicesPage.isDischargingFacilitySelected(dischargingFacilityOption,servicesCity, servicesState);
	}

	public boolean verifyDischargeFacilitySearchPage() {
		objServicesPage = new ServicesPage(driver);
		return objServicesPage.verifyDischargeFacilitySearchPage();
	}

	public void searchFacilityUsingNPIAndZipCode(String PhysicianNPI,String PhysicianZipCode) {
		//readPropertyFileServicesTab();
		objServicesPage = new ServicesPage(driver);
		objServicesPage.searchFacilityUsingNPIAndZipCode(PhysicianNPI, PhysicianZipCode);
	}

	public void searchFacilityUsingNPIAndName(String PhysicianNPI,String PhysicianName) {
		//readPropertyFileServicesTab();
		objServicesPage = new ServicesPage(driver);
		objServicesPage.searchFacilityUsingNPIAndName(PhysicianNPI, PhysicianName);
	}
	
	public void selectDischargingFacility() {
		objServicesPage = new ServicesPage(driver);
		objServicesPage.selectDischargingFacility();
	}

	public void chooseAdmitDateAndDischargeDate() {
		objServicesPage = new ServicesPage(driver);
		objServicesPage.chooseAdmitDateAndDischargeDate();

	}

	public void clickOnNext() {
		objServicesPage = new ServicesPage(driver);
		objServicesPage.clickOnNext();

	}

	public boolean isFacilitySelected() {
		objServicesPage = new ServicesPage(driver);
		return objServicesPage.isFacilitySelected();
	}

	public boolean isAdmitDateAndDischargeDateSelected() {
		objServicesPage = new ServicesPage(driver);
		return objServicesPage.isAdmitDateAndDischargeDateSelected();
	}

	public boolean isRequiredFieldsDisplayed() {
		objServicesPage = new ServicesPage(driver);
		return objServicesPage.isRequiredFieldsDisplayed();
	}

	public boolean isRequestTypeChanged() {
		objServicesPage = new ServicesPage(driver);
		return objServicesPage.isRequestTypeChanged();
	}

	public boolean isRequestTypeNotEnabled() {
		objServicesPage = new ServicesPage(driver);
		return objServicesPage.isRequestTypeNotEnabled();
	}

	public void searchFacilityUsingCityAndState() {
		readPropertyFileServicesTab();
		objServicesPage = new ServicesPage(driver);
		objServicesPage.searchFacilityUsingCityAndState(physicianCity, physicianState);
	}

	public boolean isServiceDetailsDisplayed(String serviceType) {
		readPropertyFileServicesTab();
		objServicesPage = new ServicesPage(driver);
		return objServicesPage.isServiceDetailsDisplayed(serviceType, skilledNursingFacility,
				inpatientRehabilitationFacility, longTermAcuteCare, skilledNursingFacilityRevCode,
				skilledNursingFacilityDesc, inpatientRehabilitationFacilityRevCode, inpatientRehabilitationFacilityDesc,
				longTermAcuteCareRevCode, longTermAcuteCareDesc);
	}

	public void clickOnNextButton() {
		objServicesPage = new ServicesPage(driver);
		objServicesPage.clickOnNextButton();
	}
	
	public void clickOnNextButtonforques_Does_the_patient_have_acute_hospital_needs() {
		objServicesPage = new ServicesPage(driver);
		objServicesPage.clickOnNextButtonforques_Does_the_patient_have_acute_hospital_needs();
	}
	
	
	public void clickOnNextButtonforques_Does_the_patient_have_intense_and_complex_care_needs_that_make_skilled_nursing_facility_care() throws InterruptedException {
		objServicesPage = new ServicesPage(driver);
		objServicesPage.clickOnNextButtonforques_Does_the_patient_have_intense_and_complex_care_needs_that_make_skilled_nursing_facility_care();
	}
	
	public void clickOnNextButtonforques_Does_the_care_include_multiple_components_delivered_by_skilled_professionals() throws InterruptedException {
		objServicesPage = new ServicesPage(driver);
		objServicesPage.clickOnNextButtonforques_Does_the_care_include_multiple_components_delivered_by_skilled_professionals();
	}
	
	public void clickOnNextButtonforques_Is_there_a_plan_to_provide_ALL_of_the_following() {
		objServicesPage = new ServicesPage(driver);
		objServicesPage.clickOnNextButtonforques_Is_there_a_plan_to_provide_ALL_of_the_following();
	}
	
	public void clickOnNextButtonforques_Is_skilled_treatment_needed_daily_or_more_frequent() {
		objServicesPage = new ServicesPage(driver);
		objServicesPage.clickOnNextButtonforques_Is_skilled_treatment_needed_daily_or_more_frequent();
	}
	
	public void clickOnNextButtonforques_What_type_of_skilled_treatments_are_needed() {
		objServicesPage = new ServicesPage(driver);
		objServicesPage.clickOnNextButtonforques_Is_skilled_treatment_needed_daily_or_more_frequent();
	}
	
	public void clickOnNextButtonforques_What_are_the_nursing_interventions_being_requested() {
		objServicesPage = new ServicesPage(driver);
		objServicesPage.clickOnNextButtonforques_Is_skilled_treatment_needed_daily_or_more_frequent();
	}
	
	public void clickOnNextButtonforques_Do_you_have_clinical_documentation_to_support_this_request() {
		objServicesPage = new ServicesPage(driver);
		objServicesPage.clickOnNextButtonforques_Do_you_have_clinical_documentation_to_support_this_request();
	}
	
	public void clickOnSaveButton() {
		objServicesPage = new ServicesPage(driver);
		objServicesPage.clickOnSaveButton();
	}

	public Object verifySearchCriteriaMessage() {
		objServicesPage = new ServicesPage(driver);
		return objServicesPage.verifySearchCriteriaMessage();
	}

	public boolean verifyDischargeFacilityDetails() {
		objServicesPage = new ServicesPage(driver);
		return objServicesPage.verifyDischargeFacilityDetails();
	}

	public void searchFacilitydetailsWithTwoOptions(String PhysicianNPI, String PhysicianName,String physicianZipCode,String physicianCity,String physicianState) {
		//readPropertyFileServicesTab();
		objServicesPage = new ServicesPage(driver);
		objServicesPage.searchFacilitydetailsWithTwoOptions(PhysicianName, PhysicianNPI, physicianZipCode,
				physicianCity, physicianState);
	}

	public void searchFacilityusingAllOptions() {
		readPropertyFileServicesTab();
		objServicesPage = new ServicesPage(driver);
		objServicesPage.searchFacilityusingAllOptions(physicianName, physicianNPI, physicianZipCode,
				physicianCity, physicianState);
	}

	public boolean verifyRequiredFieldsAreDisplayed() {
		objServicesPage = new ServicesPage(driver);
		return objServicesPage.verifyRequiredFieldsAreDisplayed();
	}

	public boolean searchFacilityTogetNoResult(String physicianname, String physiciannpi) {
		//readPropertyFileServicesTab();
		objServicesPage = new ServicesPage(driver);
		//return objServicesPage.searchFacilityTogetNoResult(physicianName1, physicianNPI1);
		return objServicesPage.searchFacilityTogetNoResult(physicianname, physicianname);
	}

	public boolean verifyMessageForNoResult() {
		objServicesPage = new ServicesPage(driver);
		return objServicesPage.verifyMessageForNoResult();
	}

	public void searchFacilityTogetmoreResults(String physicianname, String physiciannpi) {
		//readPropertyFileServicesTab();
		objServicesPage = new ServicesPage(driver);
		//objServicesPage.searchFacilityTogetmoreResults(physicianName2, physicianNPI2);
		objServicesPage.searchFacilityTogetmoreResults(physicianname, physiciannpi);
	}

	public boolean verifyMessageFormoreResults() {
		objServicesPage = new ServicesPage(driver);
		return objServicesPage.verifyMessageFormoreResults();
	}

	public boolean verifyStateDropdownPresent() {
		objServicesPage = new ServicesPage(driver);
		return objServicesPage.verifyStateDropdownPresent();
	}

	public void clickStateDropdown() {
		objServicesPage = new ServicesPage(driver);
		objServicesPage.clickStateDropdown();
	}

	public boolean verifyStateListPresent() {
		objServicesPage = new ServicesPage(driver);
		return objServicesPage.verifyStateListPresent();
	}

	public boolean verifyStateListOrder() {
		objServicesPage = new ServicesPage(driver);
		return objServicesPage.verifyStateListSortorder();
	}

	public boolean checkStateDropdownValues(String Statelist) {
		//readPropertyFileServicesTab();
		objServicesPage = new ServicesPage(driver);
		return objServicesPage.checkStateDropdownvalues(Statelist);

	}

	public void goToServicesTab() {
		objServicesPage = new ServicesPage(driver);
		objServicesPage.goToServicesTab();
	}

	public void clickEditDischargingFacilityBtn() {
		objServicesPage = new ServicesPage(driver);
		objServicesPage.clickEditDischargingFacilityBtn();
	}
	
	public void selectclinicaltemplateDoes_the_patient_have_acute_hospital_needs(String Ans_Doestpathavacuhosneeds) throws InterruptedException {
		objServicesPage = new ServicesPage(driver);
		objServicesPage.selectDoes_the_patient_have_acute_hospital_needs(Ans_Doestpathavacuhosneeds);

	}
	
	public void selectclinicaltemplateDoes_the_patient_have_intense_and_complex_care_needs_that_make_skilled_nursing_facility_care(String Ans_DoestpathavensecomcathamakeSkilnursfaccare) throws InterruptedException {
		objServicesPage = new ServicesPage(driver);
		objServicesPage.selectclinicaltemplateDoes_the_patient_have_intense_and_complex_care_needs_that_make_skilled_nursing_facility_care(Ans_DoestpathavensecomcathamakeSkilnursfaccare);

	}
	
	public void selectclinicaltemplateDoes_the_patient_have_intense_and_complex_care_needs_that_make_skilled_nursing_facility_care_for_16556(String Ans_DoestpathavensecomcathamakeSkilnursfaccare) throws InterruptedException {
		objServicesPage = new ServicesPage(driver);
		objServicesPage.selectclinicaltemplateDoes_the_patient_have_intense_and_complex_care_needs_that_make_skilled_nursing_facility_care_for_16556(Ans_DoestpathavensecomcathamakeSkilnursfaccare);

	}
	
	public void selectclinicaltemplateDoes_the_care_include_multiple_components_delivered_by_skilled_professionals(String Ans_Doesthecareincludemultiplecomptsdelidbyskilledprofnals) throws InterruptedException {
		objServicesPage = new ServicesPage(driver);
		objServicesPage.selectclinicaltemplateDoes_the_care_include_multiple_components_delivered_by_skilled_professionals(Ans_Doesthecareincludemultiplecomptsdelidbyskilledprofnals);

	}
	
	public void selectclinicaltemplateDoes_the_care_include_multiple_components_delivered_by_skilled_professionals_for_16556(String Ans_Doesthecareincludemultiplecomptsdelidbyskilledprofnals) throws InterruptedException {
		objServicesPage = new ServicesPage(driver);
		objServicesPage.selectclinicaltemplateDoes_the_care_include_multiple_components_delivered_by_skilled_professionals_for_16556(Ans_Doesthecareincludemultiplecomptsdelidbyskilledprofnals);

	}
	
	public void selectclinicaltemplateIs_there_a_plan_to_provide_ALL_of_the_following(String Ans_IsthereaplantoprovideALLofthefollowing) throws InterruptedException {
		objServicesPage = new ServicesPage(driver);
		objServicesPage.selectclinicaltemplateIs_there_a_plan_to_provide_ALL_of_the_following(Ans_IsthereaplantoprovideALLofthefollowing);

	}
	
	public void selectclinicaltemplateIs_there_a_plan_to_provide_ALL_of_the_following_For_16556(String Ans_IsthereaplantoprovideALLofthefollowing) throws InterruptedException {
		objServicesPage = new ServicesPage(driver);
		objServicesPage.selectclinicaltemplateIs_there_a_plan_to_provide_ALL_of_the_following_For_16556(Ans_IsthereaplantoprovideALLofthefollowing);

	}
	
	public void selectclinicaltemplateIs_skilled_treatment_needed_daily_or_more_frequent(String Ans_Isskilledtreatmentneededdailyormorefrequent) throws InterruptedException {
		objServicesPage = new ServicesPage(driver);
		objServicesPage.selectclinicaltemplateIs_skilled_treatment_needed_daily_or_more_frequent(Ans_Isskilledtreatmentneededdailyormorefrequent);

	}
	
	public void selectclinicaltemplateIs_skilled_treatment_needed_daily_or_more_frequent_For_16556(String Ans_Isskilledtreatmentneededdailyormorefrequent) throws InterruptedException {
		objServicesPage = new ServicesPage(driver);
		objServicesPage.selectclinicaltemplateIs_skilled_treatment_needed_daily_or_more_frequent_For_16556(Ans_Isskilledtreatmentneededdailyormorefrequent);

	}
	
	public void selectclinicaltemplateWhat_type_of_skilled_treatments_are_needed(String Ans_Whattypeofskilledtreatmentsareneeded) throws InterruptedException {
		objServicesPage = new ServicesPage(driver);
		objServicesPage.selectclinicaltemplateWhat_type_of_skilled_treatments_are_needed(Ans_Whattypeofskilledtreatmentsareneeded);

	}
	
	public void selectclinicaltemplateWhat_are_the_nursing_interventions_being_requested(String Ans_Whatarethenursinginterventionsbeingrequested) throws InterruptedException {
		objServicesPage = new ServicesPage(driver);
		objServicesPage.selectclinicaltemplateWhat_are_the_nursing_interventions_being_requested(Ans_Whatarethenursinginterventionsbeingrequested);

	}
	
	public void selectclinicaltemplateDo_you_have_clinical_documentation_to_support_this_request(String Ans_Whattypeofskilledtreatmentsareneeded) throws InterruptedException {
		objServicesPage = new ServicesPage(driver);
		objServicesPage.selectclinicaltemplateDo_you_have_clinical_documentation_to_support_this_request(Ans_Whattypeofskilledtreatmentsareneeded);

	}
	
	

}
