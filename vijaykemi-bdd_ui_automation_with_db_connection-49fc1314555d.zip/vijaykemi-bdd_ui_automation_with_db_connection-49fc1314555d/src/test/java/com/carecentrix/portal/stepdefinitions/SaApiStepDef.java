package com.carecentrix.portal.stepdefinitions;

import static net.serenitybdd.rest.SerenityRest.rest;
import static net.serenitybdd.rest.SerenityRest.then;
import static org.hamcrest.Matchers.equalTo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.carecentrix.api.setup.SetupHeaders;
import com.carecentrix.portal.testUtils.ExcelReadWrite;
import com.carecentrix.portal.testUtils.ExcelReader;
import com.carecentrix.utilities.Constant;

import com.carecentrix.utilities.PropLoader;
import com.carecentrix.validations.EpsValidations;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.response.Response;
import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Steps;

public class SaApiStepDef {
	
	String DATA_MAP = "dataMap";
	
	String serviceAuthMultiLineContent;
	
	ExcelReadWrite excelreadwrite;
	
	@Steps
	private SetupHeaders setup = new SetupHeaders();
	
	 @Steps
	    private EpsValidations validation = new EpsValidations();

	//Map<String, Object> dataMap;
	private static final Logger log = LogManager.getLogger(SaApiStepDef.class);
	
	
	@Given("^Setup proxy for Service Auth$")
	public void setup_proxy_for_a_Member_Request() throws Throwable {
		
		setup.initialSetup("udhsaapihost");

	}
	

	@When("^Service Auth Get request triggered such that \"([^\"]*)\"$")
	public void serviceAuthEventMultipleLinesAddUpd(String scenario) throws Throwable {

		String sheetName= PropLoader.props.apply("EpsServiceAuthDatasetupSheet");
		
		String udhsaapihost = PropLoader.props.apply("udhsaapihost") 
				+ PropLoader.props.apply("baseudhsaapihost");
				
		
		
		log.info("udhsaapihosturi:" + udhsaapihost);
		log.info("scenario {}", scenario);

		Constant.dataMap = ExcelReader.readAllRow(sheetName, scenario);
		Serenity.getCurrentSession().put(DATA_MAP, Constant.dataMap);
		log.info("dataMap {}" + Constant.dataMap);
		log.info("Caseid " + Constant.dataMap.get("Caseid"));
		//Serenity.getCurrentSession().get(Constant.SERVICELINE_NUMBER);
		
		Response RESP =
	            rest().given().contentType("application/json").header("Content-Type", "application/json").auth()
	            .basic(PropLoader.props.apply("UdhSaApiusername"), PropLoader.props.apply("UdhSaApipassword"))
	           
	            .when().log().all()
	            .get(udhsaapihost + Constant.dataMap.get("Caseid"));
	           
	       // Serenity.getCurrentSession().put(Constant.UDHPAYLOAD, RESP.asString());
	        log.info("Response is ********** " + RESP.asString());
		
	
	}

	@Then("^Validate the fields in ResponseBody for the \"([^\"]*)\"$")
	public void Validate_the_fields_in_ResponseBody_for_the(String scenario) throws Throwable {
		Serenity.getCurrentSession().get(DATA_MAP);
				
	    String[] arrSplit = ((String) Constant.dataMap.get("dob")).split("/");
	    String DOB = arrSplit[2]+"-"+arrSplit[0]+"-"+arrSplit[1];
	    String HealthPlan = null;
	   if(((String) Constant.dataMap.get("healthPlan")).equals("Florida Blue")){
		   HealthPlan = "Florida BCBS";
	    }

		then().assertThat()
		
		//v1.4
//		.body("caseDetails[0].caseSource", equalTo((String) Constant.dataMap.get("Enhanced Portal")),
//				"caseDetails[0].member.subscriberId", equalTo((String) Constant.dataMap.get("subscriberId")),
//				"caseDetails[0].member.firstName", equalTo((String) Constant.dataMap.get("firstName")),
//				"caseDetails[0].member.lastName", equalTo((String) Constant.dataMap.get("lastName")),
//				"caseDetails[0].member.dob", equalTo(DOB),
//				"caseDetails[0].caseServiceLine[0].diagnosis[0].diagnosisCode", equalTo((String) Constant.dataMap.get("ICDCode")),
//						"caseDetails[0].caseServiceLine[0].routingPriority", equalTo((String) Constant.dataMap.get("RequestType")),
//						"caseDetails[0].caseServiceLine[0].planDetails.healthPlan", equalTo(HealthPlan)
//						);
		//v1.2
		.body(
				"caseDetails[0].member.subscriberId", equalTo((String) Constant.dataMap.get("subscriberId")),
				"caseDetails[0].member.firstName", equalTo((String) Constant.dataMap.get("firstName")),
				"caseDetails[0].member.lastName", equalTo((String) Constant.dataMap.get("lastName")),
				"caseDetails[0].member.dob", equalTo(DOB),
				"caseDetails[0].diagnosis[0].diagnosisCode", equalTo((String) Constant.dataMap.get("ICDCode")),
				"caseDetails[0].caseServiceLine[0].routingPriority", equalTo((String) Constant.dataMap.get("RequestType"))
						);
		
	}
	
	@Then("^Capture Portal Information in Excel \"([^\"]*)\" and \"([^\"]*)\"$")
	public void CapturePortalInformationinExcel(String scenario , String sheetname) throws IOException, InterruptedException {
		
		
		String sheetName = "EPE2EData";
		
		
		capturePortalInfoInExcelForReAuth(scenario,sheetName);
		log.info("Captured the informations successfully");
	}
	
	public void capturePortalInfoInExcelForReAuth(String scenario,
			String sheetName) throws IOException, InterruptedException {
		
		String filePath =(System.getProperty("user.dir") + "/src/test/resources/testdata/EP_Inputsheet.xlsx");
		
		log.info("filePath: {}", filePath);
		
		excelreadwrite = new ExcelReadWrite(filePath);
		
		File file = new File(filePath);
		FileInputStream fis = new FileInputStream(file);
		Workbook wb = WorkbookFactory.create(fis);
		Sheet sheet = wb.getSheet(sheetName);

		Constant.dataMap.size();
		int startNewRowAt = excelreadwrite.findRow1(scenario, sheetName);
		Row newRow = sheet.getRow(startNewRowAt);
		
		Cell Request_ID = newRow.createCell(Constant.dataMap.size()-8);
		Cell NewCaseID = newRow.createCell(Constant.dataMap.size()-7);
		Cell correlationId = newRow.createCell(Constant.dataMap.size()-6);
		Cell Ref_Request_ID = newRow.createCell(Constant.dataMap.size()-5);
		Cell Parent_auth_ID = newRow.createCell(Constant.dataMap.size()-4);
		Cell INTAKEID = newRow.createCell(Constant.dataMap.size()-3);
		Cell INTAKEID_CREATED_TIME = newRow.createCell(Constant.dataMap.size()-2);
		Cell REF_PATIENT_PLAN_ID = newRow.createCell(Constant.dataMap.size()-1);
		Request_ID.setCellValue(Constant.RequestID);
		NewCaseID.setCellValue(Constant.NewCaseID);
		correlationId.setCellValue(Constant.correlationId);
		Parent_auth_ID.setCellValue(Constant.Parent_Auth_ID);
		Ref_Request_ID.setCellValue(Constant.REF_REQUEST_ID);
		INTAKEID.setCellValue(Constant.INTAKEID);
		INTAKEID_CREATED_TIME.setCellValue(Constant.INTAKEID_CREATED_TIME);
		REF_PATIENT_PLAN_ID.setCellValue(Constant.REF_PATIENT_PLAN_ID);
		
		FileOutputStream fos = new FileOutputStream(file);
		wb.write(fos);
		fos.flush();
		fos.close();
		fis.close();
		wb.close();
	
}
}