package com.carecentrix.portal.stepdefinitions;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;

import com.carecentrix.portal.testpages.TestSignUpPage;
import com.carecentrix.utilities.Constant;

import cucumber.api.DataTable;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 * @author KKJANAK
 *
 */

public class SignUpStepDef {

	TestSignUpPage testSignUpPage = new TestSignUpPage();
	private static final Logger log = LogManager.getLogger(SignUpStepDef.class);

	Constant constant = new Constant();
	
	@Then("^Click on Register Button$")
	public void clickRegisterButton() {
		Assert.assertEquals(true, testSignUpPage.clickRegisterButton());
		log.info("Register button clicked");
	}

	@When("^Verify User Type dropdown present$")
	public void verifyUserTypeDropdownPresent() {
		Assert.assertEquals(true, testSignUpPage.verifyUserTypeDropdownPresent());
		log.info("User Type Dropdown is present");
	}

	@Then("^Click User Type dropdown$")
	public void clickUserTypeDropdown() {
		testSignUpPage.clickUserTypeDropdown();
		log.info("User Type dropdown is clicked");
	}

	@Then("^Verify User Type list is present$")
	public void verifyUserTypeListPresent() {
		Assert.assertEquals(true, testSignUpPage.verifyUserTypeListPresent());
		log.info("User Type list is Present");
	}

	@Then("^Verify User Type list is in sort order$")
	public void verifyUserTypeListOrder() {
		Assert.assertEquals(true, testSignUpPage.verifyUserTypeListOrder());
		log.info("User Type list is in Sort Order");
	}

	@Then("^Check User Type dropdown values$")
	public void checkUserTypeDropdownValuesUserType() {
		
		String userType = (String) constant.dataMap.get("UserType");
		testSignUpPage.checkUserTypeDropdownValuesUserType(userType);
	}

	@When("^Verify Portal Provider Type dropdown present$")
	public void verifyPortalProviderTypedropdownpresent() {
		Assert.assertEquals(true, testSignUpPage.verifyPortalProviderTypeDropdownPresent());
		log.info("Portal Provider Type Dropdown is present");
	}

	@Then("^Click Portal Provider Type dropdown$")
	public void clickPortalProviderTypeDropdown() {
		testSignUpPage.clickPortalProviderTypeDropdown();
		log.info("Portal Provider Type dropdown is clicked");
	}

	@Then("^Verify Portal Provider Type list is present$")
	public void verifyPortalProviderTypeListPresent() {
		Assert.assertEquals(true, testSignUpPage.verifyPortalProviderTypeListPresent());
		log.info("Portal Provider Type list is Present");
	}

	@Then("^Verify Portal Provider Type list is in sort order$")
	public void verifyPortalProviderTypeListSortorder() {
		Assert.assertEquals(false, testSignUpPage.verifyPortalProviderTypeListSortorder());
		log.info("Portal Provider Type list is not in Sort Order");
	}

	@Then("^Check Portal Provider Type dropdown values$")
	public void checkPortalProviderTypeDropdownvalues() {
		String portalProviderType = (String) constant.dataMap.get("PortalProviderType");
		testSignUpPage.checkPortalProviderTypeDropdownvalues(portalProviderType);
	}

	@When("^Verify Health Plan dropdown present$")
	public void verifyHealthPlanDropdownPresent() {
		Assert.assertEquals(true, testSignUpPage.verifyHealthPlanDropdownPresent());
		log.info("Health Plan Dropdown is present");
	}

	@Then("^Click Health Plan dropdown$")
	public void clickHealthPlanDropdown() {
		testSignUpPage.clickHealthPlanDropdown();
		log.info("Health Plan dropdown is clicked");
	}

	@Then("^Verify Health Plan list is present$")
	public void verifyHealthPlanListPresent() {
		Assert.assertEquals(true, testSignUpPage.verifyHealthPlanListPresent());
		log.info("Health Plan list is Present");
	}

	@Then("^Verify Health Plan list is in sort order$")
	public void verifyHealthPlanListOrder() {
		Assert.assertEquals(true, testSignUpPage.verifyHealthPlanListOrder());
		log.info("Health Plan list is in Sort Order");
	}

	@Then("^Verify no default value selected$")
	public void verifyNoDefaultValueSelected() {
		Assert.assertEquals(true, testSignUpPage.verifyNoDefaultValueSelected());
		log.info("No default value selected in Health Plan dropdown");
	}

	@Then("^Check Health Plan dropdown values$")
	public void checkHealthPlanDropdownValuesHealthPlan() {
		String healthPlan = (String) constant.dataMap.get("HealthPlan");
		testSignUpPage.checkHealthPlanDropdownValuesHealthPlan(healthPlan);
	}

	@When("^Verify State dropdown present$")
	public void verifyStateDropdownPresent() {
		Assert.assertEquals(true, testSignUpPage.verifyStateDropdownPresent());
		log.info("State Dropdown is present");
	}

	@Then("^Click State dropdown$")
	public void clickStateDropdown() {
		testSignUpPage.clickStateDropdown();
		log.info("State dropdown is clicked");
	}

	@Then("^Verify State list is present$")
	public void verifyStateListPresent() {
		Assert.assertEquals(true, testSignUpPage.verifyStateListPresent());
		log.info("State list is Present");
	}

	@Then("^Verify State list is in sort order$")
	public void verifyStateListOrder() {
		Assert.assertEquals(false, testSignUpPage.verifyStateListOrder());
		log.info("State list is in Sort Order");
	}

	@Then("^Check State dropdown values$")
	public void checkStateDropdownValues(DataTable stateList) {
		try {
			List<List<String>> stateDetails = stateList.raw();
			testSignUpPage.checkStateDropdownValues(stateDetails);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Then("^Select \"([^\"]*)\" from Health Plan$")
	public void selectOptionFromHealthPlan(String option) {
		testSignUpPage.selectOptionFromHealthPlan(option);
	}

	@Then("^Verify alert message$")
	public void verifyAlertMessage() {
		Assert.assertEquals(true, testSignUpPage.verifyAlertMessage());
	}

	@Then("^Go to main page")
	public void goToMainPage() {
		Assert.assertEquals(true, testSignUpPage.goToMainPage());
	}

	@Then("^Enter details in all fields$")
	public void enterDetailsInAllFields() {

		String firstName = (String) constant.dataMap.get("Firstname");
		String lastName = (String) constant.dataMap.get("lastName"); 
		String Email  = (String) constant.dataMap.get("Email")+"@carecentrix.com";
		String Location  = (String) constant.dataMap.get("Location");
		String NPI  = (String) constant.dataMap.get("NPI");
		String Address  = (String) constant.dataMap.get("Address");
		String City  = (String) constant.dataMap.get("City");
		String Zip  = (String) constant.dataMap.get("Zip");
		String Phone  = (String) constant.dataMap.get("Phone");
		String Fax  = (String) constant.dataMap.get("Fax");
		
		
		testSignUpPage.enterDetailsInAllFields(firstName, lastName, Email, Location, NPI, Address, City, Zip, Phone, Fax);
	}

	@Then("^Enter details in all fields with new EmailID$")
	public void enterDetailsInAllFieldsWithNewEmailID() {
		testSignUpPage.enterDetailsInAllFieldsWithNewEmailID();
	}

	@Then("^Verify Location details fetched$")
	public void verifyLocationDetailsFetched() {
		
		String Location  = (String) constant.dataMap.get("Location");
		String NPI  = (String) constant.dataMap.get("NPI");
		String Address  = (String) constant.dataMap.get("Address");
		String City  = (String) constant.dataMap.get("City");
		String Zip  = (String) constant.dataMap.get("Zip");
		String Phone  = (String) constant.dataMap.get("Phone");
		
		
		testSignUpPage.verifyLocationDetailsFetched(Location, NPI, Address, City, Zip, Phone);
	}

	@Then("^Select Locaton details$")
	public void selectLocationDetails() {
		testSignUpPage.selectLocationDetails();
	}

	@Then("^Enter incorrect email$")
	public void enterIncorrectEmail() {
		String firstName = (String) constant.dataMap.get("Firstname");
		String lastName = (String) constant.dataMap.get("lastName"); 
		String InvalidEmail  = (String) constant.dataMap.get("Email");
		String Location  = (String) constant.dataMap.get("Location");
		String NPI  = (String) constant.dataMap.get("NPI");
		String Address  = (String) constant.dataMap.get("Address");
		String City  = (String) constant.dataMap.get("City");
		String Zip  = (String) constant.dataMap.get("Zip");
		String Phone  = (String) constant.dataMap.get("Phone");
		String Fax  = (String) constant.dataMap.get("Fax");
		
		
		//testSignUpPage.enterDetailsInAllFields(firstName, lastName, Email, Location, NPI, Address, City, Zip, Phone, Fax);
		testSignUpPage.enterIncorrectEmail(firstName, lastName, InvalidEmail, Location, NPI, Address, City, Zip, Phone,Fax);
	}

	@Then("^Click Verify Button$")
	public void clickVerifyBtn() {
		testSignUpPage.clickVerifyBtn();
	}

	@Then("^Verify alert error message$")
	public void verifyAlertErrMsg() {
		Assert.assertEquals(true, testSignUpPage.verifyAlertErrMsg());
	}

	@Then("^Verify Email validation message$")
	public void verifyEmailValidationMsg() {
		Assert.assertEquals(true, testSignUpPage.verifyEmailValidationMsg());
	}

	@When("^Enter details in mandatory fields$")
	public void enterDetailsInMandatoryFields() {
		String fieldName = (String) constant.dataMap.get("Mandatory_Missing_Fields");
		String blankValue = (String) constant.dataMap.get("BlankValue");
		String firstName = (String) constant.dataMap.get("Firstname");
		String lastName = (String) constant.dataMap.get("lastName"); 
		String Email  = (String) constant.dataMap.get("Email");
		String Location  = (String) constant.dataMap.get("Location");
		String NPI  = (String) constant.dataMap.get("NPI");
		testSignUpPage.enterDetailsInMandatoryFields(fieldName,blankValue,firstName,lastName,Email,Location,NPI);
	}

	@When("^Verify missing fields error message$")
	public void verifyMissingFieldsErrMsg() {
		String fieldName = (String) constant.dataMap.get("Mandatory_Missing_Fields");
		Assert.assertEquals(true, testSignUpPage.verifyMissingFieldsErrMsg(fieldName));
	}

	@Then("^Verify Register Page Labels$")
	public void verifyRegisterPageLabels() {
		Assert.assertEquals(true, testSignUpPage.verifyRegisterPageLabels());
	}

	@Then("^Verify Register Page Address Labels$")
	public void verifyRegisterPageAddressLabels() {
		Assert.assertEquals(true, testSignUpPage.verifyRegisterPageAddressLabels());
	}

	@When("^Click on SignUp for EFT And ERA$")
	public void clickSinguUplnk() {
		testSignUpPage.clickSinguUplnk();
	}

	@Then("^Verify Sign up for EFT/ERA through CAQH is displayed$")
	public boolean verifylnkEFTERACAQH() {
		return testSignUpPage.verifylnkEFTERACAQH();
	}

	@Then("^Verify ERA Enrollment Frequently Asked Question is displayed$")
	public boolean verifylnkERAEnrollmentFAQ() {
		return testSignUpPage.verifylnkERAEnrollmentFAQ();
	}

	@Then("^Verify ERA Enrollment Only – Paper Enrollment Form is displayed$")
	public boolean verifylnkERAPaperEnrollment() {
		return testSignUpPage.verifylnkERAPaperEnrollment();
	}

	@Then("^Click on Sign up for EFT/ERA through CAQH and Verify CAQH Registration page is displayed$")
	public boolean verifyCAQHRegisterisDisplayed() {
		return testSignUpPage.clickEFTERACAQHVerifyCAQHRegisterisDisplayed();
	}

	@Then("^Click on ERA Enrollment Frequently Asked Question$")
	public void clicklnkERAEnrollmentFAQ() {
		testSignUpPage.clicklnkERAEnrollmentFAQ();
	}

	@Then("^Click on ERA Enrollment Only – Paper Enrollment Form$")
	public void clicklnkERAPaperEnrollment() {
		testSignUpPage.clicklnkERAPaperEnrollment();
	}

	@Then("^Verify File is downloaded$")
	public void verifyFileDownloaded() {
		
		String fileName = (String) constant.dataMap.get("FileName");
		testSignUpPage.verifyFileDownloaded(fileName);
	}

	@Then("^Enter UserType ProviderType and HealthPlan$")
	public void enterUserTypeDetails(DataTable signUpDetails) {
		try {
			List<List<String>> data = signUpDetails.raw();
			String userType = data.get(0).get(0);
			String portalProviderType = data.get(0).get(1);
			String healthPlan = data.get(0).get(2);
			testSignUpPage.enterUserTypeDetails(userType, portalProviderType, healthPlan);
			log.info("Application launched successfully");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Then("^Enter Contact Details$")
	public void enterUserContactDetails() {
		testSignUpPage.enterUserContactDetails();
	}

	@Then("^Enter Address Details$")
	public void enterUserAddressDetails() {
		testSignUpPage.enterUserAddressDetails();
	}

}
