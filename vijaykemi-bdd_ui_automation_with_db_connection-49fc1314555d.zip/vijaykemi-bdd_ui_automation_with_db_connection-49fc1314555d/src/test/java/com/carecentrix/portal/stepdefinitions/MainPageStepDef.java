package com.carecentrix.portal.stepdefinitions;

import java.io.IOException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;

import com.carecentrix.portal.testpages.TestMainPage;
import com.carecentrix.utilities.Constant;
import com.carecentrix.utilities.SeleniumMethods;

import cucumber.api.DataTable;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 * @author KKJANAK
 *
 */

public class MainPageStepDef {

	TestMainPage testMainPage = new TestMainPage();
	private static final Logger log = LogManager.getLogger(MainPageStepDef.class);
	Constant constant = new Constant();


	@When("^Verify Top section menus present$")
	public void verifyTopSectionMenusPresent() throws IOException, InterruptedException {
		String menuList = (String) constant.dataMap.get("TopMenu");
		String[] listOfMenus = menuList.split(":");
		Assert.assertEquals(true, testMainPage.verifyTopSectionMenusPresent(listOfMenus[0],
				listOfMenus[1], listOfMenus[2]));
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "TopMenu");
		log.info("TopMenu Verified successfully");
	}

	@When("^Verify Call of actions menus present$")
	public void verifyCallOfActionsMenusPresent() throws IOException, InterruptedException {
		String menuList = (String) constant.dataMap.get("ActionMenu");
		String[] listOfMenus = menuList.split(":");
		Assert.assertEquals(true, testMainPage.verifyCallOfActionsMenusPresent(listOfMenus[0],
				listOfMenus[1], listOfMenus[2], listOfMenus[3]));
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "ActionMenu");
		log.info("ActionMenu Verified successfully");
	}

	@Then("^Verify Resources Section menus present$")
	public void verifyResourcesSectionMenusPresent() throws IOException, InterruptedException {
		String menuList = (String) constant.dataMap.get("ResourceMenu");
		String[] listOfMenus = menuList.split(":");
		Assert.assertEquals(true,
				testMainPage.verifyResourcesSectionMenusPresent(listOfMenus[0], listOfMenus[1],
						listOfMenus[2], listOfMenus[3], listOfMenus[4]));
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "ResourcesMenu");
		log.info("ResourcessMenu Verified successfully");
	}

	@Then("^Click ResourcesForms link$")
	public void clickResourcesFormsLinks() {
		Assert.assertEquals(true, testMainPage.clickResourcesFormsLinks());
	}

	@Then("^Verify ResourcesForms Menu options$")
	public void verifyResourcesFormsMenuOptions() throws IOException, InterruptedException {
		String menuList = (String) constant.dataMap.get("ResourcesFormsMenu");
		String[] listOfMenus = menuList.split(":");
		Assert.assertEquals(true,
				testMainPage.verifyResourcesFormsMenuOptions(listOfMenus[0], listOfMenus[1],
						listOfMenus[2], listOfMenus[3], listOfMenus[4]));
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "ResourcesFormsMenu");
		log.info("ResourcesFormsMenu Verified successfully");
	}

	@Then("^Verify HomeBridge content$")
	public void verifyHomeBridgeContent() throws IOException, InterruptedException {
		String menuList = (String) constant.dataMap.get("HomeBridgeContent");
		Assert.assertEquals(true, testMainPage.verifyHomeBridgeContent(menuList));
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "HomeBridgeContent");
		log.info("HomeBridgeContent Verified successfully");
	}

	@Then("^Click LearnMore Button$")
	public void clickLearnMoreButton() {
		Assert.assertEquals(true, testMainPage.clickLearnMoreButton());
	}

	@Then("^Verify Footer Menus present$")
	public void verifyFooterMenusPresent() throws IOException, InterruptedException {
		String menuList = (String) constant.dataMap.get("FooterMenu");
		String[] listOfMenus = menuList.split(":");
		Assert.assertEquals(true, testMainPage.verifyFooterMenusPresent(listOfMenus[0],
				listOfMenus[1], listOfMenus[2], listOfMenus[3]));
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "FooterMenu");
		log.info("FooterMenu Verified successfully");
	}

	@Then("^Verify Footer Menu Links")
	public void verifyFooterMenuLinks() {
		Assert.assertEquals(true, testMainPage.verifyFooterMenuLinks());
	}

	@Then("^Verify Footer Logo Clicks$")
	public void verifyFooterLogoClicks() {
		Assert.assertEquals(true, testMainPage.verifyFooterLogoClicks());
	}

	@Then("^Verify Footer CopyRight details$")
	public void verifyFooterCopyRightDetails() throws IOException, InterruptedException {
		String menuList = (String) constant.dataMap.get("FooterCopyRight");
		Assert.assertEquals(true, testMainPage.verifyFooterCopyRightDetails(menuList));
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Footer CopyRight");
		log.info("Footer CopyRight Verified successfully");
	}

	@Then("^Verify Footer Follow Link details$")
	public void verifyFooterFollowLinkDetails()  throws IOException, InterruptedException {
		String menuList = (String) constant.dataMap.get("FollowLink");
		Assert.assertEquals(true, testMainPage.verifyFooterFollowLinkDetails(menuList));
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "FollowLink");
		log.info("FollowLink Verified successfully");
	}

	@Then("^Verify Provider Manual Menu$")
	public void verifyProviderManualMenu() {
		Assert.assertEquals(true, testMainPage.verifyProviderManualMenu());
	}

	@Then("^Verify Provider Addened Menu$")
	public void verifyProviderAddenedMenu() throws IOException, InterruptedException {
		testMainPage.verifyProviderAddenedMenu();
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Provider Added");
		log.info("Provider Added Menu Verified successfully");
	}

	@Then("^Click links and verify downloads$")
	public void clickLinksAndVerifyDownload() throws IOException, InterruptedException{
		String pdfList = (String) constant.dataMap.get("Downloads");
		String[] pdfFileName = pdfList.split(":");
		//List<List<String>> pdfFileName = fileNames.raw();
		testMainPage.clickLinksAndVerifyDownload(pdfFileName[0], pdfFileName[1],
				pdfFileName[2], pdfFileName[3], pdfFileName[4],	pdfFileName[5], 
				pdfFileName[6], pdfFileName[7],	pdfFileName[8], pdfFileName[9]);
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Verify downloads");
		log.info("Downloads Verified successfully");
	}

	@Then("^Click on FAQ link$")
	public void clickOnFAQLink() {
		Assert.assertEquals(true, testMainPage.clickOnFAQLink());
	}

	@Then("^Verify FAQ questions$")
	public void verifyFAQQuestions() throws IOException, InterruptedException {
		String faqList = (String) constant.dataMap.get("FAQ_Questions");
		Assert.assertEquals(true, testMainPage.verifyFAQQuestions(faqList));
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Verify FAQ");
		log.info("FAQ Verified successfully");		
	}

	@Then("^Click on Join button$")
	public void clickOnJoinButton() {
		testMainPage.clickOnJoinButton();
	}

	@Then("^Verify Join Page$")
	public void verifyJoinPage() throws IOException, InterruptedException {
		String PageURL = (String) constant.dataMap.get("PageURL");
		Assert.assertEquals(true, testMainPage.verifyJoinPage(PageURL));
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Join Page");
		log.info("Join Page Verified successfully");
	}

	@When("^Click on Review Button$")
	public void clickReviewBtn() {
		testMainPage.clickReviewBtn();
	}

	@Then("^Verify Review page URL$")
	public void verifyReviewPageURL() throws IOException, InterruptedException {
		String PageURL = (String) constant.dataMap.get("PageURL");
		Assert.assertEquals(true, testMainPage.verifyReviewPageURL(PageURL));
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Review Page");
		log.info("Review Page Verified successfully");
	}

	@Then("^Click Menus \"([^\"]*)\"$")
	public void clickMenu(String menu) {
		testMainPage.clickMenu(menu);
	}

	@Then("^Verify Menu options present in page \"([^\"]*)\"$")
	public void verifyMenuOptionsPresentInPage(String menu) {
		testMainPage.verifyMenuOptionsPresentInPage(menu);
	}

	@Then("^Click and verify Claims link \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void clickAndVerifyClaimsLink(String menu, String link, String isURL) {
		Assert.assertEquals(true, testMainPage.clickAndVerifyClaimsLink(menu, link, isURL));
		log.info("Claims link verified");
	}

	@Then("^Click and verify TrainingAndReferenceMaterials link \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void clickAndVerifyTrainingLink(String menu, String link, String isURL) {
		Assert.assertEquals(true, testMainPage.clickAndVerifyTrainingLink(menu, link, isURL));
		log.info("Training link verified");
	}

	@Then("^Click and verify TrainingAndReferenceMaterials link dropdown \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"")
	public void clickAndVerifyTrainingLinkdropdown(String menu1, String menu, String link, String isURL) {
		Assert.assertEquals(true, testMainPage.clickAndVerifyTrainingLinkdropdown(menu1, menu, link, isURL));
		log.info("Training link verified");
	}

	@Then("^Click and verify Tools link \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void clickAndVerifyToolsLink(String menu, String link, String isURL) {
		Assert.assertEquals(true, testMainPage.clickAndVerifyToolsLink(menu, link, isURL));
		log.info("Tools link verified");
	}

	@Then("^Click and verify Health Plan Specific Materials link \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void clickAndVerifyHealthPlanLink(String menu, String link, String isURL) {
		Assert.assertEquals(true, testMainPage.clickAndVerifyHealthPlanLink(menu, link, isURL));
		log.info("Health Plan link verified");
	}

	@Then("^Click Health Plan Specific Materials dropdown link \"([^\"]*)\"$")
	public void clickHealthPlanddLink(String menu) {
		testMainPage.clickHealthPlanddLink(menu);
		log.info("Health Plan link verified");
	}

	@Then("^Verify Copy rights content \"([^\"]*)\"$")
	public void verifyCopyRightsContent(String page) throws IOException, InterruptedException {
		Assert.assertEquals(true, testMainPage.verifyCopyRightsContent(page));
		SeleniumMethods.captureFullScreenShot(Constant.SCRSHT_MSG+ "Copy Rights Content");
		log.info("Copy Rights Content verified");
	}

}
