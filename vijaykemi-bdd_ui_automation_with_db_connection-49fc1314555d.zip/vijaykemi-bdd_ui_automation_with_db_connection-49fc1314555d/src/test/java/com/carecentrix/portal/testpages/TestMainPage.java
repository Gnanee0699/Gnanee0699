package com.carecentrix.portal.testpages;

import com.carecentrix.portal.pages.MainPage;
import com.carecentrix.utilities.BasePage;
import com.carecentrix.utilities.Constant;
import com.carecentrix.utilities.PropLoader;

/**
 * @author KKJANAK
 *
 */

public class TestMainPage extends BasePage {

	MainPage mainPage;

	String mainPageResourcesLinkURL;
	String mainPageLearnMoreButtonURL;
	String mainPageFooterAboutUsURL;
	String mainPageFooterContactUsURL;
	String mainPageFooterReportFraudURL;
	String mainPageURL;
	String mainPageFooterContent;
	String mainPageFooterNCQAURL;
	String mainPageFooterURACURL;
	String mainPageFooterHiTrustURL;
	String mainPageFooterTermsURL;
	String mainPageFooterPrivacyURL;
	String mainPageFooterTwitURL;
	String mainPageFooterLIURL;
	String mainPageFooterYTURL;
	String mainPageProviderManualURL;
	String mainPageProviderAddendedURL;
	String mainPageFAQLnk;
	String mainPageFAQs;
	String mainPageJoinURL;
	String reviewPageURL;
	String claimsList;
	String trainingList;
	String toolsList;
	String healthPlanList;

	public void readPropFileMainPage() {
		mainPageResourcesLinkURL = PropLoader.props.apply("SignUp_ResourcesLinkURL");
		mainPageLearnMoreButtonURL = PropLoader.props.apply("SignUp_LearnMoreURL");
		mainPageFooterAboutUsURL = PropLoader.props.apply("SignUp_FooterAboutUsURL");
		mainPageFooterContactUsURL = PropLoader.props.apply("SignUp_FooterContactUsURL");
		mainPageFooterReportFraudURL = PropLoader.props.apply("SignUp_FooterReportFraudURL");
		mainPageURL = PropLoader.props.apply("QA_ENHANCEPORTALBASE_URL");
		mainPageFooterContent = PropLoader.props.apply("SignUP_FooterContent");
		mainPageFooterNCQAURL = PropLoader.props.apply("SignUp_FooterNCQAURL");
		mainPageFooterURACURL = PropLoader.props.apply("SignUp_FooterURACURL");
		mainPageFooterHiTrustURL = PropLoader.props.apply("SignUp_FooterHiTrustURL");
		mainPageFooterTermsURL = PropLoader.props.apply("SignUp_FooterTermsURL");
		mainPageFooterPrivacyURL = PropLoader.props.apply("SignUp_FooterPrivacyURL");
		mainPageFooterTwitURL = PropLoader.props.apply("SignUp_FooterTwitLinkURL");
		mainPageFooterLIURL = PropLoader.props.apply("SignUp_FooterLIURL");
		mainPageFooterYTURL = PropLoader.props.apply("SignUp_FooterYTURL");
		mainPageProviderManualURL = PropLoader.props.apply("SignUp_FooterProviderManual");
		mainPageProviderAddendedURL = PropLoader.props.apply("SignUp_FooterProviderAddended");
		mainPageFAQLnk = PropLoader.props.apply("SignUp_FAQ_Page");
		mainPageFAQs = PropLoader.listProps.apply("SignUp_FAQ_Questions");
		mainPageJoinURL = PropLoader.listProps.apply("SignUp_JoinLinkURL");
		reviewPageURL = PropLoader.props.apply("ReviewPage_URL");
		claimsList = PropLoader.listProps.apply("ClaimsList");
		trainingList = PropLoader.listProps.apply("TrainingList");
		toolsList = PropLoader.listProps.apply("ToolsList");
		healthPlanList = PropLoader.listProps.apply("HealthPlanList");

	}

	public boolean verifyTopSectionMenusPresent(String menu1, String menu2, String menu3) {
		mainPage = new MainPage(driver);
		return mainPage.verifyTopSectionMenusPresent(menu1, menu2, menu3);
	}

	public boolean verifyCallOfActionsMenusPresent(String menu1, String menu2, String menu3, String menu4) {
		mainPage = new MainPage(driver);
		return mainPage.verifyCallOfActionsMenusPresent(menu1, menu2, menu3, menu4);
	}

	public boolean verifyResourcesSectionMenusPresent(String menu1, String menu2, String menu3, String menu4,
			String menu5) {
		mainPage = new MainPage(driver);
		return mainPage.verifyResourcesSectionMenusPresent(menu1, menu2, menu3, menu4, menu5);
	}

	public boolean clickResourcesFormsLinks() {
		readPropFileMainPage();
		mainPage = new MainPage(driver);
		return mainPage.clickResourcesFormsLinks(mainPageResourcesLinkURL);
	}

	public boolean verifyResourcesFormsMenuOptions(String menu1, String menu2, String menu3, String menu4,
			String menu5) {
		mainPage = new MainPage(driver);
		return mainPage.verifyResourcesFormsMenuOptions(menu1, menu2, menu3, menu4, menu5, mainPageURL);
	}

	public boolean verifyHomeBridgeContent(String content1) {
		mainPage = new MainPage(driver);
		return mainPage.verifyHomeBridgeContent(content1);
	}

	public boolean clickLearnMoreButton() {
		readPropFileMainPage();
		mainPage = new MainPage(driver);
		return mainPage.clickLearnMoreButton(mainPageLearnMoreButtonURL, mainPageURL);
	}

	public boolean verifyFooterMenusPresent(String menu1, String menu2, String menu3, String menu4) {
		readPropFileMainPage();
		mainPage = new MainPage(driver);
		return mainPage.verifyFooterMenusPresent(menu1, menu2, menu3, menu4, mainPageFooterContent, mainPageURL);
	}

	public Object verifyFooterMenuLinks() {
		readPropFileMainPage();
		mainPage = new MainPage(driver);
		return mainPage.verifyFooterMenuLinks(mainPageURL, mainPageFooterAboutUsURL, mainPageFooterContactUsURL,
				mainPageFooterReportFraudURL);
	}

	public boolean verifyFooterLogoClicks() {
		readPropFileMainPage();
		mainPage = new MainPage(driver);
		return mainPage.verifyFooterLogoClicks(mainPageFooterNCQAURL, mainPageFooterURACURL, mainPageFooterHiTrustURL,
				mainPageURL);
	}

	public boolean verifyFooterCopyRightDetails(String mainPageFooterCopyRight) {
		readPropFileMainPage();
		mainPage = new MainPage(driver);
		return mainPage.verifyFooterCopyRightDetails(mainPageFooterCopyRight, mainPageFooterTermsURL,
				mainPageFooterPrivacyURL, mainPageURL);
	}

	public boolean verifyFooterFollowLinkDetails(String mainPageFooterFollowUs) {
		readPropFileMainPage();
		mainPage = new MainPage(driver);
		return mainPage.verifyFooterFollowLinkDetails(mainPageFooterFollowUs, mainPageFooterTwitURL,
				mainPageFooterLIURL, mainPageFooterYTURL, mainPageURL);
	}

	public boolean verifyProviderManualMenu() {
		readPropFileMainPage();
		mainPage = new MainPage(driver);
		return mainPage.verifyProviderManualMenu(mainPageProviderManualURL, mainPageURL);
	}

	public void verifyProviderAddenedMenu() {
		readPropFileMainPage();
		mainPage = new MainPage(driver);
		mainPage.verifyProviderAddenedMenu();
	}

	public void clickLinksAndVerifyDownload(String pdf1, String pdf2, String pdf3, String pdf4, String pdf5,
			String pdf6, String pdf7, String pdf8, String pdf9, String pdf10) {
		mainPage = new MainPage(driver);
		mainPage.clickLinksAndVerifyDownload(pdf1, pdf2, pdf3, pdf4, pdf5, pdf6, pdf7, pdf8, pdf9, pdf10);
	}

	public boolean clickOnFAQLink() {
		readPropFileMainPage();
		mainPage = new MainPage(driver);
		return mainPage.clickOnFAQLink(mainPageFAQLnk);
	}

	public boolean verifyFAQQuestions(String strPageFAQs) {
		//readPropFileMainPage(String );
		mainPage = new MainPage(driver);
		return mainPage.verifyFAQQuestions(strPageFAQs);
	}

	public void clickOnJoinButton() {
		mainPage = new MainPage(driver);
		mainPage.clickOnJoinButton();
	}

	public boolean verifyJoinPage(String strPageURL) {
		//readPropFileMainPage();
		mainPage = new MainPage(driver);
		return mainPage.verifyJoinPage(strPageURL);
	}

	public void clickReviewBtn() {
		mainPage = new MainPage(driver);
		mainPage.clickReviewBtn();
	}

	public boolean verifyReviewPageURL(String strPageURL) {
		//readPropFileMainPage();
		mainPage = new MainPage(driver);
		return mainPage.verifyReviewPageURL(strPageURL);
	}

	public void clickMenu(String menu) {
		readPropFileMainPage();
		mainPage = new MainPage(driver);
		mainPage.clickMenu(menu, Constant.OPTION_NO, claimsList, trainingList, toolsList, healthPlanList);
	}

	public void verifyMenuOptionsPresentInPage(String menu) {
		readPropFileMainPage();
		mainPage = new MainPage(driver);
		mainPage.clickMenu(menu, Constant.OPTION_YES, claimsList, trainingList, toolsList, healthPlanList);
	}

	public boolean clickAndVerifyClaimsLink(String menu, String link, String isURL) {
		mainPage = new MainPage(driver);
		return mainPage.clickAndVerifyClaimsLink(menu, link, isURL);

	}

	public boolean clickAndVerifyTrainingLink(String menu, String link, String isURL) {
		mainPage = new MainPage(driver);
		return mainPage.clickAndVerifyTrainingLink(menu, link, isURL);
	}

	public boolean clickAndVerifyTrainingLinkdropdown(String menu1, String menu, String link, String isURL) {
		mainPage = new MainPage(driver);
		return mainPage.clickAndVerifyTrainingLinkdropdown(menu1, menu, link, isURL);
	}

	public boolean clickAndVerifyToolsLink(String menu, String link, String isURL) {
		mainPage = new MainPage(driver);
		return mainPage.clickAndVerifyTrainingLinkdropdown(menu, link, isURL);
	}

	public boolean clickAndVerifyHealthPlanLink(String menu, String link, String isURL) {
		mainPage = new MainPage(driver);
		return mainPage.clickAndVerifyHealthPlanLink(menu, link, isURL);
	}

	public void clickHealthPlanddLink(String menu) {
		mainPage = new MainPage(driver);
		mainPage.clickHealthPlanddLink(menu);
	}

	public boolean verifyCopyRightsContent(String page) {
		mainPage = new MainPage(driver);
		return mainPage.verifyCopyRightsContent(page);
	}
}
