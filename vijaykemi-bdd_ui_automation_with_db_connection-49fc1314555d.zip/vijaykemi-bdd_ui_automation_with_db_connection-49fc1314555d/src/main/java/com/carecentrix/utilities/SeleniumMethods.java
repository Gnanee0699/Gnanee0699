package com.carecentrix.utilities;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;

/**
 * @author KJ
 *
 */

public class SeleniumMethods extends BasePage {

	private static String progressDivXapth = "//*[@id='progressDiv']";
	private static final Logger log = LogManager.getLogger(SeleniumMethods.class);
	private static String screeShots = "\\ScreenShots";

	public static WebDriver setBrowser(String browserType) {
		switch (browserType.toLowerCase()) {
		case Constant.BROWSER_CHROME:
			setDriver(Constant.BROWSER_CHROME);
			break;
		case Constant.BROWSER_IE:
			setDriver(Constant.BROWSER_IE);
			break;
		case Constant.BROWSER_FIREFOX:
			setDriver(Constant.BROWSER_FIREFOX);
			break;
		case Constant.BROWSER_EDGE:
			setDriver(Constant.BROWSER_EDGE);
			break;
		default:
			log.info("This Browser is is not a supported {}", browserType);
		}
		driver.manage().window().maximize();
		return driver;
	}

	public static void startTest(String environment, String testcase, String browser, String testCase) {
		// ExtentReport er = new ExtentReport();
		// Removed closing of driver method here
		log.info("Browser is {}", browser);
		createFolderStructure(environment, testcase);
		// er.startReport(testCase);
	}

	public static WebDriver setDriver(String baseDriver) {
		switch (baseDriver) {
		case Constant.BROWSER_CHROME:
			String chromedriverpath = PropLoader.props.apply("chromeDriver");
			System.setProperty("webdriver.chrome.driver", chromedriverpath);
			// Create instance of ChromeOptions Class
			ChromeOptions options = new ChromeOptions();
			// Using the accept insecure cert method with true as parameter to
			// accept the untrusted certificate
			options.setAcceptInsecureCerts(true);
			// Default chrome downloaded path changed to Temp directory
			HashMap<String, Object> chromePref = new HashMap<>();
			chromePref.put("download.default_directory", System.getProperty(Constant.JAVA_IO_TEMP_DIR));
			log.info("Downloads Temp Path:{}", System.getProperty(Constant.JAVA_IO_TEMP_DIR));
			options.setExperimentalOption("prefs", chromePref);
			driver = new ChromeDriver(options);

			log.info("Starting Chrome browser");
			break;
		case Constant.BROWSER_IE:
			String iedriverpath = PropLoader.props.apply("ieDriver");
			System.setProperty("webdriver.ie.driver", iedriverpath);
			driver = new InternetExplorerDriver();
			log.info("Starting Internet Explorer browser");
			break;
		case Constant.BROWSER_FIREFOX:
			String firefoxdriverpath = PropLoader.props.apply("firefoxDriver");
			System.setProperty("webdriver.gecko.driver", firefoxdriverpath);
			driver = new FirefoxDriver();
			log.info("Starting Firefox browser");
			break;
		case Constant.BROWSER_EDGE:
			String edgedriverpath = PropLoader.props.apply("edgeDriver");
			System.setProperty("webdriver.gecko.driver", edgedriverpath);
			driver = new EdgeDriver();
			log.info("Starting Edge browser");
			break;
		default:
			log.info("This Browser is is not a supported {}", baseDriver);
		}

		return driver;
	}

	public static void openBrowserAndNavigateToBasePage(String application, String environment, String testcase) throws IOException, InterruptedException {

		String url = PropLoader.props.apply(environment.toUpperCase() + "_" + application.toUpperCase() + "_URL");
		// String runType = PropLoader.props.apply("TestMode");
		String browserType = PropLoader.props.apply("driver");
		log.info("Test running in the environment {} and the test case is {}", environment, testcase);
		log.info("URL read from Property File {}", url);
		driver = setBrowser(browserType);
		// isTestMode(runType);
		driver.get(url);
		driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);

	}

	public static void openWebApplication(String environment, String application, String browser)
			throws AWTException, InterruptedException, IOException {
		// prop = new ReadPropertiesFile();

		String url = PropLoader.props.apply(environment.toUpperCase() + "_" + application.toUpperCase() + "_URL");
		String runType = PropLoader.props.apply("TestMode");
		log.info("Checking user access in {} and the application is {}", environment, application);
		killProcessExe(browser);
		driver = setBrowser(browser);
		isTestMode(runType);
		driver.get(url);
	}

	public static void quitDriver() {
		driver.close();
		driver.quit();
	}

	public static void turnOffCapsLock() {
		Toolkit capLock = Toolkit.getDefaultToolkit();
		boolean isCapsOn = capLock.getLockingKeyState(KeyEvent.VK_CAPS_LOCK);
		if (isCapsOn) {
			capLock.setLockingKeyState(KeyEvent.VK_CAPS_LOCK, Boolean.FALSE);
		}
	}

	public static void killProcessExe(String param1) throws InterruptedException {
		String[] cmdString = null;

		switch (param1.toLowerCase()) {
		case "chrome":
			cmdString = new String[] { "chrome.exe", "chromedriver.exe" };
			break;
		case "ie":
			cmdString = new String[] { "iexplore.exe", "IEDriverServer.exe" };
			break;
		default:
			cmdString = new String[] { param1 };
			log.info("Browser input is missing");
			break;
		}

		Process process = null;
		for (int i = 0; i < cmdString.length; i++) {
			String runCMD = "taskkill /f /im " + cmdString[i] + " /t";
			try {
				process = Runtime.getRuntime().exec(runCMD);
			} catch (IOException e) {
				e.printStackTrace();
			}
			if (process != null) {
				process.waitFor();
				process.destroy();
			}

			log.info("Closing {}", cmdString[i]);
		}
	}

	public static void isTestMode(String runType) throws AWTException {
		if (runType.equalsIgnoreCase("y") || runType.equalsIgnoreCase("yes")) {
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_WINDOWS);
			robot.keyPress(KeyEvent.VK_RIGHT);
			robot.keyRelease(KeyEvent.VK_RIGHT);
			robot.keyRelease(KeyEvent.VK_WINDOWS);
		}
	}

	public static String currentDate() {
		LocalDateTime datetime = LocalDateTime.now();
		DateTimeFormatter pattern = DateTimeFormatter.ofPattern(Constant.DATE_FORMAT);
		return datetime.format(pattern);
	}

	public static String currentDateTime(String currentDateTimePattern) {
		LocalDateTime datetime = LocalDateTime.now();
		DateTimeFormatter pattern = DateTimeFormatter.ofPattern(currentDateTimePattern);
		return datetime.format(pattern);
	}

	public static String currentDatePlusDays(Integer daysToAdd) {
		String formattedDate = null;
		LocalDateTime datetime = LocalDateTime.now().plusDays(daysToAdd);
		DateTimeFormatter pattern = DateTimeFormatter.ofPattern(Constant.DATE_FORMAT);
		formattedDate = datetime.format(pattern);
		return formattedDate;
	}

	public static String currentMonthStartDate() {
		LocalDateTime datetime = LocalDateTime.now();
		LocalDateTime start = datetime.withDayOfMonth(1);
		DateTimeFormatter pattern = DateTimeFormatter.ofPattern(Constant.DATE_FORMAT);
		return start.format(pattern);
	}

	public static String foreverDate() {
		String formattedDate = null;
		formattedDate = "12/12/9999";
		return formattedDate;
	}

	public static String setDate(String patternString) {
		LocalDateTime datetime = LocalDateTime.now();
		DateTimeFormatter pattern = DateTimeFormatter.ofPattern(patternString);
		return datetime.format(pattern);
	}

	public static String setDate(Integer daysToAdd, String patternString) {
		LocalDateTime datetime = LocalDateTime.now().plusDays(daysToAdd);
		DateTimeFormatter pattern = DateTimeFormatter.ofPattern(patternString);
		return datetime.format(pattern);
	}

	public static void waitUntilElementIsClickable(WebElement element) {
		new WebDriverWait(driver, 60).until(ExpectedConditions.elementToBeClickable(element));
	}

	public static void longwaitUntilElementIsClickable(WebElement element) {
		new WebDriverWait(driver, 110).until(ExpectedConditions.elementToBeClickable(element));
	}

	public static void shortwaitUntilElementIsClickable(WebElement element) {
		new WebDriverWait(driver, 10).until(ExpectedConditions.elementToBeClickable(element));
	}

	public static void waitUntilElementIsVisible(WebElement element) {
		WebDriverWait wait1 = new WebDriverWait(driver, 500);
		wait1.until(ExpectedConditions.visibilityOfElementLocated((By) element)).click();
	}

	public static void shortwaitUntilElementIsVisible(String xpath) {
		WebDriverWait wait = new WebDriverWait(driver, 300);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
	}

	public static void longwaitUntilElementIsVisible(WebElement element) {
		WebDriverWait wait = new WebDriverWait(driver, 500);
		wait.until(ExpectedConditions.visibilityOf(element));
	}

	public static void waitUsingJavascriptExecuter(WebElement element) {
		driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
		element.submit();
	}

	// central function to extract Objects
	public WebElement getObject(String objectKey) {
		WebElement e = null;
		try {
			if (objectKey.endsWith("_xpath"))
				e = driver.findElement(By.xpath((objectKey)));
			else if (objectKey.endsWith("_id"))
				e = driver.findElement(By.id((objectKey)));
			else if (objectKey.endsWith("_css"))
				e = driver.findElement(By.cssSelector((objectKey)));
			else if (objectKey.endsWith("_name"))
				e = driver.findElement(By.name((objectKey)));
			WebDriverWait wait1 = new WebDriverWait(driver, 30);

			wait1.until(ExpectedConditions.visibilityOf((e)));
			// visibility of Object
			// state of the object- clickable
			wait1.until(ExpectedConditions.elementToBeClickable(e));

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return e;

	}

	// true - present
	// false - not present
	public boolean isElementPresent(String objectKey) {
		List<WebElement> list = null;
		boolean status = false;
		if (objectKey.endsWith("_xpath"))
			list = driver.findElements(By.xpath((objectKey)));
		else if (objectKey.endsWith("_id"))
			list = driver.findElements(By.id((objectKey)));
		else if (objectKey.endsWith("_css"))
			list = driver.findElements(By.cssSelector((objectKey)));
		else if (objectKey.endsWith("_name"))
			list = driver.findElements(By.name((objectKey)));

		if (list.isEmpty())
			status = false;
		else
			status = true;
		return status;
	}

	public static void waitUntilProcessingImageInvisible() {
		new WebDriverWait(driver, 10)
		.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(progressDivXapth)));
	}

	public static void waitUntilProcessingImageVisible() {
		// img alt=Loading...
		new WebDriverWait(driver, 5).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(progressDivXapth)));
	}

	public static boolean isElementDisplayed() {
		try {
			String xpathval = "//*[@id='progressDiv']";
			WebDriverWait wait = new WebDriverWait(driver, 3);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpathval)));
			return driver.findElement(By.xpath(xpathval)).isDisplayed();
		} catch (org.openqa.selenium.NoSuchElementException | org.openqa.selenium.StaleElementReferenceException
				| org.openqa.selenium.TimeoutException e) {
			return false;
		}
	}

	public static void waitForElementToBeGone() {
		if (isElementDisplayed()) {
			new WebDriverWait(driver, 10)
			.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(progressDivXapth)));
		}
	}

	public static void waitUntilClickable(WebElement element) {
		try {
			waitUntilElementIsClickable(element);
		} catch (Exception e) {
			waitUntilElementIsClickable(element);
		}
	}

	public static void longwaitUntilClickable(WebElement element) {
		try {
			longwaitUntilElementIsClickable(element);
		} catch (Exception e) {
			longwaitUntilElementIsClickable(element);
		}
	}

	public static void shortwaitUntilClickable(WebElement element) {
		try {
			shortwaitUntilElementIsClickable(element);
		} catch (Exception e) {
			shortwaitUntilElementIsClickable(element);
		}
	}

	public static void waitAndClick(WebElement element) {
		waitUntilClickable(element);
		element.click();
	}

	public static void shortwaitAndClick(WebElement element) {
		shortwaitUntilClickable(element);
		element.click();
	}

	public static void waitAndSendKeys(WebElement element, String testData) {
		// waitUntilClickable(element);
		element.sendKeys(testData);
	}

	public static void createFolderStructure(String environment, String testcase) {
		LocalDateTime dateTime = LocalDateTime.now();
		DateTimeFormatter pattern = DateTimeFormatter.ofPattern("yyyyMMdd_hhmm");
		String dateTimeStamp = dateTime.format(pattern);

		executionPath = PropLoader.props.apply("executionPath") + environment.toUpperCase() + " - " + testcase
				+ "\\Runtime_" + dateTimeStamp;

		//File testResultHTMLReportPath = new File(executionPath + "\\HTML_Report");
		File testLogPath = new File(executionPath + "\\Logs");
		File testScreenShotPath = new File(executionPath + screeShots);
		//testResultHTMLReportPath.mkdirs();
		testLogPath.mkdirs();
		testScreenShotPath.mkdirs();
		log.info("test Log Path {}", testLogPath);
	}

	public static boolean isTextPresent(String testData) {
		boolean flag = false;
		try {
			driver.findElement(By.xpath(testData));
			flag = true;
		} catch (Exception e) {
			flag = false;
		}
		return flag;
	}

	public static void checkIfPageIsReady() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		String pageState = null;
		do {
			pageState = js.executeScript("return document.readyState").toString();
		} while (!pageState.equalsIgnoreCase("complete"));
	}

	public static void captureScreenShot() throws IOException, InterruptedException {
		Thread.sleep(1000);
		String dateStamp = setDate("yyyyMMdd_hhmmss");
		String destPath = executionPath + screeShots;
		String destFilePath = destPath + "\\SS_" + dateStamp + ".png";
		TakesScreenshot screenshot = (TakesScreenshot) driver;
		File tempFile = screenshot.getScreenshotAs(OutputType.FILE);
		File destFile = new File(destFilePath);
		FileUtils.copyFile(tempFile, destFile);
	}

	public static void captureScreenShot(String screenShotName) throws IOException, InterruptedException {
		Thread.sleep(1000);
		String dateStamp = setDate("yyyyMMdd_hhmmss");
		String destPath = executionPath + screeShots;
		String destFilePath = destPath + "\\SS_" + dateStamp + "_" + screenShotName + ".png";
		TakesScreenshot screenshot = (TakesScreenshot) driver;
		File tempFile = screenshot.getScreenshotAs(OutputType.FILE);
		File destFile = new File(destFilePath);
		FileUtils.copyFile(tempFile, destFile);
	}
	
	public static void captureFullScreenShot(String screenShotName) throws IOException, InterruptedException {
		Thread.sleep(1000);
		String dateStamp = setDate("yyyyMMdd_hhmmss");
		String destPath = executionPath + screeShots;
		String destFilePath = destPath + "\\SS_" + dateStamp + "_" + screenShotName + ".png";
		
		Screenshot screenshots = new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000)).takeScreenshot(driver);
		ImageIO.write(screenshots.getImage(),"PNG",new File(destFilePath));
		
		
	}

	public static String convertToFullLengthGender(String gender, String patternType) {
		String fullGender = null;
		if (gender.equalsIgnoreCase("M") && patternType.contentEquals("1")) {
			fullGender = "Male";
		} else if (gender.equalsIgnoreCase("M") && patternType.contentEquals("2")) {
			fullGender = "M=Male";
		} else if (gender.equalsIgnoreCase("M") && patternType.contentEquals("3")) {
			fullGender = "MALE";
		} else if (gender.equalsIgnoreCase("F") && patternType.contentEquals("1")) {
			fullGender = "Female";
		} else if (gender.equalsIgnoreCase("F") && patternType.contentEquals("2")) {
			fullGender = "F=Female";
		} else if (gender.equalsIgnoreCase("F") && patternType.contentEquals("3")) {
			fullGender = "FEMALE";
		} else {
			fullGender = gender;
		}
		return fullGender;
	}

	public static boolean isFileClosed(String fileName) {
		File file = new File(fileName);
		return file.renameTo(file);
	}

	public static void copyLogFile() throws IOException {
		// user.dir is not working
		String delimiter = "\\";
		Path sourcePath = Paths.get(System.getProperty("user.dir") + delimiter + PropLoader.props.apply("LogFile"));
		Path destinationPath = Paths.get(executionPath + "\\Logs\\user.log");
		Files.copy(sourcePath, destinationPath);
		log.info("Copy Log file Completed.Destination Log file path is {}", destinationPath);
	}

	public static void endTest() throws IOException {
		// ExtentReport er = new ExtentReport();
		quitDriver();
		// er.endReport();
		copyLogFile();
	}

	public static void selectFromDropDown(WebElement element, String testdata) {
		waitUntilClickable(element);
		Select option = new Select(element);
		option.selectByVisibleText(testdata);
	}

	public static void selectFromDropDownByValue(WebElement element, String testdata) {
		waitUntilClickable(element);
		Select option = new Select(element);
		option.selectByValue(testdata);
	}

	public static void selectFromDropDownByIndex(WebElement element, int index) {
		waitUntilClickable(element);
		Select option = new Select(element);
		option.selectByIndex(index);
	}

	public static Integer interpretDate(String testData) {
		int serviceDate = 0;
		switch (testData.toLowerCase()) {
		case "current":
			serviceDate = 0;
			break;
		case "future":
			serviceDate = 3;
			break;

		default:
			log.info("Accept only Current or Future keyword.");
			break;
		}
		return serviceDate;
	}

	public static void copyfile(String filepath, String destinationpath) throws IOException {

		Date d = new Date();

		File file = new File(filepath);
		if (file.exists()) {

			Path path = Paths.get(filepath);
			Path result = path.getFileName();

			String[] workbookandsheetname = result.toString().split(".xlsx");
			String workbookname = workbookandsheetname[0];

			File dest = new File(
					destinationpath + workbookname + "_" + d.toString().replace(":", "_").replace(" ", "_") + ".xlsx");
			FileUtils.copyFile(file, dest);
			log.info("File copied successfully");
		}

		else {

			log.info("File not available to Copy or Move");
		}

	}

	public static void deletefile(String filepath) {

		File file = new File(filepath);
		if (file.exists()) {
			file.delete();
			log.info("File deleted successfully");
		} else {
			log.info("File not available to delete");
		}
	}

	public static void sleepWait(int timeInMills) {
		try {
			Thread.sleep(timeInMills);
		} catch (InterruptedException e) {
			log.info(e, e);
		}
	}

	public static boolean isBrowserActive() {
		if (driver.toString().contains("null")) {
			log.info("All Browser windows are closed ");
			return true;
		} else
			return false;
	}

	static String username;
	static String password;

	/**
	 * This method will read user login details from Property file and return
	 * according the page
	 *
	 * @param page
	 *            name
	 * @return user login EmailID and Password
	 */

	public static String[] readPropertyFile(String page) {

		if (page.equalsIgnoreCase(Constant.LOGIN)) {
			username = PropLoader.props.apply(Constant.LOGIN_USERID);
			password = PropLoader.props.apply(Constant.LOGIN_PASSWORD);
			return new String[] { username, password };
		} else if (page.equalsIgnoreCase(Constant.MEMBER_INFO)) {
			username = PropLoader.props.apply(Constant.MEMBERINFO_USERID);
			password = PropLoader.props.apply(Constant.MEMBERINFO_PASSWORD);
			return new String[] { username, password };
		} else if (page.equalsIgnoreCase(Constant.DIAGNOSIS)) {
			username = PropLoader.props.apply(Constant.DIAGNOSIS_USERID);
			password = PropLoader.props.apply(Constant.DIAGNOSIS_PASSWORD);
			return new String[] { username, password };
		} else if (page.equalsIgnoreCase(Constant.SERVICES)) {
			username = PropLoader.props.apply(Constant.SERVICES_USERID);
			password = PropLoader.props.apply(Constant.SERVICES_PASSWORD);
			return new String[] { username, password };
		} else if (page.equalsIgnoreCase(Constant.PHYSICIAN)) {
			username = PropLoader.props.apply(Constant.PHYSICIAN_USERID);
			password = PropLoader.props.apply(Constant.PHYSICIAN_PASSWORD);
			return new String[] { username, password };
		} else if (page.equalsIgnoreCase(Constant.LOCATION)) {
			username = PropLoader.props.apply(Constant.LOCATION_USERID);
			password = PropLoader.props.apply(Constant.LOCATION_PASSWORD);
			return new String[] { username, password };
		} else if (page.equalsIgnoreCase(Constant.REFERRALINFO)) {
			username = PropLoader.props.apply(Constant.REFERRALINFO_USERID);
			password = PropLoader.props.apply(Constant.REFERRALINFO_PASSWORD);
			return new String[] { username, password };
		} else if (page.equalsIgnoreCase(Constant.TERMED)) {
			username = PropLoader.props.apply(Constant.TERMEDUSER_ID);
			password = PropLoader.props.apply(Constant.TERMEDUSER_PASSWORD);
			return new String[] { username, password };
		} else if (page.equalsIgnoreCase(Constant.DEACTIVATED)) {
			username = PropLoader.props.apply(Constant.DEACTIVATEDUSER_ID);
			password = PropLoader.props.apply(Constant.DEACTIVATEDUSER_PASSWORD);
			return new String[] { username, password };
		} else if (page.equalsIgnoreCase(Constant.LOCKED)) {
			username = PropLoader.props.apply(Constant.LOCKEDUSER_ID);
			password = PropLoader.props.apply(Constant.LOCKEDUSER_PASSWORD);
			return new String[] { username, password };
		} else
			return new String[] { username, password };
	}

	public static void refreshPage() {
		driver.navigate().refresh();
	}

	public static void scrollDown(WebElement scrollToWebElement) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();", scrollToWebElement);
	}

	public static void javaScriptExecutorClick(WebElement element) {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("arguments[0].click()", element);
	}

	public static void javaScriptExecutorScrollByValue() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1000)");
	}

	public static void javaScriptExecutorScrollIntoView(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView(true);", element);
	}

	// Verify the Downloaded file in temp folder and delete
	// Default chrome downloaded path changed to Temp directory
	public static boolean verifyDownloadedFileAndDelete(String filename) {
		String temp = System.getProperty(Constant.JAVA_IO_TEMP_DIR);
		boolean flag = false;
		log.info("Temp Path is: {}", temp);
		String fileLocation = temp + filename;
		log.info("file_with_location: {}", fileLocation);
		File file = new File(fileLocation);
		if (file.exists()) {
			log.info("file is present in the location: {}", fileLocation);
			flag = true;
			if (file.delete()) {
				log.info("file deleted");
				flag = true;
			} else {
				log.info("file not deleted");
			}
		} else {
			flag = false;
			log.info("file is not present in the location: {}", fileLocation);
		}
		return flag;
	}

	public static boolean isCollectionSorted(List<WebElement> webElementList) {
		List<String> ddList = new ArrayList<String>();
		List<String> ddListSort = new ArrayList<String>();
		boolean isEqual = false;
		if (!webElementList.isEmpty()) {
			for (WebElement element : webElementList) {
				ddList.add(element.getText());
				ddListSort.add(element.getText());
			}
			log.info("Dropdown List Size  {}", ddList.size());
			Collections.sort(ddList);
			isEqual = ddList.equals(ddListSort);
		}
		return isEqual;
	}

	public static boolean checkStateDropdownvalues(List<WebElement> dropdownListUI, String requiredList) {
		List<String> requiredListProp = new ArrayList<String>();
		List<String> listFromUI = new ArrayList<String>();
		boolean isStatesEqual = false;
//		String[] stateListArray = requiredList.split(", ");
		String strActual = "";	

		for (WebElement dd_list : dropdownListUI) {
			if (!dd_list.getText().isEmpty()) {
				listFromUI.add(dd_list.getText());
				strActual = strActual + dd_list.getText().trim();				
			}
		}
			
		requiredList  = requiredList.replaceAll(",", "");
//		requiredList  = requiredList.replaceAll(" ", "");
		strActual = strActual.replaceAll("\n", "");
		strActual = strActual.replaceAll(",", "");
		System.out.println("re act"+ requiredList + "\n" + strActual);
		
		if (requiredList.length() == strActual.length()) {
			isStatesEqual = requiredList.equals(strActual);
		}
		
//		if (stateListArray.length == listFromUI.size()) {
//			
//			for (int i = 0; i < stateListArray.length; i++) {
//				requiredListProp.add(stateListArray[i]);
//			}
//			isStatesEqual = requiredListProp.equals(listFromUI);
//		}
		log.info("List Values {} \n {}", listFromUI, requiredListProp);
		return isStatesEqual;
	}

	public static boolean compareListValues(List<String> dropdownListUI, String requiredList) {
		List<String> requiredListProp = new ArrayList<String>();
		List<String> listFromUI = new ArrayList<String>();
		boolean isListEqual = false;
		String[] ddPropArray = requiredList.split(":");
		for (String dd_list : dropdownListUI) {
			if (!dd_list.isEmpty()) {
				listFromUI.add(dd_list);
			}
		}
		if (ddPropArray.length == listFromUI.size()) {
			for (int i = 0; i < ddPropArray.length; i++) {
				requiredListProp.add(ddPropArray[i]);
			}
			isListEqual = requiredListProp.equals(listFromUI);
		}
		log.info("List Values {} \n {} \n {}", isListEqual, listFromUI, requiredListProp);
		return isListEqual;
	}

	public static String isCompleted(WebElement button, WebElement status) {
		waitUntilElementIsClickable(button);
		javaScriptExecutorClick(button);
		String tabStatus = "";
		if (status.isDisplayed())
			tabStatus = status.getText();
		return tabStatus;
	}

	public static String getValue(WebElement valueEle) {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		return jse.executeScript("return arguments[0].value", valueEle).toString();
	}

	public static void clearData(WebElement element) {
		String inputText = element.getAttribute("value");
		if (inputText != null) {
			for (int i = 0; i < inputText.length(); i++) {
				element.sendKeys(Keys.BACK_SPACE);
			}
		}
	}

	public static boolean isValidFormat(String format, String value) {
		Date date = null;
		boolean flag = false;
		try {
			SimpleDateFormat sdf = new SimpleDateFormat(format);
			date = sdf.parse(value);
			if (value.equals(sdf.format(date))) {
				flag = true;
			}
		} catch (ParseException ex) {
			ex.printStackTrace();
			flag = false;
		}
		return flag;
	}
}