package com.carecentrix.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.function.Function;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 
 * @author KJ
 *
 */

public class PropLoader {

	String env = null;

	private static Logger logger = LogManager.getLogger(PropLoader.class);
	private Properties properties;
	private File file;
	private InputStream input;

	public PropLoader() throws IOException {
		String path = null;

//----------------------------------------------------------------------------------------	
		
		try {
            env = System.getProperty("Env");
            if (env == null) {
            	
            	Properties prop = new Properties();
        		try {
        			InputStream input = new FileInputStream("src/test/resources/Properties/Environment.properties");
        			prop.load(input);
        			logger.info("Default environment from properties file" + prop.getProperty("Environment"));
        			
        		if(prop.getProperty("Environment").equals("Q4")){
        			 path = "src/test/resources/Properties/Q4_common.properties";
                     logger.info("Q4 properties are loaded by default");
        		}else if(prop.getProperty("Environment").equals("Q1")){
       			 path = "src/test/resources/Properties/QA_common.properties";
                 logger.info("Q1 properties are loaded by default");
    		} 
        		
        		} catch (FileNotFoundException e) {
        			// TODO Auto-generated catch block
        			e.printStackTrace();
        		}
            	
               
            } else {
                switch (env) {
                    case "Dev":
                        path = "src/test/resources/Properties/Dev_common.properties";
                        logger.info("Environment is  {}", env);
                        break;
                    case "QA":
                        path = "src/test/resources/Properties/QA_common.properties";
                        logger.info("Environment is {}", env);
                        break;
                    case "Q4":
                        path = "src/test/resources/Properties/Q4_common.properties";
                        logger.info("Environment is {}", env);
                        break;
                    default:
                        logger.info("Please pass the correct environment value");
                        break;
                }
            }
		
		
		
		
		
//-----------------------------------previous-----------------------------------------------		
//		try {
//			switch ("QA") {
//			case "Dev":
//				path = "src/test/resources/Properties/Dev_common.properties";
//				logger.info("Environment is  {}", env);
//				break;
//			case "QA":
//				path = System.getProperty("user.dir") + "\\src\\test\\resources\\Properties\\QA_common.properties";
//				logger.info("Environment is {}", path);
//				break;
//			case "Q4":
//				path = "src/test/resources/Properties/Q4_common.properties";
//				logger.info("Environment is {}", env);
//				break;
//			default:
//				logger.info("Please pass the correct environment value");
//				break;
//			}
//----------------------------------------------------------------------------------
				
				
				

			// }
			file = new File(path);
			input = new FileInputStream(file);
			properties = new Properties();
			properties.load(input);
		} catch (Exception e) {
			logger.info(e, e);
			logger.info("Failed to Load Property File");
		}
	}

	public String propertyReader(String key) {
		return properties.getProperty(key);
	}

	public static Function<String, String> props = new Function<String, String>() {
		@Override
		public String apply(String key) {
			try {
				return new PropLoader().propertyReader(key);
			} catch (IOException e) {
				logger.info("No Such variable exists");
			}
			return null;
		}
	};

	public String listPropertyReader(String key) {
		String stateArray = null;
		try {
			Object thisState = properties.get(key);
			stateArray = thisState.toString();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return stateArray;
	}

	public static Function<String, String>  listProps = new Function<String, String>() {
		@Override
		public String apply(String key) {
			try {
				return new PropLoader().listPropertyReader(key);
			} catch (IOException e) {
				logger.info("No Such variable exists");
			}
			return null;
		}
	};

}