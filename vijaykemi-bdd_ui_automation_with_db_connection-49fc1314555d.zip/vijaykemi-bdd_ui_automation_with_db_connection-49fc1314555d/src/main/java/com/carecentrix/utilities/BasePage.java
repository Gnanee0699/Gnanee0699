/**
 * 
 */
package com.carecentrix.utilities;

import java.util.Map;

import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;


public class BasePage {
	
	
	protected static Logger log;
	protected static WebDriver driver;
	protected static String executionPath = "";

}
