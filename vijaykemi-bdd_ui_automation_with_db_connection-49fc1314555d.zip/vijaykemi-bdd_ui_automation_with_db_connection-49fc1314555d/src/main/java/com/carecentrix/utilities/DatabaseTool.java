/**
 * 
 */
package com.carecentrix.utilities;

import java.io.BufferedReader;
import java.io.IOException;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.testng.Reporter;


/**
 * @author Mani Rai
 *
 */

public class DatabaseTool extends BasePage {

	/**
	 * @param args
	 * @throws SQLException
	 */

//	Sample
//	public static void main(String[] args) throws SQLException {
//		String env = "Q3";
//		String databaseType = "Oracle";
//		String sqlQuery = "Select shortname From networx_owner.TblPlan tp where tp.planname like '%OPTIMA%'";
//		String sqlQuery = "Select planid, plantypecode, carid, shortname, planname, carname From networx_owner.TblPlan tp where tp.planname like '%OPTIMA%'";
//
//
//		/*
//		 * --------------------------------------------------------------------------
//		 * Return sql result in an object. Supports single value, list or table.
//		 * --------------------------------------------------------------------------
//		 */
//		Object object = getData(env, databaseType, sqlQuery);
//		/*
//		 * --------------------------------------------------------------------------
//		 * For Single Value
//		 * --------------------------------------------------------------------------
//		 */
//
////		System.out.println(object.toString());
//
//		/*
//		 * --------------------------------------------------------------------------
//		 * For List
//		 * --------------------------------------------------------------------------
//		 */
//		@SuppressWarnings("unchecked")
//		List<Object> list = (List<Object>) object;
//		for (Object obj : list) {
//			System.out.println(obj);
//		}
//
//		/*
//		 * --------------------------------------------------------------------------
//		 * For Table
//		 * --------------------------------------------------------------------------
//		 */
////		@SuppressWarnings("unchecked")
////		Map<Integer, Map<String, Object>> dataTable = (Map<Integer, Map<String, Object>>) object;
////		for (Map.Entry<Integer, Map<String, Object>> obj : dataTable.entrySet()) {
////			System.out.println(obj.getKey());
////			Map<String, Object> dataTable2 = obj.getValue();
////			for (Map.Entry<String, Object> obj2 : dataTable2.entrySet()) {
////				System.out.println(obj2.getKey() + " : " + obj2.getValue());
////			}
////		}
//
//	}

	/**
	 * 
	 * This method is the public method for executedSqlQueryAuto and return object
	 * type of either a table, a list or a value.<br>
	 * env is an environment provided by framework.<br>
	 * databaseType is usually Oracle but can be used for other database.<br>
	 * sqlQuery is mostly run against one table at a time with either one or more
	 * than one fields.<br>
	 * 
	 * @param env
	 * @param databaseType
	 * @param sqlQuery
	 * @return
	 * @throws SQLException
	 */
	public static Object getData(String env, String databaseType, String sqlQuery) throws SQLException {
		return executeSqlQueryAuto(env, databaseType, sqlQuery);
	}

	private static Object executeSqlQueryAuto(String env, String databaseType, String sqlQuery) throws SQLException {

		String userid = getUserId(databaseType);
		String password = getEncodedPasswordId(env, databaseType);

		String dbUrl = getDatabaseConnectionUrl(env, databaseType);
		Connection connection = null;
		Statement statement = null;
		System.out.println("userid : "+userid+" "+"password : "+password );
		
		if (databaseType.equalsIgnoreCase("Oracle")) {
			try {
				connection = DriverManager.getConnection(dbUrl, userid, password);
				statement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} else if (databaseType.equalsIgnoreCase("Vertica")) {
			Properties prop = new Properties();
			prop.put("user", userid);
			prop.put("password", password);
			prop.put("tlsmode", "require");
			prop.put("Locale", "LEN_S1");

			connection = DriverManager.getConnection(dbUrl, prop);
			statement = connection.createStatement();
		} else {
			System.err.println("Unknown database");
		}

		ResultSet result = statement.executeQuery(sqlQuery);
		ResultSetMetaData metaData = result.getMetaData();

		int fieldCounts = metaData.getColumnCount();

		Object object = null;

		if (fieldCounts > 1) {
			Map<Integer, Map<String, Object>> queryTableResult = getDataTable(result, metaData);
			if (queryTableResult.isEmpty()) {
//				no_result_message(sqlQuery);
			} else {
				object = queryTableResult;
			}
		} else {
			switch (databaseType.toUpperCase()) {
			case "ORACLE":
				int resultSize = 0;
				while (result.next()) {
					resultSize++;
				}
				result.beforeFirst();
				if (resultSize > 1) {
					List<Object> queryListResult = getFieldValueList(result);
					if (queryListResult.isEmpty()) {
//						no_result_message(sqlQuery);
					} else {
						object = queryListResult;
					}
				} else {
					Object queryFieldValueResult = getFieldValue(result);
					if (queryFieldValueResult.equals(null) || queryFieldValueResult.equals("")) {
//						no_result_message(sqlQuery);
					} else {
						object = queryFieldValueResult;
					}
				}
				break;
			case "VERTICA":
				object = getFieldValueList(result);
				break;
			default:
				System.err.println("unable to get field values");
				break;
			}
		}
		statement.close();
		connection.close();
		return object;
	}

	private static String getUserId(String databaseType) {
		String userId = null;
		try {
//			prop = new ReadPropertiesFile();
			switch (databaseType.toUpperCase().trim()) {
			case "ORACLE":
//				userId = prop.getPropertyValue("OracleUserId");
//				userId = "ssakell";
//				userId = "CORE_SND_PROCESSOR";
				userId = PropLoader.props.apply("UserID_OracleDB");
				break;
			case "VERTICA":
//				userId = prop.getPropertyValue("NetworkUserId");
				userId = "ssdimbl";
				break;
			default:
				System.err.println("Unable to get user id");
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return userId;
	}
	
	public static String getUserID(String databaseType)
	{
		
		return getNetworkUserId() ;
	}

	private static String getNetworkUserId() {
		String userId = null;
		try {
//			prop = new ReadPropertiesFile();
//			userId = prop.getPropertyValue("NetworkUserId");
			userId = "CORE_SND_PROCESSOR";

		} catch (Exception e) {
			e.printStackTrace();
		}
		return userId.trim();
	}

	private static String getEncodedPasswordId(String env, String databaseType) {
		String userPassword = null;
		try {
//			prop = new ReadPropertiesFile();
			switch (databaseType.toUpperCase().trim()) {
			case "ORACLE":
//				userPassword = prop.getEncodedPropertyValue(env.toUpperCase() + "_OraclePassword");
//				userPassword = "V2VsY29tZTJRMQ==";
//				userPassword = "d6fJ8d9UERC5muUE";
				userPassword = PropLoader.props.apply("Password_OracleDB");
				break;
			case "VERTICA":
//				userPassword = prop.getEncodedPropertyValue("NetworkPassword");
				break;
			default:
				System.err.println("Unable to get user id");
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return userPassword;
	}

	private static Object getFieldValue(ResultSet result) throws SQLException {
		Object object = null;
		while (result.next()) {
			object = result.getObject(1);
		}
		return object;
	}

	private static List<Object> getFieldValueList(ResultSet result) throws SQLException {
		List<Object> record = new ArrayList<Object>();
		while (result.next()) {
			record.add(result.getObject(1));
		}
		return record;
	}

	private static Map<Integer, Map<String, Object>> getDataTable(ResultSet result, ResultSetMetaData metaData)
			throws SQLException {
		int fieldCounts = metaData.getColumnCount();
		Map<Integer, Map<String, Object>> dataTable = new HashMap<>();
		int recordNum = 1;
		while (result.next()) {
			Map<String, Object> record = new HashMap<>();
			int i = 1;
			for (; i <= fieldCounts; i++) {
				record.put(metaData.getColumnName(i).toUpperCase(), result.getObject(i));
			}
			dataTable.put(recordNum++, record);
		}
		return dataTable;
	}

	private static String getDatabaseConnectionUrl(String env, String databaseType) {
		String databaseConnectionUrl = null;
		switch (databaseType.toUpperCase()) {
		case "ORACLE":
			databaseConnectionUrl = getOracleConnectionUrl(env);
			break;
		case "VERTICA":
			databaseConnectionUrl = getVerticaConnectionUrl(env);
			break;
		default:
			break;
		}
		return databaseConnectionUrl;
	}

	private static String getOracleConnectionUrl(String env) {
		String hostName = null;
		switch (env.toUpperCase()) {
		case "Q1":
//			hostName = "qa1.legacy.adhoc";
			hostName = "ccxqat_adhoc";
			break;
		case "Q2":
			hostName = "qa2.legacy.adhoc";
			break;
		case "Q3":
			hostName = "qa3.legacy.adhoc";
			break;
		case "Q4":
			hostName = "qa4.legacy";
			break;
		case "Q5":
			hostName = "qa5.legacy.adhoc";
			break;
		default:
			System.err.println("Unable to get the hostname for Oracle");
			break;
		}

//		return "jdbc:oracle:thin:@(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=qdborarac-scan)(PORT=1521)))(CONNECT_DATA=(SERVICE_NAME="
//				+ hostName + ")(GLOBAL_NAME=" + hostName + ")))";		

		if (env.toUpperCase().equals("Q1"))
		{
			System.out.println("Using new Q1 connector");
			return "jdbc:oracle:thin:@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=qa1dbccx-scan.ccx.carecentrix.com)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME="
					+ hostName + ")))";
		}
		else
		{
			System.out.println("Using old connector");
			return "jdbc:oracle:thin:@(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=qdborarac-scan)(PORT=1521)))(CONNECT_DATA=(SERVICE_NAME="
					+ hostName + ")(GLOBAL_NAME=" + hostName + ")))";
		}
	}

	
	
	private static String getVerticaConnectionUrl(String env) {
		String connectionUrl = null;
		switch (env.toUpperCase()) {
		case "Q1":
		case "Q2":
		case "Q3":
		case "Q4":
		case "Q5":
			connectionUrl = "jdbc:vertica://D1VERTICA:5433/D1DA01";
			break;
		default:
			System.err.println("Unable to get the hostname for Vertica");
			break;
		}
		return connectionUrl;
	}

	public static List<String> convertArrayToList(String[] arrExpectedList) {
		List<String> list = new ArrayList<String>();
		for (String string : arrExpectedList) {
			list.add(string);
		}
		return list;
	}

	public static List<String> getFieldValueListFromTable(Object object, String fieldName) {
		@SuppressWarnings("unchecked")
		Map<Integer, Map<String, Object>> dataTable = (Map<Integer, Map<String, Object>>) object;
		List<String> list = new ArrayList<String>();
		for (Map.Entry<Integer, Map<String, Object>> obj : dataTable.entrySet()) {
			Map<String, Object> dataTable2 = obj.getValue();
			for (Map.Entry<String, Object> obj2 : dataTable2.entrySet()) {
				if (obj2.getKey().equalsIgnoreCase(fieldName)) {
					if (obj2.getValue() == null || obj2.getValue().toString().trim().equals("")) {
						list.add("");
					} else {
						list.add(obj2.getValue().toString());
					}
				}
			}
		}
		return list;
	}

	/**
	 * This method validate either list of field values or a single value and return
	 * boolean type. <br>
	 * dataPool can be a table or a list or a value.<br>
	 * field is the targeted or TO BE validated field.<br>
	 * expectedValueList can be either a list in String format or a String value<br>
	 * 
	 * @param dataPool
	 * @param fieldName
	 * @param expectedValueList
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static boolean validateTableFieldValues(Object dataPool, String fieldName, String expectedValueList) {
		boolean flag = false;
		if (dataPool instanceof Map<?, ?>) {
			List<String> actualTextList = new ArrayList<String>();
			actualTextList = getFieldValueListFromTable(dataPool, fieldName);

			String[] arrExpectedList = expectedValueList.split(",");
			List<String> expectedTextList = convertArrayToList(arrExpectedList);

			flag = compareTwoList(actualTextList, expectedTextList);
		} else if (dataPool instanceof ArrayList<?>) {
			List<Object> tempList = (List<Object>) dataPool;
			List<String> actualTextList = new ArrayList<String>();
			for (int i = 0; i < tempList.size(); i++) {
				actualTextList.add(tempList.get(i).toString());
			}
			String[] arrExpectedList = expectedValueList.split(",");
			List<String> expectedTextList = convertArrayToList(arrExpectedList);

			flag = compareTwoList(actualTextList, expectedTextList);
		} else {
			String actualText = dataPool.toString().trim();
			String expectedText = expectedValueList.trim();
			if (actualText.equalsIgnoreCase(expectedText)) {
//				matched_message(actualText, expectedText);
				flag = true;
			}
		}
		return flag;
	}

	private static boolean compareTwoList(List<String> actualTextList, List<String> expectedTextList) {
		boolean flag = false;
		try {
			int actualTextListSize = actualTextList.size();
			int expectedTextListSize = expectedTextList.size();
			int iCounter = 0;

			if (actualTextListSize == expectedTextListSize) {
				iCounter = compareList(actualTextList, expectedTextList);
				if (iCounter == actualTextListSize && iCounter == expectedTextListSize) {
					flag = true;
				}
			} else if (actualTextListSize > expectedTextListSize && expectedTextListSize == 1) {
				iCounter = compareList(actualTextList, expectedTextList);
				if (iCounter == actualTextListSize && expectedTextListSize == 1) {
					flag = true;
				}
			} else {
				System.out.println("Failure Reason -> Actual List Size : " + actualTextListSize
						+ " | Expected List Size : " + expectedTextListSize);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	private static int compareList(List<String> actualTextList, List<String> expectedTextList) {
		int iCounter = 0;
		for (String actual : actualTextList) {
			String actualText = actual.toString().trim();
			for (String expected : expectedTextList) {
				String expectedText = expected.toString().trim();
				if (actualText.equalsIgnoreCase(expectedText)) {
//					matched_message(actualText, expectedText);
					iCounter++;
					break;
				}
			}
		}
		return iCounter;
	}

	

	public static Map<Integer, Map<String, String>> getRecordstFromTable(String env, String databaseType,
			String query) {
		Connection conn = null;
		Statement stmt = null;
		String[] resultFields = query.toUpperCase().substring(6, query.indexOf("from")).trim().replace("DISTINCT", "").trim().split(",");

		int rownum = 1;
		String userName = getUserId(databaseType);
		String pwd = getEncodedPasswordId(env, databaseType);
		String dbUrl = getDatabaseConnectionUrl(env, databaseType);
		query = query.replace("'USERID'", "'" + getNetworkUserId().toUpperCase() + "'");

		Map<Integer, Map<String, String>> lMap = new LinkedHashMap<>();
		System.out.println("Query  : " + query);
		Reporter.log("Query  : " + query);
		System.out.println("dbUrl  : " + dbUrl);
		Reporter.log("dbUrl  : " + dbUrl);
		System.out.println("userName  : " + userName);
		Reporter.log("userName  : " + userName);
		System.out.println("pwd  : " + pwd);
		
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			conn = DriverManager.getConnection(dbUrl, userName, pwd);
			stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(query);
		
			// ResultSetMetaData rsMtdt = rs.getMetaData();
			String res = "";
			while (rs.next()) {
				Map<String, String> mp = new LinkedHashMap<String, String>();
				for (int i = 0; i < resultFields.length; i++) {
					
					if (resultFields[i].trim().contains(" ")) {
						String[] temp = resultFields[i].trim().split(" ");
						if (rs.getNString(temp[1].trim()) == null || rs.getNString(temp[1].trim()).trim().equals(""))
							res = "";
						else
							res = rs.getNString(temp[1].trim()).trim();
						System.out.println(temp[1].trim());
						mp.put(temp[1].trim(), res);
					} else {
						if (rs.getNString(resultFields[i].trim()) == null
								|| rs.getNString(resultFields[i].trim()).trim().equals(""))
							res = "";
						else
							res = rs.getNString(resultFields[i].trim()).trim();
						mp.put(resultFields[i].trim(), res);
					}
					
				}
				lMap.put(rownum, mp);
				rownum++;
				//System.out.println(lMap);
			}
			return lMap;
		} catch (ClassNotFoundException e) {
			System.out.println("Issue in getRecordstFromTable method : " + e);
			Reporter.log("Issue in getRecordstFromTable method : " + e);
			e.printStackTrace();
			return lMap;
		} catch (SQLException e) {
			System.out.println("Issue in getRecordstFromTable method : " + e);
			Reporter.log("Issue in getRecordstFromTable method : " + e);
			e.printStackTrace();
			return lMap;
		}
	}

	public static boolean insertUpdateRecordsInTable(String env, String databaseType, String query) {
		Connection conn = null;
		Statement stmt = null;

		String userName = getUserId(databaseType);
		String pwd = getEncodedPasswordId(env, databaseType);
		String dbUrl = getDatabaseConnectionUrl(env, databaseType);

		System.out.println("Query  : " + query);
		System.out.println("dbUrl  : " + dbUrl);
		System.out.println("userName  : " + userName);
		System.out.println("pwd  : " + pwd);
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			conn = DriverManager.getConnection(dbUrl, userName, pwd);
			stmt = conn.createStatement();
			stmt.executeUpdate(query);
			return true;
		} catch (ClassNotFoundException e) {
			System.out.println("Issue in getRecordstFromTable method : " + e);
			return false;
		} catch (SQLException e) {
			System.out.println("Issue in getRecordstFromTable method : " + e);
			return false;
		}
	}

//	private static void no_result_message(String sqlQuery) {
//		String displayMessagesInConsole = testData.get("DisplayMessagesInConsole");
//		if (displayMessagesInConsole != null && displayMessagesInConsole.equalsIgnoreCase("Y")) {
//			System.out.println("No result returned for : " + sqlQuery);
//		}
//	}

//	private static void matched_message(String actualText, String expectedText) {
//		String displayMessagesInConsole = testData.get("DisplayMessagesInConsole");
//		if (displayMessagesInConsole != null && displayMessagesInConsole.equalsIgnoreCase("Y")) {
//			System.out.println("Actual: " + actualText + " | Expected: " + expectedText);
//		}
//	}
	public static String getClobRecordstFromTable(String env, String databaseType,
			String query) {
		Connection conn = null;
		Statement stmt = null;
		String[] resultFields = query.toUpperCase().substring(6, query.indexOf("from")).trim().replace("DISTINCT", "").trim().split(",");

		int rownum = 1;
		String userName = getUserId(databaseType);
		String pwd = getEncodedPasswordId(env, databaseType);
		String dbUrl = getDatabaseConnectionUrl(env, databaseType);
		query = query.replace("'USERID'", "'" + getNetworkUserId().toUpperCase() + "'");

		Map<Integer, Map<String, String>> lMap = new LinkedHashMap<>();
		System.out.println("Query  : " + query);
		Reporter.log("Query  : " + query);
		System.out.println("dbUrl  : " + dbUrl);
		Reporter.log("dbUrl  : " + dbUrl);
		System.out.println("userName  : " + userName);
		Reporter.log("userName  : " + userName);
		System.out.println("pwd  : " + pwd);
		StringBuffer buffer = new StringBuffer();
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			conn = DriverManager.getConnection(dbUrl, userName, pwd);
			stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(query);
		
			// ResultSetMetaData rsMtdt = rs.getMetaData();
			String res = "";
			while (rs.next()) {
				System.out.println(resultFields[0]);
				Clob clob = rs.getClob(resultFields[0].trim());
				BufferedReader stringReader = new BufferedReader(
		                clob.getCharacterStream());
		        String singleLine = null;
		       
		        while ((singleLine = stringReader.readLine()) != null) {
		        	buffer.append(singleLine);
		        }
			}
			return buffer.toString();
		} catch (ClassNotFoundException e) {
			System.out.println("Issue in getRecordstFromTable method : " + e);
			Reporter.log("Issue in getRecordstFromTable method : " + e);
			e.printStackTrace();
			return buffer.toString();
		} catch (SQLException e) {
			System.out.println("Issue in getRecordstFromTable method : " + e);
			Reporter.log("Issue in getRecordstFromTable method : " + e);
			e.printStackTrace();
			return buffer.toString();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return buffer.toString();
		}
	}
	
	
	public static void executeSqlQueryAuto2(String env, String databaseType, String sqlQuery) throws SQLException {

		String userid = getUserId(databaseType);
		String password = getEncodedPasswordId(env, databaseType);

		String dbUrl = getDatabaseConnectionUrl(env, databaseType);
		Connection connection = null;
		Statement statement = null;
		if (databaseType.equalsIgnoreCase("Oracle")) {
			try {
				connection = DriverManager.getConnection(dbUrl, userid, password);
				statement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} else if (databaseType.equalsIgnoreCase("Vertica")) {
			Properties prop = new Properties();
			prop.put("user", userid);
			prop.put("password", password);
			prop.put("tlsmode", "require");
			prop.put("Locale", "LEN_S1");

			connection = DriverManager.getConnection(dbUrl, prop);
			statement = connection.createStatement();
		} else {
			System.err.println("Unknown database");

		}

		statement.executeQuery(sqlQuery);
		statement.close();
		connection.close();	
		
	}

	
	@SuppressWarnings("unchecked")
	public static boolean validateTableFieldWithNullValues(Object dataPool, String fieldName, String expectedValueList) {
		boolean flag = false;
		if (dataPool instanceof Map<?, ?>) {
			List<String> actualTextList = new ArrayList<String>();
			actualTextList = getFieldValueListFromTable(dataPool, fieldName);

			String[] arrExpectedList = expectedValueList.split(",");
			List<String> expectedTextList = convertArrayToList(arrExpectedList);

			flag = compareTwoList(actualTextList, expectedTextList);
		} else if (dataPool instanceof ArrayList<?>) {
			List<Object> tempList = (List<Object>) dataPool;
			List<String> actualTextList = new ArrayList<String>();
			for (int i = 0; i < tempList.size(); i++) {
				if (tempList.get(i) == null) {
					actualTextList.add("");
				} else {
					actualTextList.add(tempList.get(i).toString());
				}
			}
			String[] arrExpectedList = expectedValueList.split(",");
			List<String> expectedTextList = convertArrayToList(arrExpectedList);

			flag = compareTwoList(actualTextList, expectedTextList);
		} else {
			String actualText = dataPool.toString().trim();
			String expectedText = expectedValueList.trim();
			if (actualText.equalsIgnoreCase(expectedText)) {
//				matched_message(actualText, expectedText);
				flag = true;
			}
		}
		return flag;
	}
	
	
	public static Object getDataOrNull(String env, String databaseType, String sqlQuery) throws SQLException {
		try {
			return executeSqlQueryAuto(env, databaseType, sqlQuery);
		} catch (NullPointerException e) { return null; }
	}

}
