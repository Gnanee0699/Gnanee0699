package com.carecentrix.portal.pages;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.carecentrix.utilities.Constant;
import com.carecentrix.utilities.SeleniumMethods;

/**
 * @author KKJANAK
 *
 */

public class DiagnosisPage {

	WebDriver driver;
	int rowCount;

	private static final Logger log = LogManager.getLogger(DiagnosisPage.class);

	public DiagnosisPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}

	@FindBy(xpath = "//section[@class='main-layout__section']//div[@class='css-0']//div[1]//button[@class='completed css-drfiuf']")
	WebElement memberInfoTabTopButton;

	@FindBy(xpath = "//span[@class='form-nav__title' and contains(text(),'Member Info.')]//following-sibling::span[@class='form-nav__caption']")
	WebElement memberInfoTabStatus;

	@FindBy(xpath = "//input[@name='icdCode']")
	WebElement searchICDCode;

	@FindBy(name = "description")
	WebElement description;

	//@FindBy(xpath = "//div[contains(@class,'flexgrid__item small--col-1')]//button[@class='css-1lvde2m' and @type='submit']")
	@FindBy(xpath = "(//button[@type='submit'])[2]")
	WebElement searchButton;

	@FindBy(xpath = "//table[@class='table-content fade-in']")
	WebElement searchResultTable1;

	// UI changes applied
	//@FindBy(xpath = "//table[@class='table-content fade-in with-border undefined undefined']//tbody//tr[1]//td[3]//button")
	//@FindBy(xpath = "//table[@class='table-content fade-in with-border']//tbody//tr[1]//td[3]//button")
	//@FindBy(xpath = "//table[@class='table-content fade-in with-border undefined undefined undefined']//tbody//tr[1]//td[3]//button")
	@FindBy(xpath = "//table[contains(@class,'table-content fade-in with-border')]//tbody//tr[1]//td[3]//button")
	WebElement addButton;

	@FindBy(xpath = "//button[@class='css-1y02vpj' and contains(text(),'Add') and @aria-disabled='true']")
	WebElement availableAddButton;

//	@FindBy(xpath = "//button[@class='css-16s2dtn' and contains(text(),'primary')]")
	@FindBy(xpath = "//button[normalize-space()='primary']")
	WebElement primaryButton;

//	@FindBy(xpath = "//button[@class='css-16s2dtn' and contains(text(),'secondary')]")
	@FindBy(xpath = "//button[normalize-space()='secondary']")
	WebElement secondaryButton;

//	@FindBy(xpath = "//button[@class='css-16s2dtn' and contains(text(),'tertiary')]")
	@FindBy(xpath = "//button[normalize-space()='tertiary']")
	WebElement teritoryButton;

//	@FindBy(xpath = "//button[@class='css-sgc28y' and contains(text(),'other')]")
	@FindBy(xpath = "//button[normalize-space()='other']")
	WebElement otherButton;

	// UI changes applied.
	//@FindBy(xpath = "//table[@class='table-content fade-in with-border undefined undefined']//tbody//tr")
	//@FindBy(xpath = "//table[@class='table-content fade-in with-border']//tbody//tr")
	@FindBy(xpath = "//table[contains(@class, 'table-content fade-in with-border undefined undefined')]//tbody//tr")
	List<WebElement> searchResultTable;
	
	// UI changes applied.
	//@FindBy(xpath = "//table[@class='table-content fade-in with-border undefined undefined']//tbody//tr//td[3]//div//button[@class='css-1y02vpj']")
	//@FindBy(xpath = "//table[@class='table-content fade-in']//tbody//tr//td[3]//div//button[@class='css-1y02vpj']")
	@FindBy(xpath = "//table[contains(@class, 'table-content fade-in with-border undefined undefined')]//tbody//tr//td[3]//div//button[@class='css-1y02vpj']")
	WebElement secondRowAddButton;
	
	// UI changes applied.
	@FindBy(xpath = "//table[contains(@class, 'table-content fade-in with-border undefined undefined')]//tbody//tr[1]//td[3]//div//button[@class='css-1y02vpj']")
	//@FindBy(xpath = "//table[@class='table-content fade-in']//tbody//tr[1]//td[3]//div//button[@class='css-1y02vpj']")
	WebElement tertiaryAddButton;

	@FindBy(xpath = "//table[@class='table-content fade-in']//tbody//tr[1]//td[3]//div//button[@class='css-1y02vpj']")
	WebElement otherAddButton;

	@FindBy(xpath = "//div[@class='count-title']")
	WebElement scrollDown;

	@FindBy(xpath = "//span[@class='table__tag']")
	WebElement primaryAdded;

//	@FindBy(xpath = "//button[@class='css-d75n6e']")
//	@FindBy(xpath = "//button[contains(@class,'css-d75n6e')]")
	@FindBy(xpath = "//button[normalize-space()='Save & Continue']")
	WebElement nextButton;

	@FindBy(xpath = "//div[@class='alert__content']")
	WebElement alertCheck;

	@FindBy(xpath = "//button[@class='alert__close']")
	WebElement alertClose;

	@FindBy(xpath = "//div[@class='form-nav__info']//span[@class='form-nav__title' and contains(text(),'Diagnosis')]//following-sibling::span[@class='form-nav__caption']")
	WebElement diagnosisTabStatus;

	@FindBy(xpath = "//span[@class='form-nav__title' and contains(text(),'Diagnosis')]")
	WebElement diagnosisTabTitle;
	
	// UI change updated
	//@FindBy(xpath = "//div[@class='table-container']//table[@class='table-content fade-in with-border undefined undefined']")
	//@FindBy(xpath = "//div[@class='search__filter']//following-sibling::div//table[@class='table-content fade-in with-border']")
	//@FindBy(xpath = "//div[@class='table-container']//table[@class='table-content fade-in with-border undefined undefined undefined']")
	@FindBy(xpath = "//div[@class='table-container']//table[contains(@class, 'table-content fade-in with-border')]")
	WebElement diagnosisTabSearchResultPanel;

	@FindBy(xpath = "//*/section[2]/div[2]/table/tbody/tr[1]/td[3]/div/div/div/button")
	List<WebElement> diagnosisTabDiagnosisTypes;

	@FindBy(xpath = "//div[@class='button-content']")
	WebElement diagnosisTabDiagnosisTypesPanel;

	@FindBy(xpath = "//*[@id='panel:8-1']/section[2]/section/div")
	WebElement diagnosisTabSearchErrorMessage;
	
	@FindBy(xpath = "//*[@id='panel:8-1']/section[2]/section/div//span[@class='empty-state__title']")
	WebElement diagnosisTabSearchErrorMessageContent;
	
	@FindBy(xpath = "//span[@class='empty-state__title' and contains(text(),'Your search produced more than 50 results')]")
	WebElement diagnosisTabSearchMoreErrorMessageContent;

	@FindBy(xpath = "//button[@class='completed css-drfiuf' and @id='tab:1-0']")
	WebElement diagnosisTabMemberInfoClick;

	@FindBy(xpath = "//div[@class='form-nav css-1dxxh68']//button[2]")
	WebElement diagnosisTab_status;

	@FindBy(xpath = "//div[@class='form-nav css-1dxxh68']//button[2]//span[@class='form-nav__title']")
	WebElement diagnosisTabSpan1;

	@FindBy(xpath = "//div[@class='form-nav css-1dxxh68']//button[2]//span[@class='form-nav__caption']")
	WebElement diagnosisTabSpan2;
	
	@FindBy(xpath = "//button[@class='css-1y02vpj' and contains(text(),'Add') and not(@disabled)]")
	List<WebElement> diagnosisTabAddButton;

	List<String> labelsList = new ArrayList<String>();

	public boolean isDiagnosisTabAvailable() {
		boolean isDiagnosisTabAvailable = true;
		try {
			SeleniumMethods.waitUntilClickable(diagnosisTab_status);
			if (diagnosisTab_status.isDisplayed()) {
				SeleniumMethods.javaScriptExecutorClick(diagnosisTab_status);
				if (diagnosisTabSpan1.getText().equalsIgnoreCase(Constant.DIAGNOSIS)
						&& diagnosisTabSpan2.getText().equalsIgnoreCase(Constant.STATUS_COMPLETED)) {
					isDiagnosisTabAvailable = false;
				}
			}
		} catch (NoSuchElementException exception) {
			log.info("Diagnosis Tab is not available to enter details");
		}
		return isDiagnosisTabAvailable;
	}

	public boolean enterICDCode(String valueICDCode) {
		SeleniumMethods.waitUntilElementIsClickable(searchICDCode);
		boolean flag = isDiagnosisTabAvailable() && searchICDCode.isDisplayed();
		if (flag)
		{
//			String strText =  searchICDCode.getText();
//			System.out.println("len" + strText.length() + strText);
//			if (strText.length()== 0) 		
			searchICDCode.sendKeys(valueICDCode);
		}
		return flag;
	}

	public void clickSearchButton() {
		if (isDiagnosisTabAvailable()) {
			SeleniumMethods.waitUntilElementIsClickable(searchButton);
			searchButton.click();
			log.info("Search Button Clicked");
		} else {
			log.info("Browser not active");
		}
	}

	public void verifySearchResult(String ICDCode1) {
		if (isDiagnosisTabAvailable() && diagnosisTabSearchResultPanel.isDisplayed()) {
			rowCount = searchResultTable.size();
			log.info("List Size is {}", rowCount);

			if (rowCount > 0) {
				for (WebElement webElement : searchResultTable) {
					if (webElement.getText().contains(ICDCode1))
						labelsList.add(webElement.getText());
				}
				log.info("Search result {}", labelsList);
			} else {
				log.info("No Results Found");
			}
		}
	}

	public void clickAddButton() {
		SeleniumMethods.longwaitUntilElementIsClickable(addButton);
		if (isDiagnosisTabAvailable() && addButton.isDisplayed()) {
			addButton.click();
			log.info("Add button clicked");
		}
	}

	public void clickAvailableAddButton() {
		SeleniumMethods.longwaitUntilElementIsClickable(diagnosisTabAddButton.get(0));
		if (isDiagnosisTabAvailable() && diagnosisTabAddButton.get(0).isDisplayed()) {
			scrollDownPage();
			diagnosisTabAddButton.get(0).click();
			log.info("Add button clicked");
		}
	}
	public void searchByDescription(String searchDescription) {
		SeleniumMethods.waitUntilElementIsClickable(description);
		description.sendKeys(searchDescription);
	}

	public void searchByICDCodeAndDescription(String searchICDCode, String diagnosisDescription) {
		enterICDCode(searchICDCode);
		searchByDescription(diagnosisDescription);
	}

	public void clickPrimaryButton() {
		rowCount = searchResultTable.size();
		clickAddButton();
		if (rowCount > 0) {
			SeleniumMethods.waitUntilElementIsClickable(primaryButton);
			primaryButton.click();
			log.info("Primary Button is clicked");
			scrollDown();
		} else {
			log.info("Primary Button is not clicked");
		}
	}

	public boolean isPrimaryOptionAdded() {
		return SeleniumMethods.isTextPresent("//span[@class='table__tag']");
		
	}

	public void clickSecondaryButton() {
		rowCount = searchResultTable.size();
		if (rowCount > 0) {
			secondaryButton.click();
			scrollDown();
		}
	}

	public void isSecondaryOptionAdded() {
		if (SeleniumMethods.isTextPresent("//span[@class='table__tag' and contains(text(),'secondary')]")) {
			log.info("Secondary Option Added");
		}
	}

	public void clickTertiaryButton() {
		rowCount = searchResultTable.size();
		if (rowCount > 0) {
			teritoryButton.click();
			scrollDown();
		}
	}

	public void isTertiaryOptionAdded() {
		if (SeleniumMethods.isTextPresent("//span[@class='table__tag' and contains(text(),'tertiary')]")) {
			log.info("Tertiary Option Added");
		}
	}

	public void clickOtherButton() {
		rowCount = searchResultTable.size();
		if (rowCount > 0) {
			otherButton.click();
			scrollDown();
		}
	}

	public void isOtherOptionAdded() {
		if (SeleniumMethods.isTextPresent("//span[@class='table__tag' and contains(text(),'other')]")) {
			log.info("Other Option Added");
		}
	}

	public void scrollDown() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();", scrollDown);
	}
	
	public void scrollDownPage() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1000)");
	}

	public void clickNextButton() {
		nextButton.click();
		if (isPrimaryOptionAdded()) {
			log.info("Primary option is added");
		} else if (checkErrorMessage()) {
			alertClose.click();
			addButton.click();
			clickPrimaryButton();
		}
	}

	public void quitBrowser() {
		driver.quit();
	}

	public boolean checkErrorMessage() {
		if (alertCheck.isDisplayed()) {
			log.info("Alert message to add Primary Button");
			return true;
		} else
			return false;
	}

	public void verifyDiagnosisTypes(String diagnosisNamePrimary, String diagnosisNameSecondary,
			String diagnosisNameTertiary, String diagnosisNameOther) {
		if (diagnosisTabDiagnosisTypesPanel.isDisplayed() && !diagnosisTabDiagnosisTypes.isEmpty()
				&& diagnosisNamePrimary.equalsIgnoreCase(diagnosisTabDiagnosisTypes.get(0).getText())
				&& diagnosisNameSecondary.equalsIgnoreCase(diagnosisTabDiagnosisTypes.get(1).getText())
				&& diagnosisNameTertiary.equalsIgnoreCase(diagnosisTabDiagnosisTypes.get(2).getText())
				&& diagnosisNameOther.equalsIgnoreCase(diagnosisTabDiagnosisTypes.get(3).getText())) {
			log.info("All the diagnosis Types are displayed");
		}
	}

	public void searchByInvalidICDCodeAndDescription(String invalidICDCode, String invalidDescription) {
		enterICDCode(invalidICDCode);
		searchByDescription(invalidDescription);
	}

	public boolean verifyErrorMessageToUpdateSearchCriteria() {
		return (diagnosisTabSearchErrorMessage.isDisplayed() && diagnosisTabSearchErrorMessageContent.getText()
				.equalsIgnoreCase(Constant.ORDERING_PHYSICIAN_ERROR_MESSAGE));
	}

	public void enterDetailsToGetMoreRecords(String iCDCodeForMoreResult) {
		searchByDescription(iCDCodeForMoreResult);
	}

	public boolean verifyErrorMessageForMoreRecords() {
		SeleniumMethods.longwaitUntilElementIsVisible(diagnosisTabSearchMoreErrorMessageContent);
		return (diagnosisTabSearchMoreErrorMessageContent.getText()
				.equalsIgnoreCase(Constant.DIAGNOSIS_MORE_RECORDS_MESSAGE));
	}

	public void chooseDiagType(String digType) {
		if (digType.equalsIgnoreCase(Constant.PRIMARY)) {
			clickPrimaryButton();
		}
		if (digType.equalsIgnoreCase(Constant.SECONDARY)) {
			clickSecondaryButton();
		}
		if (digType.equalsIgnoreCase(Constant.TERTIARY)) {
			clickTertiaryButton();
		}
		if (digType.equalsIgnoreCase(Constant.OTHER)) {
			clickOtherButton();
		}
	}

	public boolean checkPrimaryOptionDisabled() {
		// TODO Auto-generated method stub
		return false;
	}

}
