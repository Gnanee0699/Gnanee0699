package com.carecentrix.portal.pages;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.carecentrix.utilities.Constant;
import com.carecentrix.utilities.SeleniumMethods;

/**
 * @author KKJANAK
 *
 */

public class MemberInfoPage {

	private static final Logger log = LogManager.getLogger(MemberInfoPage.class);

	@FindBy(xpath = "//button[@class='modal-content__close']")
	WebElement closeButton;

//	@FindBy(xpath = "//button[@class='push-half--top css-zdppwq']")
	@FindBy(xpath = "//*[@type='submit' and contains(text(),'Confirm Information')]")
	WebElement confirmInfoButton;

	@FindBy(xpath = "//button[@class='css-nuwoyx']")
	WebElement continueWithInfoBtn;

	@FindBy(xpath = "//section[@class='main-layout__header']//h3")
	WebElement createReqHeader;

	@FindBy(xpath = "//div//a[@class=' profile-box__request-button button button--primary']")
	WebElement createRequest;

	@FindBy(xpath = "//div[@id='react-toast']//div[@class='alert error']")
	WebElement dateAlertBox;

	@FindBy(xpath = "//div[@id='react-toast']//span[@class='alert__title']")
	WebElement dateAlertContent;

	@FindBy(xpath = "//input[@label='Date of birth']")
	WebElement dob;

	WebDriver driver;

	@FindBy(xpath = "//input[@label='Earliest Requested Start Date']")
	WebElement earliestReqStartDate;

	@FindBy(xpath = "//div[@class='Toaster__message-wrapper']//div[@class='alert error']//span[@class='alert__description']")
	WebElement errorMessageContent;

	@FindBy(xpath = "//div[@class='Toaster__message-wrapper']//div[@class='alert error']")
	WebElement errorMessagePanel;

	@FindBy(xpath = "//div[@class='Toaster__message-wrapper']//div[@class='alert error']//span[@class='alert__title']")
	WebElement errorMessageTitle;

	@FindBy(name = "firstName")
	WebElement firstName;

	@FindBy(xpath = "//input[contains(@id,'react-select-2-input')]")
	WebElement healthPlan;

	@FindBy(name = "address")
	WebElement memAddress;

	@FindBy(xpath = "//div[@class='form-nav css-1dxxh68']//button[1]")
	WebElement memberinfoTab_status;

	@FindBy(xpath = "//*[@id='react-toast']/span[1]/div[2]/div/div/div/div[2]/span[1]")
	WebElement memberInfoTabDateFieldErrorMessage;

	@FindBy(xpath = "//div[@class='form-nav css-1dxxh68']//button[1]//span[@class='form-nav__title']")
	WebElement memberInfoTabSpan1;

	@FindBy(xpath = "//div[@class='form-nav css-1dxxh68']//button[1]//span[@class='form-nav__caption']")
	WebElement memberInfoTabSpan2;

	@FindBy(xpath = "//div[@class='form__text-header success-status']//div//h2")
	WebElement memElegibleMsg;

	@FindBy(name = "gender")
	WebElement memGender;

	@FindBy(name = "homeCity")
	WebElement memHomeCity;

	@FindBy(name = "homeZip")
	WebElement memHomeZip;

	@FindBy(name = "lastName")
	WebElement memLastName;

	@FindBy(name = "phone")
	WebElement memPhone;

	@FindBy(name = "state")
	WebElement memState;

	@FindBy(xpath = "//*[@id='react-select-3-input']")
	WebElement referralRequestType_dd;

	@FindBy(xpath = "//label[contains(text(),'Referral source')]")
	WebElement referralRequestLbl;

	@FindBy(xpath = "//div/form/div[1]/div/fieldset/div/div[9]/div/div/div/div[2]/div")
	List<WebElement> referralSourceList;

	@FindBy(xpath = "//input[contains(@id,'react-select-3-input')]")
	WebElement referralSource;

	@FindBy(xpath = "//button[@class='css-14e4j4f']")
	WebElement reviewInfoBtn;

	@FindBy(xpath = "//span[@class='modal-message__description text-center push--bottom']")
	WebElement reviewInfoErrCnt;

	@FindBy(xpath = "//span[@class='modal-message__title text-center']")
	WebElement reviewInfoErrTitle;

	@FindBy(xpath = "//div[contains(@class,'modal-content')]")
//	@FindBy(xpath = "//div[@class='modal-content']")
	WebElement reviewMessage;

	@FindBy(xpath = "//input[contains(@value,'Sign out')]")
	WebElement signout;

	@FindBy(name = "subscriberId")
	WebElement subscriberID;

	@FindBy(xpath = "//div[contains(@id,'0')]//input[@name='firstName']")
	WebElement verifyFName;

	@FindBy(xpath = "//div[contains(@id,'0')]//input[@name='lastName']")
	WebElement verifyLName;

	//@FindBy(xpath = "//button[@type='submit' and contains(@class,'css-giff87')]")
	@FindBy(xpath = "//*[@type='submit' and contains(text(),'Verify Member')]")
	WebElement verifyMemberButton;
	
	@FindBy(xpath = "//*[@type='submit' and contains(text(),'Continue')]")
	WebElement ConfirmButton;

	@FindBy(xpath = "//div[@class=' css-1uccc91-singleValue']")
	WebElement verifyHP;

	@FindBy(xpath = "//div[@class='css-0']//label[contains(text(),'Last name')]")
	WebElement lblLastName;

	@FindBy(xpath = "//div[@class='css-0']//label[contains(text(),'First name')]")
	WebElement lblFirstName;

	@FindBy(xpath = "//div[@class='css-0']//label[contains(text(),'Date of birth')]")
	WebElement lblDOB;

	@FindBy(xpath = "//div[@class='css-0']//label[contains(text(),'Health plan name')]")
	WebElement lblHPName;

	@FindBy(xpath = "//div[@class='css-0']//label[contains(text(),'Subscriber ID')]")
	WebElement lblSubscriberID;

	@FindBy(xpath = "//div[@class='css-0']//label[contains(text(),'Referral source')]")
	WebElement lblReferralSource;

	@FindBy(xpath = "//div[@class='css-0']//label[contains(text(),'Earliest Requested Start Date')]")
	WebElement lblEarliestReqStartDate;

	List<String> externalReferralList = new ArrayList<String>();

	public MemberInfoPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}

	private void addressValidation() {
		SeleniumMethods.longwaitUntilElementIsVisible(memAddress);
		getAttributeForValidation(memAddress);
	}

	public void blankValuetoUserDetails() {
		log.info("Blank values are passed successfully");
	}

	public void checkAvailabilityofFields() {
	}

	public boolean checkDateValidationErrMsg() {
		SeleniumMethods.longwaitUntilElementIsVisible(dateAlertBox);
		return dateAlertBox.isDisplayed() && dateAlertContent.getText().equalsIgnoreCase(Constant.INVALID_DATE_ERR);
	}

	public void checkReferralTypeDropdownValues(String referralSrcList) {
		SeleniumMethods.longwaitUntilElementIsClickable(referralRequestType_dd);
		referralRequestType_dd.click();
		List<String> referralSourceUIList = new ArrayList<String>();
		for (WebElement dd_list : referralSourceList) {
			if (!dd_list.getText().isEmpty()) {
				referralSourceUIList.add(dd_list.getText());
			}
		}
		SeleniumMethods.compareListValues(referralSourceUIList, referralSrcList);
	}

	public boolean checkVerifyButton() {
		return verifyMemberButton.isEnabled();
	}

	public void clickAutoPopulatedFieldVerification() {
		genderValidation();
		homeZipValidation();
		stateValidation();
		homeCityValidation();
		addressValidation();
		phoneValidation();

	}

	public void clickCloseButton() {
		SeleniumMethods.waitUntilClickable(closeButton);
		closeButton.click();
	}

	public void clickConfirmInfo() {
		SeleniumMethods.longwaitUntilElementIsClickable(confirmInfoButton);
		confirmInfoButton.click();
	}

	public boolean clickCreateRequestButton() {
		try {
			Thread.sleep(700);
			SeleniumMethods.longwaitUntilElementIsClickable(createRequest);
			createRequest.click();
			SeleniumMethods.longwaitUntilElementIsVisible(createReqHeader);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return createReqHeader.isDisplayed();
	}

	public void clickOnContinueButton() {
		SeleniumMethods.waitUntilElementIsClickable(continueWithInfoBtn);
		if (continueWithInfoBtn.isDisplayed()
				&& continueWithInfoBtn.getText().equalsIgnoreCase(Constant.MEMBER_INFO_CONTINUE_BTN)) {
			continueWithInfoBtn.click();
			clickCloseButton();
			driver.navigate().refresh();
		}
	}

	public void clickReviewButton() {
		SeleniumMethods.waitUntilElementIsClickable(reviewInfoBtn);
		if (reviewInfoBtn.isDisplayed() && reviewInfoBtn.getText().equalsIgnoreCase(Constant.MEMBER_INFO_REVIEW_BTN)) {
			reviewInfoBtn.click();
			log.info("Review Member Details button clicked");
		}
	}

	public void clickVerifyMemberBtn() {
		SeleniumMethods.shortwaitUntilElementIsClickable(verifyMemberButton);
		verifyMemberButton.click();
	}
	
	public void clickConfirmBtn() {
		SeleniumMethods.shortwaitUntilElementIsClickable(ConfirmButton);
		ConfirmButton.click();
	}

	public void closeBrowser() {
		if (SeleniumMethods.isBrowserActive())
			driver.close();
	}

	public void editDOB(String dob2) {
		sendDate(dob, dob2);
	}

	public void editEarlierStartDate(String earlierReqStartDate) {
		SeleniumMethods.clearData(earliestReqStartDate);
		earliestReqStartDate.click();
		SeleniumMethods.waitUntilElementIsClickable(earliestReqStartDate);
		earliestReqStartDate.clear();
		earliestReqStartDate.sendKeys(earlierReqStartDate);
		earliestReqStartDate.sendKeys(Keys.ESCAPE);

	}

	public void editFirstName(String fName) {
		sendInputDetails(firstName, fName);
	}

	public void editLastName(String lName) {
		sendInputDetails(memLastName, lName);
	}

	public void editSubscriberID(String sID) {
		sendInputDetails(subscriberID, sID);
	}

	public void enterDetailsToCheckDOB(String lastNm, String firstNm, String dobField) {
		memLastName.sendKeys(lastNm);
		firstName.sendKeys(firstNm);
		sendDate(dob, dobField);
	}

	public void sendInputDetails(WebElement element, String inputData) {
		SeleniumMethods.clearData(element);
		element.click();
		SeleniumMethods.waitUntilElementIsClickable(element);
		element.clear();
		element.sendKeys(inputData);
	}

	public void enterDetailsToChecReqStartDate(String lastNm, String firstNm, String dobField, String hp,
			String subscriberId, String referraltyp, String reqDateField) {
		enterMemberDetails(lastNm, firstNm, dobField, hp, subscriberId, referraltyp, reqDateField);
	}

	public void enterMemberDetails(String lastNm, String firstNm, String dobField, String healthPln,
			String subscriberId, String referralTyp, String reqDateField) {
		memLastName.sendKeys(lastNm);
		firstName.sendKeys(firstNm);
		sendDate(dob, dobField);
		SeleniumMethods.longwaitUntilElementIsClickable(healthPlan);
		healthPlan.clear();
		SeleniumMethods.javaScriptExecutorClick(healthPlan);
		healthPlan.sendKeys(healthPln);
		healthPlan.sendKeys(Keys.TAB);
		SeleniumMethods.longwaitUntilElementIsClickable(subscriberID);
		subscriberID.sendKeys(subscriberId);
		subscriberID.sendKeys(Keys.TAB);
		SeleniumMethods.longwaitUntilElementIsClickable(referralSource);
		log.info("ReferralType is {}", referralTyp);
		referralSource.click();
		referralSource.sendKeys(referralTyp);
		referralSource.sendKeys(Keys.TAB);
		sendDate(earliestReqStartDate, reqDateField);
	}

	public void enterMemberDetailstoCheckErrorMessage(String lastName2, String firstName2, String dob2,
			String healthPlan2, String subscriberId2, String referralType) {
		enterMemberDetails(lastName2, firstName2, dob2, healthPlan2, subscriberId2, referralType, dob2);
	}

	public void enterMemberInfoDetails(String memLastName, String memFirstName, String memDOB, String memHealthPlan,
			String memSubscriberId, String memRefferralType, String memEarlierRequestedStartDate) {
		if (isMemberInfoTabAvailable()) {
			enterMemberDetails(memLastName, memFirstName, memDOB, memHealthPlan, memSubscriberId, memRefferralType,
					memEarlierRequestedStartDate);
		}
	}

	public void enterUserNameInLowerCase(String lastNm, String firstNm, String dobField, String hp, String subscriberId,
			String referraltyp, String reqDateField) {
		String fName = firstNm.toLowerCase();
		String lName = lastNm.toLowerCase();
		enterMemberDetails(lName, fName, dobField, hp, subscriberId, referraltyp, reqDateField);

	}

	private void genderValidation() {
		SeleniumMethods.longwaitUntilElementIsVisible(memGender);
		getAttributeForValidation(memGender);
	}

	private void getAttributeForValidation(WebElement attributeElement) {
		if (attributeElement.getAttribute(Constant.VALUE) == null
				|| attributeElement.getAttribute(Constant.VALUE).isEmpty()) {
			log.info("{} is null", attributeElement);
		} else {
			log.info("{} is --------------- {}", attributeElement, attributeElement.getAttribute(Constant.VALUE));
		}
	}

	private void homeCityValidation() {
		SeleniumMethods.longwaitUntilElementIsVisible(memHomeCity);
		getAttributeForValidation(memHomeCity);
	}

	private void homeZipValidation() {
		SeleniumMethods.longwaitUntilElementIsVisible(memHomeZip);
		getAttributeForValidation(memHomeZip);
	}

	public void incorrectMemberDetails(String wrongLastName, String memFirstName, String memDOB, String memHealthPlan,
			String memSubscriberId, String memRefferralType, String memRequestStartDate) {

		enterMemberDetails(wrongLastName, memFirstName, memDOB, memHealthPlan, memSubscriberId, memRefferralType,
				memRequestStartDate);

	}

	public boolean isMemberInfoTabAvailable() {
		boolean memberInfoTabAvailability = true;
		try {
			SeleniumMethods.waitUntilElementIsClickable(memberinfoTab_status);
			if (memberinfoTab_status.isDisplayed()) {
				SeleniumMethods.javaScriptExecutorClick(memberinfoTab_status);
				SeleniumMethods.longwaitUntilElementIsVisible(memberInfoTabSpan1);
				SeleniumMethods.longwaitUntilElementIsVisible(memberInfoTabSpan2);
				if (memberInfoTabSpan1.getAttribute("innerText").equalsIgnoreCase(Constant.MEMBER_INFO)
						&& memberInfoTabSpan2.getText().equalsIgnoreCase(Constant.STATUS_COMPLETED)) {
					memberInfoTabAvailability = false;
				}
			}
		} catch (NoSuchElementException exception) {
			log.info("MemberInfo Tab is not available to enter details");
		}
		return memberInfoTabAvailability;
	}

	public boolean isReferralSourceDDAvailable() {
		SeleniumMethods.longwaitUntilElementIsClickable(referralRequestType_dd);
		log.info("{} {}", referralRequestLbl.getText().equalsIgnoreCase(Constant.TXT_REFERRALSOURCE),
				referralRequestType_dd.isDisplayed());
		return (referralRequestLbl.getText().equalsIgnoreCase(Constant.TXT_REFERRALSOURCE)
				&& referralRequestType_dd.isDisplayed());
	}

	public boolean isReferralSourceInAscendingOrder() {
		SeleniumMethods.longwaitUntilElementIsClickable(referralRequestType_dd);
		referralRequestType_dd.click();
		SeleniumMethods.longwaitUntilElementIsClickable(referralRequestType_dd);
		return SeleniumMethods.isCollectionSorted(referralSourceList);
	}

	public boolean mandatoryFieldMissingErrorMsg() {
		SeleniumMethods.longwaitUntilElementIsVisible(errorMessagePanel);
		return (errorMessagePanel.isDisplayed()
				&& errorMessageTitle.getText().equalsIgnoreCase(Constant.MISSING_MSSG_TITLE)
				&& errorMessageContent.getText().equalsIgnoreCase(Constant.MISSING_MSSG_CNTENT));
	}

	public void pageRefresh() {
		driver.navigate().refresh();
	}

	private void phoneValidation() {
		SeleniumMethods.longwaitUntilElementIsVisible(memPhone);
		getAttributeForValidation(memPhone);
	}

	public void signoutFromApplication() {
		SeleniumMethods.shortwaitUntilElementIsClickable(signout);
		signout.click();
	}

	private void stateValidation() {
		SeleniumMethods.longwaitUntilElementIsVisible(memState);
		getAttributeForValidation(memState);
	}

	public boolean validateUserNameDisplayed(String lastNm, String firstNm) {
		SeleniumMethods.longwaitUntilElementIsVisible(verifyLName);
		return (verifyLName.getAttribute(Constant.VALUE).equals(lastNm)
				&& verifyFName.getAttribute(Constant.VALUE).equals(firstNm));
	}

	public boolean verifyErrMsg() {
		return reviewInfoErrCnt.isDisplayed() && reviewInfoErrTitle.isDisplayed()
				&& reviewInfoErrCnt.getText().equalsIgnoreCase(Constant.MEMBER_INFO_ERR_MSG_CONTENT)
				&& reviewInfoErrTitle.getText().equalsIgnoreCase(Constant.MEMBER_INFO_ERR_MSG_TITLE);
	}

	public boolean verifyMemberEligibleMsg() {
		SeleniumMethods.longwaitUntilElementIsVisible(memElegibleMsg);
		try {
			Thread.sleep(2000);
			log.info("Eligibility {}", memElegibleMsg.getAttribute("innerHTML"));
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return memElegibleMsg.isDisplayed()
				&& memElegibleMsg.getAttribute("innerHTML").equalsIgnoreCase(Constant.MEMBER_INFO_ELEGIBLE_MSG);
	}

	public boolean verifyMessage() {
		SeleniumMethods.longwaitUntilElementIsVisible(reviewMessage);
		return reviewMessage.isDisplayed();
	}

	public boolean verifyReviewInfoErrMsgContent() {
		SeleniumMethods.longwaitUntilElementIsVisible(reviewInfoErrCnt);
		return verifyErrMsg();
	}

	public void enterInvalidDateFormat(String fieldName, String invalidDate) {
		if (fieldName.equalsIgnoreCase(Constant.MEMBER_INFO_DOB)) {
			sendDate(dob, invalidDate);
		} else if (fieldName.equalsIgnoreCase(Constant.MEMBER_INFO_EARLIERDATE)) {
			sendDate(earliestReqStartDate, invalidDate);
		}
	}

	public void sendDate(WebElement dateElement, String date) {
		dateElement.clear();
		dateElement.click();
		SeleniumMethods.waitUntilElementIsClickable(dateElement);
		dateElement.sendKeys(date);
		dateElement.sendKeys(Keys.ESCAPE);
		dateElement.sendKeys(Keys.TAB);
	}

	public void enterDetailsInMemberInfoMandatoryFields(String fieldName, String blankValue, String lName, String fName,
			String memDOB, String hp, String subID, String referralType, String earlierReqDate) {
		switch (fieldName) {
		case Constant.LNAME: {
			enterMemberDetails(blankValue, fName, memDOB, hp, subID, referralType, earlierReqDate);
			break;
		}
		case Constant.FNAME: {
			enterMemberDetails(lName, blankValue, memDOB, hp, subID, referralType, earlierReqDate);
			break;
		}
		case Constant.DOB: {
			enterMemberDetails(lName, fName, blankValue, hp, subID, referralType, earlierReqDate);
			break;
		}
		case Constant.SUBID: {
			enterMemberDetails(lName, fName, memDOB, hp, blankValue, referralType, earlierReqDate);
			break;
		}
		case Constant.REFTYPE: {
			memLastName.sendKeys(lName);
			firstName.sendKeys(fName);
			sendDate(dob, memDOB);
			SeleniumMethods.longwaitUntilElementIsClickable(healthPlan);
			healthPlan.clear();
			SeleniumMethods.javaScriptExecutorClick(healthPlan);
			healthPlan.sendKeys(hp);
			healthPlan.sendKeys(Keys.TAB);
			SeleniumMethods.longwaitUntilElementIsClickable(subscriberID);
			subscriberID.sendKeys(subID);
			subscriberID.sendKeys(Keys.TAB);
			sendDate(earliestReqStartDate, earlierReqDate);
			break;
		}
		case Constant.REQDATE: {
			enterMemberDetails(lName, fName, memDOB, hp, subID, referralType, blankValue);
			break;
		}
		}

	}

	public boolean verifyAllLabelsInMemberInfoTab(String memLblDetails) {
		//List<String> lblList = new ArrayList<String>();
		String lblList =""; 
		lblList = lblList + lblLastName.getText() + ";";
		lblList = lblList + lblFirstName.getText()+ ";";
		lblList = lblList + lblDOB.getText()+ ";";
		lblList = lblList + lblHPName.getText()+ ";";
		lblList = lblList + lblSubscriberID.getText()+ ";";
		lblList = lblList + lblReferralSource.getText()+ ";";
		lblList = lblList + lblEarliestReqStartDate.getText();
		//String strTemp = lblLastName.getText() + lblFirstName.getText() + lblDOB.getText() + lblHPName.getText() + lblSubscriberID.getText()+lblReferralSource.getText()+lblEarliestReqStartDate.getText();
		System.out.println("actual "+lblList);
		System.out.println("expected "+memLblDetails);
		//List<String> lst = memLblDetails.stream().flatMap(Collection::stream).collect(Collectors.toList());
		return lblList.equalsIgnoreCase(memLblDetails);
	}

	public boolean verifyHPNamePrePopulated() {
		return !verifyHP.getText().isEmpty();
	}

}
