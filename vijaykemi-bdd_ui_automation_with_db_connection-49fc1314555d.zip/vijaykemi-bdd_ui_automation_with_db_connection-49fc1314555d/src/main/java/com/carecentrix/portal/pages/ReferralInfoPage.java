package com.carecentrix.portal.pages;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.apache.http.client.methods.HttpPost;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.logging.LogEntry;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.remote.http.HttpResponse;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.carecentrix.utilities.Constant;
import com.carecentrix.utilities.PropLoader;
import com.carecentrix.utilities.SeleniumMethods;

/**
 * @author KJ
 *
 */

public class ReferralInfoPage {

	WebDriver driver;

	private static final Logger log = LogManager.getLogger(ReferralInfoPage.class);

	public ReferralInfoPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}

	int Row_count;

	@FindBy(xpath = "//*[@id='layout']/section[2]/div/div[1]//button[1]")
	WebElement memberInfoTabBtn;

	@FindBy(xpath = "//*[@id='layout']/section[2]/div/div[1]//button[2]")
	WebElement diagnosisTabBtn;

	@FindBy(xpath = "//*[@id='layout']/section[2]/div/div[1]//button[3]")
	WebElement servicesTabBtn;

	@FindBy(xpath = "//*[@id='layout']/section[2]/div/div[1]//button[4]")
	WebElement physicianTabBtn;

	@FindBy(xpath = "//*[@id='layout']/section[2]/div/div[1]//button[5]")
	WebElement renderingProvTabBtn;

	@FindBy(xpath = "//*[@id='layout']/section[2]/div/div[1]//button[6]")
	WebElement addInfoTabBtn;

	@FindBy(xpath = "//span[@class='form-nav__title' and contains(text(),'Member Info.')]//following-sibling::span[@class='form-nav__caption']")
	WebElement memberInfoStatus;

	@FindBy(xpath = "//*[@id='layout']/section[2]/div/div[1]//button[1]//span[@class='form-nav__title']")
	WebElement memberInfoTitle;

	@FindBy(xpath = "//span[@class='form-nav__title' and contains(text(),'Diagnosis')]//following-sibling::span[@class='form-nav__caption']")
	WebElement diagnosisStatus;

	@FindBy(xpath = "//*[@id='layout']/section[2]/div/div[1]//button[2]//span[@class='form-nav__title']")
	WebElement diagnosisTitle;

	@FindBy(xpath = "//*[@id='layout']/section[2]/div/div[1]//button[3]//span[@class='form-nav__title']")
	WebElement servicesTitle;

	@FindBy(xpath = "//*[@id='layout']/section[2]/div/div[1]//button[4]//span[@class='form-nav__title']")
	WebElement physicianTitle;

	@FindBy(xpath = "//*[@id='layout']/section[2]/div/div[1]//button[5]//span[@class='form-nav__title']")
	WebElement renderingTitle;

	@FindBy(xpath = "//*[@id='layout']/section[2]/div/div[1]//button[6]//span[@class='form-nav__title']")
	WebElement addinlInfoTitle;

	@FindBy(xpath = "//span[@class='form-nav__title' and contains(text(),'Services')]//following-sibling::span[@class='form-nav__caption']")
	WebElement servicesStatus;

	@FindBy(xpath = "//span[@class='form-nav__title' and contains(text(),'Physician')]//following-sibling::span[@class='form-nav__caption']")
	WebElement physicianStatus;

	@FindBy(xpath = "//button[5]//span[@class='form-nav__caption']")
	WebElement renderingProvStatus;

	@FindBy(xpath = "//span[@class='form-nav__title' and contains(text(),'Additional Information')]//following-sibling::span[@class='form-nav__caption']")
	WebElement addInfoStatus;

	@FindBy(xpath = "//div[@class='css-0']/div[2]/section[1]")
	WebElement diagnosisTabTopPanel;

	@FindBy(xpath = "//div[@class='css-0']/div[3]/section[1]")
	WebElement servicesTabTopPanel;

	@FindBy(xpath = "//div[@class='css-0']/div[4]/section[1]")
	WebElement physicianTabTopPanel;

	@FindBy(xpath = "//div[@class='css-0']/div[5]/section[1]")
	WebElement renderingTabTopPanel;

	@FindBy(xpath = "//div[@class='css-0']/div[6]/section[1]")
	WebElement addInfoTabTopPanel;

	@FindBy(xpath = "//*/section[1]/ul/li/div")
	List<WebElement> servicesTabMemberInfoDetails;

	@FindBy(xpath = "//input[@name='contactLastName']")
	WebElement addInfoLastName;

	@FindBy(xpath = "//input[@name='contactFirstName']")
	WebElement addInfoFirsttName;

	@FindBy(xpath = "//div//input[@id='react-select-7-input']")
	WebElement addInfoPhNumDD;

	@FindBy(xpath = "//div[@class=' css-1p1q6t5-option' and @id='react-select-7-option-1']")
	WebElement contactPhNum;

	@FindBy(xpath = "//input[@name='contactPhone']")
	WebElement addInfoPhNum;

	@FindBy(xpath = "//input[@name='contactFax']")
	WebElement addInfoFaxNum;

//	@FindBy(xpath = "//button[@class='css-158d537']")
	@FindBy(xpath = "//button[normalize-space()='Review request']")
	WebElement addInfoReviewReq;

	@FindBy(xpath = "//*/section[2]//div[4]/div/button[1]")
	WebElement addInfoSubmitReq;

	@FindBy(xpath = "//div[@class='push--top']")
	WebElement addInfoSubmitReqPanel;

	@FindBy(xpath = "//div[@class='push-half--top bottom-line'][1]")
	WebElement addInfoDiagnosisPanel;

	@FindBy(xpath = "//div[@class='push-half--top bottom-line'][1]")
	WebElement addInfoPhysicianPanel;

	@FindBy(xpath = "//button[@class='css-e3t8n4']")
	WebElement addInfoGoHomeBtn;

	@FindBy(xpath = "//input[@name='caregiverName']")
	WebElement addInfoCaregiverName;

	@FindBy(xpath = "//input[@name='caregiverPhone']")
	WebElement addInfoCaregiverPhNum;

	@FindBy(xpath = "//textarea[@name='knownAllergies']")
	WebElement addInfoKnownAllergies;

	@FindBy(xpath = "//textarea[@name='notes']")
	WebElement addInfoNotes;

	@FindBy(xpath = "//button[@class='button button--default']")
	WebElement attachementBrowserBtn;

	@FindBy(xpath = "//input[@id='react-select-9-input']")
	WebElement attachmentTyp;

	@FindBy(xpath = "//button[normalize-space()='Upload Document']")
	WebElement uploadDocBtn;

	@FindBy(xpath = "//div[@class='upload-button__body']")
	WebElement docUploaded;

	@FindBy(xpath = "//div[@class=' css-v45c7s']/div")
	List<WebElement> addInfoAttachTypeDD;

	@FindBy(xpath = "//button[@class='css-yple4g']")
	WebElement addachmentTypeBtn;

	//@FindBy(xpath = "//div[@class='modal-content ']")
	@FindBy(xpath = "//div[contains(@class, 'modal-message__content')]")	
	WebElement succMsgDiag;

	@FindBy(xpath = "//span[@class='modal-message__title']")
	WebElement succMsgTitle;

	@FindBy(xpath = "//ul[@class='quote__list']//li[1]//span[1]")
	WebElement succMsgReqIDTxt;
	

	@FindBy(xpath = "//ul[@class='quote__list']//li[1]//span[2]")
	WebElement succMsgReqID;

	@FindBy(xpath = "//ul[@class='quote__list']//li[2]//span[1]")
	WebElement succMsgServTypTxt;

	@FindBy(xpath = "//ul[@class='quote__list']//li[2]//span[2]")
	WebElement succMsgServTyp;

	@FindBy(xpath = "//ul[@class='quote__list']//li[3]//span[1]")
	WebElement succMsgReqDateTxt;

	@FindBy(xpath = "//ul[@class='quote__list']//li[3]//span[2]")
	WebElement succMsgReqDate;

	@FindBy(xpath = "//div[@class='section-card']//h2")
	WebElement createReqPage;

	@FindBy(xpath = "//div[@class='info-header']//p[contains(text(),'Please review')]")
	WebElement refReviewMsg;

	@FindBy(xpath = "//div[@class='push-half--top bottom-line']//td[1]")
	WebElement refDiagICDCode;

	@FindBy(xpath = "//div[@class='push-half--top bottom-line']//td[2]")
	WebElement refDiagDesc;

	@FindBy(xpath = "//div[@class='push-half--top bottom-line']//td[3]//span")
	WebElement refDiagOrderingType;

	@FindBy(xpath = "//h4[@class='info-title' and contains(text(),'Diagnosis')]//following-sibling::span[@class='edit-link']")
	WebElement diagEditInfo;

	@FindBy(xpath = "//section[@class='search']//h4[contains(text(),'Diagnosis')]")
	WebElement diagTabTitle;

	@FindBy(xpath = "//section[2]/div[2]/div[2]/div[2]/table/tbody/tr/td[1]")
	WebElement diagICDCode;

	@FindBy(xpath = "//section[2]/div[2]/div[2]/div[2]/table/tbody/tr/td[2]")
	WebElement diagDescription;

	@FindBy(xpath = "//section[2]/div[2]/div[2]/div[2]/table/tbody/tr/td[3]/div/span")
	WebElement diagType;

	@FindBy(xpath = "//h4[@class='info-title' and contains(text(),'Services')]//following-sibling::span[@class='edit-link']")
	WebElement servEditInfo;

	@FindBy(xpath = "//section[@class='search']//h2[contains(text(),'Services')]")
	WebElement servTabTitle;

	@FindBy(xpath = "//*[@id='panel:6-2']/section[2]/div[2]/table/tbody/tr/td[1]")
	WebElement servTabType;

	@FindBy(xpath = "//*[@id='panel:6-2']/section[2]/div[2]/table/tbody/tr/td[3]")
	WebElement servTabDescType;

	@FindBy(xpath = "//*[@id='panel:6-2']/section[2]/div[2]/table/tbody/tr/td[2]")
	WebElement servTabReqType;

	@FindBy(xpath = "//div[@class='react-datepicker__input-container']//input[@label='Requested Start Date']")
	WebElement serviceReqStartDate;

	@FindBy(xpath = "//div[2]//li[1]/div[2]/span")
	WebElement servType;

	@FindBy(xpath = "//button[@class='tab-card__tab css-1jr08pk']")
	WebElement servDesc;

	@FindBy(xpath = "//input[@label='Requested Type']")
	WebElement servReqType;

	@FindBy(xpath = "//div[@class='flexgrid__item xsmall--col-12 small--col-12 medium--col-12']//input[@label='Requested Start Date']")
	WebElement servReqStartDate;

	@FindBy(xpath = "//div[@class='section-card form-edit']//span[@class='form__subs']//following-sibling::div[@id='QID3']/div[1]/label/input")
	WebElement servAuthYes;

	@FindBy(xpath = "//div[@class='section-card form-edit']//span[@class='form__subs']//following-sibling::div[@id='QID3']/div[2]/label/input")
	WebElement servAuthNo;

	@FindBy(xpath = "//div[@class='section-card form-edit']//span[@class='form__subs']//following-sibling::div[@id='QID4']/div[1]/label/input")
	WebElement servReqYes;

	@FindBy(xpath = "//div[@class='section-card form-edit']//span[@class='form__subs']//following-sibling::div[@id='QID4']/div[2]/label/input")
	WebElement servReqNo;

	@FindBy(xpath = "//div[@class='section-card form-edit']//span[@class='form__subs']//following-sibling::div[@id='QID5']/div[1]/label/input")
	WebElement servDaysYes;

	@FindBy(xpath = "//div[@class='section-card form-edit']//span[@class='form__subs']//following-sibling::div[@id='QID5']/div[2]/label/input")
	WebElement servDaysNo;

	@FindBy(xpath = "//h4[@class='info-title' and contains(text(),'Physicians')]//following-sibling::span[@class='edit-link']")
	WebElement physEditInfo;

	@FindBy(xpath = "//section[@class='search']//h4[contains(text(),'Physician')]")
	WebElement physTabTitle;

	@FindBy(xpath = "//div[@class='push-half--top']//td[1]")
	WebElement physName;

	@FindBy(xpath = "//div[@class='push-half--top']//td[2]")
	WebElement physNPI;

	@FindBy(xpath = "//div[@class='push-half--top']//td[3]")
	WebElement physZip;

	@FindBy(xpath = "//div[@class='push-half--top']//td[4]")
	WebElement physState;

	@FindBy(xpath = "//div[@class='push-half--top']//td[5]")
	WebElement physCity;

	@FindBy(xpath = "//div[@class='push-half--top']//td[6]")
	WebElement physPhone;

	@FindBy(xpath = "//div[@class='push-half--top']//td[7]//span")
	WebElement physType;

	@FindBy(xpath = "//*[@id='panel:6-3']/section[2]//table//tr/td[1]")
	WebElement physTabName;

	@FindBy(xpath = "//*[@id='panel:6-3']/section[2]//table//tr/td[2]")
	WebElement physTabNPI;

	@FindBy(xpath = "//*[@id='panel:6-3']/section[2]//table//tr/td[3]")
	WebElement physTabZip;

	@FindBy(xpath = "//*[@id='panel:6-3']/section[2]//table//tr/td[4]")
	WebElement physTabState;

	@FindBy(xpath = "//*[@id='panel:6-3']/section[2]//table//tr/td[5]")
	WebElement physTabCity;

	@FindBy(xpath = "//*[@id='panel:6-3']/section[2]//table//tr/td[6]")
	WebElement physTabPhone;

	@FindBy(xpath = "//*[@id='panel:6-3']/section[2]//table//tr/td[9]/div/div/span")
	WebElement physTabType;

	@FindBy(xpath = "//h4[@class='info-title' and contains(text(),'Diagnosis')]")
	WebElement refDiagTitle;

	@FindBy(xpath = "//h4[@class='info-title' and contains(text(),'Services')]")
	WebElement refServTitle;

	@FindBy(xpath = "//h4[@class='info-title' and contains(text(),'Physician')]")
	WebElement refPhyTitle;

	@FindBy(xpath = "//*/section[1]/ul/li[5]//div[2]")
	List<WebElement> refDOB;

	@FindBy(xpath = "//*/section[1]/ul/li[5]//div[2]")
	List<WebElement> topPanelDOB;

	@FindBy(xpath = "//div[@class=' css-26l3qy-menu']//div[@class=' css-11unzgr']//div")
	List<WebElement> contactMthd;

	String reqDate;

	public boolean isReferralInfoTabAvailable() {

		SeleniumMethods.waitUntilElementIsClickable(memberInfoTabBtn);
		memberInfoTabBtn.click();
		String memberInfoButton = memberInfoStatus.getText();
		SeleniumMethods.waitUntilElementIsClickable(diagnosisTabBtn);
		diagnosisTabBtn.click();
		String diagnosisButton = diagnosisStatus.getText();
		SeleniumMethods.waitUntilElementIsClickable(servicesTabBtn);
		servicesTabBtn.click();
		String servicesButton = servicesStatus.getText();
		SeleniumMethods.waitUntilElementIsClickable(physicianTabBtn);
		physicianTabBtn.click();
		String physicianButton = physicianStatus.getText();
		SeleniumMethods.waitUntilElementIsClickable(renderingProvTabBtn);
		renderingProvTabBtn.click();
		String locationButton = renderingProvStatus.getText();
		SeleniumMethods.waitUntilElementIsClickable(addInfoTabBtn);
		addInfoTabBtn.click();
		String additonalInfoButton = addInfoStatus.getText();

		return (memberInfoButton.equalsIgnoreCase(Constant.STATUS_COMPLETED)
				&& diagnosisButton.equalsIgnoreCase(Constant.STATUS_COMPLETED)
				&& servicesButton.equalsIgnoreCase(Constant.STATUS_COMPLETED)
				&& physicianButton.equalsIgnoreCase(Constant.STATUS_COMPLETED)
				&& locationButton.equalsIgnoreCase(Constant.STATUS_COMPLETED)
				&& additonalInfoButton.equalsIgnoreCase(Constant.STATUS_NOTCOMPLETED));
	}

	public boolean verifyMemberInfoDetails(String tabName, String memName, String memFullName, String memSubID,
			String memSubID1, String memHP, String memHP1, String memNoHp, String memLOB, String memLOB1,
			String memNoLOB, String memDOB, String memDOB1) {
		boolean flag = false;
		switch (tabName) {
		case Constant.DIAGNOSIS: {
			flag = memberInfoTopPanel(diagnosisTabTopPanel, 10, memName, memFullName, memSubID, memSubID1, memHP,
					memHP1, memNoHp, memLOB, memLOB1, memNoLOB, memDOB, memDOB1);
			break;
		}
		case Constant.SERVICES: {
			flag = memberInfoTopPanel(servicesTabTopPanel, 20, memName, memFullName, memSubID, memSubID1, memHP, memHP1,
					memNoHp, memLOB, memLOB1, memNoLOB, memDOB, memDOB1);
			break;
		}
		case Constant.PHYSICIAN: {
			flag = memberInfoTopPanel(physicianTabTopPanel, 30, memName, memFullName, memSubID, memSubID1, memHP,
					memHP1, memNoHp, memLOB, memLOB1, memNoLOB, memDOB, memDOB1);
			break;
		}
		case Constant.LOCATION: {
			flag = memberInfoTopPanel(renderingTabTopPanel, 40, memName, memFullName, memSubID, memSubID1, memHP,
					memHP1, memNoHp, memLOB, memLOB1, memNoLOB, memDOB, memDOB1);
			break;
		}
		case Constant.REFERRALINFO: {
			flag = memberInfoTopPanel(addInfoTabTopPanel, 50, memName, memFullName, memSubID, memSubID1, memHP, memHP1,
					memNoHp, memLOB, memLOB1, memNoLOB, memDOB, memDOB1);
			break;
		}
		default: {
			log.info("MemberInfo Top Panel Validation");
		}
		}
		return flag;
	}

	public void fillMandatoryDetailsInReferralPage(String lastName, String firstName, String phoneNumber,
			List<String> contactMethd) {
		contactDetails(lastName, firstName, phoneNumber, contactMethd.get(0));
	}

	public boolean clickReviewRequestButton() {
		SeleniumMethods.longwaitUntilElementIsVisible(addInfoCaregiverName);
		SeleniumMethods.javaScriptExecutorScrollIntoView(addInfoCaregiverName);
		SeleniumMethods.longwaitUntilElementIsVisible(addInfoReviewReq);
		SeleniumMethods.javaScriptExecutorScrollIntoView(addInfoReviewReq);
		SeleniumMethods.waitUntilElementIsClickable(addInfoReviewReq);
		addInfoReviewReq.click();
		SeleniumMethods.longwaitUntilElementIsVisible(refReviewMsg);
		return refReviewMsg.isDisplayed();
	}

	public boolean clickSubmitButton() {
		boolean isSubmitButtonClicked = false;
		SeleniumMethods.waitUntilElementIsClickable(addInfoDiagnosisPanel);
		SeleniumMethods.scrollDown(addInfoDiagnosisPanel);
		SeleniumMethods.scrollDown(addInfoPhysicianPanel);
		SeleniumMethods.scrollDown(addInfoSubmitReqPanel);
		SeleniumMethods.waitUntilElementIsClickable(addInfoSubmitReq);
		if (addInfoSubmitReq.isDisplayed()) {
			addInfoSubmitReq.click();
			
//---------------------------------------------------------------------------
//			System.out.println("hi");
//			String scriptToExecute = "var performance = window.performance || window.mozPerformance || window.msPerformance || window.webkitPerformance || {}; var network = performance.getEntries() || {}; return network;";
////			String netData = ((JavascriptExecutor)driver).executeScript(scriptToExecute).toString();
////			System.out.println(netData);
//			
//			List<LogEntry> entries = driver.manage().logs().get(LogType.PERFORMANCE).getAll();
//			System.out.println(entries.size() + " " + LogType.PERFORMANCE + " log entries found");
//			 for (LogEntry entry : entries) {
//				 System.out.println("Entry message is ");
//			   System.out.println(entry.getMessage());

//-----------------------------------------------------------------------------		 
//        }
			
		
			
//			String source = driver.getPageSource();
//			System.out.println(source.toString());
			
			SeleniumMethods.longwaitUntilElementIsVisible(succMsgDiag);
			if (succMsgDiag.isDisplayed()) {
				isSubmitButtonClicked = true;
			}
		}
		return isSubmitButtonClicked;

	}

	public boolean isStatusNotCompleted(String tabName) {
		boolean tabStatus = false;
		switch (tabName) {
		case Constant.MEMBER_INFO: {
			tabStatus = isNotCompleted(memberInfoTabBtn, memberInfoStatus);
			break;
		}
		case Constant.DIAGNOSIS: {
			tabStatus = isNotCompleted(diagnosisTabBtn, diagnosisStatus);
			break;
		}
		case Constant.SERVICES: {
			tabStatus = isNotCompleted(servicesTabBtn, servicesStatus);
			break;
		}
		case Constant.PHYSICIAN: {
			tabStatus = isNotCompleted(physicianTabBtn, physicianStatus);
			break;
		}
		case Constant.LOCATION: {
			tabStatus = isNotCompleted(renderingProvTabBtn, renderingProvStatus);
			break;
		}
		case Constant.REFERRALINFO: {
			SeleniumMethods.waitUntilElementIsClickable(addInfoTabBtn);
			addInfoTabBtn.click();
			if (addInfoStatus.isDisplayed() && addInfoStatus.getText().equalsIgnoreCase(Constant.STATUS_NOTCOMPLETED))
				tabStatus = true;
			break;
		}
		default:
			log.info("Tab status verified");

		}
		return tabStatus;

	}

	public boolean isStatusCompleted(String tabName) {
		boolean tabStatus = false;
		log.info("Tab Name is  {}", tabName);
		switch (tabName) {
		case Constant.MEMBER_INFO: {
			tabStatus = isCompleted(memberInfoTabBtn, memberInfoStatus);
			break;
		}
		case Constant.DIAGNOSIS: {
			tabStatus = isCompleted(diagnosisTabBtn, diagnosisStatus);
			break;
		}
		case Constant.SERVICES: {
			tabStatus = isCompleted(servicesTabBtn, servicesStatus);
			break;
		}

		case Constant.PHYSICIAN: {
			tabStatus = isCompleted(physicianTabBtn, physicianStatus);
			break;
		}
		case Constant.LOCATION: {
			tabStatus = isCompleted(renderingProvTabBtn, renderingProvStatus);
			break;
		}
		case Constant.REFERRALINFO: {
			log.info("AdditionalInformation_status  {}", addInfoStatus.getText());
			if (addInfoStatus.isDisplayed() && addInfoStatus.getText().equalsIgnoreCase(Constant.STATUS_COMPLETED))
				tabStatus = true;
			break;
		}
		default:
			log.info("Tab Completed status is verified");
		}
		return tabStatus;
	}

	public boolean isCompleted(WebElement button, WebElement status) {
		SeleniumMethods.longwaitUntilElementIsClickable(button);
		SeleniumMethods.javaScriptExecutorClick(button);
		SeleniumMethods.longwaitUntilElementIsClickable(button);
		log.info("Status of the Tab {}", status.getText());
		return (status.isDisplayed() && status.getText().equalsIgnoreCase(Constant.STATUS_COMPLETED));
	}

	public boolean isNotCompleted(WebElement button, WebElement status) {
		SeleniumMethods.waitUntilElementIsClickable(button);
		SeleniumMethods.javaScriptExecutorClick(button);
		SeleniumMethods.longwaitUntilElementIsClickable(button);
		log.info("Status of the Tab {}", status.getText());
		return (status.isDisplayed() && status.getText().equalsIgnoreCase(Constant.STATUS_NOTCOMPLETED));
	}

	public void chooseContactDetail(String lastName, String firstName, String phoneNumber) {
		SeleniumMethods.longwaitUntilElementIsClickable(addInfoLastName);
		addInfoLastName.sendKeys(lastName);
		addInfoFirsttName.sendKeys(firstName);
		addInfoPhNumDD.click();
		SeleniumMethods.longwaitUntilElementIsClickable(addInfoPhNumDD);
		contactPhNum.click();
		addInfoPhNumDD.sendKeys(Keys.TAB);
		addInfoPhNum.sendKeys(phoneNumber);
		addInfoFaxNum.sendKeys(phoneNumber);
	}

	public void enterContactInfoDetails(String lastName, String firstName, String phoneNumber,
			List<String> contactMethd) {
		for (String contactMthd1 : contactMethd) {
			contactDetails(lastName, firstName, phoneNumber, contactMthd1);
		}
	}

	public void contactDetails(String lastName, String firstName, String phoneNumber, String contactMtd) {
		SeleniumMethods.longwaitUntilElementIsClickable(addInfoLastName);
		addInfoLastName.sendKeys(lastName);
		addInfoFirsttName.sendKeys(firstName);
		addInfoPhNumDD.click();
		SeleniumMethods.longwaitUntilElementIsClickable(addInfoPhNumDD);
		contactPhNum.click();
		addInfoPhNumDD.sendKeys(contactMtd);
		addInfoPhNumDD.sendKeys(Keys.TAB);
		addInfoPhNum.sendKeys(phoneNumber);
		addInfoFaxNum.sendKeys(phoneNumber);
	}

	public void enterAdditionalInfoDetails(String careGiverName, String careGiverPhone, String knownAllergies,
			String notesTextMsg) {
		SeleniumMethods.longwaitUntilElementIsClickable(addInfoCaregiverName);
		addInfoCaregiverName.sendKeys(careGiverName);
		addInfoCaregiverPhNum.sendKeys(careGiverPhone);
		addInfoKnownAllergies.sendKeys(knownAllergies);
		addInfoNotes.sendKeys(notesTextMsg);
	}

	public void selectAttachementTyAndUploadDoc(String attachmentType) {
		SeleniumMethods.javaScriptExecutorScrollIntoView(attachmentTyp);//MD - Corrected the parameter here
		SeleniumMethods.longwaitUntilElementIsClickable(attachmentTyp);
		attachmentTyp.click();
		attachmentTyp.sendKeys(attachmentType);
		attachmentTyp.sendKeys(Keys.TAB);
		SeleniumMethods.javaScriptExecutorScrollIntoView(uploadDocBtn);
		SeleniumMethods.longwaitUntilElementIsClickable(uploadDocBtn);
		uploadDocBtn.click();

	}

	public boolean verifySuccessMsgDisplayed() {
		SeleniumMethods.longwaitUntilElementIsVisible(succMsgDiag);
		return succMsgDiag.isDisplayed();
	}

	public boolean verifySuccMsgDetails() {
		return verifySuccssMsgDetails();
	}

	public boolean verifySuccssMsgDetails() {
		return (succMsgTitle.getText().equalsIgnoreCase(Constant.ADD_INFO_SUCC_MSG)
				&& succMsgReqIDTxt.getText().equalsIgnoreCase(Constant.ADD_INFO_REQ_TYPE)
				&& succMsgServTypTxt.getText().equalsIgnoreCase(Constant.ADD_INFO_SERV_TYPE)
				&& succMsgReqDateTxt.getText().equalsIgnoreCase(Constant.ADD_INFO_REQ_START_DATE));
		// && succMsgReqDate.getText().equalsIgnoreCase(reqDate));
	}
	
	public String getRequestID() {
		String RequestID = succMsgReqID.getText();
		//System.out.println("Req id is "+RequestID);
		//log.info("RequestID is "+RequestID);
		return (RequestID);
		
	}

	// && succMsgServTyp.getText().equalsIgnoreCase(Constant.ADD_INFO_SERV_TYPE)
	public boolean clickGoToHomeButton() {
		boolean isBtnClicked = false;
		if (addInfoGoHomeBtn.isDisplayed() && addInfoGoHomeBtn.getText().equalsIgnoreCase(Constant.ADD_INFO_GOHOME)) {
			addInfoGoHomeBtn.click();
			SeleniumMethods.longwaitUntilElementIsVisible(createReqPage);
			if (createReqPage.isDisplayed())
				isBtnClicked = true;
		}
		return isBtnClicked;
	}

	public boolean verifyDiagnosisDetails() {
		SeleniumMethods.longwaitUntilElementIsVisible(refDiagTitle);
		SeleniumMethods.javaScriptExecutorScrollIntoView(refDiagTitle);
		diagEditInfo.click();
		SeleniumMethods.longwaitUntilElementIsVisible(diagTabTitle);
		String icdCode = diagICDCode.getText();
		String desc = diagDescription.getText();
		String type = diagType.getText();
		addInfoTabBtn.click();
		SeleniumMethods.longwaitUntilElementIsVisible(refDiagTitle);
		SeleniumMethods.javaScriptExecutorScrollIntoView(refDiagTitle);
		return refDiagICDCode.getText().equalsIgnoreCase(icdCode) && refDiagDesc.getText().equalsIgnoreCase(desc)
				&& refDiagOrderingType.getText().equalsIgnoreCase(type);
	}

	public boolean verifyServicesDetails() {
		SeleniumMethods.longwaitUntilElementIsVisible(refServTitle);
		SeleniumMethods.javaScriptExecutorScrollIntoView(refServTitle);
		servEditInfo.click();
		SeleniumMethods.longwaitUntilElementIsVisible(servTabTitle);
		String serviceType = servTabType.getText();
		String servicedesc = servTabDescType.getText();
		// String servReqtype = servTabReqType.getText();
		String servRequStartDate = serviceReqStartDate.getText();
		addInfoTabBtn.click();
		SeleniumMethods.longwaitUntilElementIsVisible(refServTitle);
		SeleniumMethods.javaScriptExecutorScrollIntoView(refServTitle);
		return servType.getText().equalsIgnoreCase(serviceType) && servDesc.getText().equalsIgnoreCase(servicedesc)
				// && servReqType.getText().equalsIgnoreCase(servReqtype)
				&& servReqStartDate.getText().equalsIgnoreCase(servRequStartDate);
	}

	public boolean verifyPhysicianDetails() {
		SeleniumMethods.longwaitUntilElementIsVisible(refPhyTitle);
		SeleniumMethods.javaScriptExecutorScrollIntoView(refPhyTitle);
		physEditInfo.click();
		SeleniumMethods.longwaitUntilElementIsVisible(physTabTitle);
		String physicianName = physTabName.getText();
		String physicianNPI = physTabNPI.getText();
		String physicianZip = physTabZip.getText();
		String physicianState = physTabState.getText();
		String physicianCity = physTabCity.getText();
		String physicianPhone = physTabPhone.getText();
		String physicianType = physTabType.getText();
		addInfoTabBtn.click();
		SeleniumMethods.longwaitUntilElementIsVisible(refPhyTitle);
		SeleniumMethods.javaScriptExecutorScrollIntoView(refPhyTitle);

		return physName.getText().equalsIgnoreCase(physicianName) && physNPI.getText().equalsIgnoreCase(physicianNPI)
				&& physZip.getText().equalsIgnoreCase(physicianZip)
				&& physState.getText().equalsIgnoreCase(physicianState)
				&& physCity.getText().equalsIgnoreCase(physicianCity)
				&& physPhone.getText().equalsIgnoreCase(physicianPhone)
				&& physType.getText().equalsIgnoreCase(physicianType);
	}

	public void servicesSelectedOptions() {

	}

	public boolean verifyDateFormatInTopPanel(String tabName) {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			log.info("Interrupted!", e);
			Thread.currentThread().interrupt();
		}
		int j = panelName(tabName);
		log.info("DOB is {}", topPanelDOB.get(j).getText());
		return SeleniumMethods.isValidFormat("mm/dd/yyyy", topPanelDOB.get(j).getText());
	}

	public boolean memberInfoTopPanel(WebElement element, int i, String memName, String memFullName, String memSubID,
			String memSubID1, String memHP, String memHP1, String memNoHp, String memLOB, String memLOB1,
			String memNoLOB, String memDOB, String memDOB1) {
		SeleniumMethods.longwaitUntilElementIsVisible(element);

		return (!servicesTabMemberInfoDetails.isEmpty()
				&& (servicesTabMemberInfoDetails.get(i).getText().equalsIgnoreCase(memName)
						&& servicesTabMemberInfoDetails.get(i + 1).getText().equalsIgnoreCase(memFullName)
						&& servicesTabMemberInfoDetails.get(i + 2).getText().equalsIgnoreCase(memSubID)
						&& servicesTabMemberInfoDetails.get(i + 3).getText().equalsIgnoreCase(memSubID1)
						&& servicesTabMemberInfoDetails.get(i + 4).getText().equalsIgnoreCase(memHP)
						&& (servicesTabMemberInfoDetails.get(i + 5).getText().equalsIgnoreCase(memHP1)
								|| servicesTabMemberInfoDetails.get(i + 5).getText().equalsIgnoreCase(memNoHp))
						&& servicesTabMemberInfoDetails.get(i + 6).getText().equalsIgnoreCase(memLOB)
						&& (servicesTabMemberInfoDetails.get(i + 7).getText().equalsIgnoreCase(memLOB1)
								|| servicesTabMemberInfoDetails.get(i + 7).getText().equalsIgnoreCase(memNoLOB))
						&& servicesTabMemberInfoDetails.get(i + 8).getText().equalsIgnoreCase(memDOB)
						&& servicesTabMemberInfoDetails.get(i + 9).getText().equalsIgnoreCase(memDOB1)));
	}

	public int panelName(String tabName) {
		int j = 0;
		switch (tabName) {
		case Constant.DIAGNOSIS: {
			j = 1;
			break;
		}
		case Constant.SERVICES: {
			j = 2;
			break;
		}
		case Constant.PHYSICIAN: {
			j = 3;
			break;
		}
		case Constant.LOCATION: {
			j = 4;
			break;
		}
		case Constant.REFERRALINFO: {
			j = 5;
			break;
		}
		}
		return j;
	}

	public boolean verifyUserTypeListOrder() {
		SeleniumMethods.longwaitUntilElementIsVisible(addInfoPhNumDD);
		addInfoPhNumDD.click();
		log.info("Contact List {} {}", contactMthd.get(0).getText(), contactMthd.get(1).getText());
		return SeleniumMethods.isCollectionSorted(contactMthd);
	}

	public void clickBrowseButtonToAddAttachement() {
		SeleniumMethods.longwaitUntilElementIsVisible(attachementBrowserBtn);
		attachementBrowserBtn.click();
		try {
			Thread.sleep(2500);
			Robot rb;
			rb = new Robot();
			String path = PropLoader.props.apply("AttachmentfilePath");
			Path sourcePath = Paths.get(System.getProperty("user.dir") + path);
			log.info("Spath {}", sourcePath.toString());
			StringSelection str = new StringSelection(sourcePath.toString());
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, null);
			rb.keyPress(KeyEvent.VK_CONTROL);
			rb.keyPress(KeyEvent.VK_V);
			rb.keyRelease(KeyEvent.VK_CONTROL);
			rb.keyRelease(KeyEvent.VK_V);
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
		} catch (AWTException | InterruptedException e) {
			log.info("Interrupted!", e);
			Thread.currentThread().interrupt();
		}
	}

	public boolean verifyDocumentUploaded() {
		SeleniumMethods.longwaitUntilElementIsVisible(docUploaded);
		return docUploaded.isDisplayed();

	}

	public boolean goToMemberInfoPage() {
		memberInfoTabBtn.click();
		SeleniumMethods.longwaitUntilElementIsVisible(memberInfoStatus);
		return memberInfoTitle.getText().equalsIgnoreCase(Constant.MEMBER_INFO);
	}

	public boolean goToDiagnosisPage() {
		diagnosisTabBtn.click();
		SeleniumMethods.longwaitUntilElementIsVisible(diagnosisStatus);
		return diagnosisTitle.getText().equalsIgnoreCase(Constant.DIAGNOSIS);
	}

	public boolean goToServicesPage() {
		servicesTabBtn.click();
		SeleniumMethods.longwaitUntilElementIsVisible(servicesStatus);
		return servicesTitle.getText().equalsIgnoreCase(Constant.SERVICES);
	}

	public boolean goToPhysicianPage() {
		physicianTabBtn.click();
		SeleniumMethods.longwaitUntilElementIsVisible(physicianTitle);
		return physicianTitle.getText().equalsIgnoreCase(Constant.PHYSICIAN);
	}

	public boolean goToRederingProvPage() {
		renderingProvTabBtn.click();
		SeleniumMethods.longwaitUntilElementIsVisible(renderingTitle);
		return renderingTitle.getText().equalsIgnoreCase(Constant.RENDERINGPROV);
	}

	public boolean goToAdditionalInfoPage() {
		addInfoTabBtn.click();
		SeleniumMethods.longwaitUntilElementIsVisible(addinlInfoTitle);
		return addinlInfoTitle.getText().equalsIgnoreCase(Constant.REFERRALINFOTITLE);
	}
}
