package com.carecentrix.portal.pages;



import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.carecentrix.utilities.Constant;
import com.carecentrix.utilities.SeleniumMethods;


/**
 * @author KJ
 *
 */

public class LoginPage {

	WebDriver driver;

	private static final Logger log = LogManager.getLogger(LoginPage.class);

	public LoginPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}

	@FindBy(className = "sign-in")
	WebElement signInLink;

	@FindBy(id = "user_email")
	WebElement userEmailID;

	@FindBy(id = "user_password")
	WebElement userPassword;

	@FindBy(className = "button")
	WebElement submitButton;

	@FindBy(xpath = "//input[@value='Sign out']")
	WebElement signout;
	
	@FindBy(xpath = "//span[@class='alert__description']")
	WebElement errorMessage;

	public void clickSignInLink() {

		log.info(Constant.SIGN_IN_PAGE+"Link clicked");
		SeleniumMethods.waitUntilElementIsClickable(signInLink);
		signInLink.click();
	}

	public void setEmailIDAndPassword(String emailID, String password){
		SeleniumMethods.waitUntilElementIsClickable(userEmailID);
		SeleniumMethods.waitUntilElementIsClickable(userPassword);
		userEmailID.sendKeys(emailID);
		userPassword.sendKeys(password);
	}

	public void clickSignInBTN() {
		SeleniumMethods.waitUntilElementIsClickable(submitButton);
		submitButton.click();
		

	}

	public void clickSignoutBTN() {
		SeleniumMethods.shortwaitUntilElementIsClickable(signout);
		signout.click();
	}

	public boolean checkNavigatedPage(String signInURL) {
		String strUrl = driver.getCurrentUrl();
		log.info("Navigated URL is {} ", signInURL);
		return strUrl.equalsIgnoreCase(signInURL);
	}

	public boolean verifiedUserErrMsg(String userType) {
		boolean flag= false;
		switch (userType){
		case "TermedUser":	//Constant.TERMED:
			flag = errorMessage.getText().equalsIgnoreCase(Constant.TERMED_ERR);			
			break;
		case "DeactivatedUser":		
			flag = errorMessage.getText().equalsIgnoreCase(Constant.DEACTIVATED_ERR);
			System.out.println("deactivealertetxt flag"+errorMessage.getText() + flag);
			break;
		case "LockedUser":
			flag = errorMessage.getText().equalsIgnoreCase(Constant.LOCKED_ERR);	
			System.out.println("lockedalertetxt flag"+errorMessage.getText() + flag);
			break;
		}
		System.out.println(" flag" + flag);
		return flag;
	}

}
