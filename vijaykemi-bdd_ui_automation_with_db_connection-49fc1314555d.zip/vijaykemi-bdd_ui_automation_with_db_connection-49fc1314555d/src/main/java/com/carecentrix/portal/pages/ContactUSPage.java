package com.carecentrix.portal.pages;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.carecentrix.utilities.Constant;
import com.carecentrix.utilities.SeleniumMethods;

/**
 * @author Murali
 */

public class ContactUSPage {

	private static final Logger log = LogManager.getLogger(ContactUSPage.class);

	WebDriver driver;

	@FindBy(xpath = "//a[contains(text(),'Contact US')]")
	WebElement lnkContactUS;

	@FindBy(xpath = "//label[contains(text(),'Contact name')]")
	WebElement lblContactName;

	@FindBy(id = "contact_name")
	WebElement txtContactName;

	@FindBy(xpath = "//label[contains(text(),'Email')]")
	WebElement lblEmail;

	@FindBy(id = "email")
	WebElement txtEmail;

	@FindBy(xpath = "//label[contains(text(),'Contact phone')]")
	WebElement lblContactPhone;

	@FindBy(id = "contact_phone")
	WebElement txtContactPhone;

	@FindBy(xpath = "//label[contains(text(),'Inquiry type')]")
	WebElement lblInquiryType;

	@FindBy(id = "inquiry_type")
	WebElement drpdwnInquiryType;

	@FindBy(xpath = "//label[contains(text(),'Inquiry reason')]")
	WebElement lblInquiryReason;

	@FindBy(id = "inquiry_reason")
	WebElement drpdwnInquiryReason;

	@FindBy(xpath = "//label[contains(text(),'Inquiry message')]")
	WebElement lblInquiryMessage;

	@FindBy(id = "inquiry_message")
	WebElement txtInquiryMessage;

	@FindBy(xpath = "//div[@class='alert__content']//span[@class='alert__description']")
	WebElement alertDescription;

	@FindBy(xpath = "//input[(@type='submit') and (@name='commit')]")
	WebElement btnSubmit;

	@FindBy(xpath = "//p[contains(text(),'The information has been sent')]")
	WebElement lblInfoMessageSent;

	@FindBy(xpath = "//a[contains(text(),'Go to Dashboard')]")
	WebElement lnkGotoDashboard;

	public ContactUSPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}

	public void clickContatUSlnk() {
		SeleniumMethods.shortwaitUntilElementIsClickable(lnkContactUS);
		lnkContactUS.click();
	}

	public void clickSubmit() {
		SeleniumMethods.shortwaitUntilElementIsClickable(btnSubmit);
		btnSubmit.click();
		log.info("Clicked on Submit in 'Contact US' Page");
	}

	public void enterContactDetails(String strContactName, String strEmail, String strContactPhone,
			String strInquiryType, String strInquiryReasson, String strInquiryMessage) {

		txtContactName.sendKeys(strContactName);
		txtEmail.sendKeys(strEmail);
		txtContactPhone.sendKeys(strContactPhone);
		SeleniumMethods.selectFromDropDown(drpdwnInquiryType, strInquiryType);
		SeleniumMethods.selectFromDropDown(drpdwnInquiryReason, strInquiryReasson);
		txtInquiryMessage.sendKeys(strInquiryMessage);
		btnSubmit.click();

	}

	public void enterContactName(String strContactName) {
		SeleniumMethods.shortwaitUntilElementIsClickable(txtContactName);
		if (lblContactName.isDisplayed() && txtContactName.isDisplayed()) {
			txtContactName.sendKeys(strContactName);
		}
	}

	public void enterContactPhone(String strContactPhone) {
		SeleniumMethods.shortwaitUntilElementIsClickable(txtContactPhone);
		if (lblContactPhone.isDisplayed() && txtContactPhone.isDisplayed()) {
			txtContactPhone.sendKeys(strContactPhone);
		}
	}

	public void enterEmail(String strEmail) {
		SeleniumMethods.shortwaitUntilElementIsClickable(txtEmail);
		if (lblEmail.isDisplayed() && txtEmail.isDisplayed()) {
			txtEmail.sendKeys(strEmail);
		}
	}

	public void enterInquiryMessage(String strInquiryMessage) {
		SeleniumMethods.shortwaitUntilElementIsClickable(txtInquiryMessage);
		if (lblInquiryMessage.isDisplayed() && txtInquiryMessage.isDisplayed()) {
			txtInquiryMessage.sendKeys(strInquiryMessage);
		}
	}

	public void quitBrowser() {
		SeleniumMethods.quitDriver();
		log.info("Browser closed successfully");
	}

	public void selectInquiryReason(String strInquiryReasson) {
		SeleniumMethods.shortwaitUntilElementIsClickable(txtContactPhone);
		if (lblInquiryReason.isDisplayed() && drpdwnInquiryReason.isDisplayed()) {
			drpdwnInquiryReason.click();
			drpdwnInquiryReason.sendKeys(strInquiryReasson);
		}
	}

	public void selectInquiryType(String strInquiryType) {
		SeleniumMethods.shortwaitUntilElementIsClickable(drpdwnInquiryType);
		if (lblInquiryType.isDisplayed() && drpdwnInquiryType.isDisplayed()) {
			drpdwnInquiryType.click();
			drpdwnInquiryType.sendKeys(strInquiryType);
			drpdwnInquiryType.sendKeys(Keys.TAB);
		}
	}

	public boolean verifyAlertMessage() {
		String strAlertMessage = alertDescription.getText().trim();
		log.info("Alert Message is: {}", strAlertMessage);
		return (alertDescription.isDisplayed()
				&& strAlertMessage.equalsIgnoreCase(Constant.CONTACTUS_ALERT_MESSAGE_CONTENT));
	}

	public boolean verifyDefaultOptionSelected(String inquiryReason) {
		SeleniumMethods.longwaitUntilElementIsVisible(drpdwnInquiryReason);
		Select option = new Select(drpdwnInquiryReason);
		log.info("Selected Option {}", option.getFirstSelectedOption().getText());
		return inquiryReason.equalsIgnoreCase(option.getFirstSelectedOption().getText());

	}

	public boolean verifyInfoMsgSent() {
		SeleniumMethods.shortwaitUntilElementIsClickable(lblInfoMessageSent);
		boolean flag = lblInfoMessageSent.isDisplayed() && lnkGotoDashboard.isDisplayed();
		if (flag) {
			log.info("Contact Information sent successfully");
		} else {
			log.info("Contact Information not sent successfully");
		}

		return flag;
	}
}
