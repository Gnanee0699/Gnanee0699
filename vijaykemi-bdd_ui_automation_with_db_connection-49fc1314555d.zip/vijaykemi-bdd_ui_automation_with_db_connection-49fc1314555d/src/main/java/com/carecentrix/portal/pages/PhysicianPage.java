package com.carecentrix.portal.pages;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.carecentrix.utilities.Constant;
import com.carecentrix.utilities.SeleniumMethods;



/**
 * @author KKJANAK
 *
 */

public class PhysicianPage {

	WebDriver driver;

	private static final Logger log = LogManager.getLogger(PhysicianPage.class);

	public PhysicianPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}

	@FindBy(xpath = "//span[@class='form-nav__title' and contains(text(),'Member Info.')]/following-sibling::span[@class='form-nav__caption']")
	WebElement memberInfoTabStatus;

	@FindBy(xpath = "//div[@class='form-nav__info']//span[@class='form-nav__title' and contains(text(),'Diagnosis')]//following-sibling::span[@class='form-nav__caption']")
	WebElement diagnosisTabStatus;

	@FindBy(xpath = "//span[@class='form-nav__title' and contains(text(),'Services')]//following-sibling::span[@class='form-nav__caption']")
	WebElement servicesTabStatus;

	@FindBy(xpath = "//div[@class='form-nav__info']//span[@class='form-nav__title' and contains(text(),'Physician')]//following-sibling::span[@class='form-nav__caption']")
	WebElement physicianTabStatus;

	@FindBy(xpath = "//div[@class='form-nav css-1dxxh68']//button[1]")
	WebElement memberInfoTabBtn;

	@FindBy(xpath = "//div[@class='form-nav css-1dxxh68']//button[2]")
	WebElement diagnosisTabBtn;

	@FindBy(xpath = "//div[@class='form-nav css-1dxxh68']//button[3]")
	WebElement servicesTabBtn;

	@FindBy(xpath = "//div[@class='form-nav css-1dxxh68']//button[4]")
	WebElement physicianTabBtn;

	@FindBy(xpath = "//div[contains(@aria-labelledby,'3')]//input[@name='lastName']")
	WebElement physicianTabLastName;

	@FindBy(xpath = "//div[contains(@aria-labelledby,'3')]//input[@name='firstName']")
	WebElement physicianTabFirstName;

	@FindBy(xpath = "//div[contains(@aria-labelledby,'3')]//input[@name='npi']")
	WebElement physicianTabNPI;

	@FindBy(xpath = "//div[contains(@aria-labelledby,'3')]//input[@name='phoneNumber']")
	WebElement physicianTabPhoneNumber;

	@FindBy(xpath = "//*//div[@class='flexgrid__item small--col-3 medium--col-2']//input[@name='city']")
	WebElement physician_City;

	@FindBy(xpath = "//input[@id='react-select-5-input']")
	WebElement physician_State;
	
	@FindBy(xpath = "//input[@name='npi']")
	WebElement physician_Npi;

	@FindBy(xpath = "//div[contains(@aria-labelledby,'3')]//input[@name='zipCode']")
	WebElement physician_ZipCode;

	@FindBy(xpath = "(//button[@type='submit'])[3]")
	WebElement physician_SearchButton;

	@FindBy(xpath = "//div[contains(@aria-labelledby,'3')]//table[contains(@class,'table-content fade-in')]")
	WebElement physician_SearchResult_Table;

	@FindBy(xpath = "//div[contains(@aria-labelledby,'3')]//table[contains(@class,'table-content fade-in')]//tbody//tr")
	List<WebElement> searchResultTblRow;

	@FindBy(xpath = "//div[contains(@aria-labelledby,'3')]//table[contains(@class,'table-content fade-in')]//tbody//tr//td")
	List<WebElement> searchResultTblData;

	@FindBy(xpath = "//div[@class='empty-state__content']")
	WebElement noResultFound;

	@FindBy(xpath = "//div[contains(@aria-labelledby,'3')]//tr[1]/td[9]/div/button[1]")
	WebElement addButtonToChoosePhysician;

//	@FindBy(xpath = "//button[@class='css-16s2dtn' and contains(text(),'ordering')]")
	@FindBy(xpath = "//button[normalize-space()='ordering Physician']")
	WebElement physicianType_ordering;

	@FindBy(xpath = "//button[normalize-space()='primary care Physician']")
	WebElement physicianType_PrimaryCare;

	@FindBy(xpath = "//button[normalize-space()='Both']")
	WebElement physicianType_Both;
	
	//@FindBy(xpath = "//div[contains(@aria-labelledby,'3')]/section[2]/div[2]//table//span[contains(text(),'ordering Physician')]")
	@FindBy(xpath = "//table//span[contains(text(),'ordering Physician')]")
	WebElement physicianType_ordering_Added;

	@FindBy(xpath = "//div[contains(@aria-labelledby,'3')]/section[2]/div[2]//table//span[contains(text(),'primary care Physician')]")
	WebElement physicianType_primary_Added;

	//@FindBy(xpath = "//div[contains(@aria-labelledby,'3')]/section[2]/div[2]//table//span[contains(text(),'primary care Physician') or contains(text(),'ordering Physician')]")
	@FindBy(xpath = "//table//span[contains(text(),'primary care Physician')]")
	WebElement physicianType_primary_Added1;

	@FindBy(xpath = "//div[contains(@aria-labelledby,'3')]/section[2]/div[2]/table[2]/tbody/tr/td[9]/div/div[2]/span")
	WebElement physicianType_both_Added;

	//@FindBy(xpath = "//div[contains(@aria-labelledby,'3')]/section[2]/div[2]/table[2]/tbody/tr[2]/td[9]/div/div[1]/span")
	@FindBy(xpath = "//table//span[contains(text(),'ordering Physician')]")
	WebElement physicianType_ordering_Added1;

	//@FindBy(xpath = "//div[contains(@aria-labelledby,'3')]/section[2]/div[2]/table[2]/tbody/tr[1]/td[9]/div/div[1]/span")
	@FindBy(xpath = "//table//span[contains(text(),'primary care Physician')]")
	WebElement physicianType_primary_Added2;

//	@FindBy(xpath = "//div[@id='panel:8-3']//button[@type='button'][normalize-space()='Save & Continue']")
	@FindBy(xpath = "(//button[@type='button'][normalize-space()='Save & Continue'])[3]")
	WebElement nextButton;

	@FindBy(xpath = "//div[@class='alert__content']")
	WebElement alertCheck;

	@FindBy(xpath = "//div[@class='alert error']//div[2]//span[@class='alert__title' and contains(text(),'An Ordering')]")
	WebElement alert_Content;

	@FindBy(xpath = "//div[contains(@aria-labelledby,'3')]//span[@class='empty-state__title']")
	WebElement errorMessage_orderingPhysician;

	@FindBy(xpath = "//div[contains(@aria-labelledby,'3')]//span[2]")
	WebElement errorMessage_orderingPhysician1;

	@FindBy(xpath = "//div[@class='empty-state__content']")
	WebElement errorMessage_OrderingPhysician_box;

	@FindBy(xpath = "//div[contains(@aria-labelledby,'3')]//table[1]//tbody//tr[1]//td")
	List<WebElement> searchResult_Table;

	//@FindBy(xpath = "//div[contains(@aria-labelledby,'3')]//table[2]//tbody//tr[1]//td")
	//List<WebElement> selectedPhysician_Table;
	
	@FindBy(xpath = "//div[contains(@aria-labelledby,'3')]/section[2]/div[4]/table[1]/tbody[1]/tr[1]/td")
	List<WebElement> selectedPhysician_Table;
	
	//@FindBy(xpath = "//div[contains(@aria-labelledby,'3')]/section[2]/div[2]/table[2]//span[@class='icon-icon_minus ']")
	@FindBy(xpath = "(//span[contains(@class,'icon-icon_minus')])[2]")
	WebElement unSelectIcon;

	@FindBy(xpath = "//div[contains(@aria-labelledby,'3')]/section[2]/div[2]/table[1]/tbody/tr[2]/td[9]/div/button")
	WebElement primaryCare_AddButton;

	@FindBy(xpath = "//*//form/div/div[8]//div[@class=' css-1hwfws3']/div[1]")
	WebElement physicianTabDropdownClick;

	@FindBy(xpath = "//div[@class=' css-26l3qy-menu']//div[@class=' css-11unzgr']//div")
	List<WebElement> physicianTabDropdown;

	@FindBy(xpath = "//div[contains(@aria-labelledby,'3')]//table[1]//tbody//tr")
	List<WebElement> moreRows;

	List<String> labelsList = new ArrayList<String>();
	int rowCount;
	boolean isPhysicianTabAvailable = false;

	public boolean isPhysicianTabAvailable() {

		String memberStatus = SeleniumMethods.isCompleted(memberInfoTabBtn, memberInfoTabStatus);
		String diagStatus = SeleniumMethods.isCompleted(diagnosisTabBtn, diagnosisTabStatus);
		try
		{
		Thread.sleep(500);
		} catch(InterruptedException e) { e.printStackTrace();}
		String serStatus = SeleniumMethods.isCompleted(servicesTabBtn, servicesTabStatus);
				
		if (memberStatus.equalsIgnoreCase(Constant.STATUS_COMPLETED)
				&& diagStatus.equalsIgnoreCase(Constant.STATUS_COMPLETED))
			//	&& serStatus.equalsIgnoreCase(Constant.STATUS_COMPLETED)) 	
		{
			
			SeleniumMethods.longwaitUntilClickable(physicianTabBtn);
			SeleniumMethods.javaScriptExecutorClick(physicianTabBtn);
			SeleniumMethods.longwaitUntilClickable(physicianTabBtn);
			log.info("Location Tab Status is **** {}", physicianTabStatus.getText());
			if (physicianTabStatus.getText().equalsIgnoreCase(Constant.STATUS_NOTCOMPLETED)) {
				isPhysicianTabAvailable = true;
			}
		}
		return isPhysicianTabAvailable;
	}

	public void enterValidInfoSeachfields(String physicianLastName, String physicianFirstName, String physicianNPI,
			String physicianPhoneNumber, String physicianCity, String physicianState, String physicianZipCode) {
		if (isPhysicianTabAvailable()) {
			SeleniumMethods.waitUntilElementIsClickable(physicianTabLastName);
			SeleniumMethods.waitUntilElementIsClickable(physicianTabFirstName);
			SeleniumMethods.waitUntilElementIsClickable(physicianTabNPI);
			SeleniumMethods.waitUntilElementIsClickable(physicianTabPhoneNumber);
			SeleniumMethods.waitUntilElementIsClickable(physician_City);
			SeleniumMethods.waitUntilElementIsClickable(physician_State);
			SeleniumMethods.waitUntilElementIsClickable(physician_ZipCode);

			physicianTabLastName.sendKeys(physicianLastName);
			physicianTabFirstName.sendKeys(physicianFirstName);
			physicianTabNPI.sendKeys(physicianNPI);
			physician_ZipCode.sendKeys(physicianZipCode);
			physicianTabPhoneNumber.sendKeys(physicianPhoneNumber);
			physician_City.sendKeys(physicianCity);
			SeleniumMethods.javaScriptExecutorClick(physician_State);
			physician_State.sendKeys(physicianState);
			physician_State.sendKeys(Keys.TAB);
		}
	}

	public boolean clickSearchButton() {
		SeleniumMethods.waitUntilElementIsClickable(physician_SearchButton);
		physician_SearchButton.click();
		SeleniumMethods.waitUntilElementIsClickable(physician_SearchButton);
		log.info("Table Count"+searchResultTblRow.size());
		return !searchResultTblRow.isEmpty();
	}

	public void verifyResultWithSearchDetails(String physicianLastName, String physicianFirstName, String physicianNPI,
			String physicianPhoneNumber, String physicianCity, String physicianState, String physicianZipCode) {
		rowCount = searchResultTblRow.size();
		log.info("Physician search result table size is {}", rowCount);
		if (rowCount > 0 && !searchResultTblData.isEmpty()) {
			for (int i = 0; i < rowCount; i++) {
				verifyRecords(searchResultTblData.get(0).getText(), physicianFirstName + " " + physicianLastName);
				verifyRecords(searchResultTblData.get(1).getText(), physicianNPI);
				verifyRecords(searchResultTblData.get(2).getText(), physicianZipCode);
				verifyRecords(searchResultTblData.get(3).getText(), physicianState);
				verifyRecords(searchResultTblData.get(4).getText(), physicianCity);
				verifyRecords(searchResultTblData.get(5).getText(), physicianPhoneNumber);
			}
		} else {
			log.info("No Results Found");
		}
	}

	public void verifyRecords(String feildUIData, String feildData) {
		if (feildUIData.equalsIgnoreCase(feildData)) {
			log.info("{} are matching", feildUIData);
		} else {
			log.info("{} is not matching", feildUIData);
		}
	}

	public void enterInvalidInformation() {
		if (isPhysicianTabAvailable()) {
			SeleniumMethods.waitUntilElementIsClickable(physicianTabLastName);
			SeleniumMethods.waitUntilElementIsClickable(physicianTabFirstName);
			SeleniumMethods.waitUntilElementIsClickable(physicianTabNPI);
			physicianTabLastName.sendKeys("ABC");
			physicianTabFirstName.sendKeys("MIKE");
			physicianTabNPI.sendKeys("1231");
		}
	}

	public void clickAddBottonToChoosePhysicianType() {
		SeleniumMethods.longwaitUntilElementIsVisible(addButtonToChoosePhysician);
		if (addButtonToChoosePhysician.isDisplayed()) {
			SeleniumMethods.javaScriptExecutorClick(addButtonToChoosePhysician);
		}
	}

	public void choosePhysiciantype(String physicianType) {
		if (physicianType.equalsIgnoreCase(Constant.ORDERING_PHYSICIAN)) {
			SeleniumMethods.waitUntilElementIsClickable(physicianType_ordering);
			physicianType_ordering.click();
		} else if (physicianType.equalsIgnoreCase(Constant.PRIMARY_PHYSICIAN)) {
			SeleniumMethods.waitUntilElementIsClickable(physicianType_PrimaryCare);
			physicianType_PrimaryCare.click();
		} else if (physicianType.equalsIgnoreCase(Constant.BOTH_PHYSICIAN)) {
			SeleniumMethods.waitUntilElementIsClickable(physicianType_Both);
			physicianType_Both.click();
		}
	}

	public boolean isPhysicianAdded() {
		return (physicianType_ordering_Added.isDisplayed() || physicianType_primary_Added.isDisplayed()
				|| physicianType_both_Added.isDisplayed());
	}

	public void enterInformationToSearch(String physicianZipCode1, String physicianCity1, String physicianState, String physicianNPI, String physicianLastname,String physicianFirstname) {
		SeleniumMethods.longwaitUntilElementIsClickable(physicianTabLastName);
//		SeleniumMethods.longwaitUntilElementIsClickable(physician_City);
//		SeleniumMethods.longwaitUntilElementIsClickable(physician_State);
		//physician_ZipCode.sendKeys(physicianZipCode1);
		//physician_City.sendKeys(physicianCity1);
//		physician_Npi.sendKeys(physicianNPI);
//		SeleniumMethods.javaScriptExecutorClick(physician_State);
//		physician_State.sendKeys(physicianState);
//		physician_State.sendKeys(Keys.TAB);
		
		physicianTabLastName.sendKeys(physicianLastname);
		physicianTabFirstName.sendKeys(physicianFirstname);
	}

	public boolean selectMoreThanOnePhysician() {
		rowCount = searchResultTblRow.size();
		boolean isMoreRecords = false;
		log.info("Physician search result table size is {}", rowCount);
		if (rowCount > 0 && !searchResultTblData.isEmpty()) {
			for (int row = 1; row < rowCount; row++) {
				List<WebElement> column = searchResultTblRow.get(row).findElements(By.tagName("td"));
				int columnCount = column.size();
				for (int col = 0; col < columnCount; col++) {
					selectAddBtn(column.get(col).getText(), row);
					isMoreRecords = true;
				}
			}
		} else {
			log.info("No Results Found");
		}
		return isMoreRecords;
	}

	public void selectAddBtn(String textFromUI, int row) {
		if (textFromUI.equalsIgnoreCase(Constant.ADD)) {
			driver.findElement(By.xpath("//div[contains(@aria-labelledby,'3')]/section[2]/div[2]/table/tbody/tr[" + row
					+ "]/td[9]/div/button")).click();
			physicianType_Both.click();
		} else {
			log.info("Add button not Selected");
		}
	}

	public void clickNextButton() {
		if (nextButton.isDisplayed()) {
			nextButton.click();
		}
	}

	public boolean verifyErrorMessage() {
		return (alertCheck.isDisplayed() && alert_Content.getText().equalsIgnoreCase(Constant.PHYSICIAN_ALERT_MESSAGE));
	}

	public boolean verifyErrorMessageForOrderingPhysician() {
		SeleniumMethods.waitUntilElementIsClickable(alertCheck);
		return (alertCheck.isDisplayed()
				&& alert_Content.getText().equalsIgnoreCase(Constant.ORDERING_PHYSICIAN_ALERT_MESSAGE));
	}

	public boolean verifyErrorMessageToUpdateSearchCriteria() {
		return (errorMessage_OrderingPhysician_box.isDisplayed()
				&& errorMessage_orderingPhysician.getText().equalsIgnoreCase(Constant.ORDERING_PHYSICIAN_ERROR_MESSAGE)
				&& errorMessage_orderingPhysician1.getText()
				.equalsIgnoreCase(Constant.ORDERING_PHYSICIAN_ERROR_MESSAGE1));
	}

	public boolean checkDetailsOfSelectedPhysician(String physicianType) {
		boolean isSelectedOptionMatch = false;
		if (verifyPhysicianAdded(physicianType) && !searchResult_Table.isEmpty()) {
				
			for (int i = 0; i < searchResult_Table.size() - 12; i++) {
				System.out.println("Print "+ searchResult_Table.size() +" "+i);
				if (searchResult_Table.get(i).getText().equals(selectedPhysician_Table.get(i).getText())) {
					log.info("\t Search Result Value  \t {} %n \t\t\t\t\t\t\t Selected Option Value {}",
							searchResult_Table.get(i).getText(), selectedPhysician_Table.get(i).getText());
					isSelectedOptionMatch = true;
				}
			}
		}
		return isSelectedOptionMatch;
	}

	public boolean verifyPhysicianAdded(String physicianType) {
		return ((physicianType.equalsIgnoreCase(Constant.PRIMARY_PHYSICIAN)
				&& physicianType_primary_Added.getText().equalsIgnoreCase(Constant.PRIMARY_PHYSICIAN))
				|| (physicianType.equalsIgnoreCase(Constant.ORDERING_PHYSICIAN)
						&& physicianType_ordering_Added.getText().equalsIgnoreCase(Constant.ORDERING_PHYSICIAN))
				|| (physicianType.equalsIgnoreCase(Constant.BOTH_PHYSICIAN)
						&& physicianType_ordering_Added.getText().equalsIgnoreCase(Constant.ORDERING_PHYSICIAN)
						&& physicianType_both_Added.getText().equalsIgnoreCase(Constant.PRIMARY_PHYSICIAN)));
	}

	public boolean unSelectChoosenPhysician() {
		boolean isOptionUnSelected = false;
		if (!selectedPhysician_Table.isEmpty()) {
			unSelectIcon.click();
			isOptionUnSelected = true;
		} else
			isOptionUnSelected = false;

		return isOptionUnSelected;
	}

	public boolean isSearchResultsDisplayed() {
		return !searchResult_Table.isEmpty();
	}

	public boolean selectOrderingAndPrimaryPhysicianInOneOption() {
		boolean selectOrderingAndPrimaryPhysicianInOneOption = false;
		if (!searchResult_Table.isEmpty()) {
			SeleniumMethods.waitUntilElementIsClickable(physicianType_ordering);
			physicianType_ordering.click();
			clickAddBottonToChoosePhysicianType();
			SeleniumMethods.waitUntilElementIsClickable(physicianType_PrimaryCare);
			physicianType_PrimaryCare.click();
			selectOrderingAndPrimaryPhysicianInOneOption = true;
		} else {
			selectOrderingAndPrimaryPhysicianInOneOption = false;
		}
		return selectOrderingAndPrimaryPhysicianInOneOption;
	}

	public boolean checkOrderingAndPrimaryPhysicianAdded() {
		return (!searchResult_Table.isEmpty() && physicianType_ordering_Added.isDisplayed()
				&& physicianType_primary_Added1.isDisplayed());

	}

	public boolean chooseDiffPhysiciantypes(String physician) {
		boolean isMoreRecords = false;
		if (moreRows.size() > 1) {
			isMoreRecords = true;
			if (physician.equalsIgnoreCase(Constant.ORDERING_PHYSICIAN)) {
				SeleniumMethods.waitUntilElementIsClickable(physicianType_ordering);
				physicianType_ordering.click();
			} else if (physician.equalsIgnoreCase(Constant.PRIMARY_PHYSICIAN)) {
				SeleniumMethods.waitUntilElementIsClickable(primaryCare_AddButton);
				primaryCare_AddButton.click();
				SeleniumMethods.waitUntilElementIsClickable(physicianType_PrimaryCare);
				physicianType_PrimaryCare.click();
			}
		} else {
			log.info("Search Result is not sufficiant to choose Ordering and Primary Physician in Different option");
		}
		return isMoreRecords;
	}

	public boolean checkOrderingAndPrimaryPhysicianAddedInDiffOption() {
		return (moreRows.size() > 1 && physicianType_ordering_Added1.isDisplayed()
				&& physicianType_primary_Added2.isDisplayed());
	}

	public boolean verifyStateDropdownPresent() {
		SeleniumMethods.shortwaitUntilElementIsClickable(physicianTabDropdownClick);
		return physicianTabDropdownClick.isDisplayed();
	}

	public void clickStateDropdown() {
		SeleniumMethods.waitUntilElementIsClickable(physicianTabDropdownClick);
		physicianTabDropdownClick.click();
	}

	List<String> physicianPageStateList = new ArrayList<String>();

	public boolean verifyStateListPresent() {
		boolean isStateListPresent = false;
		for (WebElement dd_list : physicianTabDropdown) {
			if (!dd_list.getText().isEmpty()) {
				isStateListPresent = true;
				physicianPageStateList.add(dd_list.getText());
			}
		}
		log.info("State Drop Down size is: {} and list is {}", physicianPageStateList.size(), physicianPageStateList);
		return isStateListPresent;
	}

	public boolean verifyStateListSortorder() {
		SeleniumMethods.waitUntilElementIsClickable(physicianTabDropdownClick);
		return SeleniumMethods.isCollectionSorted(physicianTabDropdown);
	}

	public boolean checkStateDropdownvalues(String physicianStateList) {
		SeleniumMethods.waitUntilElementIsClickable(physicianTabDropdownClick);
		return SeleniumMethods.checkStateDropdownvalues(physicianTabDropdown, physicianStateList);
	}

}
