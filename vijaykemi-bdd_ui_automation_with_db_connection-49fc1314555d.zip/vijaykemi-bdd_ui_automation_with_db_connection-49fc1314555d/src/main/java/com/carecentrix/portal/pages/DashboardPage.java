package com.carecentrix.portal.pages;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.carecentrix.utilities.Constant;
import com.carecentrix.utilities.SeleniumMethods;

/**
 * @author KKJANAK
 *
 */

public class DashboardPage {

	WebDriver driver;

	private static final Logger log = LogManager.getLogger(DashboardPage.class);

	public DashboardPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}

	@FindBy(xpath = "//span[@class='name' and contains(text(),'CREATE REQUEST')]")
	WebElement dashboardCreateRequestButton;

	@FindBy(xpath = "//div[@class='section-card__content']//h2[contains(text(),'Pending Task')]")
	WebElement dashboardPendingTask;

	@FindBy(xpath = "//span[contains(text(),'My Tasks')]")
	WebElement dashboardMyTasks;

	@FindBy(xpath = "//span[contains(text(),'Settings')]")
	WebElement dashBoardSettingsMenu;

	@FindBy(xpath = "//a[contains(text(),'Security')]")
	WebElement settingsSecurityMenu;

	@FindBy(xpath = "//div[@class='link-container']")
	WebElement settingsGoToSecurityQ;

	@FindBy(xpath = "//input[@name='password']")
	WebElement settingAccVerifyPass;

	@FindBy(xpath = "//input[@name='commit']")
	WebElement settingAccVerifyBtn;

	@FindBy(id = "select-questions-0")
	WebElement securityQ1;

	@FindBy(id = "select-questions-1")
	WebElement securityQ2;

	@FindBy(id = "select-questions-2")
	WebElement securityQ3;

	@FindBy(xpath = "//div[@class='field']//input[1]")
	WebElement securityA1;

	@FindBy(xpath = "//div[@class='field']//input[3]")
	WebElement securityA2;

	@FindBy(xpath = "//div[@class='field']//input[5]")
	WebElement securityA3;

	@FindBy(id = "submit_questions")
	WebElement securitySaveBtn;

	@FindBy(xpath = "//div[@class='option-card']")
	WebElement pwdLink;

	@FindBy(xpath = "//div[@class='option-card']/h1")
	WebElement pwdTitle;

	@FindBy(xpath = "//h1[@class='top-banner__title']")
	WebElement chgPwdTitle;

	@FindBy(xpath = "//input[@name='user[password]']")
	WebElement newPwd;

	@FindBy(xpath = "//ul[@class='pass-validation__content']/li[1]")
	WebElement minCharMsg;

	@FindBy(xpath = "//li[@class='pass-validation__list has-upper']")
	WebElement upperCaseMsg;

	@FindBy(xpath = "//li[@class='pass-validation__list has-lower']")
	WebElement lowerCaseMsg;

	@FindBy(xpath = "//li[@class='pass-validation__list has-number']")
	WebElement numberMsg;

	@FindBy(xpath = "//li[@class='pass-validation__list has-special']")
	WebElement splCharMsg;

	@FindBy(xpath = "//input[@name='user[password_confirmation]']")
	WebElement cnfPwd;

	@FindBy(xpath = "//input[@name='user[current_password]']")
	WebElement currentPwd;

	@FindBy(xpath = "//span[@class='alert__description']")
	WebElement reqAlertMsg;

	@FindBy(name = "commit")
	WebElement savePwdBtn;

	@FindBy(xpath = "//div[@class='alert error verify__error hide']//span[@class='alert__description']")
	WebElement previousPwdAlert;

	Select select;
	List<WebElement> allOptions;

	public boolean verifyUserInDashboardPage(String dashboardURL) {
		return dashboardURL.equalsIgnoreCase(driver.getCurrentUrl());
	}

	public boolean verifyRequiredOptionsAreInDashboardPage() {
		return dashboardCreateRequestButton.isDisplayed() && dashboardPendingTask.isDisplayed()
				&& dashboardMyTasks.isDisplayed();
	}

	public boolean clickOnSettings(String settingsURL) {
		SeleniumMethods.waitUntilElementIsClickable(dashBoardSettingsMenu);
		dashBoardSettingsMenu.click();
		SeleniumMethods.waitUntilElementIsClickable(settingsSecurityMenu);
		return settingsSecurityMenu.isDisplayed() && settingsURL.equalsIgnoreCase(driver.getCurrentUrl());
	}
	
	public boolean clickOnSecurity() {
		dashBoardSettingsMenu.click();
		SeleniumMethods.longwaitUntilElementIsClickable(settingsSecurityMenu);
		settingsSecurityMenu.click();
		SeleniumMethods.waitUntilElementIsClickable(settingsGoToSecurityQ);
		return settingsGoToSecurityQ.isDisplayed();
	}

	public boolean clickSecurityQuestionsLink(String securityAccVerifyURL) {
		SeleniumMethods.waitUntilElementIsClickable(settingsGoToSecurityQ);
		settingsGoToSecurityQ.click();
		SeleniumMethods.waitUntilElementIsClickable(settingAccVerifyPass);
		return securityAccVerifyURL.equalsIgnoreCase(driver.getCurrentUrl());
	}

	public boolean providePWD(String password) {
		SeleniumMethods.waitUntilElementIsClickable(settingAccVerifyPass);
		settingAccVerifyPass.sendKeys(password);
		boolean btnClick = false;
		if (settingAccVerifyBtn.isEnabled()) {
			settingAccVerifyBtn.click();
			btnClick = true;
		}
		return btnClick;
	}

	public boolean verifySaveButtonDisabled() {
		return !securitySaveBtn.isEnabled();
	}

	public boolean verifySecurityQuesDrpdwn(String securityQues) {
		Select select1 = new Select(securityQ1);
		List<WebElement> allOptions1 = select1.getOptions();
		List<String> listFromUI = new ArrayList<String>();
		for (WebElement ele : allOptions1) {
			listFromUI.add(ele.getText());
		}
		return SeleniumMethods.compareListValues(listFromUI, securityQues);
	}

	public void selectSecurityQandA(String secutiryQandA) {
		SeleniumMethods.waitUntilElementIsClickable(securityQ1);
		if (securityQ1.isDisplayed()) {
			select = new Select(securityQ1);
			allOptions = select.getOptions();
			if (!allOptions.isEmpty()) {
				select.selectByIndex(1);
				SeleniumMethods.waitUntilElementIsClickable(securityA1);
				securityA1.sendKeys(secutiryQandA);
				log.info("Security Question1 and Answer selected");
			}
		}
		if (securityQ2.isDisplayed()) {
			SeleniumMethods.waitUntilElementIsClickable(securityQ2);
			select = new Select(securityQ2);
			allOptions = select.getOptions();
			if (!allOptions.isEmpty()) {
				select.selectByIndex(2);
				SeleniumMethods.waitUntilElementIsClickable(securityA2);
				securityA2.sendKeys(secutiryQandA);
				log.info("Security Question2 and Answer selected");
			}
		}
		if (securityQ3.isDisplayed()) {
			SeleniumMethods.waitUntilElementIsClickable(securityQ3);
			select = new Select(securityQ3);
			allOptions = select.getOptions();
			if (!allOptions.isEmpty()) {
				select.selectByIndex(3);
				SeleniumMethods.waitUntilElementIsClickable(securityA3);
				securityA3.sendKeys(secutiryQandA);
				securityA3.sendKeys(Keys.TAB);
				log.info("Security Question3 and Answer selected");
			}
		}
	}

	public boolean verifySaveButtonAndSave() {
		boolean isEnabled = false;
		SeleniumMethods.waitUntilElementIsClickable(securitySaveBtn);
		if (securitySaveBtn.isEnabled()) {
			securitySaveBtn.click();
			isEnabled = true;
		}
		return isEnabled;
	}

	public boolean clickMyPasswordLink() {
		boolean isClicked = false;
		SeleniumMethods.waitUntilElementIsClickable(pwdLink);
		if (pwdTitle.isDisplayed() && pwdTitle.getText().equalsIgnoreCase(Constant.MYPASSWORD)) {
			pwdLink.click();
			SeleniumMethods.longwaitUntilElementIsVisible(chgPwdTitle);
			if (chgPwdTitle.isDisplayed() && chgPwdTitle.getText().equalsIgnoreCase(Constant.CHANGEPWDTITLE)) {
				isClicked = true;

			}
		}
		return isClicked;
	}

	public void providePWDWithoutReq(String pwd) {
		provideNewPWD(pwd);
	}

	public boolean clearPasswordField() {
		newPwd.clear();
		return newPwd.getText().equalsIgnoreCase(Constant.EMPTYVALUE);
	}

	public void providePWDWithoutUppercase(String pwd) {
		provideNewPWD(pwd);
	}

	public void providePWDWithoutLowercase(String pwd) {
		provideNewPWD(pwd);
	}

	public void providePWDWithoutNumbers(String pwd) {
		provideNewPWD(pwd);
	}

	public void providePWDWithoutSpecialChar(String pwd) {
		provideNewPWD(pwd);
	}

	public void provideNewPWD(String pwd) {
		SeleniumMethods.waitUntilElementIsClickable(newPwd);
		newPwd.sendKeys(pwd);
	}

	public boolean checkPWDValidMsg(WebElement ele, String className) {
		return ele.getAttribute(Constant.CLASSVALUE).equalsIgnoreCase(className);
	}

	public boolean validatePasswordReq(String req) {
		boolean isValid = false;
		switch (req) {
		case Constant.MINCHAR: {
			isValid = checkPWDValidMsg(minCharMsg, Constant.PWD_MINCHAR_INVALID);
			break;
		}
		case Constant.UPPERCASE: {
			isValid = checkPWDValidMsg(upperCaseMsg, Constant.PWD_UC_INVALID);
			break;
		}
		case Constant.LOWERCASE: {
			isValid = checkPWDValidMsg(lowerCaseMsg, Constant.PWD_LC_INVALID);
			break;
		}
		case Constant.NUMBER: {
			isValid = checkPWDValidMsg(numberMsg, Constant.PWD_NUM_INVALID);
			break;
		}
		case Constant.SPLCHAR: {
			isValid = checkPWDValidMsg(splCharMsg, Constant.PWD_SPL_INVALID);
			break;
		}
		default:
			log.info("Password requirements validated");
		}
		return isValid;
	}

	public void providePasswords(String newPwd1, String cnfPwd1) {
		SeleniumMethods.waitUntilElementIsClickable(newPwd);
		newPwd.sendKeys(newPwd1);
		SeleniumMethods.waitUntilElementIsClickable(cnfPwd);
		cnfPwd.sendKeys(cnfPwd1);
	}

	public void clickSavePwdBtn() {
		SeleniumMethods.longwaitUntilElementIsVisible(savePwdBtn);
		SeleniumMethods.javaScriptExecutorClick(savePwdBtn);
	}

	public boolean validateReqAlertMsg() {
		SeleniumMethods.longwaitUntilElementIsVisible(reqAlertMsg);
		return reqAlertMsg.getText().equalsIgnoreCase(Constant.REQ_ALERT_MSG);
	}

	public boolean validatePwdMatchAlertMsg() {
		SeleniumMethods.longwaitUntilElementIsVisible(reqAlertMsg);
		return reqAlertMsg.getText().equalsIgnoreCase(Constant.PWD_MATCH_MSG);
	}

	public void provideCurrentPwd(String addInfoPwd) {
		SeleniumMethods.waitUntilElementIsClickable(currentPwd);
		currentPwd.sendKeys(addInfoPwd);
	}

	public boolean validatePreviousPwdMatchAlertMsg() {
		SeleniumMethods.longwaitUntilElementIsVisible(previousPwdAlert);
		return previousPwdAlert.getText().equalsIgnoreCase(Constant.OLD_PWD_MSG);
	}

	public void clickOutside() {
		Actions action = new Actions(driver);
		action.moveByOffset(0, 0).click().build().perform();
	}

	public void clickOutsideToChkErrMsg() {
		clickOutside();
	}

}
