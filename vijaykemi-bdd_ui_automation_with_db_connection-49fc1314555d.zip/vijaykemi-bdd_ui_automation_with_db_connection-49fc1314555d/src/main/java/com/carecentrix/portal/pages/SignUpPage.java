package com.carecentrix.portal.pages;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.carecentrix.utilities.Constant;
import com.carecentrix.utilities.SeleniumMethods;

/**
 * @author KKJANAK
 *
 */

public class SignUpPage {

	WebDriver driver;

	private static final Logger log = LogManager.getLogger(SignUpPage.class);

	public SignUpPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}

	String eRAFAQfileName = "005_ERA_Provider_FAQ_FINAL_121813.pdf";
	String eRAPaperfileName = "ERA_Paper_Enrollement_Form_V1_1.pdf";

	@FindBy(xpath = "//div[@class='menu-list__link']//a[contains(text(),'Register')]")
	WebElement signUpRegisterButton;

	@FindBy(id = "user_user_type")
	WebElement signUpUserTypeDropdown;

	@FindBy(id = "user_provider_type")
	WebElement signUpProviderTypeDropdown;

	@FindBy(id = "user_health_plan")
	WebElement signUpHealthPlanDropdown;

	@FindBy(id = "user_state")
	WebElement signUpStateDropdown;

	@FindBy(xpath = "//div[@class='pardon-our-dust']")
	WebElement notListedAlert;

	@FindBy(xpath = "//div[@class='pardon-our-dust']/h1")
	WebElement alertTitle;

	@FindBy(xpath = "//div[@class='pardon-our-dust']/p")
	WebElement alertContent;

	@FindBy(xpath = "//div[@class='pardon-our-dust']/a")
	WebElement alertBtn;

	@FindBy(xpath = "//div[@class='modal-content']/span")
	WebElement alertCloseBtn;

	@FindBy(id = "user_first_name")
	WebElement signUpFirstName;

	@FindBy(id = "user_last_name")
	WebElement signUpLastName;

	@FindBy(id = "user_email")
	WebElement signUpEmail;

	@FindBy(id = "user_location_name")
	WebElement signUpLocName;

	@FindBy(id = "user_npi")
	WebElement signUpNPI;

	@FindBy(id = "user_address")
	WebElement signUpAddress;

	@FindBy(id = "user_city")
	WebElement signUpCity;

	@FindBy(id = "//label[contains(text(),'State')]")
	WebElement signUpStateTitle;

	@FindBy(id = "user_zip")
	WebElement signUpZip;

	@FindBy(id = "user_phone")
	WebElement signUpPhNum;

	@FindBy(id = "user_fax")
	WebElement signUpFax;

	@FindBy(id = "verify-btn")
	WebElement signUpVerifyBtn;

	@FindBy(id = "facility_0")
	WebElement signUpSelectBtn;

	@FindBy(xpath = "//div[@class='locations-table']//table/tbody/tr/td")
	List<WebElement> locationTblData;

	@FindBy(xpath = "//div[@class='locations-table__header']")
	WebElement locationTbl;

	@FindBy(xpath = "//div[@class='alert error']")
	WebElement alertBox;

	@FindBy(xpath = "//div[@class='alert info']//span[@class='alert__description']")
	WebElement alertDesc;

	@FindBy(xpath = "//div[@class='alert-container']//span[@class='alert__title']")
	WebElement alertMsgTitle;

	@FindBy(xpath = "//div[@class='alert-container']//span[@class='alert__description']")
	WebElement alertDescription;

	@FindBy(xpath = "//div[@class='based-our-records']")
	WebElement emailValidationMsgBox;

	@FindBy(xpath = "//div[@class='based-our-records']/p")
	WebElement emailValidationMsg;

	@FindBy(xpath = "//div[@class='based-our-records']//a[@class='button button--secondary']")
	WebElement contactUsBtn;

	@FindBy(xpath="//label[@class='field-required']")
	List<WebElement> registerDetails;

	@FindBy(xpath = "//div[11]//div//label")
	WebElement addressLabel;

	@FindBy(xpath = "//div[12]//div//label")
	WebElement cityLabel;

	@FindBy(xpath = "//div[13]//div//label")
	WebElement stateLabel;

	@FindBy(xpath = "//div[14]//div//label")
	WebElement zipLabel;

	@FindBy(xpath = "//div[15]//div//label")
	WebElement phoneLabel;

	@FindBy(xpath = "//div[16]//div//label")
	WebElement faxLabel;

	@FindBy(xpath = "//label[@class='button-link']/span")
	WebElement btnSingUp;

	@FindBy(xpath = "//a[contains(text(),'Sign up for EFT/ERA through CAQH')]")
	WebElement lnkEFTERACAQH;

	@FindBy(xpath = "//a[contains(text(),'ERA Enrollment Frequently Asked Question')]")
	WebElement lnkERAEnrollmentFAQ;

	@FindBy(xpath = "//a[contains(text(),'ERA Enrollment Only – Paper Enrollment Form')]")
	WebElement lnkERAPaperEnrollment;

	@FindBy(xpath = "//img[@alt='Register']")
	WebElement btnRegister;

	@FindBy(xpath="//table/thead/tr/th")
	List<WebElement> locationTblLbl;

	public boolean clickRegisterButton() {
		signUpRegisterButton.click();
		return true;
	}

	public boolean verifyUserTypeDropdownPresent() {
		return signUpUserTypeDropdown.isDisplayed();
	}

	public void clickUserTypeDropdown() {
		signUpUserTypeDropdown.click();
	}

	public boolean verifyUserTypeListPresent() {
		Select select = new Select(signUpUserTypeDropdown);
		List<WebElement> allOptions = select.getOptions();
		return !allOptions.isEmpty();
	}

	public boolean verifyUserTypeListOrder() {
		Select select = new Select(signUpUserTypeDropdown);
		List<WebElement> userTypeOptions = select.getOptions();
		return SeleniumMethods.isCollectionSorted(userTypeOptions);
	}

	public void checkUserTypeDropdownValuesUserType(String userType) {
		Select select = new Select(signUpUserTypeDropdown);
		List<WebElement> userTypeOptions = select.getOptions();
		if (!userTypeOptions.isEmpty()) {
			if (userType.equalsIgnoreCase(userTypeOptions.get(1).getText())) {
				log.info("User Type Provider is available in dropdown");
			} else if (userTypeOptions.size() > 2 && userType.equalsIgnoreCase(userTypeOptions.get(2).getText())) {
				log.info("User Type Facility is available in dropdown");
			} else if (userTypeOptions.size() > 3 && userType.equalsIgnoreCase(userTypeOptions.get(3).getText())) {
				log.info("User Type HealthPlan is available in dropdown");
			} else if (userTypeOptions.size() > 4 && userType.equalsIgnoreCase(userTypeOptions.get(4).getText())) {
				log.info("User Type Physician is available in dropdown");
			} else {
				log.info("New User Type is added");
			}
		}
	}

	public boolean verifyPortalProviderTypeDropdownPresent() {
		return signUpProviderTypeDropdown.isDisplayed();
	}

	public void clickPortalProviderTypeDropdown() {
		signUpProviderTypeDropdown.click();
	}

	public boolean verifyPortalProviderTypeListPresent() {
		Select select = new Select(signUpProviderTypeDropdown);
		List<WebElement> allOptions = select.getOptions();
		return !allOptions.isEmpty();
	}

	public boolean verifyPortalProviderTypeListSortorder() {
		Select select = new Select(signUpProviderTypeDropdown);
		List<WebElement> providerTypeOptions = select.getOptions();
		return SeleniumMethods.isCollectionSorted(providerTypeOptions);
	}

	public void checkPortalProviderTypeDropdownvalues(String portalProviderType) {
		Select select = new Select(signUpProviderTypeDropdown);
		List<WebElement> providerTypeOptions = select.getOptions();
		if (!providerTypeOptions.isEmpty()) {
			if (portalProviderType.equalsIgnoreCase(providerTypeOptions.get(1).getText())) {
				logMessage(providerTypeOptions, 1);
			} else if (providerTypeOptions.size() > 2
					&& portalProviderType.equalsIgnoreCase(providerTypeOptions.get(2).getText())) {
				logMessage(providerTypeOptions, 2);
			} else if (providerTypeOptions.size() > 3
					&& portalProviderType.equalsIgnoreCase(providerTypeOptions.get(3).getText())) {
				logMessage(providerTypeOptions, 3);
			} else {
				log.info("New Portal Provider Type is added");
			}
		}
	}

	public void logMessage(List<WebElement> options, int i) {
		log.info("Portal Provider Type %s is available in dropdown", options.get(i).getText());
	}

	public boolean verifyHealthPlanDropdownPresent() {
		return signUpHealthPlanDropdown.isDisplayed();
	}

	public void clickHealthPlanDropdown() {
		signUpHealthPlanDropdown.click();
	}

	public boolean verifyHealthPlanListPresent() {
		Select select = new Select(signUpHealthPlanDropdown);
		List<WebElement> allOptions = select.getOptions();
		return !allOptions.isEmpty();
	}

	public boolean verifyHealthPlanListOrder() {
		Select select = new Select(signUpHealthPlanDropdown);
		List<WebElement> userTypeOptions = select.getOptions();
		return SeleniumMethods.isCollectionSorted(userTypeOptions);
	}

	public boolean verifyNoDefaultValueSelected() {
		SeleniumMethods.waitUntilElementIsClickable(signUpHealthPlanDropdown);
		String empty = "";
		Select select = new Select(signUpHealthPlanDropdown);
		WebElement option = select.getFirstSelectedOption();
		log.info("signUpHealthPlanDropdown.getText() {}", option.getText());
		return empty.equals(option.getText());
	}

	public void checkHealthPlanDropdownValuesHealthPlan(String healthPlan) {
		Select select = new Select(signUpHealthPlanDropdown);
		List<WebElement> healthPlanOptions = select.getOptions();
		if (!healthPlanOptions.isEmpty()) {
			if (healthPlan.equalsIgnoreCase(healthPlanOptions.get(1).getText())) {
				log.info("User Type Provider is available in dropdown");
			} else if (healthPlanOptions.size() > 2
					&& healthPlan.equalsIgnoreCase(healthPlanOptions.get(2).getText())) {
				log.info("User Type Facility is available in dropdown");
			} else if (healthPlanOptions.size() > 3
					&& healthPlan.equalsIgnoreCase(healthPlanOptions.get(3).getText())) {
				log.info("User Type HealthPlan is available in dropdown");
			} else if (healthPlanOptions.size() > 4
					&& healthPlan.equalsIgnoreCase(healthPlanOptions.get(4).getText())) {
				log.info("User Type Physician is available in dropdown");
			} else {
				log.info("New Health Plan is added");
			}
		}
	}

	public boolean verifyStateDropdownPresent() {
		return signUpStateDropdown.isDisplayed();
	}

	public void clickStateDropdown() {
		signUpStateDropdown.click();
	}

	public boolean verifyStateListPresent() {
		Select select = new Select(signUpStateDropdown);
		List<WebElement> allOptions = select.getOptions();
		return !allOptions.isEmpty();
	}

	public boolean verifyStateListSortorder() {
		Select select = new Select(signUpStateDropdown);
		List<WebElement> stateOptions = select.getOptions();
		return SeleniumMethods.isCollectionSorted(stateOptions);
	}

	public void checkStateDropdownvalues(List<List<String>> stateDetails) {
		Select select = new Select(signUpStateDropdown);
		List<WebElement> stateOptions = select.getOptions();
		List<String> newOptionList = new ArrayList<String>();
		if (stateDetails.equals(newOptionList)) {
			log.info("State lists are same");
			for (WebElement option : stateOptions) {
				newOptionList.add(option.getText());
			}
		} else {
			log.info("State lists are not same");
		}
	}

	public void selectOptionFromHealthPlan(String option) {
		Select select = new Select(signUpHealthPlanDropdown);
		select.selectByValue(option);
	}

	public boolean verifyAlertMessage() {
		boolean isAlretPresent = false;
		SeleniumMethods.waitUntilElementIsClickable(notListedAlert);
		if (notListedAlert.isDisplayed() && alertTitle.getText().equalsIgnoreCase(Constant.HP_ALERT_TITLE)
				&& alertContent.getText().equalsIgnoreCase(Constant.HP_ALERT_CONTENT)
				&& alertBtn.getText().equalsIgnoreCase(Constant.HP_BTN_CONTENT)) {
			alertBtn.click();
			isAlretPresent = true;
		}
		return isAlretPresent;
	}

	public void enterDetailsInAllFields(String firstNm, String lastNm, String email, String location, String npi,
			String address, String city, String zip, String phone, String fax) {
		userDetailsValidation(firstNm, lastNm, email, location, npi, address, city, zip, phone, fax);
	}

	public boolean verifyLocationDetailsFetched(String location, String npi, String address, String city, String zip,
			String phone) {
		List<String> userLocation = new ArrayList<String>();
		List<String> uiLocation = new ArrayList<String>();
		userLocation.add(location);
		userLocation.add(address);
		userLocation.add(city);
		userLocation.add(Constant.LOCATIONFL);
		userLocation.add(zip);
		userLocation.add(phone);
		userLocation.add(npi);
		SeleniumMethods.longwaitUntilElementIsVisible(locationTbl);
		for (WebElement ele : locationTblData) {
			uiLocation.add(ele.getText());
		}
		return userLocation.containsAll(uiLocation);
	}

	public void selectLocationDetails() {
		SeleniumMethods.waitUntilElementIsClickable(signUpSelectBtn);
		signUpSelectBtn.click();
	}

	public void userDetailsValidation(String firstNm, String lastNm, String email, String location, String npi,
			String address, String city, String zip, String phone, String fax) {
		SeleniumMethods.waitUntilElementIsClickable(signUpFirstName);
		Select userType = new Select(signUpUserTypeDropdown);
		userType.selectByIndex(1);
		Select providerType = new Select(signUpProviderTypeDropdown);
		providerType.selectByIndex(1);
		Select healthPlan = new Select(signUpHealthPlanDropdown);
		healthPlan.selectByIndex(1);
		signUpFirstName.sendKeys(firstNm);
		signUpLastName.sendKeys(lastNm);
		signUpEmail.sendKeys(email);
		signUpLocName.sendKeys(location);
		signUpNPI.sendKeys(npi);
		Select state = new Select(signUpStateDropdown);
		state.selectByValue("S10");
		signUpAddress.sendKeys(address);
		signUpCity.sendKeys(city);
		signUpZip.sendKeys(zip);
		signUpPhNum.sendKeys(phone);
		signUpFax.sendKeys(fax);
	}

	public void clickVerifyBtn() {
		SeleniumMethods.waitUntilElementIsClickable(signUpVerifyBtn);
		signUpVerifyBtn.click();
	}

	public boolean verifyAlertErrMsg(String alertTit, String alertCnt) {
		SeleniumMethods.longwaitUntilElementIsVisible(alertBox);
		return (alertBox.isDisplayed() && alertMsgTitle.getText().equalsIgnoreCase(alertTit)
				&& alertDescription.getText().equalsIgnoreCase(alertCnt));
	}

	public boolean goToMainPage() {
		driver.navigate().back();
		return true;
	}

	public boolean verifyEmailValidationMsg() {
		SeleniumMethods.longwaitUntilElementIsVisible(emailValidationMsgBox);
		SeleniumMethods.longwaitUntilElementIsVisible(emailValidationMsg);
		return (emailValidationMsgBox.isDisplayed()
				&& emailValidationMsg.getText().equalsIgnoreCase(Constant.SIGN_UP_EMAIL_ERR_MSG));
	}

	public void enterDetailsInMandatoryFields(String fieldName, String blankVal, String firstNm, String lastNm,
			String email, String location, String npi) {

		switch (fieldName) {
		case Constant.SIGNUP_USER_TYPE: {
			fillMandotaryFields(0, 1, 1, firstNm, lastNm, email, location, npi);
			break;
		}
		case Constant.SIGNUP_PROV_TYPE: {
			fillMandotaryFields(1, 0, 1, firstNm, lastNm, email, location, npi);
			break;
		}
		case Constant.SIGNUP_HP: {
			fillMandotaryFields(1, 1, 0, firstNm, lastNm, email, location, npi);
			break;
		}
		case Constant.SIGNUP_FNAME: {
			fillMandotaryFields(1, 1, 1, blankVal, lastNm, email, location, npi);
			break;
		}
		case Constant.SIGNUP_LNAME: {
			fillMandotaryFields(1, 1, 1, firstNm, blankVal, email, location, npi);
			break;
		}
		case Constant.SIGNUP_LOC: {
			fillMandotaryFields(1, 1, 1, firstNm, lastNm, email, blankVal, npi);
			break;
		}
		case Constant.SIGNUP_EMAIL: {
			fillMandotaryFields(1, 1, 1, firstNm, lastNm, blankVal, location, npi);
			break;
		}
		case Constant.SIGNUP_NPI: {
			fillMandotaryFields(1, 1, 1, firstNm, lastNm, email, location, blankVal);
			break;
		}
		}
	}

	public boolean verifyMissingFieldsErrMsg(String fieldName) {
		SeleniumMethods.longwaitUntilElementIsVisible(alertBox);
		boolean flag = false;
		if (fieldName.equalsIgnoreCase(Constant.SIGNUP_EMAIL)) {
			flag = (alertBox.isDisplayed() && alertMsgTitle.getText().equalsIgnoreCase(Constant.SIGNUP_ALERT_TITLE)
					&& alertDescription.getText().equalsIgnoreCase(Constant.MISSING_MSSG_CNTENT));
		} else {
			flag = (alertBox.isDisplayed() && alertMsgTitle.getText().equalsIgnoreCase(Constant.MISSING_MSSG_TITLE)
					&& alertDescription.getText().equalsIgnoreCase(Constant.MISSING_MSSG_CNTENT));
		}
		return flag;

	}

	public void fillMandotaryFields(int userTyp, int provType, int hp, String firstNm, String lastNm, String email,
			String location, String npi) {
		SeleniumMethods.waitUntilElementIsClickable(signUpFirstName);
		Select userType = new Select(signUpUserTypeDropdown);
		userType.selectByIndex(userTyp);
		Select providerType = new Select(signUpProviderTypeDropdown);
		providerType.selectByIndex(provType);
		Select healthPlan = new Select(signUpHealthPlanDropdown);
		healthPlan.selectByIndex(hp);
		signUpFirstName.sendKeys(firstNm);
		signUpLastName.sendKeys(lastNm);
		signUpEmail.sendKeys(email);
		signUpLocName.sendKeys(location);
		signUpNPI.sendKeys(npi);
		Select state = new Select(signUpStateDropdown);
		state.selectByValue("S10");
	}

	public boolean verifyRegisterPageLabels(String registrationLabel) {
		List<String> listFromUI = new ArrayList<String>();
		for (WebElement ele : registerDetails) {
			listFromUI.add(ele.getText());
		}
		return SeleniumMethods.compareListValues(listFromUI, registrationLabel);
	}

	public boolean verifyRegisterPageAddressLabels(String registrationAddressLabels) {
		List<String> listFromUI = new ArrayList<String>();
		listFromUI.add(addressLabel.getText());
		listFromUI.add(cityLabel.getText());
		listFromUI.add(stateLabel.getText());
		listFromUI.add(zipLabel.getText());
		listFromUI.add(phoneLabel.getText());
		listFromUI.add(faxLabel.getText());
		return SeleniumMethods.compareListValues(listFromUI, registrationAddressLabels);
	}

	public void clickSinguUplnk() {
		SeleniumMethods.shortwaitUntilElementIsClickable(btnSingUp);
		btnSingUp.click();
		log.info("Clicked on SignUp in 'SignUp EFT ERA' Page");
	}

	public boolean verifylnkEFTERACAQH() {
		SeleniumMethods.shortwaitUntilElementIsClickable(lnkEFTERACAQH);
		boolean flag = lnkEFTERACAQH.isDisplayed();
		String strText = lnkEFTERACAQH.getText().trim();
		if (flag) {
			log.info("Link Displayed is: {}", strText);
		}
		return flag;
	}

	public boolean verifylnkERAEnrollmentFAQ() {
		SeleniumMethods.shortwaitUntilElementIsClickable(lnkERAEnrollmentFAQ);
		boolean flag = lnkERAEnrollmentFAQ.isDisplayed();
		String strText = lnkERAEnrollmentFAQ.getText().trim();
		if (flag) {
			log.info("Displayed Link is: {}", strText);
		}
		return flag;
	}

	public void clicklnkERAEnrollmentFAQ() {
		SeleniumMethods.shortwaitUntilElementIsClickable(lnkERAEnrollmentFAQ);
		if (lnkERAEnrollmentFAQ.isDisplayed()) {
			lnkERAEnrollmentFAQ.click();
		}
	}

	public boolean clickEFTERACAQHVerifyCAQHRegisterisDisplayed() {
		SeleniumMethods.shortwaitUntilElementIsClickable(lnkEFTERACAQH);
		if (lnkEFTERACAQH.isDisplayed()) {
			lnkEFTERACAQH.click();
			SeleniumMethods.shortwaitUntilElementIsClickable(btnRegister);
		}
		return btnRegister.isDisplayed();
	}

	public void clicklnkERAPaperEnrollment() {
		SeleniumMethods.shortwaitUntilElementIsClickable(lnkERAPaperEnrollment);
		if (lnkERAPaperEnrollment.isDisplayed()) {
			lnkERAPaperEnrollment.click();
		}
	}

	public boolean verifyFileDownloaded(String fileName) {
		boolean flag = false;
		try {
			// wait is required to download the file
			Thread.sleep(3000);
			flag = SeleniumMethods.verifyDownloadedFileAndDelete(fileName);
		} catch (InterruptedException e) {
			log.info("Interrupted!", e);
			Thread.currentThread().interrupt();
		}

		return flag;
	}

	public boolean verifylnkERAPaperEnrollment() {
		SeleniumMethods.shortwaitUntilElementIsClickable(lnkERAPaperEnrollment);
		boolean flag = lnkERAPaperEnrollment.isDisplayed();
		String strText = lnkERAPaperEnrollment.getText().trim();
		if (flag) {
			log.info("Link Displayed: {}", strText);
		}
		return flag;
	}

	public void enterUserTypeDetails(String userType2, String portalProvdrType, String hplan) {
		SeleniumMethods.waitUntilElementIsClickable(signUpHealthPlanDropdown);
		SeleniumMethods.waitUntilElementIsClickable(signUpHealthPlanDropdown);
		Select userType1 = new Select(signUpUserTypeDropdown);
		userType1.selectByVisibleText(userType2);
		SeleniumMethods.waitUntilElementIsClickable(signUpProviderTypeDropdown);
		Select providerType1 = new Select(signUpProviderTypeDropdown);
		providerType1.selectByVisibleText(portalProvdrType);
		SeleniumMethods.waitUntilElementIsClickable(signUpHealthPlanDropdown);
		Select healthPln1 = new Select(signUpHealthPlanDropdown);
		healthPln1.selectByVisibleText(hplan);
	}

	public void enterUserContactDetails(String firstNm, String lastNm, String newEmail, String location, String npi) {
		signUpFirstName.sendKeys(firstNm);
		signUpLastName.sendKeys(lastNm);
		signUpEmail.sendKeys(newEmail);
		signUpLocName.sendKeys(location);
		signUpNPI.sendKeys(npi);
	}

	public void enterUserAddressDetails(String address, String city, String zip, String phone, String fax) {
		Select state = new Select(signUpStateDropdown);
		state.selectByValue("S10");
		signUpAddress.sendKeys(address);
		signUpCity.sendKeys(city);
		signUpZip.sendKeys(zip);
		signUpPhNum.sendKeys(phone);
		signUpFax.sendKeys(fax);
	}

}
