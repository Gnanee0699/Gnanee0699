package com.carecentrix.portal.pages;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.carecentrix.utilities.Constant;
import com.carecentrix.utilities.SeleniumMethods;

/**
 * @author KKJANAK
 *
 */

public class LocationPage {

	WebDriver driver;

	private static final Logger log = LogManager.getLogger(LocationPage.class);

	public LocationPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}

	@FindBy(xpath = "//span[@class='form-nav__title' and contains(text(),'Member Info.')]/following-sibling::span[@class='form-nav__caption']")
	WebElement memberInfoTabStatus;

	@FindBy(xpath = "//div[@class='form-nav__info']//span[@class='form-nav__title' and contains(text(),'Diagnosis')]//following-sibling::span[@class='form-nav__caption']")
	WebElement diagnosisTabStatus;

	@FindBy(xpath = "//span[@class='form-nav__title' and contains(text(),'Services')]//following-sibling::span[@class='form-nav__caption']")
	WebElement servicesTabStatus;

	@FindBy(xpath = "//div[@class='form-nav__info']//span[@class='form-nav__title' and contains(text(),'Physician')]//following-sibling::span[@class='form-nav__caption']")
	WebElement physicianTabStatus;

	@FindBy(xpath = "//div[@class='form-nav__info']//span[@class='form-nav__title' and contains(text(),'Rendering Prov.')]//following-sibling::span[@class='form-nav__caption']")
	WebElement renderingTabStatus;

	@FindBy(xpath = "//div[@class='form-nav css-1dxxh68']//button[1]")
	WebElement memberInfoTabBtn;

	@FindBy(xpath = "//div[@class='form-nav css-1dxxh68']//button[2]")
	WebElement diagnosisTabBtn;

	@FindBy(xpath = "//div[@class='form-nav css-1dxxh68']//button[3]")
	WebElement servicesTabBtn;

	@FindBy(xpath = "//div[@class='form-nav css-1dxxh68']//button[4]")
	WebElement physicianTabBtn;

	@FindBy(xpath = "//div[@class='form-nav css-1dxxh68']//button[5]")
	WebElement renderingTabBtn;

	@FindBy(xpath = "//div[contains(@aria-labelledby,'4')]//button[@class='css-1gjyy8']")
	WebElement locationTabAddLocationButton;

	@FindBy(xpath = "//div[contains(@aria-labelledby,'4')]/section[2]//input[@class='css-rac5bx']")
	WebElement locationTabInputCity;

	@FindBy(xpath = "//*[@id='react-select-6-input']")
	WebElement locationTabInputState;

	@FindBy(xpath = "//div[@class='form-nav css-1dxxh68']//button[5]//span[contains(text(),'Not completed')]")
	WebElement locationTabTableAvailable;

	//UI changes incorporated.
	@FindBy(xpath = "//button[normalize-space()='Select']")
	//@FindBy(xpath = "//button[@class='css-1y02vpj' and contains(text(),'select')]")
	WebElement locationTabSelectButton;
	
//		@FindBy(xpath = "//div[@id='panel:8-4']//button[@type='button'][normalize-space()='Save & Continue']")
	@FindBy(xpath = "(//button[@type='button'][normalize-space()='Save & Continue'])[4]")
	WebElement locationTabNextButton;

	@FindBy(xpath = "//section[2]/div[2]/table/tbody/tr[1]/td[6]/div/button/span")
	WebElement isSelected;

	@FindBy(xpath = "//div[contains(@aria-labelledby,'4')]/section[2]//table//tbody/tr")
	List<WebElement> locationTabTableRows;

	@FindBy(xpath = "//div[contains(@aria-labelledby,'4')]/section[2]//table/tbody/tr[1]/td")
	List<WebElement> locationTabTableData;

	@FindBy(xpath = "//section[@class='modal css-4b0q2m']//div[@class='modal-content']")
	WebElement clinicalTemplatePage;

	@FindBy(xpath = "//*[@id='patient_discharge_hospital']/div[1]/label/div[1]")
	WebElement locationTabPatientDischargeHospitalYes;

	@FindBy(xpath = "//*[@id='patient_discharge_home']/div[1]/label/div[1]")
	WebElement locationTabPatientDischargeHomeYes;

	@FindBy(xpath = "//*[@id='skill_request']/div[1]/label/div[1]")
	WebElement locationTabSkillRequestYes;

	@FindBy(xpath = "//div[contains(text(),'Wound Care')]//preceding-sibling::div[@class='css-cabb4f']/span")
	WebElement locationTabNursingIntervention;

	@FindBy(xpath = "//*[@id='therapy_interventions']/div[1]/label/div[1]")
	WebElement locationTabTherapyInterventionsPT;

	@FindBy(xpath = "//*[@id='detail_predictible_time']/div[1]/label/div[1]")
	WebElement locationTabDetailPredictibleTimeYes;

	@FindBy(xpath = "//*[@id='therapy_last_hours']/div[1]/label/div[1]")
	WebElement locationTabTherapyLastHoursYes;

	@FindBy(xpath = "//button[@class='css-kn4whn']")
	WebElement locationTabClinicalTemplateSubmit;

	//@FindBy(xpath = "//*//section[2]//form//div[1]//div[4]//div[@class=' css-1wa3eu0-placeholder']")
	@FindBy(xpath = "//div[@class=' css-1wa3eu0-placeholder' and contains(text(),'State')]")
	WebElement renderingTabDropdownClick;

//	@FindBy(xpath = "//div[@class=' css-26l3qy-menu']//div[@class=' css-11unzgr']//div")
	@FindBy(xpath = "//div[@class=' css-26l3qy-menu']")
	List<WebElement> renderingTabDropdown;

	boolean isLocationTabAvailable = false;
	boolean isSearchResultDisplayed = false;
	int rowCount;

	public boolean isLocationTabAvailable() {

		String memberStatus = SeleniumMethods.isCompleted(memberInfoTabBtn, memberInfoTabStatus);
		String diagStatus = SeleniumMethods.isCompleted(diagnosisTabBtn, diagnosisTabStatus);
		String serStatus = SeleniumMethods.isCompleted(servicesTabBtn, servicesTabStatus);
		String phyStatus = SeleniumMethods.isCompleted(physicianTabBtn, physicianTabStatus);

		if (memberStatus.equalsIgnoreCase(Constant.STATUS_COMPLETED)
				&& diagStatus.equalsIgnoreCase(Constant.STATUS_COMPLETED)
				&& serStatus.equalsIgnoreCase(Constant.STATUS_COMPLETED)
				&& phyStatus.equalsIgnoreCase(Constant.STATUS_COMPLETED)) {
			SeleniumMethods.longwaitUntilClickable(renderingTabBtn);
			SeleniumMethods.javaScriptExecutorClick(renderingTabBtn);
			SeleniumMethods.longwaitUntilClickable(renderingTabBtn);
			log.info("Location Tab Status is **** {}", renderingTabStatus.getText());
			if (renderingTabStatus.getText().equalsIgnoreCase(Constant.STATUS_NOTCOMPLETED)) {
				isLocationTabAvailable = true;
			}
		}

		return isLocationTabAvailable;
	}

	public boolean isAddLocationButtonEnabled() {
		return (isLocationTabAvailable() && locationTabAddLocationButton.isDisplayed());
	}

	public void selectLocationFromResult() {
		SeleniumMethods.longwaitUntilElementIsClickable(locationTabTableAvailable);
		rowCount = locationTabTableRows.size();
		if (rowCount > 0 && !locationTabTableData.isEmpty()) {
			for (WebElement webElement_tr : locationTabTableRows) {
				for (WebElement webElement_td : locationTabTableData) {
					if (webElement_td.getText().equalsIgnoreCase(Constant.TXT_SELECT)) {
						SeleniumMethods.javaScriptExecutorClick(locationTabSelectButton);
						log.info("Click  Select Button {}", webElement_td.getText());
						log.info("Option Selected");
						break;
					}
				}
			}
		} else
			log.info("No Results Found");
	}

	public void clickNextButtonInLocationTab() {
		if (locationTabNextButton.isDisplayed()) {
			locationTabNextButton.click();
					}
	}

	public boolean isSearchResultDisplayed() {
		rowCount = locationTabTableRows.size();
		log.info("Physician search result table size is {}", rowCount);
		if (rowCount > 0 && !locationTabTableData.isEmpty()) {
			isSearchResultDisplayed = true;
		} else {
			isSearchResultDisplayed = false;
			log.info("No Results Found");
		}
		return isSearchResultDisplayed;

	}

	public void fillClinicalTemplate() {
		if (clinicalTemplatePage.isDisplayed()) {
			SeleniumMethods.longwaitUntilElementIsClickable(locationTabPatientDischargeHospitalYes);
			locationTabPatientDischargeHospitalYes.click();
			locationTabPatientDischargeHomeYes.click();
			locationTabSkillRequestYes.click();
			locationTabNursingIntervention.click();
			locationTabTherapyInterventionsPT.click();
			locationTabDetailPredictibleTimeYes.click();
			locationTabTherapyLastHoursYes.click();
			locationTabClinicalTemplateSubmit.click();
		}
	}

	public boolean verifyStateDropdownPresent() {
		SeleniumMethods.shortwaitUntilElementIsClickable(renderingTabDropdownClick);
		return renderingTabDropdownClick.isDisplayed();
	}

	public void clickStateDropdown() {
		SeleniumMethods.waitUntilElementIsClickable(renderingTabDropdownClick);
		renderingTabDropdownClick.click();
	}

	List<String> renderingPageStateList = new ArrayList<String>();

	public boolean verifyStateListPresent() {
		boolean isStateListPresent = false;
		for (WebElement dd_list : renderingTabDropdown) {
			if (!dd_list.getText().isEmpty()) {
				isStateListPresent = true;
				renderingPageStateList.add(dd_list.getText());
			}
		}
		log.info("State Drop Down size is: {} and list is {}", renderingPageStateList.size(), renderingPageStateList);
		return isStateListPresent;
	}

	public boolean verifyStateListSortorder() {
		SeleniumMethods.waitUntilElementIsClickable(renderingTabDropdownClick);
		return SeleniumMethods.isCollectionSorted(renderingTabDropdown);
	}

	public boolean checkStateDropdownvalues(String renderingStateList) {
		SeleniumMethods.waitUntilElementIsClickable(renderingTabDropdownClick);
		return SeleniumMethods.checkStateDropdownvalues(renderingTabDropdown, renderingStateList);
	}

}
