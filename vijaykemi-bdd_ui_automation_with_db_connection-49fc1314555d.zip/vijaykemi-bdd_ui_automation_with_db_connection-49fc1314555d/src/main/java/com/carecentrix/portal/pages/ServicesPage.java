package com.carecentrix.portal.pages;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.carecentrix.utilities.Constant;
import com.carecentrix.utilities.SeleniumMethods;

import net.thucydides.core.annotations.findby.By;

/**
 * @author KKJANAK
 *
 */

public class ServicesPage {

	WebDriver driver;

	private static final Logger log = LogManager.getLogger(ServicesPage.class);

	public ServicesPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}

	int rowCount;

	@FindBy(xpath = "//span[@class='form-nav__title' and contains(text(),'Member Info.')]/following-sibling::span[@class='form-nav__caption']")
	WebElement memberInfoTabStatus;

	@FindBy(xpath = "//div[@class='form-nav__info']//span[@class='form-nav__title' and contains(text(),'Diagnosis')]//following-sibling::span[@class='form-nav__caption']")
	WebElement diagnosisTabStatus;

	@FindBy(xpath = "//div[contains(@class,'css-1g6gooi')]//input[@id='react-select-4-input']")
	WebElement servicesDDFocus;

	@FindBy(xpath = "//button[contains(@class,'search-btn css-1lvde2m')]")
	WebElement servicesDDSearchButton;

	@FindBy(xpath = "//table[contains(@class,'table-content fade-in')]//tr[1]//button[@class='css-1y02vpj' and contains(text(),'Select')]")
	WebElement selectServiceFromResult;

	@FindBy(xpath = "//input[contains(@id,'react-select-8-input')]")
	WebElement serviceRequestType;

	@FindBy(xpath = "//form[@class='service-details']//input[@class=' css-rac5bx']")
	WebElement serviceRequestStartDateInput;

	@FindBy(xpath = "//*[@id='QID3']/div[1]/label/div[1]")
	WebElement serviceInitiated_Yes;

	@FindBy(xpath = "//*[@id='QID3']/div[2]/label/div[1]")
	WebElement serviceInitiated_No;

	@FindBy(xpath = "//*[@id='QID4']/div[1]/label/div[1]")
	WebElement physicianOrder_Yes;

	@FindBy(xpath = "//*[@id='QID4']/div[2]/label/div[1]")
	WebElement physicianOrder_No;

	@FindBy(xpath = "//*[@id='QID5']/div[1]/label/div[1]")
	WebElement dischargingFacitlity_Yes;

	@FindBy(xpath = "//*[@id='QID5']/div[2]/label/div[1]")
	WebElement dischargingFacitlity_No;

	//@FindBy(xpath = "//div[@class='modal-content']")
	@FindBy(xpath = "//div[contains(@class,'modal-content')]")
	WebElement dischargeFacilityDetailsPage;

	@FindBy(xpath = "//button[@class='modal-content__close']")
	WebElement dischargeFacilityDetails_close;

	@FindBy(xpath = "//div[contains(@class,'modal-content')]")
	WebElement dischargeFacilityPage;

	@FindBy(xpath = "//section[@class='search facilities']//input[@name='npi']")
	WebElement services_npi;

	@FindBy(xpath = "//section[@class='search facilities']//input[@name='zipCode']")
	WebElement services_zipCode;
	
	@FindBy(xpath = "//section[@class='search facilities']//input[@name='facilityName']")
	WebElement services_name;
	
	@FindBy(xpath = "//section[@class='search facilities']//input[@name='city']")
	WebElement services_city;
	
//	@FindBy(xpath = "//section[@class='search facilities']//input[@name='state']")
	@FindBy(xpath = "//section[@role='dialog']//section//div//div[contains(text(),'State')]")
	WebElement services_state;

//	@FindBy(xpath = "//div[contains(@class, 'modal-content')]//button[@class='search-btn css-1lvde2m']")
	@FindBy(xpath = "(//button[@type='submit'])[7]")
	WebElement dischargeFacility_search;

	//@FindBy(xpath = "//tr[1]//button[@class='css-1y02vpj' and contains(text(),'Select')]")
	@FindBy(xpath = "(//button[@type='button'][normalize-space()='Select'])[2]")
	WebElement dischargeFacility_select;

	//@FindBy(xpath = "//div[@class='modal-content']//table[@class='table-content fade-in']")
//	@FindBy(xpath = "//div[contains(@class, 'modal-content')]//table[contains(@class,'table-content fade-in')]")
	@FindBy(xpath = "//section[@role='dialog']//section//div//table[@role='table']")
	WebElement dischargeFacilityResultTable;

	@FindBy(xpath = "//label[contains(text(),'Facility admit date')]//following::div[1]//input[1]")
	WebElement dischargeFacility_admitDate;

	@FindBy(xpath = "//label[contains(text(),'Facility Discharge Date')]//following::div[1]//input[1]")
	WebElement dischargeFacility_dischargeDate;

	@FindBy(xpath = "//button[normalize-space()='Next']")
	WebElement dischargeFacility_next;

	//@FindBy(xpath = "//*[@id='panel:1-2']//div[@class='facility-info']")
	@FindBy(xpath = "//button[@type='submit'][normalize-space()='Save & Continue']")
	WebElement dischargeFacility_selected;

	@FindBy(xpath = "//section[@class='search facilities']//th[1]")
	WebElement dischargeFacility_locationName;

	@FindBy(xpath = "//section[@class='search facilities']//th[2]")
	WebElement dischargeFacility_address;

	@FindBy(xpath = "//section[@class='search facilities']//th[3]")
	WebElement dischargeFacility_city;

	@FindBy(xpath = "//section[@class='search facilities']//th[4]")
	WebElement dischargeFacility_state;

	@FindBy(xpath = "//section[@class='search facilities']//th[5]")
	WebElement dischargeFacility_contactPhone;

	@FindBy(xpath = "//span[@class='form-nav__title' and contains(text(),'Diagnosis')]//following-sibling::span[@class='form-nav__caption']")
	WebElement status_Diagnosis;

	@FindBy(xpath = "//span[@class='form-nav__title' and contains(text(),'Services')]//following-sibling::span[@class='form-nav__caption']")
	WebElement status_Services;

	@FindBy(xpath = "//section[@class='search facilities']//input[@name='city']")
	WebElement dischargeFacility_Inputcity;

	@FindBy(xpath = "//section[@class='search facilities']//input[@id='react-select-10-input']")
	WebElement dischargeFacility_InputState;

	@FindBy(xpath = "//*[@id='panel:1-2']//div[@class=' css-107lb6w-singleValue']")
	WebElement serviceRequestType_urgent;

	@FindBy(xpath = "//*[@id='panel:1-2']/section[2]/table/tbody/tr")
	List<WebElement> services_tableRow;

	@FindBy(xpath = "//*[@id='panel:1-2']/section[2]/table/tbody/tr/td")
	List<WebElement> services_tableData;

//	@FindBy(xpath = "//button[@class='next-btn mt-24 css-giff87']")
//	@FindBy(xpath = "//button[@type='submit'][normalize-space()='Save & Continue']")
	@FindBy(xpath = "(//button[@type='button'][normalize-space()='Save & Continue'])[2]")
	WebElement servicesTabNextButton;
	
	@FindBy(xpath = "//button[normalize-space()='Next']")
	WebElement Does_the_patient_have_acute_hospital_needs_nextbutton;
	
	@FindBy(xpath = "(//button[normalize-space()='Next'])[1]")
	WebElement Does_the_patient_have_intense_and_complex_care_needs_that_make_skilled_nursing_facility_care;

	@FindBy(xpath = "(//button[normalize-space()='Next'])[1]")
	WebElement Does_the_care_include_multiple_components_delivered_by_skilled_professionals;

	@FindBy(xpath = "(//button[normalize-space()='Next'])[1]")
	WebElement Is_there_a_plan_to_provide_ALL_of_the_following;
	
	@FindBy(xpath = "(//button[normalize-space()='Next'])[1]")
	WebElement Is_skilled_treatment_needed_daily_or_more_frequent;
	
	@FindBy(xpath = "(//button[normalize-space()='Next'])[1]")
	WebElement Do_you_have_clinical_documentation_to_support_this_request;
	
	@FindBy(xpath = "(//button[@type='button'][normalize-space()='Save'])[2]")
	WebElement clinicaltemplatesavebtn;
	
	
	//@FindBy(xpath = "//div[@class='modal-content']//input[@name='facilityName']")
	@FindBy(xpath = "//div[contains(@class,'modal-content')]//input[@name='facilityName']")
	WebElement dischargingFacilityName;

	@FindBy(xpath = "//div[contains(@class,'modal-content')]//input[@name='npi']")
	WebElement dischargingFacilityNPI;

	@FindBy(xpath = "//div[contains(@class,'modal-content')]//input[@name='zipCode']")
	WebElement dischargingFacilityZipCode;

	@FindBy(xpath = "//div[contains(@class,'modal-content')]//input[@name='city']")
	WebElement dischargingFacilityCity;

	@FindBy(xpath = "*//input[contains(@id,'react-select-9-input')]")
	WebElement dischargingFacilityState;

	@FindBy(xpath = "//div[@class='push-half--bottom']//span")
	WebElement dischargingFacilitySearchCriteriaMessage;

	//@FindBy(xpath = "//div[@class='modal-content']//div[@class='empty-state__content']")
	@FindBy(xpath = "//div[contains(@class,'modal-content')]//div[@class='empty-state__content']")
	WebElement servicesTabDischargePageErrorMessage;

	@FindBy(xpath = "//div[contains(@class,'modal-content')]//div[@class='empty-state__content']//span[1]")
	WebElement servicesTabDischargePageErrorMessageContent1;

	@FindBy(xpath = "//div[contains(@class,'modal-content')]//div[@class='empty-state__content']//span[2]")
	WebElement servicesTabDischargePageErrorMessageContent2;

	@FindBy(xpath = "//div[contains(@class,'modal-content')]//div[@class=' css-1wa3eu0-placeholder']")
	WebElement servicesDischargePageDropdownClick;

	@FindBy(xpath = "//div[@class=' css-26l3qy-menu']//div[@class=' css-11unzgr']//div")
	List<WebElement> servicesTabDischargePageDropdown;

	@FindBy(xpath = "//div[@class='form-nav css-1dxxh68']//button[3]")
	WebElement servicesTab;

	@FindBy(xpath = "//button[@class='edit-facility css-177pep5']")
	WebElement editDischarginFacilityBtn;

	@FindBy(xpath = "//*[@id='layout']/section[2]/div/div[1]//button[1]")
	WebElement memberInfoTabBtn;

	@FindBy(xpath = "//*[@id='layout']/section[2]/div/div[1]//button[2]")
	WebElement diagnosisTabBtn;

	@FindBy(xpath = "//*[@id='layout']/section[2]/div/div[1]//button[3]")
	WebElement servicesTabBtn;

	@FindBy(xpath = "//span[@class='form-nav__title' and contains(text(),'Services')]//following-sibling::span[@class='form-nav__caption']")
	WebElement servicesTabStatus;
	
	@FindBy(xpath = "(//div[@type='radio'])[7]")
	WebElement Does_the_patient_have_acute_hospital_needs_Ans_Yes;
	
	@FindBy(xpath = "(//div[@type='radio'])[8]")
	WebElement Does_the_patient_have_acute_hospital_needs_Ans_No;
	
	@FindBy(xpath = "(//span)[85]")
	WebElement Does_the_patient_have_intense_and_complex_care_needs_that_make_skilled_nursing_facility_care_Yes;

	@FindBy(xpath = "(//span)[86]")
	WebElement Does_the_patient_have_intense_and_complex_care_needs_that_make_skilled_nursing_facility_care_No;

	@FindBy(xpath = "(//span)[84]")
	WebElement Does_the_patient_have_intense_and_complex_care_needs_that_make_skilled_nursing_facility_care_16556_Yes;

	@FindBy(xpath = "(//span)[85]")
	WebElement Does_the_patient_have_intense_and_complex_care_needs_that_make_skilled_nursing_facility_care_16556_No;
	
	@FindBy(xpath = "(//span)[85]")
	WebElement Does_the_care_include_multiple_components_delivered_by_skilled_professionals_Yes;

	@FindBy(xpath = "(//span)[86]")
	WebElement Does_the_care_include_multiple_components_delivered_by_skilled_professionals_No;
	
	@FindBy(xpath = "(//span)[84]")
	WebElement Does_the_care_include_multiple_components_delivered_by_skilled_professionals_Yes_16556_Yes;

	@FindBy(xpath = "(//span)[85]")
	WebElement Does_the_care_include_multiple_components_delivered_by_skilled_professionals_No_16556_Yes;
	
//	@FindBy(xpath = "(//span)[85]")
	@FindBy(xpath = "//div[@data-focus-lock-disabled='false']//label[1]//div[1]//span[1]")
	WebElement Is_there_a_plan_to_provide_ALL_of_the_following_Yes;

	@FindBy(xpath = "(//span)[86]")
	WebElement Is_there_a_plan_to_provide_ALL_of_the_following_No;
	
	@FindBy(xpath = "(//span)[84]")
	WebElement Is_there_a_plan_to_provide_ALL_of_the_following_For_16556_Yes;

	@FindBy(xpath = "(//span)[85]")
	WebElement Is_there_a_plan_to_provide_ALL_of_the_following_For_16556_No;
	
	@FindBy(xpath = "//div[@data-focus-lock-disabled='false']//label[1]//div[1]//span[1]")
	WebElement Is_skilled_treatment_needed_daily_or_more_frequent_Yes;

	@FindBy(xpath = "(//span)[86]")
	WebElement Is_skilled_treatment_needed_daily_or_more_frequent_No;
	
	@FindBy(xpath = "(//span)[84]")
	WebElement Is_skilled_treatment_needed_daily_or_more_frequent_For_16556_Yes;

	@FindBy(xpath = "(//span)[85]")
	WebElement Is_skilled_treatment_needed_daily_or_more_frequent_For_16556_No;
	
	@FindBy(xpath = "(//*[name()='svg'][@role='presentation'])[1]")
	WebElement What_type_of_skilled_treatments_are_needed_Nursing;
	
	@FindBy(xpath = "(//div[contains(text(),'Nursing')])[2]")
	WebElement Answer_Nursing;

	@FindBy(xpath = "(//*[name()='svg'][@role='presentation'])[2]")
	WebElement What_type_of_skilled_treatments_are_needed_Therapy;
	
	@FindBy(xpath = "(//*[name()='svg'][@role='presentation'])[1]")
	WebElement What_are_the_nursing_interventions_being_requested_InsulinRegimen;

	@FindBy(xpath = "//div[contains(text(),'Infusion/Injection')]")
	WebElement Answer_Infusion_Injection;

	
	@FindBy(xpath = "(//span)[85]")
	WebElement Do_you_have_clinical_documentation_to_support_this_request_YesDocAttach;
	
	boolean isServicesTabAvailable = false;
	boolean isServiceDetailsDisplayed = false;

	public boolean isServicesTabAvailable() {
		SeleniumMethods.waitUntilClickable(memberInfoTabBtn);
		SeleniumMethods.javaScriptExecutorClick(memberInfoTabBtn);
		String memberInfoStatus = "";
		if (memberInfoTabStatus.isDisplayed())
			memberInfoStatus = memberInfoTabStatus.getText();
		SeleniumMethods.waitUntilClickable(diagnosisTabBtn);
		SeleniumMethods.javaScriptExecutorClick(diagnosisTabBtn);
		String diagnosisStatus = "";
		if (diagnosisTabStatus.isDisplayed())
			diagnosisStatus = diagnosisTabStatus.getText();
		if (servicesTabStatus.isDisplayed()) {
			SeleniumMethods.longwaitUntilClickable(servicesTabBtn);
			SeleniumMethods.javaScriptExecutorClick(servicesTabBtn);
			SeleniumMethods.longwaitUntilClickable(servicesTabBtn);
			log.info("Services Tab Status is **** {}", servicesTabStatus.getText());
			if (servicesTabStatus.getText().equalsIgnoreCase(Constant.STATUS_NOTCOMPLETED)) {
				isServicesTabAvailable = true;
			}
		}
		log.info("isServicesTabAvailable {}", isServicesTabAvailable);
		return isServicesTabAvailable;
	}

	public boolean clickServicesDropDown() {
		boolean servicesDropDownClicked = false;
		if (isServicesTabAvailable()) {
			SeleniumMethods.longwaitUntilElementIsClickable(servicesDDFocus);
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("arguments[0].click()", servicesDDFocus);
			log.info("Service Drobdown clicked");
			servicesDropDownClicked = true;
		}
		return servicesDropDownClicked;
	}

	public void selectSerivces(String selectService, String skilledNursingFacility,
			String inpatientRehabilitationFacility, String longTermAcuteCare) {
		if (selectService.equalsIgnoreCase(skilledNursingFacility)) {
			selectSpecificService(skilledNursingFacility);
		} else if (selectService.equalsIgnoreCase(inpatientRehabilitationFacility)) {
			selectSpecificService(inpatientRehabilitationFacility);
		} else if (selectService.equalsIgnoreCase(longTermAcuteCare)) {
			selectSpecificService(longTermAcuteCare);
		} else {
			log.info("New option added in Services Page");
		}
	}

	public void selectSpecificService(String serviceName) {
		SeleniumMethods.waitUntilElementIsClickable(servicesDDFocus);
		SeleniumMethods.javaScriptExecutorClick(servicesDDFocus);
		servicesDDFocus.sendKeys(serviceName);
		servicesDDFocus.sendKeys(Keys.TAB);
	}

	public void clickSearchButton() {
		try {
			Thread.sleep(500);
			servicesDDSearchButton.click();
		} catch (InterruptedException e) {
			log.info("Interrupted!", e);
			Thread.currentThread().interrupt();
		}
	}

	public boolean isUserCanSelectService() {
		return isServicesTabAvailable();
	}

	public void quitBrowser() {
		SeleniumMethods.quitDriver();
		log.info("Browser closed successfully");
	}

	public void refreshBrowser() {
		SeleniumMethods.refreshPage();
		log.info("Browser is refreshed successfully");
	}

	public void selectServiceFromList() {
		SeleniumMethods.waitUntilElementIsClickable(selectServiceFromResult);
		selectServiceFromResult.click();
		log.info("Selected Service from list");
	}

	public void selectDoes_the_patient_have_acute_hospital_needs(String Ans_Doestpathavacuhosneeds) throws InterruptedException {
		SeleniumMethods.waitUntilElementIsClickable(Does_the_patient_have_acute_hospital_needs_Ans_Yes);
		Thread.sleep(500);
		Does_the_patient_have_acute_hospital_needs_Ans_Yes.click();
		log.info("Does_the_patient_have_acute_hospital_needs : Yes selected");
	}
	
	public void selectclinicaltemplateDoes_the_patient_have_intense_and_complex_care_needs_that_make_skilled_nursing_facility_care(String Ans_DoestpathavensecomcathamakeSkilnursfaccare) throws InterruptedException {
		SeleniumMethods.waitUntilElementIsClickable(Does_the_patient_have_intense_and_complex_care_needs_that_make_skilled_nursing_facility_care_Yes);
		Thread.sleep(500);
		Does_the_patient_have_intense_and_complex_care_needs_that_make_skilled_nursing_facility_care_Yes.click();
		log.info("Does_the_patient_have_intense_and_complex_care_needs_that_make_skilled_nursing_facility_care_Yes : Yes selected");
	}
	
	public void selectclinicaltemplateDoes_the_patient_have_intense_and_complex_care_needs_that_make_skilled_nursing_facility_care_for_16556(String Ans_DoestpathavensecomcathamakeSkilnursfaccare) throws InterruptedException {
//		SeleniumMethods.waitUntilElementIsClickable(Does_the_patient_have_intense_and_complex_care_needs_that_make_skilled_nursing_facility_care_16556_Yes);
		Thread.sleep(2000);
		Does_the_patient_have_intense_and_complex_care_needs_that_make_skilled_nursing_facility_care_16556_Yes.click();
		log.info("Does_the_patient_have_intense_and_complex_care_needs_that_make_skilled_nursing_facility_care_16556_Yes : Yes selected");
	}
	
	public void selectclinicaltemplateDoes_the_care_include_multiple_components_delivered_by_skilled_professionals(String Ans_DoestpathavensecomcathamakeSkilnursfaccare) throws InterruptedException {
		SeleniumMethods.waitUntilElementIsClickable(Does_the_care_include_multiple_components_delivered_by_skilled_professionals_Yes);
		Thread.sleep(500);
		Does_the_care_include_multiple_components_delivered_by_skilled_professionals_Yes.click();
		log.info("Does_the_care_include_multiple_components_delivered_by_skilled_professionals_Yes : Yes selected");
	}
	
	public void selectclinicaltemplateDoes_the_care_include_multiple_components_delivered_by_skilled_professionals_for_16556(String Ans_DoestpathavensecomcathamakeSkilnursfaccare) throws InterruptedException {
//		SeleniumMethods.waitUntilElementIsClickable(Does_the_care_include_multiple_components_delivered_by_skilled_professionals_Yes);
		Thread.sleep(2000);
		Does_the_care_include_multiple_components_delivered_by_skilled_professionals_Yes_16556_Yes.click();
		log.info("Does_the_care_include_multiple_components_delivered_by_skilled_professionals_Yes_16556_Yes : Yes selected");
	}
	
	public void selectclinicaltemplateIs_there_a_plan_to_provide_ALL_of_the_following(String Ans_DoestpathavensecomcathamakeSkilnursfaccare) throws InterruptedException {
		SeleniumMethods.waitUntilElementIsClickable(Is_there_a_plan_to_provide_ALL_of_the_following_Yes);
		Thread.sleep(1500);
		Is_there_a_plan_to_provide_ALL_of_the_following_Yes.click();
		log.info("Is_there_a_plan_to_provide_ALL_of_the_following_Yes : Yes selected");
	}
	
	public void selectclinicaltemplateIs_there_a_plan_to_provide_ALL_of_the_following_For_16556(String Ans_DoestpathavensecomcathamakeSkilnursfaccare) throws InterruptedException {
//		SeleniumMethods.waitUntilElementIsClickable(Is_there_a_plan_to_provide_ALL_of_the_following_Yes);
		Thread.sleep(2000);
		Is_there_a_plan_to_provide_ALL_of_the_following_For_16556_Yes.click();
		log.info("Is_there_a_plan_to_provide_ALL_of_the_following_For_16556_Yes : Yes selected");
	}
	
	public void selectclinicaltemplateIs_skilled_treatment_needed_daily_or_more_frequent(String Ans_DoestpathavensecomcathamakeSkilnursfaccare) throws InterruptedException {
		SeleniumMethods.waitUntilElementIsClickable(Is_skilled_treatment_needed_daily_or_more_frequent_Yes);
		Thread.sleep(1500);
		Is_skilled_treatment_needed_daily_or_more_frequent_Yes.click();
		log.info("Is_skilled_treatment_needed_daily_or_more_frequent_Yes : Yes selected");
	}
	
	public void selectclinicaltemplateIs_skilled_treatment_needed_daily_or_more_frequent_For_16556(String Ans_DoestpathavensecomcathamakeSkilnursfaccare) throws InterruptedException {
//		SeleniumMethods.waitUntilElementIsClickable(Is_skilled_treatment_needed_daily_or_more_frequent_Yes);
		Thread.sleep(2000);
		Is_skilled_treatment_needed_daily_or_more_frequent_For_16556_Yes.click();
		log.info("Is_skilled_treatment_needed_daily_or_more_frequent_For_16556_Yes : Yes selected");
	}
	
	public void selectclinicaltemplateWhat_type_of_skilled_treatments_are_needed(String Ans_DoestpathavensecomcathamakeSkilnursfaccare) throws InterruptedException {
//		SeleniumMethods.waitUntilElementIsVisible(Answer_Nursing);
//		SeleniumMethods.waitUntilElementIsClickable(What_type_of_skilled_treatments_are_needed_Nursing);
		Thread.sleep(2000);
		What_type_of_skilled_treatments_are_needed_Nursing.click();
		log.info("What_type_of_skilled_treatments_are_needed_Nursing : Yes selected");
	}
	
	public void selectclinicaltemplateWhat_are_the_nursing_interventions_being_requested(String Ans_DoestpathavensecomcathamakeSkilnursfaccare) throws InterruptedException {
//		SeleniumMethods.waitUntilElementIsClickable(Answer_Infusion_Injection);
		Thread.sleep(2000);
		What_are_the_nursing_interventions_being_requested_InsulinRegimen.click();
		log.info("What_are_the_nursing_interventions_being_requested_InsulinRegimen selected");
	}
	
	public void selectclinicaltemplateDo_you_have_clinical_documentation_to_support_this_request(String Ans_DoestpathavensecomcathamakeSkilnursfaccare) throws InterruptedException {
//		SeleniumMethods.waitUntilElementIsClickable(Do_you_have_clinical_documentation_to_support_this_request_YesDocAttach);
		Thread.sleep(2000);
		Do_you_have_clinical_documentation_to_support_this_request_YesDocAttach.click();
		log.info("Do_you_have_clinical_documentation_to_support_this_request_YesDocAttach selected");
	}
	
	public void selectRequestType(String requestTypeOption) {
		switch (requestTypeOption) {
		case Constant.REQUEST_TYPE_ROUTINE: {
			clickRequestType(requestTypeOption);
			log.info("Request Type is {} selected", requestTypeOption);
			break;
		}
		case Constant.REQUEST_TYPE_URGENT: {
			clickRequestType(requestTypeOption);
			log.info("Request Type is {} selected", requestTypeOption);
			break;
		}
		default:
			log.info("Request Type is selected");
		}
	}

	public void clickRequestType(String requestTypeOption) {
		SeleniumMethods.waitUntilElementIsClickable(serviceRequestType);
		SeleniumMethods.javaScriptExecutorClick(serviceRequestType);
		try {
			Thread.sleep(500);
			serviceRequestType.sendKeys(requestTypeOption);
			serviceRequestType.sendKeys(Keys.TAB);
		} catch (InterruptedException e) {
			log.info("interruptted!", e);
			Thread.currentThread().interrupt();
		}
	}

	public void enterRequestStartDate(int Requeststartdate) {
		SeleniumMethods.waitUntilElementIsClickable(serviceRequestStartDateInput);
		//LocalDate today = LocalDate.now().plusDays(5);
		LocalDate today = LocalDate.now().plusDays(Requeststartdate);
		DateTimeFormatter pattern = DateTimeFormatter.ofPattern(Constant.DATE_FORMAT);
		serviceRequestStartDateInput.sendKeys(today.format(pattern));
	}

	public void isServiceInitiated(String serviceInitiated) {
		if (serviceInitiated.equalsIgnoreCase(Constant.OPTION_YES)) {
			SeleniumMethods.longwaitUntilElementIsVisible(serviceInitiated_Yes);
			SeleniumMethods.javaScriptExecutorScrollIntoView(serviceInitiated_Yes);
			serviceInitiated_Yes.click();
		} else if (serviceInitiated.equalsIgnoreCase(Constant.OPTION_NO)) {
			SeleniumMethods.longwaitUntilElementIsVisible(serviceInitiated_No);
			SeleniumMethods.javaScriptExecutorScrollIntoView(serviceInitiated_No);
			serviceInitiated_No.click();
		}
	}

	public void isPhysicianOrderSelected(String physicianOrderOption) {
		if (physicianOrderOption.equalsIgnoreCase(Constant.OPTION_YES)) {
			SeleniumMethods.scrollDown(physicianOrder_Yes);
			SeleniumMethods.longwaitUntilElementIsVisible(physicianOrder_Yes);
			physicianOrder_Yes.click();
		} else if (physicianOrderOption.equalsIgnoreCase(Constant.OPTION_NO)) {
			SeleniumMethods.scrollDown(physicianOrder_No);
			SeleniumMethods.longwaitUntilElementIsVisible(physicianOrder_No);
			physicianOrder_No.click();
		}
	}

	public void isDischargingFacilitySelected(String dischargingFacilityOption,String servicesCity, String servicesState) throws InterruptedException {
		if (dischargingFacilityOption.equalsIgnoreCase(Constant.OPTION_YES)) {
			SeleniumMethods.scrollDown(dischargingFacitlity_Yes);
			SeleniumMethods.longwaitUntilElementIsVisible(dischargingFacitlity_Yes);
			dischargingFacitlity_Yes.click();
			searchFacilityUsingCityandState(servicesCity, servicesState);
			selectDischargingFacility();
			chooseAdmitDateAndDischargeDate();
			isAdmitDateAndDischargeDateSelected();
			clickOnNext();
			
		} else if (dischargingFacilityOption.equalsIgnoreCase(Constant.OPTION_NO)) {
			SeleniumMethods.scrollDown(dischargingFacitlity_No);
			SeleniumMethods.longwaitUntilElementIsVisible(dischargingFacitlity_No);
			dischargingFacitlity_No.click();
		}
	}

	public boolean verifyDischargeFacilitySearchPage() {
		return dischargeFacilityPage.isDisplayed();
	}

	public void closeDischargeFecilitySearchPage() {
		log.info("In discharge search window");
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("arguments[0].click()", dischargeFacilityDetails_close);
		log.info("Discharge facility search Window is closed");
	}

	public void searchFacilityUsingNPIAndZipCode(String servicesNPI, String servicesZipCode) {
		if (dischargeFacilityPage.isDisplayed()) {
			SeleniumMethods.waitUntilElementIsClickable(services_npi);
			SeleniumMethods.waitUntilElementIsClickable(services_zipCode);
			SeleniumMethods.waitUntilElementIsClickable(dischargeFacility_search);
			services_npi.sendKeys(servicesNPI);
			services_zipCode.sendKeys(servicesZipCode);
			dischargeFacility_search.click();
			SeleniumMethods.waitUntilElementIsClickable(dischargeFacilityResultTable);
		}

	}
	
	public void searchFacilityUsingCityandState(String servicesCity, String servicesState) throws InterruptedException {
		if (dischargeFacilityPage.isDisplayed()) {
			SeleniumMethods.waitUntilElementIsClickable(services_city);

			
			services_city.sendKeys(servicesCity);
			driver.findElement(By.xpath("//body/div/div[@data-focus-lock-disabled='false']/div/section[@role='dialog']/div/section/div/form/div/div/div/div[@role='group']/div/div/div[1]")).click();;
			driver.findElement(By.xpath("//body//div//div[26]")).click();
			dischargeFacility_search.click();
			SeleniumMethods.waitUntilElementIsClickable(dischargeFacilityResultTable);
		}

	}
	
	public void searchFacilityUsingNPIAndName(String servicesNPI, String servicesName) {
		if (dischargeFacilityPage.isDisplayed()) {
			SeleniumMethods.waitUntilElementIsClickable(services_npi);
			SeleniumMethods.waitUntilElementIsClickable(services_name);
			SeleniumMethods.waitUntilElementIsClickable(dischargeFacility_search);
			services_npi.sendKeys(servicesNPI);
			services_name.sendKeys(servicesName);
			dischargeFacility_search.click();
			SeleniumMethods.waitUntilElementIsClickable(dischargeFacilityResultTable);
		}

	}

	public void selectDischargingFacility() {
		SeleniumMethods.longwaitUntilElementIsVisible(dischargeFacilityResultTable);
		if (dischargeFacilityPage.isDisplayed() && dischargeFacilityResultTable.isDisplayed()) {
			dischargeFacility_select.click();
		}
	}

	public void chooseAdmitDateAndDischargeDate() {
		if (dischargeFacilityPage.isDisplayed() && dischargeFacilityResultTable.isDisplayed()) {
			SeleniumMethods.waitUntilElementIsClickable(dischargeFacility_admitDate);
			SeleniumMethods.waitUntilElementIsClickable(dischargeFacility_dischargeDate);
			dischargeFacility_admitDate.click();
			dischargeFacility_admitDate.sendKeys(getcurrentDate());
			dischargeFacility_admitDate.sendKeys(Keys.TAB);
			dischargeFacility_dischargeDate.click();
			dischargeFacility_dischargeDate.sendKeys(getcurrentDate());
			dischargeFacility_dischargeDate.sendKeys(Keys.ENTER);
		}
	}

	public boolean isAdmitDateAndDischargeDateSelected() {
		log.info("dischargeFacility_admitDate {} dischargeFacility_dischargeDate {}  ",
				dischargeFacility_admitDate.getAttribute(Constant.VALUE),
				dischargeFacility_dischargeDate.getAttribute(Constant.VALUE));
		return (!dischargeFacility_admitDate.getAttribute(Constant.VALUE).isEmpty()
				&& !dischargeFacility_dischargeDate.getAttribute(Constant.VALUE).isEmpty());
	}

	public void clickOnNext() {
		SeleniumMethods.waitUntilElementIsClickable(dischargeFacility_next);
		if (dischargeFacilityPage.isDisplayed() && dischargeFacilityResultTable.isDisplayed()) {
			dischargeFacility_next.click();
			SeleniumMethods.waitUntilElementIsClickable(dischargeFacility_selected);
		}
	}

	public String getcurrentDate() {
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date date = new Date();
		return dateFormat.format(date);
	}

	public boolean isFacilitySelected() {
		return dischargeFacility_selected.isDisplayed();
	}

	public boolean isRequiredFieldsDisplayed() {
		boolean isRequiredFieldsDisplayed = false;
		if (dischargeFacilityPage.isDisplayed() && dischargeFacilityResultTable.isDisplayed()) {
			if (dischargeFacility_locationName.isDisplayed() && dischargeFacility_address.isDisplayed()
					&& dischargeFacility_city.isDisplayed() && dischargeFacility_state.isDisplayed()
					&& dischargeFacility_contactPhone.isDisplayed())
				isRequiredFieldsDisplayed = true;
			else
				isRequiredFieldsDisplayed = false;
		}
		return isRequiredFieldsDisplayed;
	}

	public boolean isRequestTypeChanged() {
		return (serviceRequestType_urgent.isDisplayed()
				&& serviceRequestType_urgent.getText().equalsIgnoreCase(Constant.REQUEST_TYPE_URGENT));
	}

	public boolean isRequestTypeNotEnabled() {
		return !serviceRequestType.isEnabled();
	}

	public void searchFacilityUsingCityAndState(String physicianCity, String physicianState) {
		if (dischargeFacilityPage.isDisplayed()) {
			SeleniumMethods.waitUntilElementIsClickable(dischargeFacility_Inputcity);
			SeleniumMethods.waitUntilElementIsClickable(dischargeFacility_InputState);
			SeleniumMethods.waitUntilElementIsClickable(dischargeFacility_search);
			dischargeFacility_Inputcity.sendKeys(physicianCity);
			SeleniumMethods.javaScriptExecutorClick(dischargeFacility_InputState);
			dischargeFacility_InputState.sendKeys(physicianState);
			dischargeFacility_InputState.sendKeys(Keys.TAB);
			dischargeFacility_search.click();
			SeleniumMethods.waitUntilElementIsClickable(dischargeFacilityResultTable);
		}
	}

	public boolean isServiceDetailsDisplayed(String serviceType, String skilledNursingFacility,
			String inpatientRehabilitationFacility, String longTermAcuteCare, String skilledNursingFacilityRevCode,
			String skilledNursingFacilityDesc, String inpatientRehabilitationFacilityRevCode,
			String inpatientRehabilitationFacilityDesc, String longTermAcuteCareRevCode, String longTermAcuteCareDesc) {

		rowCount = services_tableRow.size();
		log.info("Services search result table size is {} ", rowCount);
		if (rowCount > 0 && !services_tableData.isEmpty()) {
			for (WebElement webElement_tr : services_tableRow) {
				for (WebElement webElement_td : services_tableData) {
					log.info("webElement_td.getText  {}", services_tableData.get(1).getText());
					log.info("webElement_td  {}", webElement_td);
					if (webElement_td.getText().equalsIgnoreCase(serviceType)
							&& webElement_td.getText().equalsIgnoreCase(skilledNursingFacility)) {
						if (services_tableData.get(1).getText().equalsIgnoreCase(skilledNursingFacilityRevCode)
								&& services_tableData.get(2).getText().equalsIgnoreCase(skilledNursingFacilityDesc))
							isServiceDetailsDisplayed = true;
					} else if (webElement_td.getText().equalsIgnoreCase(serviceType)
							&& webElement_td.getText().equalsIgnoreCase(inpatientRehabilitationFacility)) {
						if (services_tableData.get(1).getText().equalsIgnoreCase(inpatientRehabilitationFacilityRevCode)
								&& services_tableData.get(2).getText()
								.equalsIgnoreCase(inpatientRehabilitationFacilityDesc))
							isServiceDetailsDisplayed = true;
					} else if (webElement_td.getText().equalsIgnoreCase(serviceType)
							&& webElement_td.getText().equalsIgnoreCase(longTermAcuteCare)) {
						if (services_tableData.get(1).getText().equalsIgnoreCase(longTermAcuteCareRevCode)
								&& services_tableData.get(2).getText().equalsIgnoreCase(longTermAcuteCareDesc))
							isServiceDetailsDisplayed = true;
					} else {
						log.info("Nothing is matching");
					}
				}
			}
		} else {
			isServiceDetailsDisplayed = false;
			log.info("No Results Found");
		}
		return isServiceDetailsDisplayed;
	}

	public void clickOnNextButton() {
		SeleniumMethods.longwaitUntilElementIsClickable(servicesTabNextButton);
		servicesTabNextButton.click();
	}
	
	public void clickOnNextButtonforques_Does_the_patient_have_acute_hospital_needs() {
		SeleniumMethods.longwaitUntilElementIsClickable(Does_the_patient_have_acute_hospital_needs_nextbutton);
		Does_the_patient_have_acute_hospital_needs_nextbutton.click();
	}
	
	public void clickOnNextButtonforques_Does_the_patient_have_intense_and_complex_care_needs_that_make_skilled_nursing_facility_care() throws InterruptedException {
		SeleniumMethods.longwaitUntilElementIsClickable(Does_the_patient_have_intense_and_complex_care_needs_that_make_skilled_nursing_facility_care);
		Does_the_patient_have_intense_and_complex_care_needs_that_make_skilled_nursing_facility_care.click();
	}
	
	public void clickOnNextButtonforques_Does_the_care_include_multiple_components_delivered_by_skilled_professionals() throws InterruptedException {
		SeleniumMethods.longwaitUntilElementIsClickable(Does_the_care_include_multiple_components_delivered_by_skilled_professionals);
		Does_the_care_include_multiple_components_delivered_by_skilled_professionals.click();
	}
	
	public void clickOnNextButtonforques_Is_there_a_plan_to_provide_ALL_of_the_following() {
		SeleniumMethods.longwaitUntilElementIsClickable(Is_there_a_plan_to_provide_ALL_of_the_following);
		Is_there_a_plan_to_provide_ALL_of_the_following.click();
	}
	
	public void clickOnNextButtonforques_Is_skilled_treatment_needed_daily_or_more_frequent() {
		SeleniumMethods.longwaitUntilElementIsClickable(Is_skilled_treatment_needed_daily_or_more_frequent);
		Is_skilled_treatment_needed_daily_or_more_frequent.click();
	}
	
	public void clickOnNextButtonforques_Do_you_have_clinical_documentation_to_support_this_request() {
		SeleniumMethods.longwaitUntilElementIsClickable(Do_you_have_clinical_documentation_to_support_this_request);
		Do_you_have_clinical_documentation_to_support_this_request.click();
	}
	
	public void clickOnSaveButton() {
		SeleniumMethods.longwaitUntilElementIsClickable(clinicaltemplatesavebtn);
		clinicaltemplatesavebtn.click();
	}
	
	public boolean verifySearchCriteriaMessage() {
		SeleniumMethods.waitUntilElementIsClickable(dischargingFacilitySearchCriteriaMessage);
		return dischargingFacilitySearchCriteriaMessage.getText().equalsIgnoreCase(Constant.SERVICES_SEARCH_CRITERIA);
	}

	public boolean verifyRequiredFieldsAreDisplayed() {
		SeleniumMethods.waitUntilElementIsClickable(dischargeFacilityDetailsPage);
		return (dischargingFacilityName.isDisplayed() && dischargingFacilityNPI.isDisplayed()
				&& dischargingFacilityZipCode.isDisplayed() && dischargingFacilityCity.isDisplayed()
				&& dischargingFacilityState.isDisplayed() && dischargeFacility_search.isDisplayed());
	}

	public boolean verifyDischargeFacilityDetails() {
		boolean flag = false;
		try {
			flag = servicesTabDischargePageErrorMessage.isDisplayed();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public void searchFacilitydetailsWithTwoOptions(String physicianName, String physicianNPI, String physicianZipCode,
			String physicianCity, String physicianState) {
		SeleniumMethods.waitUntilElementIsClickable(dischargeFacilityDetailsPage);
		SeleniumMethods.waitUntilElementIsClickable(dischargingFacilityCity);
		dischargingFacilityName.sendKeys(physicianName);
		dischargingFacilityNPI.sendKeys(physicianNPI);
		dischargeFacility_search.click();
		if (!verifyDischargeFacilityDetails()) {
			SeleniumMethods.waitUntilElementIsClickable(dischargeFacilityResultTable);
		}
		SeleniumMethods.waitUntilElementIsClickable(dischargingFacilityNPI);
		clearData(dischargingFacilityName);
		dischargingFacilityZipCode.sendKeys(physicianZipCode);
		dischargeFacility_search.click();
		if (!verifyDischargeFacilityDetails()) {
			SeleniumMethods.waitUntilElementIsClickable(dischargeFacilityResultTable);
		}
		clearData(dischargingFacilityNPI);
		dischargingFacilityCity.sendKeys(physicianCity);
		dischargeFacility_search.click();
		if (!verifyDischargeFacilityDetails()) {
			SeleniumMethods.waitUntilElementIsClickable(dischargeFacilityResultTable);
		}
		clearData(dischargingFacilityZipCode);
		SeleniumMethods.javaScriptExecutorClick(dischargingFacilityState);
		dischargingFacilityState.sendKeys(physicianState);
		dischargingFacilityState.sendKeys(Keys.TAB);
		dischargeFacility_search.click();
		if (!verifyDischargeFacilityDetails()) {
			SeleniumMethods.waitUntilElementIsClickable(dischargeFacilityResultTable);
		}

	}

	public void searchFacilityusingAllOptions(String physicianName, String physicianNPI, String physicianZipCode,
			String physicianCity, String physicianState) {
		SeleniumMethods.waitUntilElementIsClickable(dischargeFacilityDetailsPage);
		SeleniumMethods.waitUntilElementIsClickable(dischargingFacilityCity);
		SeleniumMethods.waitUntilElementIsClickable(dischargingFacilityNPI);
		dischargingFacilityName.sendKeys(physicianName);
		dischargingFacilityNPI.sendKeys(physicianNPI);
		dischargingFacilityZipCode.sendKeys(physicianZipCode);
		dischargingFacilityCity.sendKeys(physicianCity);
		SeleniumMethods.javaScriptExecutorClick(dischargingFacilityState);
		dischargingFacilityState.sendKeys(physicianState);
		dischargingFacilityState.sendKeys(Keys.TAB);
		dischargeFacility_search.click();
		if (!verifyDischargeFacilityDetails()) {
			SeleniumMethods.waitUntilElementIsClickable(dischargeFacilityResultTable);
		}
	}

	public void clearData(WebElement element) {
		String inputText = element.getAttribute("value");
		if (inputText != null) {
			for (int i = 0; i < inputText.length(); i++) {
				element.sendKeys(Keys.BACK_SPACE);
			}
		}
	}

	public boolean searchFacilityTogetNoResult(String physicianName1, String physicianNPI1) {
		SeleniumMethods.waitUntilElementIsClickable(dischargeFacilityDetailsPage);
		SeleniumMethods.waitUntilElementIsClickable(dischargingFacilityCity);
		searchDischargingFacility(physicianName1, physicianNPI1);
		return servicesTabDischargePageErrorMessage.isDisplayed();
	}

	public boolean verifyMessageForNoResult() {
		
		
		return servicesTabDischargePageErrorMessage.isDisplayed()
				&& servicesTabDischargePageErrorMessageContent1.getText()
				.contains(Constant.SERVICES_ERRORMESSAGE1)
				&& servicesTabDischargePageErrorMessageContent2.getText()
				.contains(Constant.SERVICES_ERRORMESSAGE2);
	}

	public void searchFacilityTogetmoreResults(String physicianName2, String physicianNPI2) {
		SeleniumMethods.waitUntilElementIsClickable(dischargeFacilityDetailsPage);
		SeleniumMethods.waitUntilElementIsClickable(dischargingFacilityCity);
		searchDischargingFacility(physicianName2, physicianNPI2);
	}

	public void searchDischargingFacility(String facilityDetail1, String facilityDetail2) {
		dischargingFacilityName.sendKeys(facilityDetail1);
		dischargingFacilityNPI.sendKeys(facilityDetail2);
		dischargeFacility_search.click();
	}

	public boolean verifyMessageFormoreResults() {
		return servicesTabDischargePageErrorMessage.isDisplayed() && servicesTabDischargePageErrorMessageContent1
				.getText().equalsIgnoreCase(Constant.SERVICES_ERRORMESSAGE3);
	}

	public boolean verifyStateDropdownPresent() {
		SeleniumMethods.shortwaitUntilElementIsClickable(servicesDischargePageDropdownClick);
		return servicesDischargePageDropdownClick.isDisplayed();
	}

	public void clickStateDropdown() {
		SeleniumMethods.waitUntilElementIsClickable(servicesDischargePageDropdownClick);
		servicesDischargePageDropdownClick.click();
	}

	List<String> dischargePageStateList = new ArrayList<String>();

	public boolean verifyStateListPresent() {
		boolean isStateListPresent = false;
		for (WebElement dd_list : servicesTabDischargePageDropdown) {
			if (!dd_list.getText().isEmpty()) {
				isStateListPresent = true;
				dischargePageStateList.add(dd_list.getText());
			}
		}
		log.info("State Drop Down size is: {} and list is {}", dischargePageStateList.size(), dischargePageStateList);
		return isStateListPresent;
	}

	public boolean verifyStateListSortorder() {
		return SeleniumMethods.isCollectionSorted(servicesTabDischargePageDropdown);
	}

	public boolean checkStateDropdownvalues(String requiredStateList) {
		return SeleniumMethods.checkStateDropdownvalues(servicesTabDischargePageDropdown, requiredStateList);
	}

	public void goToServicesTab() {
		SeleniumMethods.waitUntilElementIsClickable(servicesTab);
		servicesTab.click();
	}

	public void clickEditDischargingFacilityBtn() {
		SeleniumMethods.waitUntilElementIsClickable(editDischarginFacilityBtn);
		editDischarginFacilityBtn.click();
	}

}
