package com.carecentrix.portal.pages;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.carecentrix.utilities.Constant;
import com.carecentrix.utilities.SeleniumMethods;

/**
 * @author KKJANAK
 *
 */

public class MainPage {

	WebDriver driver;

	private static final Logger log = LogManager.getLogger(MainPage.class);

	public MainPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}

	@FindBy(xpath = "//div[@class='main-header__content']//img")
	WebElement signUpPageHomeBridgeLogo;

	@FindBy(xpath = "//div[@class='main-header__content']//ul[@class='navbar__content']//li[1]//a")
	WebElement signUpPageTopMenuContactUS;

	@FindBy(xpath = "//div[@class='main-header__content']//ul[@class='navbar__content']//li[2]//a")
	WebElement signUpPageTopMenuFAQs;

	@FindBy(xpath = "//div[@class='main-header__content']//ul[@class='navbar__content']//li[3]//a")
	WebElement signUpPageTopMenuLogin;

	@FindBy(xpath = "//li[1]//div[@class='menu-list__card']//h4")
	WebElement signUpPageRegisterTitle;

	@FindBy(xpath = "//li[2]//div[@class='menu-list__card']//h4")
	WebElement signUpPageJoinTitle;

	@FindBy(xpath = "//li[3]//div[@class='menu-list__card']//h4")
	WebElement signUpPageSignUpTitle;

	@FindBy(xpath = "//li[4]//div[@class='menu-list__card']//h4")
	WebElement signUpPageReviewTitle;

	@FindBy(xpath = "//div[@class='documents__title']/h4")
	WebElement signUpPageResourcesTitle;

	@FindBy(xpath = "//div[@class='flexgrid flexgrid--center']//li[1]")
	WebElement signUpPageProviderManualLink;

	@FindBy(xpath = "//div[@class='flexgrid flexgrid--center']//li[2]")
	WebElement signUpPageProviderContractLink;

	@FindBy(xpath = "//div[@class='flexgrid flexgrid--center']//li[3]")
	WebElement signUpPageResourcesFormsLink;

	@FindBy(xpath = "//div[@class='flexgrid flexgrid--center']//li[4]")
	WebElement signUpPageMedicalCoverageLink;

	@FindBy(xpath = "//h4[@class='resource-title']")
	WebElement resourcesPagePriorAuthorization;

	@FindBy(xpath = "//div[contains(text(),'Provider Prior Authorization Tool')]")
	WebElement resourcesPageProviderPriorAuthorization;

	@FindBy(xpath = "//div[contains(text(),'Reports')]")
	WebElement resourcesPageReports;

	@FindBy(xpath = "//div[contains(text(),'State Specific Appeals')]")
	WebElement resourcesPageStateSpecific;

	@FindBy(xpath = "//div[contains(text(),'Medical Coverage Policies')]")
	WebElement resourcesPageMedicalCoverage;

	@FindBy(xpath = "//div[@class='action-box__text-content']")
	WebElement signUpPageHomeBridgeTitleLogo;

	@FindBy(xpath = "//span[@class='action-box__copy']")
	WebElement signUpPageHomeBridgeContent;

	@FindBy(xpath = "//div[@class='action-box__button']/a")
	WebElement signUpPageHomeBridgeLearnButton;

	@FindBy(xpath = "//div[@class='flexgrid__item small--col-6 xsmall--col-6 medium--col-6']/img")
	WebElement signUpPageFooterHomeBridgeLogo;

	@FindBy(xpath = "//span[@class='company-links__title']")
	WebElement signUpPageFooterOurcompanyTitle;

	@FindBy(xpath = "//div[@class='company-links']//ul//li[1]")
	WebElement signUpPageFooterAboutUs;

	@FindBy(xpath = "//div[@class='company-links']//ul//li[2]")
	WebElement signUpPageFooterContactUs;

	@FindBy(xpath = "//div[@class='company-links']//ul//li[3]")
	WebElement signUpPageFooterReportFraud;

	@FindBy(xpath = "//p[@class='certificates__copy']")
	WebElement signUpPageFooterContent;

	@FindBy(xpath = "//ul[@class='brand-list']/li[1]//img")
	WebElement signUpPageFooterNCQALogo;

	@FindBy(xpath = "//div[@class='mfp-figure']//button[@class='mfp-close']")
	WebElement signUpFooterNCQAPagePopUpClose;

	@FindBy(xpath = "//ul[@class='brand-list']/li[2]//img")
	WebElement signUpPageFooterURACLogo;

	@FindBy(xpath = "//ul[@class='brand-list']/li[3]//img")
	WebElement signUpPageFooterHiTrustLogo;

	@FindBy(xpath = "//div[@class='flexgrid__item medium--col-9']//span")
	WebElement signUpPageFooterCopyRight;

	@FindBy(xpath = "//div[@class='flexgrid__item medium--col-9']//a[1]")
	WebElement signUpPageFooterTerms;

	@FindBy(xpath = "//div[@class='flexgrid__item medium--col-9']//a[2]")
	WebElement signUpPageFooterPrivacy;

	@FindBy(xpath = "//div[@class='social-links']/span[1]")
	WebElement signUpPageFooterFollowUs;

	@FindBy(xpath = "//div[@class='social-links']//li[1]//a")
	WebElement signUpPageFooterTwitter;

	@FindBy(xpath = "//div[@class='social-links']//li[2]//a")
	WebElement signUpPageFooterLinkedIn;

	@FindBy(xpath = "//div[@class='social-links']//li[3]//a")
	WebElement signUpPageFooterYouTube;

	@FindBy(xpath = "//ul[@class='flexgrid flexgrid--full']//li[1]//a[@class='documents__link']")
	WebElement signUpFooterProviderManual;

	@FindBy(xpath = "//ul[@class='flexgrid flexgrid--full']//li[2]//a[@class='documents__link']")
	WebElement signUpFooterProviderAddenda;

	@FindBy(xpath = "//div[@class='text-box']//div[@class='text-box__title' and contains(text(),'Provider Manual')]")
	WebElement resourcesPrvdrManual;

	@FindBy(xpath = "//div[contains(text(),'Provider Manual')]//following-sibling::a[@class='text-box__link']")
	WebElement resourcesProvdrManualLnk;

	@FindBy(xpath = "//div[@class='text-box']//div[@class='text-box__title' and contains(text(),'Provider Contract Regulatory Addenda')]")
	WebElement resourcesProvdrContract;

	@FindBy(xpath = "//div[contains(text(),'Regulatory Addenda')]//following-sibling::a[@class='text-box__link']")
	WebElement resourcesProvdrContractLnk;

	@FindBy(xpath = "//div[@class='text-box']//div[@class='text-box__title' and contains(text(),'Florida Prior')]")
	WebElement resourcesFloridaPrior;

	@FindBy(xpath = "//div[contains(text(),'Florida Prior')]//following-sibling::a[@class='text-box__link']")
	WebElement resourcesFloridaPriorLnk;

	@FindBy(xpath = "//div[@class='text-box']//div[@class='text-box__title' and contains(text(),'Indiana Prior')]")
	WebElement resourcesIndianaPrior;

	@FindBy(xpath = "//div[contains(text(),'Indiana Prior')]//following-sibling::a[@class='text-box__link']")
	WebElement resourcesIndianaPriorLnk;

	@FindBy(xpath = "//div[@class='text-box']//div[@class='text-box__title' and contains(text(),'Texas Prior')]")
	WebElement resourcesTexasPrior;

	@FindBy(xpath = "//div[contains(text(),'Texas Prior')]//following-sibling::a[@class='text-box__link']")
	WebElement resourcesTexasPriorLnk;

	@FindBy(xpath = "//div[@class='text-box']//div[@class='text-box__title' and contains(text(),'New Mexico')]")
	WebElement resourcesNewMexico;

	@FindBy(xpath = "//div[contains(text(),'New Mexico')]//following-sibling::a[@class='text-box__link']")
	WebElement resourcesNewMexicoLnk;

	@FindBy(xpath = "//div[@class='text-box']//div[@class='text-box__title' and contains(text(),'Post Acute')]")
	WebElement resourcesPostAcute;

	@FindBy(xpath = "//div[contains(text(),'Post Acute')]//following-sibling::a[@class='text-box__link']")
	WebElement resourcesPostAcuteLnk;

	@FindBy(xpath = "//div[@class='text-box']//div[@class='text-box__title' and contains(text(),'Form - Other')]")
	WebElement resourcesPriorAuth;

	@FindBy(xpath = "//div[contains(text(),'Form - Other')]//following-sibling::a[@class='text-box__link']")
	WebElement resourcesPriorAuthLnk;

	@FindBy(xpath = "//div[@class='text-box']//div[@class='text-box__title' and contains(text(),'Provider Prior Auth')]")
	WebElement resourcesPrviderPriorAuth;

	@FindBy(xpath = "//div[contains(text(),'Provider Prior Auth')]//following-sibling::a[@class='text-box__link']")
	WebElement resourcesPrviderPriorAuthLnk;

	@FindBy(xpath = "//div[@class='text-box']//div[@class='text-box__title' and contains(text(),'Reports')]")
	WebElement resourceReports;

	@FindBy(xpath = "//div[contains(text(),'Reports')]//following-sibling::a[@class='text-box__link']")
	WebElement resourceReportsLnk;

	@FindBy(xpath = "//div[@class='text-box']//div[@class='text-box__title' and contains(text(),'State Specific')]")
	WebElement resourceStateSpecific;

	@FindBy(xpath = "//div[contains(text(),'State Specific')]//following-sibling::a[@class='text-box__link']")
	WebElement resourceStateSpecificLnk;

	@FindBy(xpath = "//div[@class='text-box']//div[@class='text-box__title' and contains(text(),'Medical ')]")
	WebElement resourceMedical;

	@FindBy(xpath = "//div[contains(text(),'Medical ')]//following-sibling::a[@class='text-box__link']")
	WebElement resourceMedicalLnk;

	@FindBy(xpath = "//h2[@class='h3 push--top']")
	WebElement questionsInFAQ;

	@FindBy(xpath = "//div[@class='css-0']//button[@class='css-o4mft6']//span[2]")
	List<WebElement> signUpPageFAQs;

	@FindBy(xpath = "//div[@class='menu-list__link']//a[contains(text(),'Join')]")
	WebElement signUpJoinButton;

	@FindBy(xpath = "//td[contains(text(),'Join Our Network')]")
	WebElement signUpJoinHeader;

	@FindBy(xpath = "//div[@class='menu-list__link']//a[contains(text(),'Review')]")
	WebElement reviewBtn;

	@FindBy(xpath = "//ul[@class='section-nav__list']//a[contains(text(),'Claims')]")
	WebElement claimsLink;

	@FindBy(xpath = "//ul[@class='section-nav__list']//a[contains(text(),'Training and Reference Materials')]")
	WebElement trainingLink;

	@FindBy(xpath = "//ul[@class='section-nav__list']//a[contains(text(),'Tools')]")
	WebElement toolsLink;

	@FindBy(xpath = "//ul[@class='section-nav__list']//a[contains(text(),'Health Plan Specific Materials')]")
	WebElement hpLink;

	@FindBy(xpath = "//section[@id='claims']//li//div[@class='card__list-name']//a")
	List<WebElement> claimsList;

	@FindBy(xpath = "//section[@id='training']//li//div[@class='card__list-name']//a")
	List<WebElement> trainingList;

	@FindBy(xpath = "//span[contains(text(),'CareCentrix Direct')]")
	WebElement trainingCareCentrixDD;

	@FindBy(xpath = "//section[@id='tools']//li//div[@class='card__list-name']//a")
	List<WebElement> toolsList;

	@FindBy(xpath = "//section[@id='tools']//li//div[@class='card__list-name']//a")
	WebElement toolsListTxt;

	@FindBy(xpath = "//section[@id='health']//li//div[@class='card__list-name']//a")
	List<WebElement> hpList;

	@FindBy(xpath = "//section[@id='health']//button[@class='css-o4mft6']")
	List<WebElement> hpDDList;

	@FindBy(xpath = "//div[@class='main-footer__content']/div/div/span")
	WebElement copyRights;
		
	@FindBy(xpath = "//div[@class='login-layout__footer']//span")
	WebElement copyRightsLogin;

	public boolean verifyTopSectionMenusPresent(String menu1, String menu2, String menu3) {
		SeleniumMethods.longwaitUntilElementIsVisible(signUpPageHomeBridgeLogo);
		return signUpPageHomeBridgeLogo.isDisplayed() && signUpPageTopMenuContactUS.getText().equalsIgnoreCase(menu1)
				&& signUpPageTopMenuFAQs.getText().equalsIgnoreCase(menu2)
				&& signUpPageTopMenuLogin.getText().equalsIgnoreCase(menu3);
	}

	public boolean verifyCallOfActionsMenusPresent(String menu1, String menu2, String menu3, String menu4) {
		SeleniumMethods.longwaitUntilElementIsVisible(signUpPageRegisterTitle);
		return signUpPageRegisterTitle.getAttribute(Constant.VARIABLE_TEXTCONTENT).equalsIgnoreCase(menu1)
				&& signUpPageJoinTitle.getAttribute(Constant.VARIABLE_TEXTCONTENT).equalsIgnoreCase(menu2)
				&& signUpPageSignUpTitle.getAttribute(Constant.VARIABLE_TEXTCONTENT).equalsIgnoreCase(menu3)
				&& signUpPageReviewTitle.getText().equalsIgnoreCase(menu4);
	}

	public boolean verifyResourcesSectionMenusPresent(String menu1, String menu2, String menu3, String menu4,
			String menu5) {
		SeleniumMethods.longwaitUntilElementIsVisible(signUpPageResourcesTitle);
		return signUpPageResourcesTitle.getText().equalsIgnoreCase(menu1)
				&& signUpPageProviderManualLink.getText().equalsIgnoreCase(menu2)
				&& signUpPageProviderContractLink.getText().equalsIgnoreCase(menu3)
				&& signUpPageResourcesFormsLink.getText().equalsIgnoreCase(menu4)
				&& signUpPageMedicalCoverageLink.getText().equalsIgnoreCase(menu5);
	}

	public boolean clickResourcesFormsLinks(String signUPResourcesLinkURL) {
		SeleniumMethods.longwaitUntilElementIsVisible(signUpPageResourcesFormsLink);
		SeleniumMethods.javaScriptExecutorScrollIntoView(signUpPageResourcesFormsLink);
		signUpPageResourcesFormsLink.click();
		return signUPResourcesLinkURL.equalsIgnoreCase(driver.getCurrentUrl());
	}

	public boolean verifyResourcesFormsMenuOptions(String menu1, String menu2, String menu3, String menu4, String menu5,
			String signUpPageURL) {
		SeleniumMethods.longwaitUntilElementIsVisible(resourcesPagePriorAuthorization);
		boolean isResourceLink = resourcesPagePriorAuthorization.getText().equalsIgnoreCase(menu1)
				&& resourcesPageProviderPriorAuthorization.getText().equalsIgnoreCase(menu2)
				&& resourcesPageReports.getText().equalsIgnoreCase(menu3)
				&& resourcesPageStateSpecific.getText().equalsIgnoreCase(menu4)
				&& resourcesPageMedicalCoverage.getText().equalsIgnoreCase(menu5);
		driver.navigate().to(signUpPageURL);
		return isResourceLink;
	}

	public boolean verifyHomeBridgeContent(String content1) {
		SeleniumMethods.longwaitUntilElementIsVisible(signUpPageHomeBridgeTitleLogo);
		return signUpPageHomeBridgeTitleLogo.isDisplayed()
				&& signUpPageHomeBridgeContent.getText().equalsIgnoreCase(content1)
				&& signUpPageHomeBridgeLearnButton.isDisplayed();
	}

	public boolean clickLearnMoreButton(String signUpLearnMoreButtonURL, String signUpPageURL) {
		SeleniumMethods.longwaitUntilElementIsVisible(signUpPageHomeBridgeLearnButton);
		SeleniumMethods.javaScriptExecutorScrollIntoView(signUpPageHomeBridgeLearnButton);
		signUpPageHomeBridgeLearnButton.click();
		boolean isLearnMoreButton = signUpLearnMoreButtonURL.equalsIgnoreCase(driver.getCurrentUrl());
		driver.navigate().to(signUpPageURL);
		return isLearnMoreButton;
	}

	public boolean verifyResourcesFormsMenuOptions(String menu1, String menu2, String menu3, String menu4) {
		SeleniumMethods.longwaitUntilElementIsVisible(signUpPageFooterHomeBridgeLogo);
		return signUpPageFooterHomeBridgeLogo.isDisplayed()
				&& signUpPageFooterOurcompanyTitle.getText().equalsIgnoreCase(menu1)
				&& signUpPageFooterAboutUs.getText().equalsIgnoreCase(menu2)
				&& signUpPageFooterContactUs.getText().equalsIgnoreCase(menu3)
				&& signUpPageFooterReportFraud.getText().equalsIgnoreCase(menu4);
	}

	public boolean verifyFooterMenusPresent(String menu1, String menu2, String menu3, String menu4,
			String signUpFooterContent, String signUpPageURL) {
		SeleniumMethods.longwaitUntilElementIsVisible(signUpPageFooterOurcompanyTitle);
		SeleniumMethods.javaScriptExecutorScrollIntoView(signUpPageFooterOurcompanyTitle);
		boolean isMenuPresent = signUpPageFooterOurcompanyTitle.getText().equalsIgnoreCase(menu1)
				&& signUpPageFooterAboutUs.getText().equalsIgnoreCase(menu2)
				&& signUpPageFooterContactUs.getText().equalsIgnoreCase(menu3)
				&& signUpPageFooterReportFraud.getText().equalsIgnoreCase(menu4)
				&& signUpPageFooterContent.getText().equalsIgnoreCase(signUpFooterContent);
		driver.navigate().to(signUpPageURL);
		return isMenuPresent;
	}

	public boolean verifyFooterMenuLinks(String signUpPageURL, String link1, String link2, String link3) {
		SeleniumMethods.longwaitUntilElementIsVisible(signUpPageFooterOurcompanyTitle);
		SeleniumMethods.javaScriptExecutorScrollIntoView(signUpPageFooterOurcompanyTitle);
		boolean isLink1Correct = false;
		boolean isLink2Correct = false;
		boolean isLink3Correct = false;
		if (signUpPageFooterAboutUs.isDisplayed()) {
			signUpPageFooterAboutUs.click();
			isLink1Correct = link1.equalsIgnoreCase(driver.getCurrentUrl());
			driver.navigate().to(signUpPageURL);
			SeleniumMethods.waitUntilElementIsClickable(signUpPageFooterContactUs);
			signUpPageFooterContactUs.click();
			isLink2Correct = link2.equalsIgnoreCase(driver.getCurrentUrl());
			driver.navigate().to(signUpPageURL);
			SeleniumMethods.waitUntilElementIsClickable(signUpPageFooterReportFraud);
			signUpPageFooterReportFraud.click();
			isLink3Correct = link3.equalsIgnoreCase(driver.getCurrentUrl());
			driver.navigate().to(signUpPageURL);
		}
		return (isLink1Correct && isLink2Correct && isLink3Correct);
	}

	public boolean verifyFooterLogoClicks(String signUpFooterNCQAURL, String signUpFooterURACURL,
			String signUpFooterHiTrustURL, String signUpPageURL) {
		SeleniumMethods.longwaitUntilElementIsVisible(signUpPageFooterNCQALogo);
		SeleniumMethods.waitUntilElementIsClickable(signUpPageFooterNCQALogo);
		boolean isNCQALinkWorking = false;
		boolean isURACLinkWorking = false;
		boolean isHiTrustLinkWorking = false;
		Set<String> allWindowHandles;
		if (signUpPageFooterNCQALogo.isDisplayed() && signUpPageFooterURACLogo.isDisplayed()
				&& signUpPageFooterHiTrustLogo.isDisplayed()) {
			signUpPageFooterNCQALogo.click();
			signUpPageFooterURACLogo.click();
			signUpPageFooterHiTrustLogo.click();
			allWindowHandles = driver.getWindowHandles();
			for (String windowID : allWindowHandles) {
				if (windowID != null && !signUpPageURL.equalsIgnoreCase(driver.getCurrentUrl())) {
					driver.switchTo().window(windowID);
					if (signUpFooterNCQAURL.equalsIgnoreCase(driver.getCurrentUrl())) {
						isNCQALinkWorking = true;
						log.info("SignUp Footer NCQA URL URL {}", driver.getCurrentUrl());
					} else if (signUpFooterURACURL.equalsIgnoreCase(driver.getCurrentUrl())) {
						isURACLinkWorking = true;
						log.info("SignUp Footer URAC URL {}", driver.getCurrentUrl());
					} else if (signUpFooterHiTrustURL.equalsIgnoreCase(driver.getCurrentUrl())) {
						isHiTrustLinkWorking = true;
						log.info("SignUp Footer HiTrust URL {}", driver.getCurrentUrl());
					}
				}
			}
		}
		driver.navigate().to(signUpPageURL);
		return (isNCQALinkWorking && isURACLinkWorking && isHiTrustLinkWorking);
	}

	public boolean verifyFooterCopyRightDetails(String signUpFooterCopyRight, String signUpFooterTermsURL,
			String signUpFooterPrivacyURL, String signUpPageURL) {
		SeleniumMethods.longwaitUntilElementIsVisible(signUpPageFooterCopyRight);
		SeleniumMethods.scrollDown(signUpPageFooterCopyRight);
		SeleniumMethods.waitUntilElementIsClickable(signUpPageFooterCopyRight);
		boolean isCopyRightPresent = false;
		boolean isTermsPresent = false;

		log.info("signUpPageFooterCopyRight {}", signUpPageFooterCopyRight.getText());
		log.info("signUpPageFooterTerms {}", signUpPageFooterTerms.getText());
		log.info("signUpPageFooterPrivacy {}", signUpPageFooterPrivacy.getText());

		if (signUpPageFooterCopyRight.isDisplayed()
				&& signUpPageFooterCopyRight.getText().equalsIgnoreCase(signUpFooterCopyRight)) {
			SeleniumMethods.waitUntilElementIsClickable(signUpPageFooterTerms);
			signUpPageFooterTerms.click();
			isCopyRightPresent = signUpFooterTermsURL.equalsIgnoreCase(driver.getCurrentUrl());
			driver.navigate().to(signUpPageURL);
			SeleniumMethods.waitUntilElementIsClickable(signUpPageFooterPrivacy);
			signUpPageFooterPrivacy.click();
			isTermsPresent = signUpFooterPrivacyURL.equalsIgnoreCase(driver.getCurrentUrl());
			driver.navigate().to(signUpPageURL);
		}
		return (isCopyRightPresent && isTermsPresent);
	}

	public boolean verifyFooterFollowLinkDetails(String signUpFooterFollowUs, String signUpFooterTwitURL,
			String signUpFooterLIURL, String signUpFooterYTURL, String signUpPageURL) {

		SeleniumMethods.waitUntilElementIsClickable(signUpPageFooterFollowUs);
		SeleniumMethods.scrollDown(signUpPageFooterFollowUs);
		boolean isTwitLinkWorking = false;
		boolean isLILinkWorking = false;
		boolean isYTLinkWorking = false;
		Set<String> allWindowHandles;
		if (signUpPageFooterFollowUs.isDisplayed()
				&& signUpPageFooterFollowUs.getText().equalsIgnoreCase(signUpFooterFollowUs)
				&& signUpPageFooterTwitter.isDisplayed() && signUpPageFooterLinkedIn.isDisplayed()
				&& signUpPageFooterYouTube.isDisplayed()) {
			signUpPageFooterTwitter.click();
			signUpPageFooterLinkedIn.click();
			signUpPageFooterYouTube.click();
			allWindowHandles = driver.getWindowHandles();
			for (String windowID : allWindowHandles) {
				if (windowID != null && !signUpPageURL.equalsIgnoreCase(driver.getCurrentUrl())) {
					driver.switchTo().window(windowID);
					if (signUpFooterTwitURL.equalsIgnoreCase(driver.getCurrentUrl())) {
						isTwitLinkWorking = true;
						log.info("SignUp Footer Twit URL {}", driver.getCurrentUrl());
					} else if (signUpFooterLIURL.equalsIgnoreCase(driver.getCurrentUrl())) {
						isLILinkWorking = true;
						log.info("SignUp LI URL {}", driver.getCurrentUrl());
					} else if (signUpFooterYTURL.equalsIgnoreCase(driver.getCurrentUrl())) {
						isYTLinkWorking = true;
						log.info("SignUp YT URL {}", driver.getCurrentUrl());
					}
				}
			}
		}
		return (isTwitLinkWorking && isLILinkWorking && isYTLinkWorking);
	}

	public boolean verifyProviderManualMenu(String singUpProviderManualURL, String signUpPageURL) {
		SeleniumMethods.waitUntilElementIsClickable(signUpFooterProviderManual);
		SeleniumMethods.javaScriptExecutorScrollIntoView(signUpFooterProviderManual);
		signUpFooterProviderManual.click();
		boolean isLinkOpened = singUpProviderManualURL.equalsIgnoreCase(driver.getCurrentUrl());
		driver.navigate().to(signUpPageURL);
		return isLinkOpened;
	}

	public void verifyProviderAddenedMenu() {
		SeleniumMethods.waitUntilElementIsClickable(signUpFooterProviderAddenda);
		SeleniumMethods.javaScriptExecutorScrollIntoView(signUpFooterProviderAddenda);
		if (signUpFooterProviderAddenda.isDisplayed()) {
			signUpFooterProviderAddenda.click();
		}
	}

	public void clickLinksAndVerifyDownload(String pdf1, String pdf2, String pdf3, String pdf4, String pdf5,
			String pdf6, String pdf7, String pdf8, String pdf9, String pdf10) {
		SeleniumMethods.waitUntilElementIsClickable(resourceReports);

		if (resourceReports.isDisplayed() && resourceMedical.isDisplayed()) {
			isResourcesDisplayed(resourcesPrvdrManual, resourcesProvdrManualLnk, pdf1);
			isResourcesDisplayed(resourcesProvdrContract, resourcesProvdrContractLnk, pdf2);
			isResourcesDisplayed(resourcesFloridaPrior, resourcesFloridaPriorLnk, pdf3);
			isResourcesDisplayed(resourcesIndianaPrior, resourcesIndianaPriorLnk, pdf4);
			isResourcesDisplayed(resourcesTexasPrior, resourcesTexasPriorLnk, pdf5);
			isResourcesDisplayed(resourcesNewMexico, resourcesNewMexicoLnk, pdf6);
			isResourcesDisplayed(resourcesPostAcute, resourcesPostAcuteLnk, pdf7);
			isResourcesDisplayed(resourcesPriorAuth, resourcesPriorAuthLnk, pdf8);
			isResourcesDisplayed(resourcesPrviderPriorAuth, resourcesPrviderPriorAuthLnk, pdf9);
			isResourcesDisplayed(resourceStateSpecific, resourceStateSpecificLnk, pdf10);
		}
	}

	public void isResourcesDisplayed(WebElement resourcesTitle, WebElement resourcesLnk, String pdf) {
		if (resourcesTitle.isDisplayed()) {
			SeleniumMethods.waitUntilElementIsClickable(resourcesLnk);
			resourcesLnk.click();
			SeleniumMethods.verifyDownloadedFileAndDelete(pdf);
		}

	}

	public boolean clickOnFAQLink(String signUpFAQLnk) {
		SeleniumMethods.waitUntilElementIsClickable(signUpPageTopMenuFAQs);
		signUpPageTopMenuFAQs.click();
		SeleniumMethods.longwaitUntilElementIsVisible(questionsInFAQ);
		return signUpFAQLnk.equalsIgnoreCase(driver.getCurrentUrl());
	}

	public boolean verifyFAQQuestions(String singUpFAQs) {
		SeleniumMethods.waitUntilElementIsClickable(signUpPageTopMenuFAQs);
		return SeleniumMethods.checkStateDropdownvalues(signUpPageFAQs, singUpFAQs);
	}

	public void clickOnJoinButton() {
		SeleniumMethods.waitUntilElementIsClickable(signUpJoinButton);
		signUpJoinButton.click();
	}

	public boolean verifyJoinPage(String signUpJoinURL) {
		SeleniumMethods.longwaitUntilElementIsVisible(signUpJoinHeader);
		return signUpJoinURL.equalsIgnoreCase(driver.getCurrentUrl());
	}

	public void clickReviewBtn() {
		SeleniumMethods.longwaitUntilElementIsVisible(reviewBtn);
		reviewBtn.click();
	}

	public boolean verifyReviewPageURL(String reviewPageURL) {
		SeleniumMethods.longwaitUntilElementIsVisible(claimsLink);
		return reviewPageURL.equalsIgnoreCase(driver.getCurrentUrl());
	}

	public void clickMenu(String menu, String isVerify, String claimsLst, String trainingLst, String toolsLst,
			String hpLst) {
		switch (menu) {
		case Constant.CLAIM: {
			menuClick(claimsLink, isVerify, claimsList, claimsLst);
			break;
		}
		case Constant.TRAINING: {
			menuClick(trainingLink, isVerify, trainingList, trainingLst);
			break;
		}
		case Constant.TOOLS: {
			menuClick(toolsLink, isVerify, toolsList, toolsLst);
			break;
		}
		case Constant.HEALTHPLAN: {
			menuClick(hpLink, isVerify, hpList, hpLst);
			break;
		}
		default:
			log.info("Review Page");
		}
	}

	public void menuClick(WebElement link, String isVerify, List<WebElement> list1, String reviewList) {
		SeleniumMethods.longwaitUntilElementIsVisible(link);
		link.click();
		if (isVerify.equalsIgnoreCase(Constant.OPTION_YES))
			SeleniumMethods.checkStateDropdownvalues(list1, reviewList);
	}

	public boolean clickAndVerifyClaimsLink(String menu, String link, String isURL) {
		boolean flag = false;
		if (menu.equalsIgnoreCase(Constant.CLAIMS_MENU1) || menu.equalsIgnoreCase(Constant.CLAIMS_MENU2)
				|| menu.equalsIgnoreCase(Constant.CLAIMS_MENU3) || menu.equalsIgnoreCase(Constant.CLAIMS_MENU4)
				|| menu.equalsIgnoreCase(Constant.CLAIMS_MENU5) || menu.equalsIgnoreCase(Constant.CLAIMS_MENU6)
				|| menu.equalsIgnoreCase(Constant.CLAIMS_MENU7) || menu.equalsIgnoreCase(Constant.CLAIMS_MENU8)
				|| menu.equalsIgnoreCase(Constant.CLAIMS_MENU9) || menu.equalsIgnoreCase(Constant.CLAIMS_MENU10)) {
			flag = checkLink(claimsList, menu, link, isURL);
		}
		return flag;
	}

	public boolean checkLink(List<WebElement> list, String menu, String link, String isURL) {
		boolean flag = false;
		for (WebElement linkMenu : list) {
			SeleniumMethods.longwaitUntilElementIsClickable(linkMenu);
			if (linkMenu.getText().equalsIgnoreCase(menu)) {
				String currentWindow = driver.getWindowHandle();
				linkMenu.click();
				if (isURL.equalsIgnoreCase(Constant.OPTION_YES)) {
					Set<String> handleWindows = driver.getWindowHandles();
					flag = handleWindow(currentWindow, handleWindows, link);
				}
				if (isURL.equalsIgnoreCase(Constant.OPTION_NO)) {
					// wait is required to download the file
					try {
						Thread.sleep(2000);
						flag = SeleniumMethods.verifyDownloadedFileAndDelete(link);
					} catch (Exception e) {
						log.info("Time Out");
					}
				}
				break;
			}
		}
		return flag;
	}

	public boolean handleWindow(String parentWindow, Set<String> handleWindows, String link) {
		Iterator<String> windowsIterator = handleWindows.iterator();
		boolean flag = false;
		try {
			while (windowsIterator.hasNext()) {
				String childWindow = windowsIterator.next();
				if (!parentWindow.equals(childWindow)) {
					driver.switchTo().window(childWindow);
					flag = link.equalsIgnoreCase(driver.getCurrentUrl());
				}
			}
		} catch (Exception e) {
			log.info("There is no  more than one child window opened");
		}
		return flag;
	}

	public boolean clickAndVerifyTrainingLink(String menu, String link, String isURL) {
		boolean flag = false;
		if (menu.equalsIgnoreCase(Constant.TRAINING_MENU1) || menu.equalsIgnoreCase(Constant.TRAINING_MENU2)
				|| menu.equalsIgnoreCase(Constant.TRAINING_MENU3) || menu.equalsIgnoreCase(Constant.TRAINING_MENU4)
				|| menu.equalsIgnoreCase(Constant.TRAINING_MENU5) || menu.equalsIgnoreCase(Constant.TRAINING_MENU6)
				|| menu.equalsIgnoreCase(Constant.TRAINING_MENU7) || menu.equalsIgnoreCase(Constant.TRAINING_MENU8)) {
			flag = checkLink(trainingList, menu, link, isURL);
		}
		return flag;
	}

	public boolean clickAndVerifyTrainingLinkdropdown(String menu1, String menu, String link, String isURL) {
		boolean flag = false;
		if ((menu1.equalsIgnoreCase(Constant.TRAINING_MENU9)) && (menu.equalsIgnoreCase(Constant.TRAINING_MENU10)
				|| menu.equalsIgnoreCase(Constant.TRAINING_MENU11))) {
			SeleniumMethods.longwaitUntilElementIsVisible(trainingCareCentrixDD);
			trainingCareCentrixDD.click();
			flag = checkLink(trainingList, menu, link, isURL);
		}
		return flag;
	}

	public boolean clickAndVerifyTrainingLinkdropdown(String menu, String link, String isURL) {
		boolean flag = false;
		if (menu.equalsIgnoreCase(Constant.TOOLS_MENU1)) {
			SeleniumMethods.longwaitUntilElementIsVisible(toolsListTxt);
			toolsListTxt.click();
			flag = checkLink(toolsList, menu, link, isURL);
		}
		return flag;
	}

	public boolean clickAndVerifyHealthPlanLink(String menu, String link, String isURL) {
		boolean flag = false;
		if (menu.equalsIgnoreCase(Constant.HEALTHPLAN_MENU1)) {
			flag = checkLink(hpList, menu, link, isURL);
		}
		return flag;
	}

	public void clickHealthPlanddLink(String menu) {
		for (WebElement linkMenu : hpDDList) {
			SeleniumMethods.longwaitUntilElementIsClickable(linkMenu);
			if (linkMenu.getText().equalsIgnoreCase(menu))
				linkMenu.click();
		}
	}

	public boolean verifyCopyRightsContent(String page) {
		boolean flag = false;
		SeleniumMethods.javaScriptExecutorScrollByValue();
		if (page.equalsIgnoreCase(Constant.LOGIN))
			flag = copyRightsLogin.getText().equalsIgnoreCase(Constant.COPY_RIGHTS);
		else
			flag = copyRights.getText().equalsIgnoreCase(Constant.COPY_RIGHTS_FULL);
		return flag;
	}
}
