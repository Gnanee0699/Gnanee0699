package com.carecentrix.portal.pages;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.carecentrix.utilities.Constant;
import com.carecentrix.utilities.SeleniumMethods;

import net.serenitybdd.core.Serenity;


public class RequestStatusPage {

	private static final Logger log = LogManager.getLogger(RequestStatusPage.class);

	@FindBy(xpath = "//a[text()='Request Status']")
	WebElement requeststatus;	
	
	@FindBy(xpath = "//span[text()='Manage Request']")
	WebElement managerequest;
	
	@FindBy(xpath = "//div[@class='css-cabb4f']")
	List<WebElement> selectrequest;
	
	@FindBy(xpath = "//input[@name='subscriberId']")
	WebElement subscriberid;
	
	@FindBy(xpath = "//input[@name='memberFirstName']")
	WebElement memberfirstname;
	
	@FindBy(xpath = "//input[@name='memberLastName']")
	List<WebElement> memberlastname;
	
	@FindBy(xpath = "//input[@placeholder='DOB (MM/DD/YYYY)']")
	WebElement memberdob;
	
	@FindBy(xpath = "//span[@class='icon-search ']")
	List<WebElement> searchbutton;	
	
	@FindBy(xpath = "//div[@class='table-container with-pagination']/table")
	WebElement searchresults;
	
	@FindBy(xpath = "//div[@class='table-container with-pagination']/table/tbody/tr[1]/td[2]")
	WebElement serviceline;
	
	@FindBy(xpath = "(//span[contains(normalize-space(), 'Results')])[2]")
	WebElement totalresults;
	
	WebDriver driver;

	List<String> Pauthid = new ArrayList<String>();

	List<String> externalReferralList = new ArrayList<String>();

	public RequestStatusPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}

	
	public void checkAvailabilityofFields() {
	}

	
	public boolean clickRequestStatus() {
		try {
			Thread.sleep(100);
			SeleniumMethods.longwaitUntilElementIsClickable(requeststatus);
			requeststatus.click();
			SeleniumMethods.longwaitUntilElementIsVisible(requeststatus);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return requeststatus.isDisplayed();
	}

	
	public boolean clickManageRequest() {
		try {
			Thread.sleep(100);
			SeleniumMethods.longwaitUntilElementIsClickable(managerequest);
			managerequest.click();
			SeleniumMethods.longwaitUntilElementIsVisible(managerequest);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return managerequest.isDisplayed();
	}
	
	public boolean searchRequest() {
		
			boolean blSearch;		
			SeleniumMethods.longwaitUntilElementIsClickable(searchbutton.get(1));
			blSearch = searchbutton.get(1).isDisplayed();
			searchbutton.get(1).click();
	
		return blSearch;
	}
	
	
	public void enterInformationToSearch(String subscriberId1, String membfirstName1, String memmblastName1, String membdob1) {
		
		try {
			Thread.sleep(700);			
			SeleniumMethods.longwaitUntilElementIsClickable(selectrequest.get(1));
			selectrequest.get(1).click();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		SeleniumMethods.longwaitUntilElementIsClickable(subscriberid);
		subscriberid.sendKeys(subscriberId1);
		memberfirstname.sendKeys(membfirstName1);
		memberfirstname.sendKeys(Keys.TAB);
		System.out.println("lastname");
		SeleniumMethods.longwaitUntilElementIsClickable(memberlastname.get(1));
		memberlastname.get(1).sendKeys(memmblastName1);
		SeleniumMethods.longwaitUntilElementIsClickable(memberdob);
		memberdob.sendKeys(membdob1);
		memberdob.sendKeys(Keys.TAB);
	}
	
	public boolean getServiceLine(String strFlag) {
		
		try {
			Thread.sleep(1500);
			if(strFlag.equalsIgnoreCase("Capture"))
			{
				System.out.println("inside capture");
				try {			
					SeleniumMethods.longwaitUntilElementIsVisible(searchresults);
				} catch (org.openqa.selenium.NoSuchElementException | org.openqa.selenium.StaleElementReferenceException
						| org.openqa.selenium.TimeoutException e) {
					log.info("No Results displayed with Service Line Number:");
					return true;
				}
			}
			SeleniumMethods.longwaitUntilElementIsVisible(searchresults);
			SeleniumMethods.longwaitUntilElementIsVisible(serviceline);
			String strserviceline = serviceline.getText();
			Serenity.getCurrentSession().put(Constant.SERVICELINE_NUMBER, strserviceline);
			Constant.CaseID=strserviceline;
			log.info("Service Line Number:" + Serenity.getCurrentSession().get(Constant.SERVICELINE_NUMBER));
			
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return serviceline.isDisplayed();
		
	
	}
	
	public String getParentauthid() throws InterruptedException {
		
		SeleniumMethods.longwaitUntilElementIsVisible(totalresults);
		
		
		int i=driver.findElements(By.xpath("(//span[contains(normalize-space(), 'Results')])[2]")).size();
		if(i>0){
			int k = driver.findElements(By.xpath("//body/div/section/div/div/section/div/div")).size();
			
			log.info("size of the searchresults : " + k);
			
			int l =driver.findElements(By.xpath("(//span[contains(normalize-space(), 'Service Header Number')])")).size();
			
			log.info("size of the Service Header Number list : " + l);
						
			for(int m=1; m<l; ){
				String parentauthid = driver.findElement(By.xpath("(//span[contains(normalize-space(), 'Service Header Number')])["+m+"]")).getText();
				String[] parentauthid2=parentauthid.trim().split(" ");
				Pauthid.add(parentauthid2[3]);
				log.info("ParentauthID : " + parentauthid2[3]);
				m++;
			}
			
		}
		
		log.info("Final list of Parent auth"+Pauthid);
		return null;
		
	}

		
}
