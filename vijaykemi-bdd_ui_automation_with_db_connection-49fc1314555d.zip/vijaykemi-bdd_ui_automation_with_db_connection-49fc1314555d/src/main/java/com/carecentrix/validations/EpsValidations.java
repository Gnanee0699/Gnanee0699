package com.carecentrix.validations;


import static net.serenitybdd.rest.SerenityRest.when;

import static net.serenitybdd.rest.SerenityRest.then;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.hasItems;
import static org.hamcrest.Matchers.hasItem;


public class EpsValidations {

	public void validatestatuscode(int code) {
		then().assertThat().statusCode(code);
	}
	
	
	public void validatefieldinResponsebody(String ExpectedField, Object ExpectedValue) {
		then().assertThat().body(ExpectedField, equalTo(ExpectedValue));
		
	}
	
	
	public void validatefieldinCallBackResponsebody(String ExpectedField, String ExpectedValue) {
		then().assertThat().body(ExpectedField, hasItem(ExpectedValue));
		
	}
	
	public void validateErrorfieldinMcClientResponsebody(String ExpectedField, String ExpectedValue) {		
		then().assertThat().body(ExpectedField, hasItem(ExpectedValue));
		
	}
	
	public void validateResponsebody(String ExpectedValue) {
		then().assertThat().body(equalTo(ExpectedValue));
		
	}
}
