package com.caretrix.medcompass.cucumber.steps;

import java.util.Map;
import static net.serenitybdd.rest.SerenityRest.rest;

import com.API.Rest.validations.MedcompassValidations;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.mc.TestUtils.Constant;
import com.mc.setup.SetupHeaders;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Steps;
import io.restassured.response.Response;

public class MemberGetSteps {
	
	Map<String,Map<String, String>> dataMap; 
	
	@Steps
	private MedcompassValidations validation = new MedcompassValidations();
	
	String hostname ="udhservicehostname";
	
	@Given("^Setup proxy for a Member get Request$")
	public void setup_proxy_for_a_Member_Request() throws Throwable {
		SetupHeaders.initialSetup(hostname);
		Serenity.getCurrentSession().put(Constant.DATA_MAP, dataMap);
	}
	
	@When("^Fetch member details from UDH \"([^\"]*)\"$")
	public void Fetch_Member_Details_From_UDH(String Membergdfic) throws Throwable {
		Response response=rest().given().when().get("/api/member/" +Membergdfic);
		DocumentContext doc =JsonPath.parse(response.body().asString());
		String zipcode=JsonPath.parse(response.body().asString()).read("$.MemPatZip");
		String state=JsonPath.parse(response.body().asString()).read("$.MemPatState");
		
		Serenity.getCurrentSession().put("zipcode", zipcode);
		
		Serenity.getCurrentSession().put("state", state);
	
	}
}
