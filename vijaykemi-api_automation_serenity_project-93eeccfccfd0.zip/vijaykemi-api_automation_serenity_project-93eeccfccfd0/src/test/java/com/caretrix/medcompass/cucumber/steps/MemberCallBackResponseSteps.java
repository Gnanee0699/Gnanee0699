package com.caretrix.medcompass.cucumber.steps;

import static net.serenitybdd.rest.SerenityRest.rest;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;

import com.API.Rest.validations.MedcompassValidations;
import com.mc.TestUtils.Constant;
import com.mc.TestUtils.ExcelReadWrite;
import com.mc.TestUtils.ExcelReader;
import com.mc.TestUtils.JsonUpdateUtil;
import com.mc.TestUtils.PropLoader;

import cucumber.api.java.en.When;
import io.restassured.response.Response;
import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Steps;

public class MemberCallBackResponseSteps {
	String addmemberuri;

	Common common = new Common();
	private static final Logger log = LogManager.getLogger(MemberCallBackResponseSteps.class);

	@Steps
	private MedcompassValidations validation = new MedcompassValidations();

	@When("^Member request is initiated for \"([^\"]*)\" and \"([^\"]*)\"$")
	public void addMemberE2E(String scenario, String sheetName) throws Throwable {

		addmemberuri = PropLoader.props.apply("mcapihostname") + PropLoader.props.apply("basemcapipath")
				+ PropLoader.props.apply("addmemberapi");

		String eventid = UUID.randomUUID().toString();

		common.Tctype = ExcelReadWrite.getTestcaseType(scenario);

		log.info("Testcase Type:", ExcelReadWrite.getTestcaseType(scenario));

		log.info("scenario {}", scenario);
		log.info("eventidvalue {}", eventid);
		Map<String, Object> dataMap = ExcelReader.readAllRow(sheetName, scenario);

		if (common.Tctype.equals("Add")) {
			common.sourcememberid = ExcelReadWrite.getRandomGenerate(12);
			log.info("source id is -------------", common.sourcememberid);
			dataMap.replace("$..sourcememberid", common.sourcememberid);
		}

		log.info("dataMap {}" + dataMap);
		String jsonTemplatePayload = new String(
				Files.readAllBytes(Paths.get("src/test/resources/jsonPayloads/member/memberWithMutilpleObjects.json")));

		// String payload = JsonUpdateUtil.buildJsonRequest(jsonTemplatePayload,dataMap);
		String payload = JsonUpdateUtil.buildJsonRequestpro(jsonTemplatePayload, dataMap,
				ExcelReadWrite.fetchXLDataNStoreInHashMap(sheetName, scenario, Constant.RowstobeDeleted));
		JSONObject newpayload = new JSONObject(payload);
		newpayload = JsonUpdateUtil.updateJson(newpayload, "eventidvalue", eventid);
		Serenity.getCurrentSession().put(Constant.EVENT_ID_VALUE_JSON_PATH, eventid);

		Response immediateResponse = rest().given().contentType(Constant.CONTENTTYPE)
				.header("Content-Type", Constant.CONTENTTYPE).auth().basic(PropLoader.props.apply("username"), PropLoader.props.apply("password")).when()
				.log().all().body(newpayload.toString()).post(addmemberuri);
		log.info(immediateResponse.getBody().asString());

	}
	
	@When("^MemberE2E request is initiated for \"([^\"]*)\"$")
	public void addMemberE2ECLBK(String scenario) throws Throwable {

		String sheetName= PropLoader.props.apply("MemberE2ECallBackResponseSHT");
		
		addmemberuri = PropLoader.props.apply("mcapihostname") + PropLoader.props.apply("basemcapipath")
				+ PropLoader.props.apply("addmemberapi");

		String eventid = UUID.randomUUID().toString();

		common.Tctype = ExcelReadWrite.getTestcaseType(scenario);

		log.info("Testcase Type:", ExcelReadWrite.getTestcaseType(scenario));

		log.info("scenario {}", scenario);
		log.info("eventidvalue {}", eventid);
		Map<String, Object> dataMap = ExcelReader.readAllRow(sheetName, scenario);

		if (common.Tctype.equals("Add")) {
			common.sourcememberid = ExcelReadWrite.getRandomGenerate(12);
			Serenity.getCurrentSession().put(Constant.SOURCE_MEMBER_ID_JSON_PATH, Common.sourcememberid);
			log.info("source id is -------------", common.sourcememberid);
			dataMap.replace("$..sourcememberid", common.sourcememberid);
		}

		log.info("dataMap {}" + dataMap);
		String jsonTemplatePayload = new String(
				Files.readAllBytes(Paths.get("src/test/resources/jsonPayloads/member/memberWithMutilpleObjects.json")));

		// String payload = JsonUpdateUtil.buildJsonRequest(jsonTemplatePayload,dataMap);
		String payload = JsonUpdateUtil.buildJsonRequestpro(jsonTemplatePayload, dataMap,
				ExcelReadWrite.fetchXLDataNStoreInHashMap(sheetName, scenario, Constant.RowstobeDeleted));
		JSONObject newpayload = new JSONObject(payload);
		newpayload = JsonUpdateUtil.updateJson(newpayload, "eventidvalue", eventid);
		Serenity.getCurrentSession().put(Constant.EVENT_ID_VALUE_JSON_PATH, eventid);

		Response immediateResponse = rest().given().contentType(Constant.CONTENTTYPE)
				.header("Content-Type", Constant.CONTENTTYPE).auth().basic(PropLoader.props.apply("username"), PropLoader.props.apply("password")).when()
				.log().all().body(newpayload.toString()).post(addmemberuri);
		log.info(immediateResponse.getBody().asString());

	}

}
