package com.caretrix.medcompass.cucumber.steps;

import static net.serenitybdd.rest.SerenityRest.rest;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;

import com.API.Rest.validations.MedcompassValidations;
import com.github.javafaker.Faker;
import com.mc.TestUtils.Constant;
import com.mc.TestUtils.ExcelReadWrite;
import com.mc.TestUtils.ExcelReader;
import com.mc.TestUtils.JsonUpdateUtil;
import com.mc.TestUtils.PropLoader;
import com.mc.TestUtils.Utils;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Steps;

public class ProviderCallBackResponseSteps {

	Common common = new Common() ;
	Utils utils = new Utils();
	private static final Logger log = LogManager.getLogger(ProviderCallBackResponseSteps.class);
	Faker faker = new Faker();
	
	
	@Steps
	private MedcompassValidations validation = new MedcompassValidations();
	
	
	@When("^Member Request Type ProviderCallBackE2ERequests end point is invoked for the \"([^\"]*)\" and \"([^\"]*)\"$")
	public void ProviderCallBackE2ERequests(String scenario, String sheetName) throws Throwable {

		String gdfidqw=UUID.randomUUID().toString();
		
		common.Tctype = ExcelReadWrite.getTestcaseType(scenario);
		
		log.info("Testcase Type:", ExcelReadWrite.getTestcaseType(scenario));
					
		log.info("eventidvalue:", common.eventidvalue);
		
		log.info("scenario {}", scenario);
			
		Map<String,Object> dataMap2=Utils.updatedmap(sheetName,scenario,common.Tctype);
				
		String jsonTemplatePayload = new String(Files.readAllBytes(Paths.get("src/test/resources/jsonPayloads/provider/providerWithMultipleobjects.json")));
		String payload = JsonUpdateUtil.buildJsonRequestpro(jsonTemplatePayload,dataMap2,ExcelReadWrite.fetchXLDataNStoreInHashMap(sheetName, scenario, Constant.RowstobeDeleted));
		JSONObject payload1 = new JSONObject(payload);		
		
		payload1=JsonUpdateUtil.updateJson(payload1, "eventidvalue", gdfidqw);
		
		Serenity.getCurrentSession().put(Constant.EVENT_ID_VALUE_JSON_PATH, gdfidqw);
		
		rest().given().contentType(Constant.CONTENTTYPE)
		.header("Content-Type",Constant.CONTENTTYPE)
		.auth().basic(PropLoader.props.apply("username"), PropLoader.props.apply("password"))
		.when().log().all()
		.body(payload1.toString())
		.post(PropLoader.props.apply("basemcapipath")+PropLoader.props.apply("addproviderapi"));
			
	}
	
		
	@When("^Member Request Type ADDProviderCallBackE2ERequests end point is invoked for the \"([^\"]*)\" and \"([^\"]*)\"$")
	public void ADDProviderCallBackE2ERequests(String scenario, String sheetName) throws Throwable {

		String gdfidqw=UUID.randomUUID().toString();
		
		Common.sourceproviderid=ExcelReadWrite.getRandomGenerate(12);
		
		common.Tctype = ExcelReadWrite.getTestcaseType(scenario);
		
		log.info("Testcase Type:", ExcelReadWrite.getTestcaseType(scenario));
				
		log.info("eventidvalue:", common.eventidvalue);
		
		log.info("scenario {}", scenario);
		
		
		Map<String,Object> dataMap2=Utils.updatedmapADD(sheetName,scenario,common.Tctype,Common.sourceproviderid);
				
		String jsonTemplatePayload = new String(Files.readAllBytes(Paths.get("src/test/resources/jsonPayloads/provider/providerWithMultipleobjects.json")));
		String payload = JsonUpdateUtil.buildJsonRequestpro(jsonTemplatePayload,dataMap2,ExcelReadWrite.fetchXLDataNStoreInHashMap(sheetName, scenario, Constant.RowstobeDeleted));
		JSONObject payload1 = new JSONObject(payload);		
		
		payload1=JsonUpdateUtil.updateJson(payload1, "eventidvalue", gdfidqw);
				
		Serenity.getCurrentSession().put(Constant.EVENT_ID_VALUE_JSON_PATH, gdfidqw);
				
		rest().given().contentType(Constant.CONTENTTYPE)
		.header("Content-Type",Constant.CONTENTTYPE)
		.auth().basic(PropLoader.props.apply("username"), PropLoader.props.apply("password"))
		.when().log().all()
		.body(payload1.toString())
		.post(PropLoader.props.apply("basemcapipath")+PropLoader.props.apply("addproviderapi"));
		
		log.info("source provider ----", common.sourceproviderid);
	}
	
	@When("^Member Request Type ADDProviderCallBackE2ERequestsE2E end point is invoked for the \"([^\"]*)\"$")
	public void ADDProviderCallBackE2ERequestsE2E(String scenario) throws Throwable {

		String sheetName= PropLoader.props.apply("ProviderE2ECallBackResponseSHT");
		
		String gdfidqw=UUID.randomUUID().toString();
		
		Common.sourceproviderid=ExcelReadWrite.getRandomGenerate(12);
				
		Serenity.getCurrentSession().put(Constant.SOURCE_PROVIDER_ID_JSON_PATH, Common.sourceproviderid);
		
		common.Tctype = ExcelReadWrite.getTestcaseType(scenario);
		
		log.info("Testcase Type:", ExcelReadWrite.getTestcaseType(scenario));
				
		log.info("eventidvalue:", common.eventidvalue);
		
		log.info("scenario {}", scenario);
		
		
		Map<String,Object> dataMap2=Utils.updatedmapADD(sheetName,scenario,common.Tctype,Common.sourceproviderid);
				
		String jsonTemplatePayload = new String(Files.readAllBytes(Paths.get("src/test/resources/jsonPayloads/provider/providerWithMultipleobjects.json")));
		String payload = JsonUpdateUtil.buildJsonRequestpro(jsonTemplatePayload,dataMap2,ExcelReadWrite.fetchXLDataNStoreInHashMap(sheetName, scenario, Constant.RowstobeDeleted));
		JSONObject payload1 = new JSONObject(payload);		
		
		payload1=JsonUpdateUtil.updateJson(payload1, "eventidvalue", gdfidqw);
				
		Serenity.getCurrentSession().put(Constant.EVENT_ID_VALUE_JSON_PATH, gdfidqw);
				
		rest().given().contentType(Constant.CONTENTTYPE)
		.header("Content-Type",Constant.CONTENTTYPE)
		.auth().basic(PropLoader.props.apply("username"), PropLoader.props.apply("password"))
		.when().log().all()
		.body(payload1.toString())
		.post(PropLoader.props.apply("basemcapipath")+PropLoader.props.apply("addproviderapi"));
		
		log.info("source provider ----", common.sourceproviderid);
	}
	
	@When("^Member Request Type UPDATEProviderCallBackE2ERequests end point is invoked for the \"([^\"]*)\" and \"([^\"]*)\"$")
	public void UPDATEProviderCallBackE2ERequests(String scenario, String sheetName) throws Throwable {
		
		log.info("source provider ", common.sourceproviderid);
		
	//	String phonenumber = faker.phoneNumber().cellPhone();
	//	String name = faker.name().firstName();
	

		String gdfidqw=UUID.randomUUID().toString();
		
		common.Tctype = ExcelReadWrite.getTestcaseType(scenario);
			
		log.info("Testcase Type:", ExcelReadWrite.getTestcaseType(scenario));
		log.info("eventidvalue:", common.eventidvalue);	
		log.info("scenario {}", scenario);
		
		Map<String,Object> dataMap2=Utils.updatedmapUPDATE(sheetName,scenario,common.Tctype,ExcelReadWrite.fetchXLDataNStoreInHashMap(sheetName, scenario,
				"Field_to_be_Updated"),ExcelReadWrite.fetchXLDataNStoreInHashMap(sheetName, scenario,
						"Field_Value"),Common.sourceproviderid);
				
		String jsonTemplatePayload = new String(Files.readAllBytes(Paths.get("src/test/resources/jsonPayloads/provider/providerWithMultipleobjects.json")));
		String payload = JsonUpdateUtil.buildJsonRequestpro(jsonTemplatePayload,dataMap2,ExcelReadWrite.fetchXLDataNStoreInHashMap(sheetName, scenario, Constant.RowstobeDeleted));
		JSONObject payload1 = new JSONObject(payload);		
		
		payload1=JsonUpdateUtil.updateJson(payload1, "eventidvalue", gdfidqw);
			
		Serenity.getCurrentSession().put(Constant.EVENT_ID_VALUE_JSON_PATH, gdfidqw);
		
		
		rest().given().contentType(Constant.CONTENTTYPE)
		.header("Content-Type",Constant.CONTENTTYPE)
		.auth().basic(PropLoader.props.apply("username"), PropLoader.props.apply("password"))
		.when().log().all()
		.body(payload1.toString())
		.post(PropLoader.props.apply("basemcapipath")+PropLoader.props.apply("addproviderapi"));
		
		
	}
	
	
}
