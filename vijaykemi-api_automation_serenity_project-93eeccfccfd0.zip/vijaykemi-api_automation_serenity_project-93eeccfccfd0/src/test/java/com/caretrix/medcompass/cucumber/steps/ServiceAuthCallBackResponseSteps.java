package com.caretrix.medcompass.cucumber.steps;

import static net.serenitybdd.rest.SerenityRest.rest;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;

import com.API.Rest.validations.MedcompassValidations;
import com.mc.TestUtils.Constant;
import com.mc.TestUtils.ExcelReader;
import com.mc.TestUtils.JsonUpdateUtil;
import com.mc.TestUtils.PropLoader;
import com.mc.setup.SetupHeaders;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import io.restassured.response.Response;
import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Steps;

public class ServiceAuthCallBackResponseSteps {
	String addserviceauthuri;
	String serviceAuthMultiLineContent;
	JSONObject serviceAuthMultiLineEventNotification;

	Common common = new Common();
	private static final Logger log = LogManager.getLogger(ServiceAuthCallBackResponseSteps.class);

	@Steps
	private MedcompassValidations validation = new MedcompassValidations();

	@Given("^Setup proxy for a ServiceAuth Request$")
	public void setup_proxy_for_a_Member_Request() throws Throwable {
		SetupHeaders.initialSetupServiceAuth();
	}

	@When("^ServiceAuth requestAddUpd is initiated for \"([^\"]*)\"$")
	public void serviceAuthEventMultipleLinesAddUpd(String scenario) throws Throwable {

		String sheetName= PropLoader.props.apply("ServiceAuthE2ECallBackResponseSHT");
		
		addserviceauthuri = PropLoader.props.apply("mcapihostname") + PropLoader.props.apply("basemcapipath")
				+ PropLoader.props.apply("addserviceauthapi");
		
		String eventid = UUID.randomUUID().toString();
		log.info("addserviceauthuri:" + addserviceauthuri);
		log.info("scenario {}", scenario);
		log.info("eventidvalue {}", eventid);
		Map<String, Object> dataMap = ExcelReader.readAllRow(sheetName, scenario);
		log.info("dataMap {}" + dataMap);
		serviceAuthMultiLineContent = new String(Files.readAllBytes(
				Paths.get("src/test/resources/jsonPayloads/serviceauth/serviceAuthMultipleLineTemplate.json")));
		serviceAuthMultiLineEventNotification = new JSONObject(serviceAuthMultiLineContent);
		String payload = JsonUpdateUtil.buildServiceAuthRequestAdd(serviceAuthMultiLineEventNotification,
				eventid, dataMap);
		Serenity.getCurrentSession().put(Constant.EVENT_ID_VALUE_JSON_PATH, eventid);
		Response immediateResponse = rest().given().contentType(Constant.CONTENTTYPE)
				.header("Content-Type", Constant.CONTENTTYPE).auth().basic(PropLoader.props.apply("username"), PropLoader.props.apply("password")).when()
				.log().all().body(payload).post(addserviceauthuri);
		log.info(immediateResponse.getBody().asString());

	}
	
	@When("^ServiceAuth Updaterequest is initiated for \"([^\"]*)\"$")
	public void serviceAuthEventMultipleLinesUpdaterequest(String scenario) throws Throwable {

		String sheetName= PropLoader.props.apply("ServiceAuthE2ECallBackResponseSHT");
		
		addserviceauthuri = PropLoader.props.apply("mcapihostname") + PropLoader.props.apply("basemcapipath")
				+ PropLoader.props.apply("addserviceauthapi");
		
		String eventid = (String) Serenity.getCurrentSession().get(Constant.EVENT_ID_VALUE_JSON_PATH);

		//String eventidvalue = UUID.randomUUID().toString();
		
		log.info("addserviceauthuri:" + addserviceauthuri);
		log.info("scenario {}", scenario);
		log.info("eventidvalue {}", eventid);
		Map<String, Object> dataMap = ExcelReader.readAllRow(sheetName, scenario);
		log.info("dataMap {}" + dataMap);
		serviceAuthMultiLineContent = new String(Files.readAllBytes(
				Paths.get("src/test/resources/jsonPayloads/serviceauth/serviceAuthMultipleLineTemplate.json")));
		serviceAuthMultiLineEventNotification = new JSONObject(serviceAuthMultiLineContent);
		String payload = JsonUpdateUtil.buildServiceAuthRequestUPD(serviceAuthMultiLineEventNotification,
				eventid,dataMap);
		//Serenity.getCurrentSession().put(Constant.EVENT_ID_VALUE_JSON_PATH, eventid);
		Response immediateResponse = rest().given().contentType(Constant.CONTENTTYPE)
				.header("Content-Type", Constant.CONTENTTYPE).auth().basic(PropLoader.props.apply("username"), PropLoader.props.apply("password")).when()
				.log().all().body(payload).post(addserviceauthuri);
		log.info(immediateResponse.getBody().asString());

	}
	
	@When("^ServiceAuth E2Erequest is initiated for \"([^\"]*)\"$")
	public void serviceAuthEventMultipleLinesE2E(String scenario) throws Throwable {

		String sheetName= PropLoader.props.apply("ServiceAuthE2ECallBackResponseSHT");
		
		addserviceauthuri = PropLoader.props.apply("mcapihostname") + PropLoader.props.apply("basemcapipath")
				+ PropLoader.props.apply("addserviceauthapi");
		
		String eventid = UUID.randomUUID().toString();

		log.info("addserviceauthuri:" + addserviceauthuri);
		log.info("scenario {}", scenario);
		log.info("eventidvalue {}", eventid);
		Map<String, Object> dataMap = ExcelReader.readAllRow(sheetName, scenario);
		log.info("dataMap {}" + dataMap);
		
	//	Serenity.getCurrentSession().get(Constant.SOURCE_PROVIDER_ID_JSON_PATH);
		dataMap.replace("$..serviceauthprovider[0].sourceproviderid", Serenity.getCurrentSession().get(Constant.SOURCE_PROVIDER_ID_JSON_PATH));
		dataMap.replace("$..serviceauthprovider[0].sourceproviderid", Serenity.getCurrentSession().get(Constant.SOURCE_PROVIDER_ID_JSON_PATH));
		dataMap.replace("$..serviceauthprovider[1].sourceproviderid", Serenity.getCurrentSession().get(Constant.SOURCE_PROVIDER_ID_JSON_PATH));
		dataMap.replace("$..serviceauthprovider[2].sourceproviderid", Serenity.getCurrentSession().get(Constant.SOURCE_PROVIDER_ID_JSON_PATH));
		dataMap.replace("$..serviceauthprovider[3].sourceproviderid", Serenity.getCurrentSession().get(Constant.SOURCE_PROVIDER_ID_JSON_PATH));
		dataMap.replace("$..serviceauthprovider[4].sourceproviderid", Serenity.getCurrentSession().get(Constant.SOURCE_PROVIDER_ID_JSON_PATH));
		dataMap.replace("$..serviceauthprovider[5].sourceproviderid", Serenity.getCurrentSession().get(Constant.SOURCE_PROVIDER_ID_JSON_PATH));
		dataMap.replace("$..serviceauthprovider[6].sourceproviderid", Serenity.getCurrentSession().get(Constant.SOURCE_PROVIDER_ID_JSON_PATH));
		dataMap.replace("$..serviceauthprovider[7].sourceproviderid", Serenity.getCurrentSession().get(Constant.SOURCE_PROVIDER_ID_JSON_PATH));
		dataMap.replace("$..serviceauthprovider[8].sourceproviderid", Serenity.getCurrentSession().get(Constant.SOURCE_PROVIDER_ID_JSON_PATH));
		dataMap.replace("$..sourcememberid", Serenity.getCurrentSession().get(Constant.SOURCE_MEMBER_ID_JSON_PATH));
		serviceAuthMultiLineContent = new String(Files.readAllBytes(
				Paths.get("src/test/resources/jsonPayloads/serviceauth/serviceAuthMultipleLineTemplate.json")));
		serviceAuthMultiLineEventNotification = new JSONObject(serviceAuthMultiLineContent);
		String payload = JsonUpdateUtil.buildServiceAuthRequest(serviceAuthMultiLineEventNotification,
				eventid, dataMap);
		
		Serenity.getCurrentSession().put(Constant.EVENT_ID_VALUE_JSON_PATH, eventid);
		Response immediateResponse = rest().given().contentType(Constant.CONTENTTYPE)
				.header("Content-Type", Constant.CONTENTTYPE).auth().basic(PropLoader.props.apply("username"), PropLoader.props.apply("password")).when()
				.log().all().body(payload).post(addserviceauthuri);
		log.info(immediateResponse.getBody().asString());

	}
	

}
