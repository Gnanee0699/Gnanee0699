package com.caretrix.medcompass.cucumber.steps;

import static net.serenitybdd.rest.SerenityRest.rest;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;

import com.API.Rest.validations.MedcompassValidations;
import com.mc.TestUtils.Constant;
import com.mc.TestUtils.ExcelReadWrite;
import com.mc.TestUtils.ExcelTestData;
import com.mc.TestUtils.JsonUpdateUtil;
import com.mc.TestUtils.PropLoader;
import com.mc.setup.SetupHeaders;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Steps;

public class MedcompassSteps {

    Common common = new Common();
    private static final Logger log = LogManager.getLogger(MedcompassSteps.class);

    Map<String, Map<String, String>> dataMap;

    @Steps
    private MedcompassValidations validation = new MedcompassValidations();

    // ######################MEDCOMPASS#############################
    @Given("^Setup proxy for a Provider Request$")
    public void setup_proxy_for_a_Provider_Request() throws Throwable {
        dataMap = ExcelTestData.getTestDataBySheet(PropLoader.props.apply(Constant.EXCEL_FILE_PATH),
            Constant.MC_CLIENT_SHEET_NAME);
        Serenity.getCurrentSession().put(Constant.DATA_MAP, dataMap);
        SetupHeaders.setupRestAssuredDefaultsMedCompassProvider();
    }

    @Given("^Setup proxy for a ServAuth Request$")
    public void setup_proxy_for_a_ServAuth_Request() throws Throwable {
        dataMap = ExcelTestData.getTestDataBySheet(PropLoader.props.apply(Constant.EXCEL_FILE_PATH),
            Constant.MC_CLIENT_SHEET_NAME);
        Serenity.getCurrentSession().put(Constant.DATA_MAP, dataMap);
        SetupHeaders.setupRestAssuredDefaultsMedCompassServAuth();
    }

    @Given("^Setup proxy for a Member Request$")
    public void setup_proxy_for_a_Member_Request() throws Throwable {
        SetupHeaders.setupRestAssuredDefaultsMedCompassMember();
        dataMap = ExcelTestData.getTestDataBySheet(PropLoader.props.apply(Constant.EXCEL_FILE_PATH),
            Constant.MC_CLIENT_SHEET_NAME);
        Serenity.getCurrentSession().put(Constant.DATA_MAP, dataMap);
    }

    /*@Given("^Temp Setup proxy for a Member Request$")
    public void temp_setup_proxy_for_a_member_Request() throws Throwable {
    	SetupHeaders.setupRestAssuredDefaultsMedCompassServAuth();
    	dataMap = ExcelTestData.getTestDataBySheet(PropLoader.props.apply(Constant.EXCEL_FILE_PATH), Constant.MC_CLIENT_SHEET_NAME);
    	Serenity.getCurrentSession().put(Constant.DATA_MAP, dataMap);
    }*/

    @When("^Member Request Type end point is invoked$")
    public void Member_Request_Type_end_point_is_invoked() throws Throwable {
        common.content = new String(
            Files.readAllBytes(Paths.get("src/test/resources/jsonPayloads/member/addMemberFullPayloadSuccess.json")));

        JSONObject jsonEventNotification;
        jsonEventNotification = new JSONObject(common.content);

        JsonUpdateUtil.updateJson(jsonEventNotification, "sourcemembercontactdetailid", "");

        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
                .basic(PropLoader.props.apply("username"), PropLoader.props.apply("password")).when().log().all()
                .body(jsonEventNotification.toString())
                .post(PropLoader.props.apply("basemcapipath") + PropLoader.props.apply("addmemberapi"));

    }

    @When("^Member Request Type memberGenderTranslationMaleToM end point is invoked for the \"([^\"]*)\" and \"([^\"]*)\"$")
    public void memberGenderTranslationMaleToM(String scenario, String sheetName) throws Throwable {

        log.info("*Inputfield value is *"
            + ExcelReadWrite.fetchXLDataNStoreInHashMap(sheetName, scenario, Constant.MemData_Sht_Data_InputValue));

        common.content = new String(
            Files.readAllBytes(Paths.get("src/test/resources/jsonPayloads/member/addMemberFullPayloadSuccess.json")));

        JSONObject jsonEventNotification;
        jsonEventNotification = new JSONObject(common.content);

        jsonEventNotification = JsonUpdateUtil.updateJson(jsonEventNotification,
            ExcelReadWrite.fetchXLDataNStoreInHashMap(sheetName, scenario, Constant.MemData_Sht_InputField),
            ExcelReadWrite.fetchXLDataNStoreInHashMap(sheetName, scenario, Constant.MemData_Sht_Data_InputValue));

        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
                .basic(PropLoader.props.apply("username"), PropLoader.props.apply("password")).when().log().all()
                .body(jsonEventNotification.toString())
                .post(PropLoader.props.apply("basemcapipath") + PropLoader.props.apply("addmemberapi"));

    }

    @When("^ServAuth Request Type servAuthValidation end point is invoked for the \"([^\"]*)\"$")
    public void servAuthValidation(String scenario) throws Throwable {

        log.info("***************Inputfield value is **********",
            dataMap.get(scenario).get(Constant.MemData_Sht_InputField));
        common.content = new String(
            Files.readAllBytes(Paths.get("src/test/resources/jsonPayloads/serviceauth/addServiceAuthSuccess.json")));

        JSONObject jsonEventNotification;
        jsonEventNotification = new JSONObject(common.content);

        jsonEventNotification =
            JsonUpdateUtil.updateJson(jsonEventNotification, dataMap.get(scenario).get(Constant.MemData_Sht_InputField),
                dataMap.get(scenario).get(Constant.MemData_Sht_Data_InputValue));
        if (dataMap.get(scenario).get(Constant.MemData_Sht_Data_InputValue) == "") {
            jsonEventNotification = JsonUpdateUtil.updateJson(jsonEventNotification,
                dataMap.get(scenario).get(Constant.MemData_Sht_InputField), null);
        }
        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
                .basic(PropLoader.props.apply("username"), PropLoader.props.apply("password")).when().log().all()
                .body(jsonEventNotification.toString())
                .post(PropLoader.props.apply("basemcapipath") + PropLoader.props.apply("addserviceauthapi"));

    }

    @When("^Provider Request Type providerValidation end point is invoked for the \"([^\"]*)\"$")
    public void providerValidation(String scenario) throws Throwable {
        common.content = new String(
            Files.readAllBytes(Paths.get("src/test/resources/jsonPayloads/provider/addProviderSuccess.json")));
        JSONObject jsonEventNotification;
        jsonEventNotification = new JSONObject(common.content);

        jsonEventNotification =
            JsonUpdateUtil.updateJson(jsonEventNotification, dataMap.get(scenario).get(Constant.MemData_Sht_InputField),
                dataMap.get(scenario).get(Constant.MemData_Sht_Data_InputValue));
        if (dataMap.get(scenario).get(Constant.MemData_Sht_Data_InputValue) == "") {
            jsonEventNotification = JsonUpdateUtil.updateJson(jsonEventNotification,
                dataMap.get(scenario).get(Constant.MemData_Sht_InputField), null);
        }
        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
                .basic(PropLoader.props.apply("username"), PropLoader.props.apply("password")).when().log().all()
                .body(jsonEventNotification.toString())
                .post(PropLoader.props.apply("basemcapipath") + PropLoader.props.apply("addproviderapi"));

    }

    @When("^Member Request Type memberValidation end point is invoked for the \"([^\"]*)\"$")
    public void memberValidation(String scenario) throws Throwable {

        log.info("***************Scenario ********** {} ", scenario);
        log.info("***************Inputfield value is ********** {} ",
            dataMap.get(scenario).get(Constant.MemData_Sht_InputField));
        common.content = new String(
            Files.readAllBytes(Paths.get("src/test/resources/jsonPayloads/member/addMemberFullPayloadSuccess.json")));
        JSONObject jsonEventNotification;
        jsonEventNotification = new JSONObject(common.content);

        jsonEventNotification =
            JsonUpdateUtil.updateJson(jsonEventNotification, dataMap.get(scenario).get(Constant.MemData_Sht_InputField),
                dataMap.get(scenario).get(Constant.MemData_Sht_Data_InputValue));
        if (dataMap.get(scenario).get(Constant.MemData_Sht_Data_InputValue) == "") {
            jsonEventNotification = JsonUpdateUtil.updateJson(jsonEventNotification,
                dataMap.get(scenario).get(Constant.MemData_Sht_InputField), null);

        }
        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
                .basic(PropLoader.props.apply("username"), PropLoader.props.apply("password")).when().log().all()
                .body(jsonEventNotification.toString())
                .post(PropLoader.props.apply("basemcapipath") + PropLoader.props.apply("addmemberapi"));

    }

}
