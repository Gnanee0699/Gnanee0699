package com.caretrix.medcompass.cucumber.steps;

public class Common {

	
	public String content;
	//public String sheetname;
	//public String scenario;
	//public String Input_Field;
	//public String Input_Value;
	public String Expected_Field;
	public String Expected_Value;
	public int Status_Code;
	public String env;
	public String excelFilePath;
	//public String Username;
	//public String Password;
	
	public int statusCode;
	public String inputField;
	public String inputValue;
	public String expectedField;
	public String expectedValue;
	
	public String eventidvalue;
	public String updatefield;
	public String updatefieldvalue;
	//public String TestScenario;
	public static String Tctype;
	public static String sourceproviderid;
	public static String sourcememberid;

	
}
