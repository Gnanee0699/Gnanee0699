package com.caretrix.medcompass.cucumber.steps;

import com.API.Rest.validations.MedcompassValidations;
import com.jayway.jsonpath.JsonPath;
import com.mc.TestUtils.Constant;
import com.mc.TestUtils.ExcelReadWrite;
import com.mc.TestUtils.ExcelTestData;
import com.mc.TestUtils.PropLoader;

import static io.restassured.RestAssured.given;
import static net.serenitybdd.rest.SerenityRest.rest;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.assertj.core.api.SoftAssertions;
import org.awaitility.Awaitility;
import org.awaitility.Duration;

import cucumber.api.java.en.Then;
import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Steps;

import io.restassured.response.Response;

public class MedcompassStepsValidations {

	Common common = new Common();
	private static final Logger log = LogManager.getLogger(MedcompassStepsValidations.class);
	public SoftAssertions softAssertions;
	
	@SuppressWarnings("unchecked")
	Map<String,Map<String, String>> dataMap= (Map<String,Map<String, String>>)Serenity.getCurrentSession().get(Constant.DATA_MAP); 
	
	@Steps
	private MedcompassValidations validation = new MedcompassValidations();

	@Then("^Validate Response code for the \"([^\"]*)\"$")
	public void Validate_Response_code_is(String scenario) throws Throwable {
		validation.validatestatuscode(Integer
				.parseInt(dataMap.get(scenario).get(Constant.STATUS_CODE)));
	}

	@SuppressWarnings("unchecked")
	@Then("^Validate the field in ResponseBody for the \"([^\"]*)\"$")
	public void Validate_the_field_in_ResponseBody_for_the(String scenario) throws Throwable {
		dataMap = (Map<String,Map<String, String>>)Serenity.getCurrentSession().get(Constant.DATA_MAP);
		validation.validatefieldinResponsebody(dataMap.get(scenario).get(Constant.MemData_Sht_Data_ExpectedField), 
											   dataMap.get(scenario).get(Constant.MemData_Sht_Data_ExpectedValue));
	}
	
	@Then("^Validate the field in CallBackE2ERequestsResponseBody for the \"([^\"]*)\" and \"([^\"]*)\"$")
	public void Validate_the_field_in_CallBackE2ERequestsResponseBody_for_the(String scenario, String sheetName) throws Throwable {

		validation.validatefieldinCallBackResponsebody(ExcelReadWrite.fetchXLDataNStoreInHashMap(sheetName, scenario,
				"ExpectedField"), ExcelReadWrite.fetchXLDataNStoreInHashMap(sheetName, scenario,
						"ErrorMessage"));

	}

	@Then("^Validate the Errorfield in MandatoryandOptionalFieldErrorValidation for the \"([^\"]*)\"$")    
    public void Validate_the_Errorfield_in_MandatoryandOptionalFieldErrorValidation_for_the(String scenario) throws Throwable {
          validation.validateErrorfieldinMcClientResponsebody(dataMap.get(scenario).get(Constant.MemData_Sht_Data_ExpectedField), 
						   									  dataMap.get(scenario).get(Constant.MemData_Sht_Data_ExpectedValue));
	}

	@Then("^Validate Success Response code$")
	public void validate_Response_Code() throws Throwable {
		validation.validatestatuscode(200);
	}

	@Then("^Validate Success Response Body$")
	public void validate_Response_Body() throws Throwable {
		validation.validateResponsebody("OK");
	}

	@Then("^Validate CallBack Response$")
	public void validate_CallBack_Response() throws Throwable {
		
		softAssertions = new SoftAssertions();
		
		// Poll interval of 10 second with an initial delay of 10 seconds and
		// Max timeout after 3 minutes.60 *3=180 seconds
		String eventresponseuri = PropLoader.props.apply("mcapihostname") + PropLoader.props.apply("basemcapipath")
				+ PropLoader.props.apply("eventnotification");

		String callbackUri=eventresponseuri + Serenity.getCurrentSession().get(Constant.EVENT_ID_VALUE_JSON_PATH);
		
		log.info("callback url is:" + callbackUri);
		Awaitility.with().ignoreExceptions().pollInterval(Duration.ONE_SECOND.multiply(10)).and().with()
				.pollDelay(
						Duration.TWO_SECONDS.multiply(5))
				.await().timeout(Duration.ONE_MINUTE.multiply(3))
				.untilAsserted(() -> 
				softAssertions
						.assertThat(given().contentType(Constant.CONTENTTYPE).when()
						.get(callbackUri).then().extract().body().jsonPath()
						.getList("responses.errorobjectlist").size()).isEqualTo(0)
		);
				
		//This is to print the call back URL in the report
		rest().given().contentType(Constant.CONTENTTYPE)
		.header("Content-Type",Constant.CONTENTTYPE)
		.when().get(callbackUri);
		
		softAssertions.assertAll();
	}
	
	@Then("^Validate CallBack with oneerror Response$")
	public void validate_CallBack_Response_with_oneerror() throws Throwable {
		
		softAssertions = new SoftAssertions();
		
		// Poll interval of 10 second with an initial delay of 10 seconds and
		// Max timeout after 3 minutes.60 *3=180 seconds
		String eventresponseuri = PropLoader.props.apply("mcapihostname") + PropLoader.props.apply("basemcapipath")
				+ PropLoader.props.apply("eventnotification");

		String callbackUri=eventresponseuri + Serenity.getCurrentSession().get(Constant.EVENT_ID_VALUE_JSON_PATH);
		
		log.info("callback url is:" + callbackUri);
		Awaitility.with().ignoreExceptions().pollInterval(Duration.ONE_SECOND.multiply(10)).and().with()
				.pollDelay(
						Duration.TWO_SECONDS.multiply(5))
				.await().timeout(Duration.ONE_MINUTE.multiply(3))
				.untilAsserted(() -> 
				softAssertions
						.assertThat(given().contentType(Constant.CONTENTTYPE).when()
						.get(callbackUri).then().extract().body().jsonPath()
						.getList("responses.errorobjectlist").size()).isEqualTo(1)
		);
				
		//This is to print the call back URL in the report
		rest().given().contentType(Constant.CONTENTTYPE)
		.header("Content-Type",Constant.CONTENTTYPE)
		.when().get(callbackUri);
		
		softAssertions.assertAll();
	}
	
	@Then("^Validate MC Member Response \"([^\"]*)\"$")
	public void validate_MC_Member(String Membergdfic) throws Throwable {
		String eventresponseuri = "https://d-mc-qa-automation.ccx.carecentrix.com/mcapi/get/member?SourceMemberID=" + Membergdfic;
		log.info("callback url is:" + eventresponseuri);
		Response response= rest().given().contentType(Constant.CONTENTTYPE)
		.header("Content-Type",Constant.CONTENTTYPE)
		.when().get(eventresponseuri);
		assertEquals(Serenity.getCurrentSession().get("zipcode"), JsonPath.parse(response.body().asString()).read("$.mcResponse.member.memberpostaladdress[0].zipcode"));
		assertEquals(Serenity.getCurrentSession().get("state"), JsonPath.parse(response.body().asString()).read("$.mcResponse.member.memberpostaladdress[0].stateorregion"));
		
	}
		
}
