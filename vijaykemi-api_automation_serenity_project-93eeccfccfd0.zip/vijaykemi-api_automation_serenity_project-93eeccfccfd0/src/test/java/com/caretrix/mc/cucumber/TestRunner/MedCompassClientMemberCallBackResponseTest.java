package com.caretrix.mc.cucumber.TestRunner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import net.thucydides.junit.annotations.Concurrent;

@Concurrent(threads = "4X")
//@UseTestDataFrom("")
@RunWith(CucumberWithSerenity.class)
@CucumberOptions(features = "src/test/resources/feature/", strict = true, tags = {
		"@MedCompassMemberCallBack"
		//"@TC_001_Member_Enrollment"
// "@TC_001_Member_Enrollment,@TC_002_Member_Enrollment"
		//"@TC_001_ProviderCallBackE2EUPDATERequests"
	//	"@TC_001_MedCompassMemberCallBack"
}, glue = "com/carecentrix/medcompass/cucumber/steps")

public class MedCompassClientMemberCallBackResponseTest {

}
