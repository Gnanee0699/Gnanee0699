package com.caretrix.mc.steps.dho.serviceauth;

import static io.restassured.RestAssured.given;

import static net.serenitybdd.rest.SerenityRest.rest;
import static net.serenitybdd.rest.SerenityRest.then;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import java.text.SimpleDateFormat;
import java.util.Date;

import static org.assertj.core.api.Assertions.assertThat;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.assertj.core.condition.Not;
import org.awaitility.Awaitility;
import org.awaitility.Duration;
import org.hamcrest.Matchers;

import com.jayway.jsonpath.JsonPath;
import com.mc.TestUtils.Constant;
import com.mc.TestUtils.PropLoader;
import com.mc.setup.SetupHeaders;

import cucumber.api.java.en.Then;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import net.minidev.json.JSONArray;
import net.serenitybdd.core.Serenity;

public class ServiceAuthInitiatorStepsValidation {

    private static final Logger log = LogManager.getLogger(ServiceAuthInitiatorStepsValidation.class);

    @Then("^Validate Event Status for the Service Auth Initiator event \"([^\"]*)\"$")
    public void validate_Status_code_for_the_Service_Auth_Initiator_event(String eventStatus) throws Throwable {
        String dhoeventuri = PropLoader.props.apply("dhoapihost") + PropLoader.props.apply("dhoevent")
            + Serenity.getCurrentSession().get(Constant.CASEID);
        log.info("dho event url :" + dhoeventuri);
        // Initially waiting for 5 seconds and for Poll interval of 2 seconds.Max Timeout is 2min
        Awaitility.with().pollInterval(Duration.FIVE_SECONDS).and().with().pollDelay(Duration.FIVE_SECONDS).await()
                .timeout(Duration.TWO_MINUTES)
                .untilAsserted(() -> assertThat(
                    JsonPath.parse(JsonPath.parse(given().contentType(ContentType.JSON).when().get(dhoeventuri)
                            .getBody().jsonPath().getList(".").get(0)).jsonString()).read(Constant.TXNSTATUS),
                    containsString(eventStatus))

        );
        
        Response response=given().contentType(ContentType.JSON).when().get(dhoeventuri);
        String txnStatus = (JsonPath.parse(JsonPath.parse(response
                .getBody().jsonPath().getList(".").get(0)).jsonString()).read(Constant.TXNSTATUS));
        log.info("TXN_STAT_DESC:" + txnStatus);
        
        String EVENT_GUID = (JsonPath.parse(JsonPath.parse(response
                .getBody().jsonPath().getList(".").get(0)).jsonString()).read(Constant.EVENTGUID));
        Serenity.getCurrentSession().put(Constant.EVENTGUID, EVENT_GUID);
        // This is to print the event status response URL in the report
        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).when()
                .get(dhoeventuri);
    }

    @Then("^Validate Event Status Response Code for the Service Auth Initiator event \"([^\"]*)\"$")
    public void validate_Event_status_response_code_for_the_Service_Auth_Initiator_event(String responseCode)
        throws Throwable {

        // Poll interval of 10 second with an initial delay of 10 seconds and
        // Max timeout after 3 minutes.60 *3=180 seconds
        String dhoeventuri = PropLoader.props.apply("dhoapihost") + PropLoader.props.apply("dhoevent")
            + Serenity.getCurrentSession().get(Constant.CASEID);
        log.info("dho event url :" + dhoeventuri);

        Awaitility.with().pollInterval(Duration.ONE_SECOND.multiply(1)).and().with()
                .pollDelay(Duration.ONE_SECOND.multiply(1)).await().timeout(Duration.ONE_SECOND.multiply(10))
                .untilAsserted(() -> assertThat(given().contentType(ContentType.JSON).when().get(dhoeventuri).then()
                        .statusCode(Integer.parseInt(responseCode)))

        );
        // This is to print the event status response URL in the report
        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).when()
                .get(dhoeventuri);

    }

    @Then("^Validate RetryFlag for the Service Auth \"([^\"]*)\"$")
    public void validate_EventTopic_RetryFlag_for_the_Service_Auth(String retryFlag) throws Throwable {
        SetupHeaders.initialSetupDHORequest();
        String dhoeventuri = PropLoader.props.apply("dhoapihost") + PropLoader.props.apply("dhoevent")
            + Serenity.getCurrentSession().get(Constant.CASEID);
        log.info("dho event url :" + dhoeventuri);
        Response response = given().contentType(ContentType.JSON).when().get(dhoeventuri);
                    
        assertThat(JsonPath.parse(JsonPath.parse(response.getBody().jsonPath().getList(".").get(0)).jsonString())
                .read(Constant.RETRYFLAG), containsString(retryFlag));
    }

    @Then("^Validate Topic and Status for the ServiceAuth event \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void validateTopicAndStatus(String eventStatus, String topicName, String retryFlag,
        String retryCount) {
        String dhoeventuri = PropLoader.props.apply("dhoapihost") + PropLoader.props.apply("dhoevent")
            + Serenity.getCurrentSession().get(Constant.CASEID);
        log.info("dho event url :" + dhoeventuri);
        int timeout = Integer.parseInt(PropLoader.props.apply("manualretrytimeoutseconds"));
        Awaitility.with().pollInterval(Duration.TWO_SECONDS).and().with().pollDelay(Duration.ONE_SECOND.multiply(40))
                .await().timeout(Duration.ONE_SECOND.multiply(timeout))
                .untilAsserted(() -> assertThat(
                    JsonPath.parse(JsonPath.parse(given().contentType(ContentType.JSON).when().get(dhoeventuri)
                            .getBody().jsonPath().getList(".").get(0)).jsonString()).read(Constant.TOPICNAME),
                    containsString(topicName)));
        
        Awaitility.with().pollInterval(Duration.TWO_SECONDS).and().with().pollDelay(Duration.ONE_SECOND.multiply(10))
        .await().timeout(Duration.ONE_SECOND.multiply(30))
        .untilAsserted(() -> assertThat(
            JsonPath.parse(JsonPath.parse(given().contentType(ContentType.JSON).when().get(dhoeventuri)
                    .getBody().jsonPath().getList(".").get(0)).jsonString()).read(Constant.TXNSTATUS),
            containsString(eventStatus)));

        Response response = given().contentType(ContentType.JSON).when().get(dhoeventuri);

        assertThat(JsonPath.parse(JsonPath.parse(response.getBody().jsonPath().getList(".").get(0)).jsonString())
                .read(Constant.RETRYFLAG).toString(), containsString(retryFlag));

        assertThat(JsonPath.parse(JsonPath.parse(response.getBody().jsonPath().getList(".").get(0)).jsonString())
                .read(Constant.RETRYCOUNT).toString(), containsString(retryCount));
        // This is to print the event status response URL in the report
        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).when()
                .get(dhoeventuri);

    }

    @Then("^Invoke Delete SA Initiator event for the CaseID and Validate Response Code\"([^\"]*)\"$")
    public void validate_Event_status__response_code_for_the_delete_Member_Inititor_event(String responseCode)
        throws Throwable {
        // Poll interval of 10 second with an initial delay of 10 seconds and
        // Max timeout after 3 minutes.60 *3=180 seconds
        String dhoeventuri = PropLoader.props.apply("dhoapihost") + PropLoader.props.apply("dhodeleteevent")
            + Serenity.getCurrentSession().get(Constant.CASEID);
        log.info("dho event url :" + dhoeventuri);

        Awaitility.with().pollInterval(Duration.ONE_SECOND.multiply(5)).and().with()
                .pollDelay(Duration.ONE_SECOND.multiply(1)).await().timeout(Duration.ONE_SECOND.multiply(10))
                .untilAsserted(() -> assertThat(given().contentType(ContentType.JSON).when().delete(dhoeventuri).then()
                        .statusCode(Integer.parseInt(responseCode)))

        );

    }
    
    @Then("^Validate New Event not triggered for Member or Provider event \"([^\"]*)\" and status \"([^\"]*)\"$")
    public void validateMemberOrProviderEvent(String eventName, String Status)
        throws Throwable {
    	
    	String dhoeventuri;
    	 
        if (eventName.contains("MEMBER"))
        {   
        	dhoeventuri = PropLoader.props.apply("dhoapihost") + PropLoader.props.apply("dhoevent")
            + Serenity.getCurrentSession().get(Constant.SA_MEMBERGDFID);
        }
        else {
        	
        	dhoeventuri = PropLoader.props.apply("dhoapihost") + PropLoader.props.apply("dhoevent")
            + Serenity.getCurrentSession().get(Constant.SA_PROVIDERGDFID);
        }
        
        log.info("dho event url :" + dhoeventuri);
        String todayDate;
        String strDateFormat = "yyyy-MM-dd"; //Date format is Specified
        SimpleDateFormat objSDF = new SimpleDateFormat(strDateFormat);
        todayDate = objSDF.format(new Date());
        
        Response response = given().contentType(ContentType.JSON).when().get(dhoeventuri);

        assertThat(JsonPath.parse(JsonPath.parse(response.getBody().jsonPath().getList(".").get(0)).jsonString())
                .read(Constant.TXNSTATUS), containsString(Status));
        assertThat(JsonPath.parse(JsonPath.parse(response.getBody().jsonPath().getList(".").get(0)).jsonString())
                .read(Constant.EventCreatedTS), Matchers.not(Matchers.containsString(todayDate)));
        
     // This is to print the event status response URL in the report
        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).when()
                .get(dhoeventuri);
        
    }
    
    @Then("^Capture SA MC Payload for secondary Key objects status \"([^\"]*)\" and verify \"([^\"]*)\"$")
    public void captureMCPayloadData(String status, String strVerify) throws Throwable {
        String dhoeventuri = PropLoader.props.apply("mcapihostname") + PropLoader.props.apply("dhomcsentpayload")
            + Serenity.getCurrentSession().get(Constant.CASEID);
        log.info("dho event url :" + dhoeventuri);

        Awaitility.with().pollInterval(Duration.ONE_SECOND.multiply(1)).and().with()
                .pollDelay(Duration.ONE_SECOND.multiply(1)).await().timeout(Duration.ONE_SECOND.multiply(30))
                .untilAsserted(() -> assertThat(given().contentType(ContentType.JSON).when().get(dhoeventuri).then()
                        .statusCode(200)));
        
        Response response = rest().given().contentType(Constant.CONTENTTYPE)
                .header("Content-Type", Constant.CONTENTTYPE).when().get(dhoeventuri);
        // Assert.equal
        String responseBody = response.getBody().prettyPrint();
        JSONArray arrsourcelob = JsonPath.parse(responseBody).read(Constant.SOURCEMEMBER_LOBInsurance);
        String strSourcelob = (String) arrsourcelob.get(0);
        log.info("resppnseBody:" + responseBody);
        log.info("Sourcememberlob:" + strSourcelob);
        
        if(status.contains("SAVE"))
        {
	        Serenity.getCurrentSession().put(Constant.SOURCEMEMBER_LOBInsuranceID, strSourcelob);
	        log.info("Sourcememberlob:" + Serenity.getCurrentSession().get(Constant.SOURCEMEMBER_LOBInsuranceID));
        }
        else
        {
        	if(strVerify.contains("Equal"))
        	{
        		 log.info("FirstRequest SourcememberlobInsurance :" + Serenity.getCurrentSession().get(Constant.SOURCEMEMBER_LOBInsuranceID));
                 log.info("SecondRequest SourcememberlobInsurance :" + strSourcelob);
        		assertEquals(Serenity.getCurrentSession().get(Constant.SOURCEMEMBER_LOBInsuranceID), strSourcelob);
        		
        	}
        	else
        	{
        		log.info("FirstRequest SourcememberlobInsurance :" + Serenity.getCurrentSession().get(Constant.SOURCEMEMBER_LOBInsuranceID));
                log.info("SecondRequest SourcememberlobInsurance :" + strSourcelob);
        		assertFalse(((String)Serenity.getCurrentSession().get(Constant.SOURCEMEMBER_LOBInsuranceID)).contentEquals(strSourcelob));
        	}
        }
   

    } 

}
