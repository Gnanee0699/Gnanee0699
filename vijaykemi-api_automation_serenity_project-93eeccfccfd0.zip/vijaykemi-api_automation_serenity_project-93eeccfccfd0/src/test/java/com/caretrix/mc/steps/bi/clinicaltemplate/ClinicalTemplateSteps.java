package com.caretrix.mc.steps.bi.clinicaltemplate;

import static io.restassured.RestAssured.given;
import static net.serenitybdd.rest.SerenityRest.rest;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.awaitility.Awaitility;
import org.awaitility.Duration;

import com.API.Rest.validations.MedcompassValidations;
import com.jayway.jsonpath.JsonPath;
import com.mc.TestUtils.Constant;
import com.mc.TestUtils.ExcelTestData;
import com.mc.TestUtils.JsonUpdateUtil;
import com.mc.TestUtils.PropLoader;
import com.mc.setup.SetupHeaders;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import net.minidev.json.JSONArray;
import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Steps;

public class ClinicalTemplateSteps {

    private static final Logger log = LogManager.getLogger(ClinicalTemplateSteps.class);

    private static final String biClinicalTemplateJsonPath =
        "src/test/resources/jsonPayloads/bi/BIClinicalTemplate.json";

    Map<String, Map<String, String>> dataMap;

    @Steps
    private MedcompassValidations validation = new MedcompassValidations();

    @Given("^Clinical Template Add event to MC resulting from a Service Auth event$")
    public void setup_proxy_for_a_Provider_Request() throws Throwable {
        SetupHeaders.initialSetup("dhoapihost");
    }

    @When("^Add Clinical Template request from UDH is triggered \"([^\"]*)\"$")
    public void updateProviderRequest(String scenario) throws Throwable {
        String payload = getProviderPayLoad(scenario, PropLoader.props.apply("BIClinicalTemplatesheet"));
        JSONArray arrCaseID = JsonPath.parse(payload).read(Constant.CASEIDJSON);
        String strCaseID = (String) arrCaseID.get(0);
        Serenity.getCurrentSession().put(Constant.CASEID, strCaseID);
        log.info("CaseID is:", Serenity.getCurrentSession().get(Constant.CASEID));
        log.info("Clinical Template add URL", PropLoader.props.apply("biclinicaltemplateapi"));
        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
                .basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password)).when()
                .log().all().body(payload).post(PropLoader.props.apply("biclinicaltemplateapi"));

    }

    @Then("^Validation of Event Status Details for the Clinical Template event\"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void validation_Event_status_response_code_for_the_ClinicalTemplate_event(String scenario,
        String responseCode, String eventStatus) throws Throwable {
        String payload = getProviderPayLoad(scenario, PropLoader.props.apply("BIClinicalTemplatesheet"));
        JSONArray arrCaseID = JsonPath.parse(payload).read(Constant.CASEIDJSON);
        String strCaseID = (String) arrCaseID.get(0);
        // Max Time Out-20 min
        int timeout = Integer.parseInt(PropLoader.props.apply("biclinicalTemplatetimeoutinminutes"));
        // Verification of Status Code
        String biClinTempEventUri =
            PropLoader.props.apply("dhoapihost") + PropLoader.props.apply("getBIClinicaltemplate") + strCaseID;
        log.info("BI ClinicalTemplate event url :" + biClinTempEventUri);

        Awaitility.with().pollInterval(Duration.TEN_SECONDS.multiply(2)).and().with()
                .pollDelay(Duration.TEN_SECONDS.multiply(1)).await().timeout(Duration.ONE_MINUTE.multiply(timeout))
                .untilAsserted(() -> assertThat(given().contentType(ContentType.JSON).when().get(biClinTempEventUri)
                        .then().statusCode(Integer.parseInt(responseCode)))

        );
        // Verification of Status
        Response response = given().contentType(ContentType.JSON).when().get(biClinTempEventUri);
        String txnStatus =
            (JsonPath.parse(JsonPath.parse(response.getBody().jsonPath().getList(".").get(0)).jsonString())
                    .read(Constant.BI_CLINTEMP_STATUS));
        log.info("TXN_STAT_DESC:" + txnStatus);

        // Max Time Out-20 min
        Awaitility.with().pollInterval(Duration.TWO_SECONDS).and().with().pollDelay(Duration.TWO_SECONDS.multiply(1))
                .await().timeout(Duration.ONE_MINUTE.multiply(timeout))
                .untilAsserted(() -> assertThat(
                    JsonPath.parse(JsonPath.parse(given().contentType(ContentType.JSON).when().get(biClinTempEventUri)
                            .getBody().jsonPath().getList(".").get(0)).jsonString()).read(Constant.BI_CLINTEMP_STATUS),
                    containsString(eventStatus))

        );

        log.info("TXN_STAT_DESC PASSED:");
        // This is to print the event status response URL in the report
        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).when()
                .get(biClinTempEventUri);

        String lineGDFID =
            (JsonPath.parse(JsonPath.parse(response.getBody().jsonPath().getList(".").get(0)).jsonString())
                    .read(Constant.BI_CLINTEMP_LN_GDFID));

        String expLineID = strCaseID + "-001";
        String fileSentName =
            (JsonPath.parse(JsonPath.parse(response.getBody().jsonPath().getList(".").get(0)).jsonString())
                    .read(Constant.BI_CLINTEMP_FILENAME));
        String successFlag =
            (JsonPath.parse(JsonPath.parse(response.getBody().jsonPath().getList(".").get(0)).jsonString())
                    .read(Constant.BI_CLINTEMP_SUCCESS_FLAG));
        assertThat(lineGDFID).isNotEmpty();
        log.info("lineGDFID is not empty");
        assertThat(lineGDFID, containsString(expLineID));
        log.info("lineGDFID:" + lineGDFID);

        // Delete the records
        if (txnStatus.contains("CANCELLED")) {
            String biClinTempDeleteEventUri = PropLoader.props.apply("dhoapihost")
                + PropLoader.props.apply("deleteBICancelledClinicaltemplate") + strCaseID;
            log.info("BI ClinicalTemplate Cancelled status Delete event url :" + biClinTempDeleteEventUri);

            Awaitility.with().pollInterval(Duration.ONE_SECOND.multiply(2)).and().with()
                    .pollDelay(Duration.ONE_SECOND.multiply(1)).await().timeout(Duration.ONE_SECOND.multiply(10))
                    .untilAsserted(() -> assertThat(given().contentType(ContentType.JSON).when()
                            .delete(biClinTempDeleteEventUri).then().statusCode(Integer.parseInt(responseCode)))

            );
        } else if (!txnStatus.contains("PENDING")) {
            // File name and success flag is null when status it pending.It is not null for success,errored
            assertThat(fileSentName).isNotEmpty();
            log.info("fileSentName:" + fileSentName);
            Serenity.getCurrentSession().put(Constant.BI_CLINTEMP_FILESENTNAME, fileSentName);
            assertThat(successFlag).isNotEmpty();
            log.info("successFlag:" + successFlag);
        }

        // DeleteApi for all Pending,Success and Errored to use the same data for automation.Cancelled has different API
        String biClinTempDeleteEventUri =
            PropLoader.props.apply("dhoapihost") + PropLoader.props.apply("deleteBIClinicaltemplate") + strCaseID;
        log.info("BI ClinicalTemplate Delete event url :" + biClinTempDeleteEventUri);
        Awaitility.with().pollInterval(Duration.ONE_SECOND.multiply(2)).and().with()
                .pollDelay(Duration.ONE_SECOND.multiply(1)).await().timeout(Duration.ONE_SECOND.multiply(10))
                .untilAsserted(() -> assertThat(given().contentType(ContentType.JSON).when()
                        .delete(biClinTempDeleteEventUri).then().statusCode(Integer.parseInt(responseCode)))

        );

    }

    private String getProviderPayLoad(String scenario, String sheetname) throws IOException {
        dataMap = ExcelTestData.getTestDataBySheet(PropLoader.props.apply(Constant.BI_CLINICALTEMPLATE_EXCEL_PATH),
            Constant.BI_CLINICALTEMPLATE_SHEET_NAME);
        Serenity.getCurrentSession().put(Constant.DATA_MAP, dataMap);
        Map<String, Object> scenarioDataMap = new HashMap<>(dataMap.get(scenario));
        String jsonTemplatePayload = new String(Files.readAllBytes(Paths.get(biClinicalTemplateJsonPath)));
        String payload = JsonUpdateUtil.buildJsonRequest(jsonTemplatePayload, scenarioDataMap, "BIClinicalTemplate");
        return payload;
    }

}
