package com.caretrix.mc.steps.dho.member;

import static net.serenitybdd.rest.SerenityRest.rest;
import static org.junit.Assert.*;
import static junit.framework.Assert.assertNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.awaitility.Awaitility;
import org.awaitility.Duration;

import com.jayway.jsonpath.JsonPath;
import com.mc.TestUtils.Constant;
import com.mc.TestUtils.PropLoader;

import cucumber.api.java.en.Then;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import net.minidev.json.JSONArray;
import net.serenitybdd.core.Serenity;



public class MemberTemplateEngineStepsValidation {

    private static final Logger log = LogManager.getLogger(MemberTemplateEngineStepsValidation.class);

    @Then("^Validate Member DHO Payload and MC Payload for object \"([^\"]*)\"$")
    public void validate_Status_code_for_the_Member_Initiator_event(String scenario) throws Throwable {
        String dhoeventuri = PropLoader.props.apply("mcapihostname") + PropLoader.props.apply("dhomcsentpayload")
            + Serenity.getCurrentSession().get(Constant.GDFID);
        log.info("dho event url :" + dhoeventuri);

        Awaitility.with().pollInterval(Duration.ONE_SECOND.multiply(1)).and().with()
                .pollDelay(Duration.ONE_SECOND.multiply(1)).await().timeout(Duration.ONE_SECOND.multiply(10))
                .until(() -> isStatus(dhoeventuri));

        Response response = rest().given().contentType(Constant.CONTENTTYPE)
                .header("Content-Type", Constant.CONTENTTYPE).when().get(dhoeventuri);
        // Assert.equal
        String responseBody = response.getBody().prettyPrint();

        log.info("resppnseBody:" + responseBody);

       // assertEquals(true, validateFieldValues(response.getBody().asString(), scenario));
        validateFieldValues(response.getBody().asString(), scenario);
    }
    
    @Then("^Validate MC Payload doesnot contain object \"([^\"]*)\"$")
    public void validate_MCPayload_doesnot_contain_field(String scenario) throws Throwable {
        String dhoeventuri = PropLoader.props.apply("mcapihostname") + PropLoader.props.apply("dhomcsentpayload")
            + Serenity.getCurrentSession().get(Constant.GDFID);
        log.info("dho event url :" + dhoeventuri);

        Awaitility.with().pollInterval(Duration.ONE_SECOND.multiply(1)).and().with()
                .pollDelay(Duration.ONE_SECOND.multiply(1)).await().timeout(Duration.ONE_SECOND.multiply(10))
                .until(() -> isStatus(dhoeventuri));

        Response response = rest().given().contentType(Constant.CONTENTTYPE)
                .header("Content-Type", Constant.CONTENTTYPE).when().get(dhoeventuri);
        // Assert.equal
        String responseBody = response.getBody().prettyPrint();

        log.info("resppnseBody:" + responseBody);

       
        validateFieldNotPresent(response.getBody().asString(), scenario);
    }

    private Boolean isStatus(String url) {
        Response response = RestAssured.given().when().get(url);
        return response.then().extract().statusCode() == 200;
    }

    @SuppressWarnings("unchecked")
    private void validateFieldValues(String response, String scenario) {
        Map<String, Map<Object, Object>> dataMap;
        dataMap = (Map<String, Map<Object, Object>>) Serenity.getCurrentSession().get(Constant.DATA_MAP);
        List<String> dataList = new ArrayList<>();
        List<String> valueList = new ArrayList<>();
        for (Entry<String, Map<Object, Object>> mainmapentry : dataMap.entrySet()) {
            try {
                // log.info("dataMap" + dataMap);
                Map<Object, Object> map = null;
                if (mainmapentry.getKey().contains(scenario)) {
                    map = mainmapentry.getValue();
                }
                String dhoValue = "";
                String mcValue = "";
                for (Map.Entry<Object, Object> entry : map.entrySet()) {
                    if (entry.getKey() != null && entry.getKey().equals("ExpectedField")) {
                        if (entry.getValue() != null) {
                            List<String> list = JsonPath.parse(response).read(entry.getValue().toString());
                            if (!list.isEmpty()) {
                                dhoValue = list.get(0).toString();
                                dataList.add(list.get(0).toString());
                            }
                        }
                    } else if (entry.getKey() != null && entry.getKey().equals("ExpectedValue")) {
                        if (entry.getValue() != null) {
                            mcValue = entry.getValue().toString();
                            valueList.add(entry.getValue().toString());
                        }
                    }

                }
               // if (!dhoValue.isEmpty() && !mcValue.isEmpty() && !dhoValue.equals(mcValue)) {
                //    return false;
                               // }
               // assertEquals(mcValue,dhoValue);

            } catch (Exception e) {
                log.info(e, e);
            }
        }
        log.info("dataList" + dataList);
        log.info("valueList" + valueList);
        //return true;
    assertEquals(valueList,dataList);
    }
    
    
 
    @SuppressWarnings({ "unchecked", "deprecation" })
	private void validateFieldNotPresent(String response, String scenario) {
        Map<String, Map<Object, Object>> dataMap;
        dataMap = (Map<String, Map<Object, Object>>) Serenity.getCurrentSession().get(Constant.DATA_MAP);
        
        for (Entry<String, Map<Object, Object>> mainmapentry : dataMap.entrySet()) {
            try {
                // log.info("dataMap" + dataMap);
                Map<Object, Object> map = null;
                if (mainmapentry.getKey().contains(scenario)) {
                    map = mainmapentry.getValue();
                }
                else {}
                for (Map.Entry<Object, Object> entry : map.entrySet()) {
                    if (entry.getKey() != null && entry.getKey().equals("ExpectedField")) {
                        if (entry.getValue() != null) {
                        	assertNull(JsonPath.parse(response).read(entry.getValue().toString()));
                        	  }
                        }
                    } 

                }
             
            catch (Exception e) {
                log.info(e, e);
            }
        }
       
    }
    
    @Then("^Capture MC Payload for secondary Key objects \"([^\"]*)\"$")
    public void validate_Status_code_for_the_Member_Initiator_events(String scenario) throws Throwable {
        String dhoeventuri = PropLoader.props.apply("mcapihostname") + PropLoader.props.apply("dhomcsentpayload")
            + Serenity.getCurrentSession().get(Constant.MEMBERGDFID);
        log.info("dho event url :" + dhoeventuri);

        Awaitility.with().pollInterval(Duration.ONE_SECOND.multiply(1)).and().with()
                .pollDelay(Duration.ONE_SECOND.multiply(1)).await().timeout(Duration.ONE_SECOND.multiply(30))
                .until(() -> isStatus(dhoeventuri));
        
        Response response = rest().given().contentType(Constant.CONTENTTYPE)
                .header("Content-Type", Constant.CONTENTTYPE).when().get(dhoeventuri);
        // Assert.equal
        String responseBody = response.getBody().prettyPrint();
        JSONArray arrLegalID = JsonPath.parse(responseBody).read(Constant.SOURCEMEMBER_LEGAL_ID);
        String strLegalID = (String) arrLegalID.get(0);
        log.info("resppnseBody:" + responseBody);
        log.info("legalid:" + strLegalID);
        
        if (((String) Serenity.getCurrentSession().get(Constant.REQUEST_TYPE)).contentEquals("Add")) {
            Serenity.getCurrentSession().put(Constant.ADD_MEMBER_LEGAL_ID, strLegalID);
            log.info("ADD LEGALID:" + Serenity.getCurrentSession().get(Constant.ADD_MEMBER_LEGAL_ID));
        }else
        {
            Serenity.getCurrentSession().put(Constant.UPDATE_MEMBER_LEGAL_ID, strLegalID);
            log.info("UPDATE LEGALID:" + Serenity.getCurrentSession().get(Constant.UPDATE_MEMBER_LEGAL_ID)); 
        }

    } 
    
    @Then("^Validate MC Member Values in Response for \"([^\"]*)\"$")
    public void validate_MC_Member_LegalID(String flag) throws Throwable { 
        if(flag.contentEquals("Equal"))           
        {
            log.info("ADD LEGALID:" + Serenity.getCurrentSession().get(Constant.ADD_MEMBER_LEGAL_ID));
            log.info("UPDATE LEGALID:" + Serenity.getCurrentSession().get(Constant.UPDATE_MEMBER_LEGAL_ID));            
            assertEquals(Serenity.getCurrentSession().get(Constant.ADD_MEMBER_LEGAL_ID), Serenity.getCurrentSession().get(Constant.UPDATE_MEMBER_LEGAL_ID));   
        }else           
        {
            log.info("ADD LEGALID:" + Serenity.getCurrentSession().get(Constant.ADD_MEMBER_LEGAL_ID));
            log.info("UPDATE LEGALID:" + Serenity.getCurrentSession().get(Constant.UPDATE_MEMBER_LEGAL_ID));
            assertFalse(((String) Serenity.getCurrentSession().get(Constant.ADD_MEMBER_LEGAL_ID)).contentEquals((String) Serenity.getCurrentSession().get(Constant.UPDATE_MEMBER_LEGAL_ID)));  
        }

        
    }
}
