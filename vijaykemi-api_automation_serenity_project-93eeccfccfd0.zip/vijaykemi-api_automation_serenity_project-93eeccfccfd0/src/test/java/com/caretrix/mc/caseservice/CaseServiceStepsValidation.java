package com.caretrix.mc.caseservice;

import static net.serenitybdd.rest.SerenityRest.rest;
import static org.hamcrest.CoreMatchers.equalTo;

import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hamcrest.Matchers;

import com.API.Rest.validations.MedcompassValidations;
import com.jayway.jsonpath.JsonPath;
import com.mc.TestUtils.Constant;
import com.mc.TestUtils.PropLoader;
import com.mc.setup.SetupHeaders;

import static io.restassured.RestAssured.given;
import static net.serenitybdd.rest.SerenityRest.then;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import io.restassured.http.ContentType;
import io.restassured.response.ValidatableResponse;
import net.minidev.json.JSONArray;
import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Steps;

public class CaseServiceStepsValidation {
	private static final Logger log = LogManager.getLogger(CaseServiceStepsValidation.class);

	@Steps
	private MedcompassValidations validation = new MedcompassValidations();

	@Then("^The system will generate a new Case ID$")
	public void Validate_Response_code_is() throws Throwable {
		validation.validatestatuscode(201);
	}

	@Then("^The system will consider the Case as eligible to MedCompass$")
	public void the_system_will_consider_the_Case_as_eligible_to_MedCompass() throws Throwable {
		validation.validatestatuscode(201);
	}

	@Then("^Validate noAdmitFlag status \"([^\"]*)\"$")
	public void Validate_noAdmitFlag(String noAdmitFlag) throws Throwable {

		Map<String, Object> attrs = new HashMap<>();
		attrs.put(Constant.CASE_$_0_TXN_NO_ADMIT_FLAG, noAdmitFlag);
		validateCaseIdAttributes(attrs);
	}

	@Then("^Validate svcEligibilityReviewFailFlag status \"([^\"]*)\"$")
	public void validate_svcEligibilityReviewFailFlag(String svcEligibilityReviewFailFlag) throws Throwable {
		Map<String, Object> attrs = new HashMap<>();
		attrs.put(Constant.CASE_$_0_ELIG_RVW_FAIL_FLAG, svcEligibilityReviewFailFlag);
		validateCaseIdAttributes(attrs);
	}

	@Then("^Validate colorCd \"([^\"]*)\" and ccxCaseLnId \"([^\"]*)\" and clinicalReviewFailFlag \"([^\"]*)\" and adminReviewFaillFlag \"([^\"]*)\"$")
	public void validate_colorCd_and_ccxCaseLnId_and_clinicalReviewFailFlag_and_adminReviewFaillFlag(String colorCd,
			Integer ccxCaseLnId, String clinicalReviewFailFlag, String adminReviewFaillFlag) throws Throwable {

		Map<String, Object> attrs = new HashMap<>();
		attrs.put(Constant.CASE_$_0_CCX_CASE_LN_ID, ccxCaseLnId);
		attrs.put(Constant.CASE_$_0_COLOR_CD, colorCd);
		attrs.put(Constant.CASE_$_0_CLINICAL_RVW_FAIL_FLAG, clinicalReviewFailFlag);
		attrs.put(Constant.CASE_$_0_ADMIN_RVW_FAIL_FLAG, adminReviewFaillFlag);
		validateCaseIdAttributes(attrs);
	}

	@Then("^Validate colorCd \"([^\"]*)\" and noAdmitFlag \"([^\"]*)\" and svcEligibilityReviewFailFlag \"([^\"]*)\" and businessFailureReviewFlag \"([^\"]*)\" and clinicalReviewFailFlag \"([^\"]*)\" and adminReviewFaillFlag \"([^\"]*)\" and ccxCaseLnId \"([^\"]*)\"$")
	public void validate_colorCd_and_noAdmitFlag_and_svcEligibilityReviewFailFlag_and_businessFailureReviewFlag_and__clinicalReviewFailFlag_and_adminReviewFaillFlaga_and_ccxCaseLnId(
			String colorCd, String noAdmitFlag, String svcEligibilityReviewFailFlag, String businessFailureReviewFlag,
			String clinicalReviewFailFlag, String adminReviewFaillFlag, Integer ccxCaseLnId) throws Throwable {

		Map<String, Object> attrs = new HashMap<>();
		attrs.put(Constant.CASE_$_0_COLOR_CD, colorCd);
		attrs.put(Constant.CASE_$_0_TXN_NO_ADMIT_FLAG, noAdmitFlag);
		attrs.put(Constant.CASE_$_0_ELIG_RVW_FAIL_FLAG, svcEligibilityReviewFailFlag);
		attrs.put(Constant.CASE_$_0_BUS_RVW_FAIL_FLAG, businessFailureReviewFlag);
		attrs.put(Constant.CASE_$_0_CLINICAL_RVW_FAIL_FLAG, clinicalReviewFailFlag);
		attrs.put(Constant.CASE_$_0_ADMIN_RVW_FAIL_FLAG, adminReviewFaillFlag);
		attrs.put(Constant.CASE_$_0_CCX_CASE_LN_ID, ccxCaseLnId);
		validateCaseIdAttributes(attrs);
	}
	
	@Then("^Validate noAdmitFlag \"([^\"]*)\" and svcEligibilityReviewFailFlag \"([^\"]*)\" and businessFailureReviewFlag \"([^\"]*)\" and businessFailureReviewResolutionCd \"([^\"]*)\" and healthPlanReviewFailFlag \"([^\"]*)\"$")
	public void validate_noAdmitFlag_and_svcEligibilityReviewFailFlag_and_businessFailureReviewFlag_and__businessFailureReviewResolutionCd_and_healthPlanReviewFailFlag(
			 String noAdmitFlag, String svcEligibilityReviewFailFlag, String businessFailureReviewFlag,
			String businessFailureReviewResolutionCd, String healthPlanReviewFailFlag) throws Throwable {

		Map<String, Object> attrs = new HashMap<>();
		attrs.put(Constant.CASE_$_0_TXN_NO_ADMIT_FLAG, noAdmitFlag);
		attrs.put(Constant.CASE_$_0_ELIG_RVW_FAIL_FLAG, svcEligibilityReviewFailFlag);
		attrs.put(Constant.CASE_$_0_BUS_RVW_FAIL_FLAG, businessFailureReviewFlag);
		attrs.put(Constant.CASE_$_0_BUS_RVW_FAIL_RSLVD_CD, businessFailureReviewResolutionCd);
		attrs.put(Constant.CASE_$_0_HP_RVW_FAIL_FLAG, healthPlanReviewFailFlag);
		validateCaseIdAttributes(attrs);
	}

	@Then("^Validate businessFailureReviewFlag \"([^\"]*)\" and businessFailureReviewResolutionCd \"([^\"]*)\"$")
	public void validate_businessFailureReviewFlag_and__businessFailureReviewResolutionCd(
			String businessFailureReviewFlag,
			String businessFailureReviewResolutionCd) throws Throwable {

		Map<String, Object> attrs = new HashMap<>();
		attrs.put(Constant.CASE_$_0_BUS_RVW_FAIL_FLAG, businessFailureReviewFlag);
		attrs.put(Constant.CASE_$_0_BUS_RVW_FAIL_RSLVD_CD, businessFailureReviewResolutionCd);
		validateCaseIdAttributes(attrs);
	}

	@Then("^Validate CaseServiceLineStatus \"([^\"]*)\"$")
    public void Validate_CaseServiceLineStatus(String Status) throws Throwable {
		ValidatableResponse response=
		then().assertThat();
		String data = response.extract().asString();
		Serenity.getCurrentSession().put(Constant.CASELineNbr1,
				JsonPath.parse(data).read("serviceRequests[0].ccxCaseLnNbr"));
		Serenity.getCurrentSession().put(Constant.CASEsvctxid1,
	            JsonPath.parse(data).read("serviceRequests[0].ccxServiceTransactionId"));
		response.statusCode(201).
		body(Constant.CaseID_Linestatus, equalTo(isEmptyverify(Status)));
    }
    
    @Then("^Validate CaseEligibletoMedCompass$")
    public void Validate_EligibleToSendToMedCompass() throws Throwable {
		then().assertThat().statusCode(201).
		body(Constant.CaseID_Eligible, equalTo(true));		
    }
    
    @Then("^Validate CaseService Status \"([^\"]*)\" and \"([^\"]*)\"$")
    public void Validate_CaseServiceStatus(String Status, int ResponseCode) throws Throwable {
    	ValidatableResponse response= then().assertThat();
    	response.statusCode(ResponseCode).		
		body("status", Matchers.containsString(Status));
    	if(Status.contains("All lines"))
       		response.body("serviceRequests[0]", Matchers.nullValue());
       }
    
    @Then("^Validate Case Not EligibletoMedCompass$")
    public void Validate_Not_EligibleToSendToMedCompass() throws Throwable {
		then().assertThat().statusCode(201).
		body(Constant.CaseID_Eligible, equalTo(false));		
    }
    
    @Then("^Validate CaseServiceLineAuthCategory \"([^\"]*)\"$")
    public void Validate_CaseServiceLineAuthCategory(String strauthcategory) throws Throwable {
		then().assertThat().statusCode(201).
		body(Constant.CaseID_AuthCategory, equalTo(strauthcategory));		
    }
    
    @And("^Validate CaseHeader Highlevelstatus \"([^\"]*)\" and Detailed Status \"([^\"]*)\"$")
    public void Validate_CaseHeaderStatus(String HighStatus, String DetStatus) throws Throwable {
    	initialSetupCaseID();
		String caseIDbdURI = PropLoader.props.apply("caseservicedb")
		+ Serenity.getCurrentSession().get(Constant.CASETransactionID1) + Constant.CASE_DB_APP_ID + Serenity.getCurrentSession().get(Constant.CASEAppID1);
		log.info("CaseID DB url :" + caseIDbdURI);
		
		given().contentType(ContentType.JSON).when().log().all().get(caseIDbdURI).
		then().assertThat().
		body(Constant.CaseID_HeaderlvlStatus, equalTo(isEmptyverify(HighStatus))).
		body(Constant.CaseID_DetailedvlStatus, equalTo(isEmptyverify(DetStatus)));	
    }
    
    @Then("^Validate LineStstus \"([^\"]*)\" and CaseHeader Highlevelstatus \"([^\"]*)\" and Detailed Status \"([^\"]*)\"$")
    public void Validate_CaseStatus(String LineStatus, String HighStatus, String DetStatus) throws Throwable {
    	initialSetupCaseID();
		String caseIDbdURI = PropLoader.props.apply("caseservicedb")
		+ Serenity.getCurrentSession().get(Constant.CASETransactionID1) + Constant.CASE_DB_APP_ID + Serenity.getCurrentSession().get(Constant.CASEAppID1);
		log.info("CaseID DB url :" + caseIDbdURI);
		
		given().contentType(ContentType.JSON).when().log().all().get(caseIDbdURI).
		then().assertThat().
		body(Constant.CaseID_LineStatusDB, equalTo(isEmptyverify(LineStatus))).
		body(Constant.CaseID_HeaderlvlStatus, equalTo(isEmptyverify(HighStatus))).
		body(Constant.CaseID_DetailedvlStatus, equalTo(isEmptyverify(DetStatus)));	
    }
    
    @And("^Validate Highlevelstatus \"([^\"]*)\" Detailed Status \"([^\"]*)\" EligibilityFailResolved \"([^\"]*)\" businessFailureResolved \"([^\"]*)\" clicnicalRvwOverrideFlag \"([^\"]*)\" adminRvwOverrideFlag \"([^\"]*)\"$")
    public void Validate_ReassignCaseHeaderStatus(String HighStatus, String DetStatus, String EligFlag, String busFlag, String cliFlag, String AdminFlag) throws Throwable {
    	initialSetupCaseID();
		String caseIDbdURI = PropLoader.props.apply("caseservicedb")
		+ Serenity.getCurrentSession().get(Constant.CASETransactionID1) + Constant.CASE_DB_APP_ID + Serenity.getCurrentSession().get(Constant.CASEAppID1);
		log.info("CaseID DB url :" + caseIDbdURI);
		
		ValidatableResponse responseone=
				given().contentType(ContentType.JSON).when().log().all().get(caseIDbdURI).then().assertThat();
		
		responseone.body(Constant.CaseID_HeaderlvlStatus, equalTo(isEmptyverify(HighStatus)));
		responseone.body(Constant.CaseID_DetailedvlStatus, equalTo(isEmptyverify(DetStatus)));	
		
		Map<String, Object> attrs = new HashMap<>();
		attrs.put(Constant.CASE_$_0_ELIG_RVW_RSLVD_FLAG, isEmptyverify(EligFlag));
		attrs.put(Constant.CASE_$_0_BUS_RVW_FAIL_RSLVD_CD, isEmptyverify(busFlag));
		attrs.put(Constant.CASE_$_0_CLINICAL_RVW_OVRD_FLAG, isEmptyverify(cliFlag));
		attrs.put(Constant.CASE_$_0_ADMIN_RVW_OVRD_FLAG, isEmptyverify(AdminFlag));
		validateCaseIdFlags(responseone, attrs);
    }
    
    @And("^Validate CaseType \"([^\"]*)\"$")
    public void Validate_CaseType(String caseType) throws Throwable {
    	initialSetupCaseID();
    	String caseIDbdURI = PropLoader.props.apply("caseservicedb")
    			+ Serenity.getCurrentSession().get(Constant.CASETransactionID1) + Constant.CASE_DB_APP_ID + Serenity.getCurrentSession().get(Constant.CASEAppID1);
    			log.info("CaseID DB url :" + caseIDbdURI);
    			
    	given().contentType(ContentType.JSON).when().log().all().get(caseIDbdURI).
		then().assertThat().
		body(Constant.CaseID_CaseType, equalTo(isEmptyverify(caseType)));	
		
    }
    
    @And("^Validate Clinical Review Mode indicator \"([^\"]*)\"$")
    public void Validate_ClinicalreviewModeIndicator(String strClinicalMode) throws Throwable {
    	initialSetupCaseID();
    	String caseIDbdURI = PropLoader.props.apply("caseservicedb")
    			+ Serenity.getCurrentSession().get(Constant.CASETransactionID1) + Constant.CASE_DB_APP_ID + Serenity.getCurrentSession().get(Constant.CASEAppID1);
    			log.info("CaseID DB url :" + caseIDbdURI);
    			
    	given().contentType(ContentType.JSON).when().log().all().get(caseIDbdURI).
		then().assertThat().
		statusCode(200).		
		body(Constant.CaseID_clinicalrvwMode, equalTo(isEmptyverify(strClinicalMode)));	
		
    }
    
    @Then("^Validate Single CaseIDGenerated with Status \"([^\"]*)\"$")
    public void Validate_SigleCaseIDGenerated(String Status) throws Throwable {
    	ValidatableResponse response= then().assertThat();
    	response.statusCode(201).		
		body("status", Matchers.containsString(Status));
    	Serenity.getCurrentSession().put(Constant.CASEIDcolor, "one");
    	Serenity.getCurrentSession().put(Constant.CASEIDLines, 1 + " ");
    	String data = response.extract().asString();
    	ValidateCaseID(response);    	
		Serenity.getCurrentSession().put(Constant.CASEID1,
	            JsonPath.parse(data).read(Constant.CaseID_ccxCaseId1));
		
       }
    
    @Then("^Validate CaseIDGenerated$")
    public void Validate_CaseIDGenerated() throws Throwable {
    	ValidatableResponse response = then().assertThat();
    	ValidateCaseID(response);	
    	log.info("Response :" + response);
    	
    }
    
    @And("^Validate CaseID generated in DB \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void Validate_CaseIDgeneratedDB(String noAdmitFlag, String businessFailureReviewFlag, String clinicalReviewFailFlag, String adminReviewFaillFlag) throws Throwable {
    	initialSetupCaseID();
    	String caseIDbdURI = PropLoader.props.apply("caseservicedb")
			+ Serenity.getCurrentSession().get(Constant.CASETransactionID1) + Constant.CASE_DB_APP_ID + Serenity.getCurrentSession().get(Constant.CASEAppID1);
			log.info("CaseID DB url :" + caseIDbdURI);
			
			ValidatableResponse responseone=
			given().contentType(ContentType.JSON).when().log().all().get(caseIDbdURI).then().assertThat();
			ValidateCaseIDDB(responseone);	
			Map<String, Object> attrs = new HashMap<>();
			attrs.put(Constant.CASE_$_0_TXN_NO_ADMIT_FLAG, noAdmitFlag);
			attrs.put(Constant.CASE_$_0_BUS_RVW_FAIL_FLAG, businessFailureReviewFlag);
			attrs.put(Constant.CASE_$_0_CLINICAL_RVW_FAIL_FLAG, clinicalReviewFailFlag);
			attrs.put(Constant.CASE_$_0_ADMIN_RVW_FAIL_FLAG, adminReviewFaillFlag);
			validateCaseIdFlags(responseone, attrs);
    }
    
    @Then("^Validate CaseIDReused with caseServiceLineStatus \"([^\"]*)\"$")
    public void Validate_CaseIDReused(String Status) throws Throwable {
		ValidatableResponse response=
		then().assertThat();
		String data = response.extract().asString();
		String strauth = JsonPath.parse(data).read(Constant.CaseID_AuthCategory);
		response.statusCode(201).
		body(Constant.CaseID_Linestatus, equalTo(isEmptyverify(Status)));
		if (strauth.equals("Re-authorization"))
			response.body(Constant.CaseID_ccxCaseId1, Matchers.notNullValue());
		else
			response.body(Constant.CaseID_ccxCaseId1, equalTo(Serenity.getCurrentSession().get(Constant.CASEID1)));
		
    }
    private void validateCaseIdFlags(ValidatableResponse responseone, Map<String, Object> props) throws InterruptedException {
	
		for (Map.Entry<String, Object> entry : props.entrySet()) {
			responseone.body(entry.getKey(), equalTo(entry.getValue()));
		}
	}
    
    private void ValidateCaseIDDB(ValidatableResponse responseone)
    {
		
			String data = responseone.extract().asString();
	    	JSONArray arrCaseID = JsonPath.parse(data).read(Constant.CaseID_ResDB_CaseAll);
	    	JSONArray arrColor = JsonPath.parse(data).read(Constant.CaseID_ResDB_ColorAll);
	    	String  strcolor;
	    	Long strcaseID;
			int intRedact = 0,intGreenact = 0,intrestact = 0;
			Long strRedcaseID = (long) 0,strGreencaseID = (long) 0,strRestcaseID = (long) 0;
			String Temp = (String) Serenity.getCurrentSession().get(Constant.CASEIDLines);
	    	int LineCount = Integer.parseInt(Temp.trim());
			for(int i=0; i< LineCount; i++)
			{
				
				strcaseID = (Long) arrCaseID.get(i);
				strcolor = (String) arrColor.get(i);
				if(strcolor.contains("RED"))
				{
					intRedact++;
					if(strRedcaseID  == 0L)
					{ strRedcaseID = strcaseID; }
					else { responseone.body(replaceIterator(Constant.CaseID_ResDB_CasID, i), equalTo(strRedcaseID));}
					responseone.body(replaceIterator(Constant.CaseID_ResDB_LNNBR, i), Matchers.containsString("00"+(intRedact)));
					responseone.body(replaceIterator(Constant.CaseID_ResDB_LNID, i), equalTo(intRedact));
				}
				else if(strcolor.contains("GREEN"))
				{
					intGreenact++;
					if(strGreencaseID == 0L)
					{ strGreencaseID = strcaseID; }
					else { responseone.body(replaceIterator(Constant.CaseID_ResDB_CasID, i), equalTo(strGreencaseID));}
					responseone.body(replaceIterator(Constant.CaseID_ResDB_LNNBR, i), Matchers.containsString("00"+(intGreenact)));
					responseone.body(replaceIterator(Constant.CaseID_ResDB_LNID, i), equalTo(intGreenact));
				}
				else
				{
					intrestact++;
					if(strRestcaseID==0L)
					{ strRestcaseID = strcaseID; }
					else { responseone.body(replaceIterator(Constant.CaseID_ResDB_CasID, i), equalTo(strRestcaseID));}
					responseone.body(replaceIterator(Constant.CaseID_ResDB_LNNBR, i), Matchers.containsString("00"+(intrestact)));
					responseone.body(replaceIterator(Constant.CaseID_ResDB_LNID, i), equalTo(intrestact));
				}
			}
    }
	
    
    private void ValidateCaseID(ValidatableResponse response)
    {
    	
    	String Temp = (String) Serenity.getCurrentSession().get(Constant.CASEIDLines);
    	int LineCount = Integer.parseInt(Temp.trim());
     	response.statusCode(201);
    	if(Serenity.getCurrentSession().get(Constant.CASEIDcolor).equals("one"))    		
    	{    	
	    	for (int i=0;i<LineCount;i++)
	    	{    	
	    		response.body(replaceIterator(Constant.CaseID_Res_Applid, i), equalTo(Serenity.getCurrentSession().get(Constant.CASEAppID1)));
		    	response.body(replaceIterator(Constant.CaseID_Res_TxnID, i), equalTo(Serenity.getCurrentSession().get(Constant.CASETransactionID1)));
		    	response.body(replaceIterator(Constant.CaseID_Res_ccxCaseLnId, i), equalTo(i+1));
		    	response.body(replaceIterator(Constant.CaseID_Res_ccxCaseLnNbr, i), Matchers.containsString("00"+(i+1)));
		    	response.body(replaceIterator(Constant.CaseID_Res_ccxCaseId, i), Matchers.notNullValue());		    	
	    	}    	
    	}
    	else { 
	    		for (int i=0;i<LineCount;i++)
		    	{    	
			    	response.body(replaceIterator(Constant.CaseID_Res_Applid, i), equalTo(Serenity.getCurrentSession().get(Constant.CASEAppID1)));
			    	response.body(replaceIterator(Constant.CaseID_Res_TxnID, i), equalTo(Serenity.getCurrentSession().get(Constant.CASETransactionID1)));
			    	response.body(replaceIterator(Constant.CaseID_Res_ccxCaseLnId, i), Matchers.greaterThan(0));
			    	response.body(replaceIterator(Constant.CaseID_Res_ccxCaseLnNbr, i), Matchers.containsString("-00"));
			    	response.body(replaceIterator(Constant.CaseID_Res_ccxCaseId, i), Matchers.notNullValue());			    	
		    	} 
    		}
    }

    private String replaceIterator(String strField, int i)
    {
    	return strField.replace("[i]", "[" + i + "]");
    	
    }
    private Object isEmptyverify(String strTemp) {
		if (strTemp.isEmpty())
		{ return null; }
		else { return strTemp; }
	}
    
    private static void initialSetupCaseID() throws InterruptedException {
    	SetupHeaders.initialSetup("mcapihostname"); 
	}
    
    private void validateCaseIdAttributes(Map<String, Object> props) throws InterruptedException {
		initialCaseIDSetup();

		String caseIdDBUri = generateCaseIdDbUri();
		log.info("CASE ID db uri: " + caseIdDBUri);

		ValidatableResponse response = rest().given().contentType(ContentType.JSON).when().get(caseIdDBUri).then()
				.assertThat();

		for (Map.Entry<String, Object> entry : props.entrySet()) {
			response.body(entry.getKey(), equalTo(entry.getValue()));
		}
	}

	private void initialCaseIDSetup() throws InterruptedException {
		SetupHeaders.initialSetup(Constant.CASE_API_HOSTNAME);
	}

	private String generateCaseIdDbUri() {
		StringBuilder sb = new StringBuilder(Constant.CASE_DB_URI);
		sb.append(Serenity.getCurrentSession().get(Constant.CASE_CCX_TXN_ID));
		sb.append(Constant.CASE_DB_APP_ID);
		sb.append(Serenity.getCurrentSession().get(Constant.CASE_APP_ID));
		return sb.toString();
	}
}
