package com.caretrix.mc.steps.dho.provider;

import static io.restassured.RestAssured.given;
import static net.serenitybdd.rest.SerenityRest.rest;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.collection.IsIterableContainingInOrder.contains;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.hamcrest.CoreMatchers.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.awaitility.Awaitility;
import org.awaitility.Duration;

import com.jayway.jsonpath.JsonPath;
import com.mc.TestUtils.Constant;
import com.mc.TestUtils.PropLoader;

import cucumber.api.java.en.Then;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import junit.framework.Assert;
import net.minidev.json.JSONArray;
import net.serenitybdd.core.Serenity;

public class ProviderTemplateEngineStepsValidation {

    private static final Logger log = LogManager.getLogger(ProviderTemplateEngineStepsValidation.class);

    @Then("^Validate Provider DHO Payload and MC Payload for object \"([^\"]*)\"$")
    public void validate_Status_code_for_the_Provider_Initiator_event(String scenario) throws Throwable {
        String dhoeventuri = PropLoader.props.apply("mcapihostname") + PropLoader.props.apply("dhomcsentpayload")
            + Serenity.getCurrentSession().get(Constant.GDFID);
        log.info("dho event url :" + dhoeventuri);

        Awaitility.with().pollInterval(Duration.ONE_SECOND.multiply(1)).and().with()
                .pollDelay(Duration.ONE_SECOND.multiply(1)).await().timeout(Duration.ONE_SECOND.multiply(10))
                .until(() -> isStatus(dhoeventuri));

        Response response = rest().given().contentType(Constant.CONTENTTYPE)
                .header("Content-Type", Constant.CONTENTTYPE).when().get(dhoeventuri);
        // Assert.equal
        String responseBody = response.getBody().prettyPrint();

        log.info("resppnseBody:" + responseBody);

       // assertEquals(true, validateFieldValues(response.getBody().asString(), scenario));
        validateFieldValues(response.getBody().asString(), scenario);
    }

    private Boolean isStatus(String url) {
        Response response = RestAssured.given().when().get(url);
        return response.then().extract().statusCode() == 200;
    }

    @SuppressWarnings("unchecked")
    private void validateFieldValues(String response, String scenario) {
        Map<String, Map<Object, Object>> dataMap;
        dataMap = (Map<String, Map<Object, Object>>) Serenity.getCurrentSession().get(Constant.DATA_MAP);
        List<String> dataList = new ArrayList<>();
        List<String> valueList = new ArrayList<>();
        for (Entry<String, Map<Object, Object>> mainmapentry : dataMap.entrySet()) {
            try {
                // log.info("dataMap" + dataMap);
                Map<Object, Object> map = null;
                if (mainmapentry.getKey().contains(scenario)) {
                    map = mainmapentry.getValue();
                }
                String dhoValue = "";
                String mcValue = "";
                for (Map.Entry<Object, Object> entry : map.entrySet()) {
                    if (entry.getKey() != null && entry.getKey().equals("ExpectedField")) {
                        if (entry.getValue() != null) {
                            List<String> list = JsonPath.parse(response).read(entry.getValue().toString());
                            if (!list.isEmpty()) {
                                dhoValue = list.get(0).toString();
                                dataList.add(list.get(0).toString());
                            }
                        }
                    } else if (entry.getKey() != null && entry.getKey().equals("ExpectedValue")) {
                        if (entry.getValue() != null) {
                            mcValue = entry.getValue().toString();
                            valueList.add(entry.getValue().toString());
                        }
                    }

                }
               // if (!dhoValue.isEmpty() && !mcValue.isEmpty() && !dhoValue.equals(mcValue)) {
                //    return false;
                               // }
               // assertEquals(mcValue,dhoValue);

            } catch (Exception e) {
                log.info(e, e);
            }
        }
        log.info("dataList" + dataList);
        log.info("valueList" + valueList);
        //return true;
        assertEquals(valueList,dataList);
    }
    @Then("^Capture MC Payload for secondary Keys ProviderSpecialty object \"([^\"]*)\"$")
    public void capture_ProviderSpecialty_for_Provider_Initiator_events(String scenario) throws Throwable {
        String dhoeventuri = PropLoader.props.apply("mcapihostname") + PropLoader.props.apply("dhomcsentpayload")
            + Serenity.getCurrentSession().get(Constant.PROVIDERGDFID);
        log.info("dho event url :" + dhoeventuri);

        Awaitility.with().pollInterval(Duration.ONE_SECOND.multiply(2)).and().with()
                .pollDelay(Duration.ONE_SECOND.multiply(5)).await().timeout(Duration.ONE_SECOND.multiply(30))
                .until(() -> isStatus(dhoeventuri));
        
        Response response = rest().given().contentType(Constant.CONTENTTYPE)
                .header("Content-Type", Constant.CONTENTTYPE).when().get(dhoeventuri);
        // Assert.equal
        String responseBody = response.getBody().prettyPrint();
        JSONArray arrSpecialityID = JsonPath.parse(responseBody).read(Constant.PROVIDER_SPECIALITY_ID);
        String strSpecialityID= (String) arrSpecialityID.get(0);
        log.info("responseBody:" + responseBody);
        log.info("SpecialityID:" + strSpecialityID);
        
        if (((String) Serenity.getCurrentSession().get(Constant.REQUEST_TYPE)).contentEquals("Add")) {
            Serenity.getCurrentSession().put(Constant.ADD_PROVIDER_SPECIALITY_ID, strSpecialityID);
            log.info("ADD Provider SpecialityID:" + Serenity.getCurrentSession().get(Constant.ADD_PROVIDER_SPECIALITY_ID));
        }else
        {
            Serenity.getCurrentSession().put(Constant.UPDATE_PROVIDER_SPECIALITY_ID, strSpecialityID);
            log.info("UPDATE Provider SpecialityID:" + Serenity.getCurrentSession().get(Constant.UPDATE_PROVIDER_SPECIALITY_ID)); 
        }
    }
    @Then("^Validate MC Provider Values in Response for ProviderSpecialty object for \"([^\"]*)\"$")
    public void validate_MC_ProviderSpecialtyID(String flag) throws Throwable { 
        if(flag.contentEquals("Equal"))           
        {
            log.info("ADD Provider SpecialityID:" + Serenity.getCurrentSession().get(Constant.ADD_PROVIDER_SPECIALITY_ID));
            log.info("UPDATE Provider SpecialityID:" + Serenity.getCurrentSession().get(Constant.UPDATE_PROVIDER_SPECIALITY_ID));            
            assertEquals(Serenity.getCurrentSession().get(Constant.ADD_PROVIDER_SPECIALITY_ID), Serenity.getCurrentSession().get(Constant.UPDATE_PROVIDER_SPECIALITY_ID));   
        }else           
        {
            log.info("ADD Provider SpecialityID:" + Serenity.getCurrentSession().get(Constant.ADD_PROVIDER_SPECIALITY_ID));
            log.info("UPDATE Provider SpecialityID:" + Serenity.getCurrentSession().get(Constant.UPDATE_PROVIDER_SPECIALITY_ID));
            assertFalse(((String) Serenity.getCurrentSession().get(Constant.ADD_PROVIDER_SPECIALITY_ID)).contentEquals((String) Serenity.getCurrentSession().get(Constant.UPDATE_PROVIDER_SPECIALITY_ID)));  
        }       
    }    
    
    @Then("^Validate Provider for the EventStatus and ErrorObject \"([^\"]*)\" \"([^\"]*)\"$")
    public void validate_Provider_Status_code_and_error_for_the_Provider_Initiator_event(String eventStatus, String scenario) throws Throwable {

        String dhoeventuri = PropLoader.props.apply("dhoapihost") + PropLoader.props.apply("dhoevent")
            + Serenity.getCurrentSession().get(Constant.GDFID);
        log.info("dho event url :" + dhoeventuri);
        int timeout = Integer.parseInt(PropLoader.props.apply("providerresponsetimeoutseconds"));
        Awaitility.with().pollInterval(Duration.FIVE_SECONDS).and().with().pollDelay(Duration.ONE_SECOND.multiply(5))
                .await().timeout(Duration.ONE_SECOND.multiply(timeout))
                .untilAsserted(() -> assertThat(
                    JsonPath.parse(JsonPath.parse(given().contentType(ContentType.JSON).when().get(dhoeventuri)
                            .getBody().jsonPath().getList(".").get(0)).jsonString()).read(Constant.TXNSTATUS),
                    containsString(eventStatus))

        );
        String txnStatus = JsonPath.parse(JsonPath.parse(
            given().contentType(ContentType.JSON).when().get(dhoeventuri).getBody().jsonPath().getList(".").get(0))
                .jsonString()).read(Constant.TXNSTATUS);
        log.info("TXN_STAT_DESC:" + txnStatus);
        // This is to print the event status response URL in the report
        Response response = rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).when()
                .get(dhoeventuri);

        validateErrorObject(response.getBody().asString(), scenario);
    }
    
    @SuppressWarnings("unchecked")
    private void validateErrorObject(String response, String scenario) {
        Map<String, Map<Object, Object>> dataMap;
        dataMap = (Map<String, Map<Object, Object>>) Serenity.getCurrentSession().get(Constant.DATA_MAP);
        List<String> dataList = new ArrayList<>();
        List<String> valueList = new ArrayList<>();
        String dhoValue = "";
        String mcValue = "";
        for (Entry<String, Map<Object, Object>> mainmapentry : dataMap.entrySet()) {
            try {
                // log.info("dataMap" + dataMap);
                Map<Object, Object> map = null;
                if (mainmapentry.getKey().contains(scenario)) {
                    map = mainmapentry.getValue();
                }
               
                for (Map.Entry<Object, Object> entry : map.entrySet()) {
                    if (entry.getKey() != null && entry.getKey().equals("ExpectedField")) {
                        if (entry.getValue() != null) {
                            List<String> list = JsonPath.parse(response).read(entry.getValue().toString());
                            if (!list.isEmpty()) {
                                dhoValue = list.get(0).toString();
                                dataList.add(list.get(0).toString());
                            }
                        }
                    } else if (entry.getKey() != null && entry.getKey().equals("ExpectedValue")) {
                        if (entry.getValue() != null) {
                            mcValue = entry.getValue().toString();
                            valueList.add(entry.getValue().toString());
                        }
                    }

                }
              

            } catch (Exception e) {
                log.info(e, e);
            }
        }
        log.info("dataList" + dhoValue);
        log.info("valueList" + mcValue);
        assertThat(valueList,hasItems(mcValue));
     
        
    }
}
