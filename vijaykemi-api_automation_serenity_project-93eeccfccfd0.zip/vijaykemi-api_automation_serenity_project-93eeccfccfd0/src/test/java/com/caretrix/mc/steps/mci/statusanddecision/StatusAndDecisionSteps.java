package com.caretrix.mc.steps.mci.statusanddecision;

import static net.serenitybdd.rest.SerenityRest.rest;


import java.io.IOException;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import com.API.Rest.validations.MedcompassValidations;
import com.jayway.jsonpath.JsonPath;
import com.mc.TestUtils.Constant;
import com.mc.TestUtils.ExcelTestData;
import com.mc.TestUtils.JsonUpdateUtil;
import com.mc.TestUtils.PropLoader;
import com.mc.setup.SetupHeaders;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Steps;

public class StatusAndDecisionSteps {
	
	private static final String statusAndDecisionJsonTemplatePath ="src/test/resources/jsonPayloads/McIntegrationService/StatusAndDecision/StatusAndDecision.json";
	
	Map<String,Map<String, String>> dataMap;
	
	String mciapihostname="mciapihostname";
	
	@Steps
	private MedcompassValidations validation = new MedcompassValidations();

	@Given("^For a referral request$")
	public void setup_proxy_for_a_Status_And_Decision_Request() throws Throwable {
		dataMap = ExcelTestData.getTestDataBySheet(PropLoader.props.apply(Constant.STATUS_AND_DECISION_EXCEL_PATH), Constant.STATUS_AND_DECISION_SHEET_NAME);
		Serenity.getCurrentSession().put(Constant.DATA_MAP, dataMap);
		SetupHeaders.initialSetup(mciapihostname);
	}
	
	@When("^Status changed from \"([^\"]*)\"$")
	public void statusAndDecision(String scenario) throws Throwable {
		String gdfid=UUID.randomUUID().toString();
		String payload = getStatusAndDecisionPayLoad(scenario);
		payload =JsonPath.parse(payload).set(Constant.GDFID,gdfid).jsonString();
		Serenity.getCurrentSession().put(Constant.GDFID, gdfid);
		rest().given().contentType(Constant.CONTENTTYPE)
			.header("Content-Type",Constant.CONTENTTYPE)
			.auth().basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password))
			.when().log().all()
			.body(payload)
			.post(PropLoader.props.apply("mcintegrationstatusdecisionapi"));
	
	}

	private String getStatusAndDecisionPayLoad(String scenario) throws IOException {
		Map<String, Object> scenarioDataMap = new HashMap<>(dataMap.get(scenario));
		String jsonTemplatePayload = new String(Files.readAllBytes(Paths.get(statusAndDecisionJsonTemplatePath)));
		String payload = JsonUpdateUtil.buildJsonRequest(jsonTemplatePayload,scenarioDataMap,"StatusAndDecision");
		return payload;
	}
	
}


