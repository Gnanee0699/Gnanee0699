package com.caretrix.mc.steps.dho.serviceauth;

import static net.serenitybdd.rest.SerenityRest.rest;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.API.Rest.validations.MedcompassValidations;
import com.jayway.jsonpath.JsonPath;
import com.mc.TestUtils.Constant;
import com.mc.TestUtils.ExcelTestData;
import com.mc.TestUtils.JsonUpdateUtil;
import com.mc.TestUtils.PropLoader;
import com.mc.setup.SetupHeaders;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import net.minidev.json.JSONArray;
import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Steps;

public class SATemplateEngineSteps {

    private static final String dhoServiceAuthJsonTemplatePath =
        "src/test/resources/jsonPayloads/dho/serviceauth/dhoserviceauthmcvalidation.json";
    private static final Logger log = LogManager.getLogger(SATemplateEngineSteps.class);
    
    Map<String, Map<Object, Object>> dataMap;

    String dhohostname = Constant.QA_APT_HOST_NAME;
    
    @Steps
    private MedcompassValidations validation = new MedcompassValidations();

    @Given("^Service Auth Add event to MC resulting$")
    public void setup_proxy_for_ServiceAuth_Add_Request() throws Throwable {
        initialSetup();
    }

    private void initialSetup() throws InterruptedException {
        Map<String, String> map = new HashMap<String, String>();
        map.put("excelpath", PropLoader.props.apply(Constant.DHO_SERVICE_AUTH_EXCEL_PATH));
        map.put("sheetname", PropLoader.props.apply(Constant.DHO_SERVICE_AUTH_TEMPLATE_SHEET_NAME));
        dataMap = ExcelTestData.getTestDataBySheet(map);
        Serenity.getCurrentSession().put(Constant.DATA_MAP, dataMap);
        SetupHeaders.initialSetup(dhohostname);
    }

    @When("^Service Auth add request triggered from DataHub \"([^\"]*)\"$")
    public void ServiceAuthInitiator(String scenario) throws Throwable {
        String payload = getServiceAuthPayLoad(scenario);
        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
                .basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password)).when()
                .log().all().body(payload).post(PropLoader.props.apply("dhoaddserviceauth"));
    }

    private String getServiceAuthPayLoad(String scenario) throws IOException {
        Map<Object, Object> scenarioDataMap = new HashMap<>();
        String jsonTemplatePayload = new String(Files.readAllBytes(Paths.get(dhoServiceAuthJsonTemplatePath)));
        //Updating the CaseIDs with Random Integer
        String strCaseID = Integer.toString(JsonUpdateUtil.getRandomNumberInts(Constant.RANDOM_NO_MIN, Constant.RANDOM_NO_MAX));
        jsonTemplatePayload = JsonPath.parse(jsonTemplatePayload).set(Constant.CASEIDJSON, strCaseID).jsonString();
        Serenity.getCurrentSession().put(Constant.CASEID, strCaseID);
        log.info("SA CaseID:" + Serenity.getCurrentSession().get(Constant.CASEID));
        
        // Finding the No of lines from Payload and updating the serviceline in the form of 123-001,123-002.
        JSONArray arr = JsonPath.parse(jsonTemplatePayload).read(Constant.CASESERVICELINENUMBER);
        int intLines = arr.size();
        String prefix = "-00";
        if (intLines >= 1) {
            for (int i = 0; i < intLines; i++) {
                String strCaseServiceLineNumber = Constant.CASESERVICELINENUMBERS.replace("[i]", "[" + i + "]");
                String strNewCaseLineNumbers = Serenity.getCurrentSession().get(Constant.CASEID) + prefix + (i + 1);
                log.info("CaseLineNumbers:" + strNewCaseLineNumbers);
                jsonTemplatePayload = JsonPath.parse(jsonTemplatePayload).set(strCaseServiceLineNumber, strNewCaseLineNumbers).jsonString();
            }
        }
        for (Map.Entry<String, Map<Object, Object>> entry : dataMap.entrySet()) {
            if (entry.getKey().contains(scenario)) {
                scenarioDataMap = entry.getValue();
                jsonTemplatePayload = JsonUpdateUtil.buildDHOJsonRequest(jsonTemplatePayload, scenarioDataMap);
            }

        }
        return jsonTemplatePayload;
    } 
}
