package com.caretrix.mc.steps.dho.provider;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import net.thucydides.junit.annotations.Concurrent;

@Concurrent(threads = "4x")
@RunWith(CucumberWithSerenity.class)

@CucumberOptions(features = "src/test/resources/feature/", strict = true, tags = {
    // "@TC_002_providerInitiatorRetry_From_MCIMonitor_RetryCountnotmaxed,@TC_001_providerInitiatorAddRequest_Initiated_From_ServiceAuth"
    "@DHOProviderInitiator" }, glue = "com/carecentrix/mc/steps/dho/provider")

public class ProviderInitiatorRunnerTest {

}
