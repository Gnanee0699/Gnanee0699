package com.caretrix.mc.steps.mci.eventresponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.API.Rest.validations.MedcompassValidations;
import com.caretrix.medcompass.cucumber.steps.Common;
import com.mc.TestUtils.Constant;

import cucumber.api.java.en.Then;
import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Steps;

public class EventresponseStepsValidation {

    Common common = new Common();

    private static final Logger log = LogManager.getLogger(EventresponseStepsValidation.class);

    @Steps
    private MedcompassValidations validation = new MedcompassValidations();

    @Then("^Validate Response code for the Member Inititor  \"([^\"]*)\"$")
    public void Validate_Response_code_is(String responseCode) throws Throwable {
        validation.validatestatuscode(Integer.parseInt(responseCode));
    }

    @Then("^Validate the field in Member Inititor ResponseBody for the \"([^\"]*)\" and \"([^\"]*)\"$")
    public void Validate_the_field_in_ResponseBody_for_the(String Scenario, String Sheetname) throws Throwable {
        validation.validateResponsebody("OK");
    }

    @Then("^Validate Success Response code$")
    public void validate_Response_Code() throws Throwable {
        validation.validatestatuscode(200);
    }

    @Then("^Validate Evt Success Response code$")
    public void validate_Status_Response_Code() throws Throwable {
        String Statuscode = (String) Serenity.getCurrentSession().get(Constant.Statuscode);
        int stscode = Integer.parseInt(Statuscode);

        validation.validatestatuscode(stscode);
    }
}
