package com.caretrix.mc.caseservice;

import static net.serenitybdd.rest.SerenityRest.rest;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.mc.TestUtils.Constant;
import com.mc.TestUtils.ExcelTestData;
import com.mc.TestUtils.JsonUpdateUtil;
import com.mc.TestUtils.PropLoader;
import com.mc.setup.SetupHeaders;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import io.restassured.response.Response;
import net.minidev.json.JSONArray;
import net.serenitybdd.core.Serenity;

public class CaseServiceSteps {

    private static final Logger log = LogManager.getLogger(CaseServiceSteps.class);

    private static final String caseServiceJsonTemplatePath =
        "src/test/resources/jsonPayloads/caseservice/CaseService.json";
    private static final String caseServiceupdateJsonTemplatePath =
            "src/test/resources/jsonPayloads/caseservice/CaseServiceUpdate.json";
    private static final String caseServicereassgnJsonTemplatePath =
            "src/test/resources/jsonPayloads/caseservice/CaseServiceReassign.json";

    Map<String, Map<Object, Object>> dataMap;
    
    
    String caseservicehostname = Constant.CASE_SERVICE_HOSTNAME;

    @Given("^The user enters a referral request resulting in an Inactive No Admit via Legacy Portal and the system invoked Case Service$")
    public void Service_Auth_Request_Resulting_In_Inactive_Activity() throws Throwable {
        initialSetup();
    }

    @When("^The received referral request is in \"([^\"]*)\"$")
    public void Refferal_Request_Is_In(String scenario) throws Throwable {
        String payload = getCaseServicePayLoad(scenario);
        log.info("CaseID payload : " + payload);

        Response response =
            rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
                    .basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password)).when()
                    .log().all().body(payload).post(PropLoader.props.apply("caseserviceapi"));

        setDBUri(response);
    }
    
    @Given("^The user enters a referral request resulting in an Eligibility Failure via Legacy Portal and the system invoked Case Service$")
    public void referral_Request_Resulting_in_an_Eligibility_Failure_Status() throws Throwable {

        initialSetup();
    }

    @Given("^The user enters a referral request is not a Inactive No Admit$")
    public void referral_Request_Resulting_in_an_NonPAC_NonHealthservices_Status() throws Throwable {

        initialSetup();
    }

    @And("^there are no eligibility failures or all identified eligibility failures were resolved by the user$")
    public void there_are_no_eligibility_failures_or_all_identified_eligibility_failures_were_resolved_by_the_user()
        throws Throwable {
        initialSetup();
    }

    @And("^none of the services associated with the request has service category as INSTAY or THH or WHS$")
    public void none_of_the_services_associated_with_the_request_has_service_category_as_INSTAY_or_THH_or_WHS()
        throws Throwable {
        initialSetup();
    }

    @And("^the system invoked Case Service$")
    public void the_system_invoked_Case_Service() throws Throwable {
        initialSetup();
    }

    @And("^there are no business failures or all identified business failures are in resolved status$")
    public void noBusinessfailure_Status() throws Throwable {

        initialSetup();
    }

    @And("^the service categories associated with all service request lines are present in the list INSTAY or THH or WHS$")
    public void ServiceCategory_INSTAY_THH_WHS_Status() throws Throwable {

        initialSetup();
    }

    @And("^there are no existing referral requests with Case IDs for the current member within retro limit i.e. 180 days and current service line Plan ID$")
    public void noExistingReferralrequestWith_CaseId_Status() throws Throwable {

        initialSetup();
    }

    @Given("^The system invokes the function to determine whether the Case is ready to submit to MedCompass$")
    public void the_system_invokes_the_function_to_determine_whether_the_Case_is_ready_to_submit_to_MedCompass()
        throws Throwable {
        initialSetup();

    }

    @When("^The received Case satisfies all the rules is in \"([^\"]*)\"$")
    public void caseService_Request_Is_In(String scenario) throws Throwable {
        String payload = getCaseServicePayLoad(scenario);
        Response response =
            rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
                    .basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password)).when()
                    .log().all().body(payload).post(PropLoader.props.apply("caseserviceapi"));

        setDBUri(response);
    }

    @Given("^The user enters a referral request resulting in a Business Failure via Legacy Portal and the system invoked Case Service$")
    public void referralRequest_BusinessFailure() throws Throwable {
        initialSetup();

    }

    @When("^The received referral request has Business failure on one or more service lines and one or more Business failures were NOT resolved by the legacy portal user in \"([^\"]*)\"$")
    public void
        the_received_referral_request_has_Business_failure_on_one_or_more_service_lines_and_one_or_more_Business_failures_were_NOT_resolved_by_the_legacy_portal_user_in(
            String scenario) throws Throwable {
        String payload = getCaseServicePayLoad(scenario);
        Response response =
            rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
                    .basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password)).when()
                    .log().all().body(payload).post(PropLoader.props.apply("caseserviceapi"));

        setDBUri(response);
    }

    @Given("^The user enters a referral request$")
    public void Service_Auth_Request() throws Throwable {
        initialSetup();
    }

    @When("^The received Case is eligible to submit to MedCompass and \"([^\"]*)\"$")
    public void Service_Auth_Eligible(String scenario) throws Throwable {
        String payload = getCaseServicePayLoad(scenario);
        int strTransactionID = JsonPath.parse(payload).read(Constant.CaseID_TransactionID_Line1);
        int strappid = JsonPath.parse(payload).read(Constant.CaseID_ApplicationID_Line1);
        Serenity.getCurrentSession().put(Constant.CASETransactionID1, strTransactionID);
        Serenity.getCurrentSession().put(Constant.CASEAppID1, strappid);

        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
                .basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password)).when()
                .log().all().body(payload).post(PropLoader.props.apply("caseserviceapi"));

    }
    
   @When("^The received Case is eligible to submit to MedCompass with multiple Lines and \"([^\"]*)\"$")
    public void Service_Auth_Eligible_MultipleLines(String scenario) throws Throwable {
        String payload = UpdatecaseIDpayloadwithTxnID(scenario);
        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
                .basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password)).when()
                .log().all().body(payload).post(PropLoader.props.apply("caseserviceapi"));

    }
   
   @When("^The received Case is not eligible and \"([^\"]*)\"$")
   public void Service_Auth_Noteligible(String scenario) throws Throwable {
       String payload1 = getCaseServicePayLoad(scenario);
       Serenity.getCurrentSession().put(Constant.CASETransactionID1, JsonPath.parse(payload1).read(Constant.CaseID_TransactionID_Line1));
       Serenity.getCurrentSession().put(Constant.CASEAppID1, JsonPath.parse(payload1).read(Constant.CaseID_ApplicationID_Line1));
       Serenity.getCurrentSession().put(Constant.CASEIDcolor1, JsonPath.parse(payload1).read(Constant.CaseID_colorCd1));
       Serenity.getCurrentSession().put(Constant.CASEsvctxid1, JsonPath.parse(payload1).read(Constant.CaseID_svctxid1));
       
       rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
               .basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password)).when()
               .log().all().body(payload1).post(PropLoader.props.apply("caseserviceapi"));

   }
    
    @When("^Cancellation or Withdrawn is requested from HomeBridge or Medcompas with status \"([^\"]*)\" and Parameter \"([^\"]*)\"$")
    public void Update_Caselinestatus(String Status, String updateparam) throws Throwable {
        String payload = getUpdatepayload(Status, updateparam);
        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
                .basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password)).when()
                .log().all().body(payload).put(PropLoader.props.apply("updatecaseservice"));

    }
    
    @When("^Reassign Case Service is invoked to recalculate Case ID with \"([^\"]*)\" and Flags \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void Reassign_CaseID(String scenario, String svcEligibilityflg, String businessFailflg, String clinicalflg, String cinicalresolveuser, String adminflag, String adminresolveuser) throws Throwable {
        
        String payload = getReassignPayload(scenario);
       
        payload = JsonPath.parse(payload).set(Constant.CaseID_TransactionID_Line1, Serenity.getCurrentSession().get(Constant.CASETransactionID1)).jsonString();
        payload = JsonPath.parse(payload).set(Constant.CaseID_ApplicationID_Line1, Serenity.getCurrentSession().get(Constant.CASEAppID1)).jsonString();
        payload = JsonPath.parse(payload).set(Constant.CaseID_ccxCaseId1, Serenity.getCurrentSession().get(Constant.CASEID1)).jsonString();
        payload = JsonPath.parse(payload).set(Constant.CaseID_colorCd1, Serenity.getCurrentSession().get(Constant.CASEIDcolor1)).jsonString();
        payload = JsonPath.parse(payload).set(Constant.CaseID_EligibilityResolved, svcEligibilityflg).jsonString();
        payload = JsonPath.parse(payload).set(Constant.CaseID_BusinessFailResolved, businessFailflg).jsonString();
        payload = JsonPath.parse(payload).set(Constant.CaseID_clinicalRvwFailFlag, isEmptyverify(clinicalflg)).jsonString();
        payload = JsonPath.parse(payload).set(Constant.CaseID_clinicalRvwResolved, isEmptyverify(cinicalresolveuser)).jsonString();
        payload = JsonPath.parse(payload).set(Constant.CaseID_adminRvwFailFlag, isEmptyverify(adminflag)).jsonString();
        payload = JsonPath.parse(payload).set(Constant.CaseID_adminRvwResolved, isEmptyverify(adminresolveuser)).jsonString();
        payload = JsonPath.parse(payload).set(Constant.CaseID_ccxCaseLnId1, 1).jsonString();
        
     
        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
                .basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password)).when()
                .log().all().body(payload).put(PropLoader.props.apply("caseserviceapi"));

    }
    
    public String getUpdatepayload(String Status, String param)  throws Throwable
    {
    	String payload = new String(Files.readAllBytes(Paths.get(caseServiceupdateJsonTemplatePath)));
        
        if(param.equals("TransID"))
        {
        payload = JsonPath.parse(payload).set(Constant.CaseID_TransactionID_Line1, Serenity.getCurrentSession().get(Constant.CASETransactionID1)).jsonString();
        payload = JsonPath.parse(payload).set(Constant.CaseID_ApplicationID_Line1, Serenity.getCurrentSession().get(Constant.CASEAppID1)).jsonString();
        payload = JsonPath.parse(payload).set(Constant.CaseID_svctxid1, Serenity.getCurrentSession().get(Constant.CASEsvctxid1)).jsonString();
        }
        else
        {
        	payload = JsonPath.parse(payload).set(Constant.CaseID_caseLnnbr1, Serenity.getCurrentSession().get(Constant.CASELineNbr1)).jsonString();
        }
        payload = JsonPath.parse(payload).set(Constant.CaseID_caseLinestatus1, Status).jsonString();
        return payload;
    }
    
    public String UpdatecaseIDpayloadwithTxnID(String scenario) throws IOException {
        String payload = getCaseServicePayLoad(scenario);
        int strTransactionID = JsonPath.parse(payload).read(Constant.CaseID_TransactionID_Line1);
        int strappid = JsonPath.parse(payload).read(Constant.CaseID_ApplicationID_Line1);

        JSONArray arrcolor = JsonPath.parse(payload).read("$..colorCd");
        int intred = 0;
        int intgreen = 0;
        int intrest = 0;
        for (int i = 0; i < arrcolor.size(); i++) {
            if (arrcolor.get(i).equals("RED")) {
                intred++;
            } else if (arrcolor.get(i).equals("GREEN")) {
                intgreen++;
            } else {
                intrest++;
            }

        }

        if ((intred > 0 && intgreen > 0) || (intred > 0 && intrest > 0) || (intgreen > 0 && intrest > 0)) {
            Serenity.getCurrentSession().put(Constant.CASEIDcolor, intred + ":" + intgreen + ":" + intrest);
        } else {
            Serenity.getCurrentSession().put(Constant.CASEIDcolor, "one");
        }

        JSONArray arr = JsonPath.parse(payload).read(Constant.CaseID_CatID);
        int intLines = arr.size();
        Serenity.getCurrentSession().put(Constant.CASEIDLines, intLines + " ");
        Serenity.getCurrentSession().put(Constant.CASETransactionID1, strTransactionID);
        Serenity.getCurrentSession().put(Constant.CASEAppID1, strappid);
        if (intLines > 1) {
            for (int i = 1; i < intLines; i++) {
                String strtransID = Constant.CaseID_TransactionID_All.replace("[i]", "[" + i + "]");
                payload = JsonPath.parse(payload).set(strtransID, strTransactionID).jsonString();
            }
        }

        return payload;
    }

    private String getCaseServicePayLoad(String scenario) throws IOException {
    
        Map<Object, Object> scenarioDataMap = new HashMap<>(dataMap.get(scenario));
        String jsonTemplatePayload = new String(Files.readAllBytes(Paths.get(caseServiceJsonTemplatePath)));
        String payload = JsonUpdateUtil.buildJsonRequestNew(jsonTemplatePayload, scenarioDataMap, "CaseService");
        return payload;
    }
    
    private String getReassignPayload(String scenario) throws IOException {
		String payload = getCaseServicePayLoad(scenario);
		DocumentContext doc = JsonPath.parse(payload);
		String deletefields = Constant.Case_reassign_deletefields;
		String[] arrSplit = deletefields.split(",");
		for (int i = 0; i < arrSplit.length; i++) {				
		    doc.delete(arrSplit[i]);		  
		}		  		
		String newPayload = doc.jsonString();
		return newPayload;
    	
    }

    private void initialSetup() throws InterruptedException {
        Map<String, String> map = new HashMap<String, String>();
        map.put("excelpath", PropLoader.props.apply(Constant.CASE_SERVICE_EXCEL_PATH));
        map.put("sheetname", PropLoader.props.apply(Constant.CASE_SERVICE_SHEET_NAME));
        dataMap = ExcelTestData.getTestDataBySheet(map);
        Serenity.getCurrentSession().put(Constant.DATA_MAP, dataMap);
        SetupHeaders.initialSetup(caseservicehostname);
    }
    
    private Object isEmptyverify(String strTemp) {
		if (strTemp.isEmpty())
		{ return null; }
		else { return strTemp; }
	}

    private void setDBUri(Response response) {
        Serenity.getCurrentSession().put(Constant.CASE_CCX_TXN_ID,
            JsonPath.parse(response.body().asString()).read(Constant.CASE_$_0_CCX_TXN_ID));
        Serenity.getCurrentSession().put(Constant.CASETransactionID1,
            JsonPath.parse(response.body().asString()).read(Constant.CASE_$_0_CCX_TXN_ID));

        Serenity.getCurrentSession().put(Constant.CASE_APP_ID,
            JsonPath.parse(response.body().asString()).read(Constant.CASE_$_0_APP_ID));
        Serenity.getCurrentSession().put(Constant.CASEAppID1,
            JsonPath.parse(response.body().asString()).read(Constant.CASE_$_0_APP_ID));
    }
}
