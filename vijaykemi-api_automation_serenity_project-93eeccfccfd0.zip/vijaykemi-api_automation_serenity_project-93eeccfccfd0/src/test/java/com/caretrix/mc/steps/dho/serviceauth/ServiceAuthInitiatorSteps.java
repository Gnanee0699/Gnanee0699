package com.caretrix.mc.steps.dho.serviceauth;

import static io.restassured.RestAssured.given;
import static net.serenitybdd.rest.SerenityRest.rest;
import static net.serenitybdd.rest.SerenityRest.then;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;

import java.io.IOException;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.awaitility.Awaitility;
import org.awaitility.Duration;

import com.API.Rest.validations.MedcompassValidations;
import com.jayway.jsonpath.JsonPath;
import com.mc.TestUtils.Constant;
import com.mc.TestUtils.ExcelTestData;
import com.mc.TestUtils.JsonUpdateUtil;
import com.mc.TestUtils.PropLoader;
import com.mc.setup.SetupHeaders;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.http.ContentType;
import net.minidev.json.JSONArray;
import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Steps;

public class ServiceAuthInitiatorSteps {

    private static final Logger log = LogManager.getLogger(ServiceAuthInitiatorSteps.class);

    private static final String dhoServiceAuthJsonTemplatePath =
        "src/test/resources/jsonPayloads/dho/serviceauth/dhoserviceauthnew.json";

    Map<String, Map<String, String>> dataMap;

    @Steps
    private MedcompassValidations validation = new MedcompassValidations();

    @Given("^Service Auth Add event to MC resulting from UDH$")
    public void setup_proxy_for_ServiceAuth_Add_Request() throws Throwable {
        dataMap = ExcelTestData.getTestDataBySheet(PropLoader.props.apply(Constant.DHO_SERVICE_AUTH_EXCEL_PATH),
            Constant.DHO_SERVICE_AUTH_SHEET_NAME);
        Serenity.getCurrentSession().put(Constant.DATA_MAP, dataMap);
        SetupHeaders.initialSetupDHORequest();
    }

    @Given("^Service Auth Update event to MC resulting from UDH$")
    public void setup_proxy_for_ServiceAuth_Update_Request() throws Throwable {
        dataMap = ExcelTestData.getTestDataBySheet(PropLoader.props.apply(Constant.DHO_SERVICE_AUTH_EXCEL_PATH),
            Constant.DHO_SERVICE_AUTH_SHEET_NAME);
        Serenity.getCurrentSession().put(Constant.DATA_MAP, dataMap);
        SetupHeaders.initialSetupDHORequest();
    }

    @When("^Service Auth add request triggered from UDH \"([^\"]*)\"$")
    public void ServiceAuthInitiator(String scenario) throws Throwable {
        String payload = UpdatepayloadwithCaseId(scenario);
        JSONArray arrMember = JsonPath.parse(payload).read(Constant.DHO_SA_MEMBERGDFID);
        JSONArray arrProvider = JsonPath.parse(payload).read(Constant.DHO_SA_PROVIDERGDFID);
        String strMemberGDFID = (String) arrMember.get(0);
        String strpProviderGDFID = (String) arrProvider.get(0);
        String strpProviderGDFID1 = (String) arrProvider.get(1);
        Serenity.getCurrentSession().put(Constant.SA_MEMBERGDFID, strMemberGDFID);
        Serenity.getCurrentSession().put(Constant.SA_PROVIDERGDFID, strpProviderGDFID);
        Serenity.getCurrentSession().put(Constant.SA_PROVIDERGDFID1, strpProviderGDFID1);
        log.info("service auth payload =" + payload);
        // Serenity.getCurrentSession().put(Constant.CASEID, caseid);
        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
                .basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password)).when()
                .log().all().body(payload).post(PropLoader.props.apply("dhoaddserviceauth"));
    }
    
    @When("^Service Auth event triggered from Retry Topic \"([^\"]*)\"$")
    public void ServiceAuthInitiatorRetry(String scenario) throws Throwable {
        String payload = UpdatepayloadwithCaseId(scenario);
        log.info("service auth payload =" + payload);
        // Serenity.getCurrentSession().put(Constant.CASEID, caseid);
        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
                .basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password)).when()
                .log().all().body(payload).post(PropLoader.props.apply("dhoretryserviceauth"));
    }

    public String UpdatepayloadwithCaseId(String scenario) throws IOException {
        String payload = getServiceAuthPayLoad(scenario);
        String streventType = JsonPath.parse(payload).read("$.header.eventType");
        log.info("streventType:" + streventType);
        // we are storing session case id for Add event say for 1st line.This case id will be used in 2nd line for
        // Update/Modify
        Serenity.getCurrentSession().put(Constant.REQUEST_TYPE, streventType);
        if (streventType.contentEquals("Service_Auth_Add")) {
            // converting Random Number Caseid integer to string
            String strCaseID = Integer.toString(JsonPath.parse(payload).read(Constant.PAYLOADCASEID));
            payload = JsonPath.parse(payload).set(Constant.CASEIDJSON, strCaseID).jsonString();
            Serenity.getCurrentSession().put(Constant.CASEID, strCaseID);
            log.info("Add CaseID:" + Serenity.getCurrentSession().get(Constant.CASEID));
        } else {
            // Replacing the update/Modify 2nd line case id's with the 1st line caseid stored in the session.
            payload = JsonPath.parse(payload)
                    .set(Constant.CASEIDJSON, Serenity.getCurrentSession().get(Constant.CASEID)).jsonString();
            log.info("Update CaseID:" + Serenity.getCurrentSession().get(Constant.CASEID));
        }
        //Capture Member and Provider GDFIDs from payload for Memmber,Provider dependent test cases
        //These GDFIDs can be validated for member and provider event status or response codes after SA is submitted
        JSONArray arrMember = JsonPath.parse(payload).read(Constant.DHO_SA_MEMBERGDFID);
        JSONArray arrProvider = JsonPath.parse(payload).read(Constant.DHO_SA_PROVIDERGDFID);
        String strMemberGDFID = (String) arrMember.get(0);
        String strpProviderGDFID = (String) arrProvider.get(0);
       // String strMemberGDFID1 = (String) arrMember.get(1);
        String strpProviderGDFID1 = (String) arrProvider.get(1);
        //payload = JsonPath.parse(payload).set(Constant.GDFID, strMemberGDFID).jsonString();
        Serenity.getCurrentSession().put(Constant.MEMBERGDFID, strMemberGDFID);
        Serenity.getCurrentSession().put(Constant.PROVIDERGDFID, strpProviderGDFID);
        Serenity.getCurrentSession().put(Constant.PROVIDERGDFID1, strpProviderGDFID1);
        log.info("Member GDFID:" + Serenity.getCurrentSession().get(Constant.MEMBERGDFID));
        log.info("Provider GDFID:" + Serenity.getCurrentSession().get(Constant.PROVIDERGDFID));
        log.info("Provider2 GDFID:" + Serenity.getCurrentSession().get(Constant.PROVIDERGDFID1));
        
        // Finding the No of lines from Payload and updating the serviceline in the form of 123-001,123-002.
        JSONArray arr = JsonPath.parse(payload).read(Constant.CASESERVICELINENUMBER);
        int intLines = arr.size();
        String prefix = "-00";
        if (intLines >= 1) {
            for (int i = 0; i < intLines; i++) {
                String strCaseServiceLineNumber = Constant.CASESERVICELINENUMBERS.replace("[i]", "[" + i + "]");
                String strNewCaseLineNumbers = Serenity.getCurrentSession().get(Constant.CASEID) + prefix + (i + 1);
                log.info("CaseLineNumbers:" + strNewCaseLineNumbers);
                payload = JsonPath.parse(payload).set(strCaseServiceLineNumber, strNewCaseLineNumbers).jsonString();
            }
        }

        return payload;
    }

    @When("^Service Auth Update request triggered from UDH \"([^\"]*)\"$")
    public void ServiceAuthUpdateInitiator(String scenario) throws Throwable {
        String payload = UpdatepayloadwithCaseId(scenario);
        // do we need to set this value for update.Updated the latest caseIDS with the 1st line case ids
        log.info("Updated CASEID:" + Serenity.getCurrentSession().get(Constant.CASEID));
        // payload = JsonPath.parse(payload).set(Constant.CASEIDJSON,
        // Serenity.getCurrentSession().get(Constant.CASEID)).jsonString();
        log.info("service auth payload =" + payload);
        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
                .basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password)).when()
                .log().all().body(payload).post(PropLoader.props.apply("dhoupdateserviceauth"));
    }
    @When("^Service Auth Update request triggered from UDH for case eligibity check \"([^\"]*)\"$")
    public void ServiceAuthUpdateInitiator1(String scenario) throws Throwable {
        //String caseid = UUID.randomUUID().toString();
        String payload = getServiceAuthPayLoad(scenario);
        String strCaseID = Integer.toString(JsonPath.parse(payload).read(Constant.PAYLOADCASEID));
        payload = JsonPath.parse(payload).set(Constant.CASEIDJSON, strCaseID).jsonString();
        Serenity.getCurrentSession().put(Constant.CASEID, strCaseID);
        log.info("Add CaseID:" + Serenity.getCurrentSession().get(Constant.CASEID));
        //Capture Member and Provider GDFIDs from payload for Memmber,Provider dependent test cases
        //These GDFIDs can be validated for member and provider event status or response codes after SA is submitted
        JSONArray arrMember = JsonPath.parse(payload).read(Constant.DHO_SA_MEMBERGDFID);
        JSONArray arrProvider = JsonPath.parse(payload).read(Constant.DHO_SA_PROVIDERGDFID);
        String strMemberGDFID = (String) arrMember.get(0);
        String strpProviderGDFID = (String) arrProvider.get(0);
        //payload = JsonPath.parse(payload).set(Constant.GDFID, strMemberGDFID).jsonString();
        Serenity.getCurrentSession().put(Constant.MEMBERGDFID, strMemberGDFID);
        Serenity.getCurrentSession().put(Constant.PROVIDERGDFID, strpProviderGDFID);
        log.info("Member GDFID:" + Serenity.getCurrentSession().get(Constant.MEMBERGDFID));
        log.info("Provider GDFID:" + Serenity.getCurrentSession().get(Constant.PROVIDERGDFID));
        // Finding the No of lines from Payload and updating the serviceline in the form of 123-001,123-002.
        JSONArray arr = JsonPath.parse(payload).read(Constant.CASESERVICELINENUMBER);
        int intLines = arr.size();
        String prefix = "-00";
        if (intLines >= 1) {
            for (int i = 0; i < intLines; i++) {
                String strCaseServiceLineNumber = Constant.CASESERVICELINENUMBERS.replace("[i]", "[" + i + "]");
                String strNewCaseLineNumbers = Serenity.getCurrentSession().get(Constant.CASEID) + prefix + (i + 1);
                log.info("CaseLineNumbers:" + strNewCaseLineNumbers);
                payload = JsonPath.parse(payload).set(strCaseServiceLineNumber, strNewCaseLineNumbers).jsonString();
            }
        }
        log.info("service auth payload =" + payload);
        //Serenity.getCurrentSession().put(Constant.CASEID, caseid);
        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
                .basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password)).when()
                .log().all().body(payload).post(PropLoader.props.apply("dhoupdateserviceauth"));
    }
    
    @When("^Manual Retry Indicator is Enabled$")
    public void ManualRetryIndicatorEnabled() throws Throwable {
        //String dhomanualretruri = PropLoader.props.apply("manualretryhost") + PropLoader.props.apply("manualretryevent") + Serenity.getCurrentSession().get(Constant.CASEID);
        String dhomanualretruri = PropLoader.props.apply("manualretryhost") + PropLoader.props.apply("manualretryevent") + Serenity.getCurrentSession().get(Constant.CASEID) + Constant.EVENT_ID_DB + Serenity.getCurrentSession().get(Constant.EVENTGUID) ;
        log.info("dho Mnaul Retry event url :" + dhomanualretruri);
        String payload ="{}";   
        payload = JsonPath.parse(payload).jsonString();
        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
        .basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password)).when()
        .log().all().body(payload).post(dhomanualretruri);
        then().assertThat().statusCode(200);
    }
    
    @When("^Update the Transaction Status for SA Event \"([^\"]*)\"$")
    public void UpdateTransactionStatusOfEvent(String status) throws Throwable {
        String dhoupdatedb = PropLoader.props.apply("dhoapihost") + PropLoader.props.apply("dhoupdateeventdb") + Serenity.getCurrentSession().get(Constant.CASEID) + Constant.SERVICEATH_STATUS_DB + status ;
        log.info("dho Mnaul Retry event url :" + dhoupdatedb);
        String payload ="{}";   
        payload = JsonPath.parse(payload).jsonString();
        // This is to print the event status response URL in the report
        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
        .basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password)).when()
        .log().all().body(payload).put(dhoupdatedb);
        then().assertThat().statusCode(200);
    }
    private String getServiceAuthPayLoad(String scenario) throws IOException {
        Map<String, Object> scenarioDataMap = new HashMap<>(dataMap.get(scenario));
        String jsonTemplatePayload = new String(Files.readAllBytes(Paths.get(dhoServiceAuthJsonTemplatePath)));
        String payload = JsonUpdateUtil.buildJsonRequest(jsonTemplatePayload, scenarioDataMap, "DHOServiceAuth");
        return payload;
    }

}
