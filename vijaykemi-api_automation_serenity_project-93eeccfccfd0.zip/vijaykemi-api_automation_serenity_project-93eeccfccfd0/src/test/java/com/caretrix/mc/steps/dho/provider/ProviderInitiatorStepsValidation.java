package com.caretrix.mc.steps.dho.provider;

import static io.restassured.RestAssured.given;
import static net.serenitybdd.rest.SerenityRest.rest;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.assertj.core.api.Assertions.assertThat;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.awaitility.Awaitility;
import org.awaitility.Duration;

import com.API.Rest.validations.MedcompassValidations;
import com.caretrix.medcompass.cucumber.steps.Common;
import com.jayway.jsonpath.JsonPath;
import com.mc.TestUtils.Constant;
import com.mc.TestUtils.PropLoader;

import cucumber.api.java.en.Then;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Steps;

public class ProviderInitiatorStepsValidation {

    Common common = new Common();

    private static final Logger log = LogManager.getLogger(ProviderInitiatorStepsValidation.class);
    private static final String dhoapihost = PropLoader.props.apply("dhoapihost");
    private static final String dhoevent = PropLoader.props.apply("dhoevent");

    @Steps
    private MedcompassValidations validation = new MedcompassValidations();

    @Then("^Validate Status code for the Provider Initiator event \"([^\"]*)\"$")
    public void validate_Status_code_for_the_Provider_Initiator_event(String eventStatus) throws Throwable {

        String dhoeventuri = PropLoader.props.apply("dhoapihost") + PropLoader.props.apply("dhoevent")
            + Serenity.getCurrentSession().get(Constant.PROVIDERGDFID);
        log.info("dho event url :" + dhoeventuri);
        int timeout = Integer.parseInt(PropLoader.props.apply("providerresponsetimeoutseconds"));
        Awaitility.with().pollInterval(Duration.FIVE_SECONDS).and().with().pollDelay(Duration.ONE_SECOND.multiply(5))
                .await().timeout(Duration.ONE_SECOND.multiply(timeout))
                .untilAsserted(() -> assertThat(
                    JsonPath.parse(JsonPath.parse(given().contentType(ContentType.JSON).when().get(dhoeventuri)
                            .getBody().jsonPath().getList(".").get(0)).jsonString()).read(Constant.TXNSTATUS),
                    containsString(eventStatus))

        );
        String txnStatus = JsonPath.parse(JsonPath.parse(
            given().contentType(ContentType.JSON).when().get(dhoeventuri).getBody().jsonPath().getList(".").get(0))
                .jsonString()).read(Constant.TXNSTATUS);
        log.info("TXN_STAT_DESC:" + txnStatus);
        // This is to print the event status response URL in the report
        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).when()
                .get(dhoeventuri);
        
        Response response=given().contentType(ContentType.JSON).when().get(dhoeventuri);
        
        String EVENT_GUID = (JsonPath.parse(JsonPath.parse(response
                .getBody().jsonPath().getList(".").get(0)).jsonString()).read(Constant.EVENTGUID));
        Serenity.getCurrentSession().put(Constant.EVENTGUID, EVENT_GUID);

    }
    
    @Then("^Validate Status code for the New Provider event \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void  validate_Status_Code_For_New_Provider_Event(String eventStatus, String topicName, String retryFlag, String retryCount){  
    	String dhoeventuri = dhoapihost + dhoevent + Serenity.getCurrentSession().get(Constant.PROVIDERGDFID);
        log.info("dho event url :" + dhoeventuri); 
    	int timeout = Integer.parseInt(PropLoader.props.apply("manualretrytimeoutseconds"));
    	Awaitility.with().pollInterval(Duration.TWO_SECONDS).and().with().pollDelay(Duration.ONE_SECOND.multiply(60)).await()
        .timeout(Duration.ONE_SECOND.multiply(timeout))
        .untilAsserted(() -> assertThat(
            JsonPath.parse(JsonPath.parse(given().contentType(ContentType.JSON).when().get(dhoeventuri)
                    .getBody().jsonPath().getList(".").get(0)).jsonString()).read(Constant.TXNSTATUS),
            containsString(eventStatus)));
    	 
    	 Response response=given().contentType(ContentType.JSON).when().get(dhoeventuri);
    	 
    	 assertThat(JsonPath.parse(JsonPath.parse(response
                 .getBody().jsonPath().getList(".").get(0)).jsonString()).read(Constant.TOPICNAME),
         containsString(topicName));
    	 
    	 assertThat(JsonPath.parse(JsonPath.parse(response
                 .getBody().jsonPath().getList(".").get(0)).jsonString()).read(Constant.RETRYFLAG).toString(),
         containsString(retryFlag));
    	 
    	 assertThat(JsonPath.parse(JsonPath.parse(response
                 .getBody().jsonPath().getList(".").get(0)).jsonString()).read(Constant.RETRYCOUNT).toString(),
         containsString(retryCount));
         
}
    
 
    
    @Then("^Validate Status code for the First Provider Initiator event \"([^\"]*)\"$")
    public void validate_Status_code_for_the_first_Provider_Initiator_event(String eventStatus) throws Throwable {

        String dhoeventuri = PropLoader.props.apply("dhoapihost") + PropLoader.props.apply("dhoevent")
            + Serenity.getCurrentSession().get(Constant.SA_PROVIDERGDFID);
        log.info("dho event url :" + dhoeventuri);
        int timeout = Integer.parseInt(PropLoader.props.apply("providerresponsetimeoutseconds"));
        Awaitility.with().pollInterval(Duration.FIVE_SECONDS).and().with().pollDelay(Duration.ONE_SECOND.multiply(5))
                .await().timeout(Duration.ONE_SECOND.multiply(timeout))
                .untilAsserted(() -> assertThat(
                    JsonPath.parse(JsonPath.parse(given().contentType(ContentType.JSON).when().get(dhoeventuri)
                            .getBody().jsonPath().getList(".").get(0)).jsonString()).read(Constant.TXNSTATUS),
                    containsString(eventStatus))

        );
        String txnStatus = JsonPath.parse(JsonPath.parse(
            given().contentType(ContentType.JSON).when().get(dhoeventuri).getBody().jsonPath().getList(".").get(0))
                .jsonString()).read(Constant.TXNSTATUS);
        log.info("TXN_STAT_DESC:" + txnStatus);
        // This is to print the event status response URL in the report
        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).when()
                .get(dhoeventuri);

    }
    
    @Then("^Validate Status code for the Second Provider Initiator event \"([^\"]*)\"$")
    public void validate_Status_code_for_the_second_Provider_Initiator_event(String eventStatus) throws Throwable {

        String dhoeventuri = PropLoader.props.apply("dhoapihost") + PropLoader.props.apply("dhoevent")
            + Serenity.getCurrentSession().get(Constant.SA_PROVIDERGDFID1);
        log.info("dho event url :" + dhoeventuri);
        int timeout = Integer.parseInt(PropLoader.props.apply("providerresponsetimeoutseconds"));
        Awaitility.with().pollInterval(Duration.FIVE_SECONDS).and().with().pollDelay(Duration.ONE_SECOND.multiply(5))
                .await().timeout(Duration.ONE_SECOND.multiply(timeout))
                .untilAsserted(() -> assertThat(
                    JsonPath.parse(JsonPath.parse(given().contentType(ContentType.JSON).when().get(dhoeventuri)
                            .getBody().jsonPath().getList(".").get(0)).jsonString()).read(Constant.TXNSTATUS),
                    containsString(eventStatus))

        );
        String txnStatus = JsonPath.parse(JsonPath.parse(
            given().contentType(ContentType.JSON).when().get(dhoeventuri).getBody().jsonPath().getList(".").get(0))
                .jsonString()).read(Constant.TXNSTATUS);
        log.info("TXN_STAT_DESC:" + txnStatus);
        // This is to print the event status response URL in the report
        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).when()
                .get(dhoeventuri);

    }

    @Then("^Validate Event Status Response Code for the Provider Initiator event\"([^\"]*)\"$")
    public void validate_Event_status__response_code_for_the_Provider_Initiator_event(String responseCode)
        throws Throwable {

        // Poll interval of 10 second with an initial delay of 10 seconds and
        // Max timeout after 3 minutes.60 *3=180 seconds
        String dhoeventuri = PropLoader.props.apply("dhoapihost") + PropLoader.props.apply("dhoevent")
            + Serenity.getCurrentSession().get(Constant.PROVIDERGDFID);
        log.info("dho event url :" + dhoeventuri);

        Awaitility.with().pollInterval(Duration.ONE_SECOND.multiply(5)).and().with()
                .pollDelay(Duration.ONE_SECOND.multiply(1)).await().timeout(Duration.ONE_SECOND.multiply(40))
                .untilAsserted(() -> assertThat(given().contentType(ContentType.JSON).when().get(dhoeventuri).then()
                        .statusCode(Integer.parseInt(responseCode)))

        );

    }

    @Then("^Validate Event Status Response Code for the Provider Update Initiator event \"([^\"]*)\"$")
    public void validate_Event_Status_Response_Code_for_the_Provider_Update_Initiator_event(String eventStatus)
        throws Throwable {

        String dhoeventuri = PropLoader.props.apply("dhoapihost") + PropLoader.props.apply("dhoevent")
            + Serenity.getCurrentSession().get(Constant.PROVIDERGDFID);
        log.info("dho event url :" + dhoeventuri);
        int timeout = Integer.parseInt(PropLoader.props.apply("providerresponsetimeoutseconds"));
        Awaitility.with().pollInterval(Duration.FIVE_SECONDS).and().with().pollDelay(Duration.ONE_SECOND.multiply(5))
                .await().timeout(Duration.ONE_SECOND.multiply(timeout))
                .untilAsserted(() -> assertThat(
                    JsonPath.parse(JsonPath.parse(given().contentType(ContentType.JSON).when().get(dhoeventuri)
                            .getBody().jsonPath().getList(".").get(0)).jsonString()).read(Constant.TXNSTATUS),
                    containsString(eventStatus))

        );
        String txnStatus = JsonPath.parse(JsonPath.parse(
            given().contentType(ContentType.JSON).when().get(dhoeventuri).getBody().jsonPath().getList(".").get(0))
                .jsonString()).read(Constant.TXNSTATUS);
        log.info("TXN_STAT_DESC:" + txnStatus);
        // This is to print the event status response URL in the report
        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).when()
                .get(dhoeventuri);

    }

    @Then("^Validate Event Status Response Code for the Delete Provider Inititor event\"([^\"]*)\"$")
    public void validate_Event_status__response_code_for_the_Provider_Delete_Initiator_event(String responseCode)
        throws Throwable {

        // Poll interval of 10 second with an initial delay of 10 seconds and
        // Max timeout after 3 minutes.60 *3=180 seconds
        String dhoeventuri = PropLoader.props.apply("dhoapihost") + PropLoader.props.apply("dhodeleteevent")
            + Serenity.getCurrentSession().get(Constant.PROVIDERGDFID);
        log.info("dho event url :" + dhoeventuri);

        Awaitility.with().pollInterval(Duration.ONE_SECOND.multiply(5)).and().with()
                .pollDelay(Duration.ONE_SECOND.multiply(1)).await().timeout(Duration.ONE_SECOND.multiply(20))
                .untilAsserted(() -> assertThat(given().contentType(ContentType.JSON).when().delete(dhoeventuri).then()
                        .statusCode(Integer.parseInt(responseCode)))

        );

    }
    
    @Then("^Validate Event Status Response Code for the Delete First Provider Inititor event\"([^\"]*)\"$")
    public void validate_Event_status__response_code_for_the_First_Provider_Delete_Initiator_event(String responseCode)
        throws Throwable {

        // Poll interval of 10 second with an initial delay of 10 seconds and
        // Max timeout after 3 minutes.60 *3=180 seconds
        String dhoeventuri = PropLoader.props.apply("dhoapihost") + PropLoader.props.apply("dhodeleteevent")
            + Serenity.getCurrentSession().get(Constant.SA_PROVIDERGDFID);
        log.info("dho event url :" + dhoeventuri);

        Awaitility.with().pollInterval(Duration.ONE_SECOND.multiply(5)).and().with()
                .pollDelay(Duration.ONE_SECOND.multiply(1)).await().timeout(Duration.ONE_SECOND.multiply(20))
                .untilAsserted(() -> assertThat(given().contentType(ContentType.JSON).when().delete(dhoeventuri).then()
                        .statusCode(Integer.parseInt(responseCode)))

        );

    }
    
    @Then("^Validate retry has hapenned for the provider \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void  validateRetry(String eventStatus, String topicName, String retryCount){  
    	String dhoeventuri = dhoapihost + dhoevent + Serenity.getCurrentSession().get(Constant.PROVIDERGDFID);
        log.info("dho event url :" + dhoeventuri); 
    	int timeout = Integer.parseInt(PropLoader.props.apply("manualretrytimeoutseconds"));
    	Awaitility.with().pollInterval(Duration.TWO_SECONDS).and().with().pollDelay(Duration.ONE_SECOND.multiply(60)).await()
        .timeout(Duration.ONE_SECOND.multiply(timeout))
        .untilAsserted(() -> assertThat(
            JsonPath.parse(JsonPath.parse(given().contentType(ContentType.JSON).when().get(dhoeventuri)
                    .getBody().jsonPath().getList(".").get(0)).jsonString()).read(Constant.TXNSTATUS),
            containsString(eventStatus)));
    	 
    	 Response response=given().contentType(ContentType.JSON).when().get(dhoeventuri);
    	 
    	 assertThat(JsonPath.parse(JsonPath.parse(response
                 .getBody().jsonPath().getList(".").get(0)).jsonString()).read(Constant.TOPICNAME),
         containsString(topicName));
    	 
    	    	 
    	 assertThat(JsonPath.parse(JsonPath.parse(response
                 .getBody().jsonPath().getList(".").get(0)).jsonString()).read(Constant.RETRYCOUNT).toString(),
         containsString(retryCount));
         
}
    
    @Then("^Validate Event Status Response Code for the Delete Second Provider Inititor event\"([^\"]*)\"$")
    public void validate_Event_status__response_code_for_the_Second_Provider_Delete_Initiator_event(String responseCode)
        throws Throwable {

        // Poll interval of 10 second with an initial delay of 10 seconds and
        // Max timeout after 3 minutes.60 *3=180 seconds
        String dhoeventuri = PropLoader.props.apply("dhoapihost") + PropLoader.props.apply("dhodeleteevent")
            + Serenity.getCurrentSession().get(Constant.SA_PROVIDERGDFID1);
        log.info("dho event url :" + dhoeventuri);

        Awaitility.with().pollInterval(Duration.ONE_SECOND.multiply(5)).and().with()
                .pollDelay(Duration.ONE_SECOND.multiply(1)).await().timeout(Duration.ONE_SECOND.multiply(20))
                .untilAsserted(() -> assertThat(given().contentType(ContentType.JSON).when().delete(dhoeventuri).then()
                        .statusCode(Integer.parseInt(responseCode)))

        );

    }

}
