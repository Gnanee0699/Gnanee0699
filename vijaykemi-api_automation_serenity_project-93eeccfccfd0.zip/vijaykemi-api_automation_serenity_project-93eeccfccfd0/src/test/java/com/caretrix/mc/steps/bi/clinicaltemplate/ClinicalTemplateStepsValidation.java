package com.caretrix.mc.steps.bi.clinicaltemplate;

import static io.restassured.RestAssured.given;
import static net.serenitybdd.rest.SerenityRest.rest;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.assertj.core.api.Assertions.assertThat;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.awaitility.Awaitility;
import org.awaitility.Duration;

import com.API.Rest.validations.MedcompassValidations;
import com.caretrix.medcompass.cucumber.steps.Common;
import com.jayway.jsonpath.JsonPath;
import com.mc.TestUtils.Constant;
import com.mc.TestUtils.PropLoader;

import cucumber.api.java.en.Then;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Steps;

public class ClinicalTemplateStepsValidation {

    Common common = new Common();

    private static final Logger log = LogManager.getLogger(ClinicalTemplateStepsValidation.class);

    @Steps
    private MedcompassValidations validation = new MedcompassValidations();

    @Then("^Validate Event Status details for the Clinical Template event \"([^\"]*)\"$")
    public void validate_Status_code_for_the_ClinicalTemplate_event(String eventStatus) throws Throwable {

        String biClinTempEventUri = PropLoader.props.apply("dhoapihost")
            + PropLoader.props.apply("getBIClinicaltemplate") + Serenity.getCurrentSession().get(Constant.CASEID);
        log.info("BI ClinicalTemplate event url :" + biClinTempEventUri);

        Response response = given().contentType(ContentType.JSON).when().get(biClinTempEventUri);

        String txnStatus =
            (JsonPath.parse(JsonPath.parse(response.getBody().jsonPath().getList(".").get(0)).jsonString())
                    .read(Constant.BI_CLINTEMP_STATUS));
        log.info("TXN_STAT_DESC:" + txnStatus);
        int timeout = Integer.parseInt(PropLoader.props.apply("biclinicalTemplatetimeoutinminutes"));
        // Max Time Out-20 min
        Awaitility.with().pollInterval(Duration.TWO_SECONDS).and().with().pollDelay(Duration.TWO_SECONDS.multiply(1))
                .await().timeout(Duration.ONE_MINUTE.multiply(timeout))
                .untilAsserted(() -> assertThat(
                    JsonPath.parse(JsonPath.parse(given().contentType(ContentType.JSON).when().get(biClinTempEventUri)
                            .getBody().jsonPath().getList(".").get(0)).jsonString()).read(Constant.BI_CLINTEMP_STATUS),
                    containsString(eventStatus))

        );

        log.info("TXN_STAT_DESC PASSED:");
        // This is to print the event status response URL in the report
        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).when()
                .get(biClinTempEventUri);
        // String fileSentName = (JsonPath.parse(JsonPath.parse(response
        // .getBody().jsonPath().getList(".").get(0)).jsonString()).read("$.FILE_SENT_NM"));
        // String successFlag = (JsonPath.parse(JsonPath.parse(response
        // .getBody().jsonPath().getList(".").get(0)).jsonString()).read("$.SUCCESS_FLAG"));
        String lineGDFID =
            (JsonPath.parse(JsonPath.parse(response.getBody().jsonPath().getList(".").get(0)).jsonString())
                    .read("$.LN_GDF_ID"));
        String eventGUID =
            (JsonPath.parse(JsonPath.parse(response.getBody().jsonPath().getList(".").get(0)).jsonString())
                    .read("$.EVENT_GUID"));

        String expLineID = Serenity.getCurrentSession().get(Constant.CASEID) + "-001";
        // 'FILE_SENT_NM
        // assertThat(fileSentName).isNotEmpty();
        // log.info("fileSentName:"+fileSentName);

        // assertThat(successFlag).isNotEmpty();
        // log.info("successFlag:"+successFlag);
        assertThat(lineGDFID).isNotEmpty();
        log.info("lineGDFID is not empty");
        assertThat(lineGDFID, containsString(expLineID));
        log.info("lineGDFID:" + lineGDFID);

        Serenity.getCurrentSession().put(Constant.EVENTGUID, eventGUID);

    }

    @Then("^Validate Event Status Response Code for the Clinical Template event\"([^\"]*)\"$")
    public void validate_Event_status_response_code_for_the_ClinicalTemplate_event(String responseCode)
        throws Throwable {

        // Poll interval of 10 second with an initial delay of 10 seconds and
        // Max timeout after 3 minutes.60 *3=180 seconds
        String biClinTempEventUri = PropLoader.props.apply("dhoapihost")
            + PropLoader.props.apply("getBIClinicaltemplate") + Serenity.getCurrentSession().get(Constant.CASEID);
        log.info("BI ClinicalTemplate event url :" + biClinTempEventUri);
        int timeout = Integer.parseInt(PropLoader.props.apply("biclinicalTemplatetimeoutinminutes"));
        Awaitility.with().pollInterval(Duration.ONE_MINUTE.multiply(1)).and().with()
                .pollDelay(Duration.ONE_MINUTE.multiply(1)).await().timeout(Duration.ONE_MINUTE.multiply(timeout))
                .untilAsserted(() -> assertThat(given().contentType(ContentType.JSON).when().get(biClinTempEventUri)
                        .then().statusCode(Integer.parseInt(responseCode)))

        );

    }

    @Then("^Validate Event Status Response Code for the Delete Clinical Template event\"([^\"]*)\"$")
    public void validate_Event_status__response_code_for_the_Delete_ClinicalTemplate_event(String responseCode)
        throws Throwable {

        // Poll interval of 10 second with an initial delay of 10 seconds and
        // Max timeout after 3 minutes.60 *3=180 seconds
        String biClinTempEventUri = PropLoader.props.apply("dhoapihost")
            + PropLoader.props.apply("deleteBIClinicaltemplate") + Serenity.getCurrentSession().get(Constant.CASEID);
        log.info("BI ClinicalTemplate Delete event url :" + biClinTempEventUri);

        Awaitility.with().pollInterval(Duration.ONE_SECOND.multiply(2)).and().with()
                .pollDelay(Duration.ONE_SECOND.multiply(1)).await().timeout(Duration.ONE_SECOND.multiply(10))
                .untilAsserted(() -> assertThat(given().contentType(ContentType.JSON).when().delete(biClinTempEventUri)
                        .then().statusCode(Integer.parseInt(responseCode)))

        );

    }

    @Then("^Validate Event Status Response Code for the Delete Cancelled Status Clinical Template event\"([^\"]*)\"$")
    public void validate_Event_status__response_code_for_the_Delete_CancelledStatus_ClinicalTemplate_event(
        String responseCode) throws Throwable {

        // Poll interval of 10 second with an initial delay of 10 seconds and
        // Max timeout after 3 minutes.60 *3=180 seconds
        String biClinTempEventUri =
            PropLoader.props.apply("dhoapihost") + PropLoader.props.apply("deleteBICancelledClinicaltemplate")
                + Serenity.getCurrentSession().get(Constant.CASEID);
        log.info("BI ClinicalTemplate Cancelled status Delete event url :" + biClinTempEventUri);

        Awaitility.with().pollInterval(Duration.ONE_SECOND.multiply(2)).and().with()
                .pollDelay(Duration.ONE_SECOND.multiply(1)).await().timeout(Duration.ONE_SECOND.multiply(10))
                .untilAsserted(() -> assertThat(given().contentType(ContentType.JSON).when().delete(biClinTempEventUri)
                        .then().statusCode(Integer.parseInt(responseCode)))

        );

    }
}
