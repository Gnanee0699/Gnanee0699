package com.caretrix.mc.cucumber.TestRunner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import net.thucydides.junit.annotations.Concurrent;

@Concurrent(threads = "4x")
@RunWith(CucumberWithSerenity.class)

@CucumberOptions(features = "src/test/resources/feature/", strict = true, tags = {

		// "@TC_002_providerMandatoryandOptionalFieldErrorValidation"

		"@ProviderMandatoryandOptionalFieldsValidation"

}, glue = "com/carecentrix/medcompass/cucumber/steps")

public class MCClientProviderMandatoryOptionalRunnerTest {

}
