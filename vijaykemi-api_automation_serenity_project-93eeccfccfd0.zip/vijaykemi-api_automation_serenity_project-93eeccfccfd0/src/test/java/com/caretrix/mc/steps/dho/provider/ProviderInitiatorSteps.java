package com.caretrix.mc.steps.dho.provider;

import static net.serenitybdd.rest.SerenityRest.rest;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.API.Rest.validations.MedcompassValidations;
import com.jayway.jsonpath.JsonPath;
import com.mc.TestUtils.Constant;
import com.mc.TestUtils.ExcelTestData;
import com.mc.TestUtils.JsonUpdateUtil;
import com.mc.TestUtils.PropLoader;
import com.mc.setup.SetupHeaders;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Steps;

public class ProviderInitiatorSteps {

	
	private static final Logger log = LogManager.getLogger(ProviderInitiatorSteps.class);

	private static final String dhoProviderJsonTemplatePath = "src/test/resources/jsonPayloads/dho/provider/DHOProviderAdd.json";
	
	Map<String,Map<String, String>> dataMap; 

	@Steps
	private MedcompassValidations validation = new MedcompassValidations();

	@Given("^Provider Add event to MC resulting from a Service Auth event$")
	public void setup_proxy_for_a_Provider_Request() throws Throwable {
		SetupHeaders.initialSetup("dhoapihost");
	}

	@Given("^Provider Add or Update event to MC is unsuccessful and the retry count is not maxed$")
	public void setup_proxy_for_a_ProviderRetry_Request() throws Throwable {
		SetupHeaders.initialSetup("dhoapihost");
	}

	@When("^Provider add request triggered without MedCompassID such that \"([^\"]*)\"$")
	public void ProviderInitiator(String scenario) throws Throwable {

		String gdfid = UUID.randomUUID().toString();
		String payload = getProviderPayLoad(scenario, PropLoader.props.apply("dhoprovidersheet"));
		payload = JsonPath.parse(payload).set(Constant.PROVIDERGDFID, gdfid).jsonString();
		Serenity.getCurrentSession().put(Constant.PROVIDERGDFID, gdfid);
        String strRequestType = JsonPath.parse(payload).read(Constant.DHO_REQUEST_TYPE);
        Serenity.getCurrentSession().put(Constant.REQUEST_TYPE, strRequestType);		
		log.info("Provider Add GDFID =" + Serenity.getCurrentSession().get(Constant.PROVIDERGDFID));
		rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
				.basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password)).when()
				.log().all().body(payload).post(PropLoader.props.apply("provideraddapi"));

	}
	
	@When("^Provider add request triggered without MedCompassID for the same provider such that \"([^\"]*)\"$")
	public void ProviderInitiatorUsingSameProvider(String scenario) throws Throwable {

		String gdfid = (String) Serenity.getCurrentSession().get(Constant.PROVIDERGDFID);
		String payload = getProviderPayLoad(scenario, PropLoader.props.apply("dhoprovidersheet"));
		payload = JsonPath.parse(payload).set(Constant.PROVIDERGDFID, gdfid).jsonString();
		Serenity.getCurrentSession().put(Constant.PROVIDERGDFID, gdfid);
		log.info("Provider Add GDFID =" + Serenity.getCurrentSession().get(Constant.PROVIDERGDFID));
		rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
				.basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password)).when()
				.log().all().body(payload).post(PropLoader.props.apply("provideraddapi"));

	}

	@When("^Provider Add or update request from MCI Monitor retry is triggered \"([^\"]*)\"$")
	public void providerInitiatorRetry(String scenario) throws Throwable {
		String gdfid = UUID.randomUUID().toString();
		String payload = getProviderPayLoad(scenario, PropLoader.props.apply("dhoprovidersheet"));
		payload = JsonPath.parse(payload).set(Constant.PROVIDERGDFID, gdfid).jsonString();
		Serenity.getCurrentSession().put(Constant.PROVIDERGDFID, gdfid);
		rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
				.basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password)).when()
				.log().all().body(payload).post(PropLoader.props.apply("providerretryapi"));

	}

	@Given("^Provider Add request already triggered from SA and failed \"([^\"]*)\"$")
	public void provider_add_request_already_triggered_from_sa(String scenario) throws Throwable {
		SetupHeaders.initialSetup("dhoapihost");
		String gdfid = UUID.randomUUID().toString();
		String payload = getProviderPayLoad(scenario, PropLoader.props.apply("dhoprovidersheet"));
		payload = JsonPath.parse(payload).set(Constant.PROVIDERGDFID, gdfid).jsonString();
		Serenity.getCurrentSession().put(Constant.PROVIDERGDFID, gdfid);
		log.info("provider add URL", PropLoader.props.apply("provideraddapi"));
		rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
				.basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password)).when()
				.log().all().body(payload).post(PropLoader.props.apply("provideraddapi"));
	}

	@When("^Update Provider request from UDH is triggered \"([^\"]*)\"$")
	public void updateProviderRequest(String scenario) throws Throwable {
		String payload = getProviderPayLoad(scenario, PropLoader.props.apply("dhoprovidersheet"));
		log.info("Provider Update GDFID =" + Serenity.getCurrentSession().get(Constant.PROVIDERGDFID));
		payload = JsonPath.parse(payload).set(Constant.PROVIDERGDFID, Serenity.getCurrentSession().get(Constant.PROVIDERGDFID))
				.jsonString();
		payload = JsonPath.parse(payload).set(Constant.DHO_REQUEST_TYPE, "Modify").jsonString();
        String strRequestType = JsonPath.parse(payload).read(Constant.DHO_REQUEST_TYPE);
        Serenity.getCurrentSession().put(Constant.REQUEST_TYPE, strRequestType);
		log.info("provider add URL", PropLoader.props.apply("providerupdateapi"));
		rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
				.basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password)).when()
				.log().all().body(payload).post(PropLoader.props.apply("providerupdateapi"));

	}


	@Given("^Provider Add request already triggered from MCI Monitor retry failed \"([^\"]*)\"$")
	public void provider_addretry_request_already_triggered(String scenario) throws Throwable {
		SetupHeaders.initialSetup("dhoapihost");
		String gdfid = UUID.randomUUID().toString();
		String payload = getProviderPayLoad(scenario, PropLoader.props.apply("dhoprovidersheet"));
		payload = JsonPath.parse(payload).set(Constant.PROVIDERGDFID, gdfid).jsonString();
		Serenity.getCurrentSession().put(Constant.PROVIDERGDFID, gdfid);
		log.info("provider add URL", PropLoader.props.apply("providerretryapi"));
		rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
				.basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password)).when()
				.log().all().body(payload).post(PropLoader.props.apply("providerretryapi"));
	}


	
	//############################Update Provider Initiator##############################
	

	@Given("^Provider Update request already triggered from UDH and received mcResponse validation \"([^\"]*)\" and \"([^\"]*)\"$")
	public void provider_Update_request_already_triggered_from_UDH_and_received_mcResponse_validation(String scenario, String sheetname) throws Throwable {
		SetupHeaders.initialSetup("dhoapihost");
	}
	
	@Given("^Provider Update request already triggered from UDH and received mcResponse validation$")
	public void provider_Update_request_already_triggered_from_UDH_and_received_mcResponse_validation() throws Throwable {
		SetupHeaders.initialSetup("dhoapihost");
	}

	@Given("^Provider Update event to MC resulting from a Service Auth event$")
	public void provider_Update_event_to_MC_resulting_from_a_Service_Auth_event()  throws Throwable {
		SetupHeaders.initialSetup("dhoapihost");
	}
	
	@When("^Update Provider request from SA Initiator is triggered for Provider with MedCompassID such that \"([^\"]*)\" and \"([^\"]*)\"$")
	public void update_Provider_request_from_SA_Initiator_is_triggered_for_Provider_with_MedCompassID_such_that_and(String scenario, String sheetname) throws Throwable {

		SetupHeaders.initialSetup("dhoapihost");
		String gdfid = UUID.randomUUID().toString();
		String payload = getProviderPayLoad(scenario, PropLoader.props.apply("dhoprovidersheet"));
		payload = JsonPath.parse(payload).set(Constant.PROVIDERGDFID, gdfid).jsonString();
		payload = JsonPath.parse(payload).set(Constant.DHO_REQUEST_TYPE, "Modify").jsonString();
		Serenity.getCurrentSession().put(Constant.PROVIDERGDFID, gdfid);
		log.info("Provider update URL",PropLoader.props.apply("providerupdateapi"));
		rest().given().contentType(Constant.CONTENTTYPE)
			.header("Content-Type",Constant.CONTENTTYPE)
			.auth().basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password))
			.when().log().all()
			.body(payload)
			.post(PropLoader.props.apply("providerupdateapi"));
	
	}
	
	@When("^Provider Update message from UDH is triggered without a MedCompassID for the same provider \"([^\"]*)\" and \"([^\"]*)\"$")
	public void triggerSameProviderForUpdate(String scenario, String sheetname) throws Throwable {

		SetupHeaders.initialSetup("dhoapihost");
		String gdfid = (String) Serenity.getCurrentSession().get(Constant.PROVIDERGDFID);
		String payload = getProviderPayLoad(scenario, PropLoader.props.apply("dhoprovidersheet"));
		payload = JsonPath.parse(payload).set(Constant.PROVIDERGDFID, gdfid).jsonString();
		payload = JsonPath.parse(payload).set(Constant.DHO_REQUEST_TYPE, "Modify").jsonString();
		Serenity.getCurrentSession().put(Constant.PROVIDERGDFID, gdfid);
		log.info("Provider update URL",PropLoader.props.apply("providerupdateapi"));
		rest().given().contentType(Constant.CONTENTTYPE)
			.header("Content-Type",Constant.CONTENTTYPE)
			.auth().basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password))
			.when().log().all()
			.body(payload)
			.post(PropLoader.props.apply("providerupdateapi"));
	
	}
	
	@When("^Update Retry Provider request from SA Initiator is triggered for Provider with MedCompassID such that \"([^\"]*)\" and \"([^\"]*)\"$")
	public void update_Retry_Provider_request_from_SA_Initiator_is_triggered_for_Provider_with_MedCompassID_such_that_and(String scenario, String sheetname) throws Throwable {

		SetupHeaders.initialSetup("dhoapihost");
		String gdfid = UUID.randomUUID().toString();
		String payload = getProviderPayLoad(scenario, PropLoader.props.apply("dhoprovidersheet"));
		payload = JsonPath.parse(payload).set(Constant.PROVIDERGDFID, gdfid).jsonString();
		payload = JsonPath.parse(payload).set(Constant.DHO_REQUEST_TYPE, "Modify").jsonString();
		Serenity.getCurrentSession().put(Constant.PROVIDERGDFID, gdfid);
		log.info("Provider update Retry URL",PropLoader.props.apply("providerretryapi"));
		rest().given().contentType(Constant.CONTENTTYPE)
			.header("Content-Type",Constant.CONTENTTYPE)
			.auth().basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password))
			.when().log().all()
			.body(payload)
			.post(PropLoader.props.apply("providerretryapi"));
	
	}
	
	
	
	@Given("^A Provider Update has been made in core systems and the update is replicated in the UDH and UDH published a provider update event$")
	public void a_update_Provider_is_created_in_core_systems_AND_the_new_Provider_data_is_replicated_in_the_UDH_AND_UDH_published_a_Provider_update_event() throws Throwable {
		SetupHeaders.initialSetup("dhoapihost");
	}
	
	
	@When("^Provider Update message from UDH is triggered without a MedCompassID \"([^\"]*)\" and \"([^\"]*)\"$")
	public void update_message_from_UDH_is_triggered_with_Provider_without_a_MedCompassID_and(String scenario, String sheetname) throws Throwable {

		SetupHeaders.initialSetup("dhoapihost");
		String gdfid = UUID.randomUUID().toString();
		String payload = getProviderPayLoad(scenario, PropLoader.props.apply("dhoprovidersheet"));
		payload = JsonPath.parse(payload).set(Constant.PROVIDERGDFID, gdfid).jsonString();

		payload = JsonPath.parse(payload).set(Constant.DHO_REQUEST_TYPE, "Modify").jsonString();
		Serenity.getCurrentSession().put(Constant.PROVIDERGDFID, gdfid);
		log.info("Provider update URL",PropLoader.props.apply("providerupdateapi"));
		rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
				.basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password)).when()
				.log().all().body(payload).post(PropLoader.props.apply("providerupdateapi"));

	}
	
	@When("^Manual Retry is triggered for the provider")
    public void triggerManualRetry(){
    	
    	String dhomanualretruri = PropLoader.props.apply("manualretryhost") + PropLoader.props.apply("manualretryevent") + Serenity.getCurrentSession().get(Constant.PROVIDERGDFID) + Constant.EVENT_ID_DB + Serenity.getCurrentSession().get(Constant.EVENTGUID) ;
    	log.info("dho Mnaul Retry event url :" + dhomanualretruri);
        String payload ="{}";   
        payload = JsonPath.parse(payload).jsonString();
        // This is to print the event status response URL in the report
        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
        .basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password)).when()
        .log().all().body(payload).post(dhomanualretruri).
        then().assertThat().statusCode(200); 
    }

    @When("^Status of the provider is changed to \"([^\"]*)\"$")
    public void statusChange(String eventStatus){
    	
    	String statuschangeuri = PropLoader.props.apply("dhoapihost") + PropLoader.props.apply("dhoupdateeventdb") + Serenity.getCurrentSession().get(Constant.PROVIDERGDFID) + Constant.SERVICEATH_STATUS_DB + eventStatus ;
        log.info("StatusChange Endpoint :" + statuschangeuri);
        String payload ="{}";   
        payload = JsonPath.parse(payload).jsonString();
        // This is to print the event status response URL in the report
        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
        .basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password)).when()
        .log().all().body(payload).put(statuschangeuri).
        then().assertThat().statusCode(200); 
    }
	
	private String getProviderPayLoad(String scenario, String sheetname) throws IOException {
		dataMap = ExcelTestData.getTestDataBySheet(PropLoader.props.apply(Constant.DHO_PROVIDER_EXCEL_PATH), Constant.DHO_PROVIDER_SHEET_NAME);
		Serenity.getCurrentSession().put(Constant.DATA_MAP, dataMap);
		Map<String, Object> scenarioDataMap = new HashMap<>(dataMap.get(scenario));
		String jsonTemplatePayload = new String(Files.readAllBytes(Paths.get(dhoProviderJsonTemplatePath)));
		String payload = JsonUpdateUtil.buildJsonRequest(jsonTemplatePayload, scenarioDataMap,"DHOProvider");
		return payload;
	}

}
