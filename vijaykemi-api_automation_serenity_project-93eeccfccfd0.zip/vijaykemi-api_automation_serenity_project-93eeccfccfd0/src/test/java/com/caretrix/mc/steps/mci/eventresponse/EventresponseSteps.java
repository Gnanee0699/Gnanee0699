package com.caretrix.mc.steps.mci.eventresponse;

import static net.serenitybdd.rest.SerenityRest.rest;


import java.io.IOException;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;

import com.API.Rest.validations.MedcompassValidations;
import com.jayway.jsonpath.JsonPath;
import com.mc.TestUtils.Constant;
import com.mc.TestUtils.ExcelReader;
import com.mc.TestUtils.ExcelTestData;
import com.mc.TestUtils.JsonUpdateUtil;
import com.mc.TestUtils.PropLoader;
import com.mc.setup.SetupHeaders;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import io.restassured.response.Response;
import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Steps;

public class EventresponseSteps {
	
	String memevntrespuri;
	String eventrespmemContent;
	JSONObject eventresponsecontent;
	
	private static final Logger log = LogManager.getLogger(EventresponseSteps.class);
	
	private static final String dhoMemberJsonTemplatePath ="src/test/resources/jsonPayloads/dho/member/DHOMember.json";
	
	Map<String,Map<String, String>> dataMap; 
	
	@Steps
	private MedcompassValidations validation = new MedcompassValidations();

	@Given("^Setup proxy for a EventResponse Request$")
	public void setup_proxy_for_a_EventResponse_Request() throws Throwable {
		SetupHeaders.initialSetupEventResp();
	}
	
	@When("^MemEvent request is initiated for \"([^\"]*)\"$")
	public void MemEvent_request_is_initiated_for(String scenario) throws Throwable {

		String sheetName= PropLoader.props.apply("MemEvtResponseSHT");
		
		memevntrespuri = PropLoader.props.apply("mcevntresphostname") + PropLoader.props.apply("baseevntrespath")
				+ PropLoader.props.apply("evtmemapi");
		
		String eventid = UUID.randomUUID().toString();
		
		log.info("memevntrespuri:" + memevntrespuri);
		log.info("scenario {}", scenario);
		log.info("eventidvalue {}", eventid);
		Map<String, Object> dataMap = ExcelReader.readAllRow(sheetName, scenario);
		log.info("dataMap {}" + dataMap);
		eventrespmemContent = new String(Files.readAllBytes(
				Paths.get("src/test/resources/jsonPayloads/McIntegrationService/MCIMember.json")));
		eventresponsecontent = new JSONObject(eventrespmemContent);
		String payload = JsonUpdateUtil.eventresponseadd(eventresponsecontent,
				eventid, dataMap);
		Serenity.getCurrentSession().put(Constant.EVENT_ID_VALUE_JSON_PATH, eventid);
		Response immediateResponse = rest().given().contentType(Constant.CONTENTTYPE)
				.header("Content-Type", Constant.CONTENTTYPE).auth().basic(PropLoader.props.apply("username"), PropLoader.props.apply("password")).when()
				.log().all().body(payload).post(memevntrespuri);
		log.info(immediateResponse.getBody().asString());

	}
	
	@When("^ProvEvent request is initiated for \"([^\"]*)\"$")
	public void ProvEvent_request_is_initiated_for(String scenario) throws Throwable {

		String sheetName= PropLoader.props.apply("ProvEvtResponseSHT");
		
		memevntrespuri = PropLoader.props.apply("mcevntresphostname") + PropLoader.props.apply("baseevntrespath")
				+ PropLoader.props.apply("evtmemapi");
		
		String eventid = UUID.randomUUID().toString();
		
		log.info("memevntrespuri:" + memevntrespuri);
		log.info("scenario {}", scenario);
		log.info("eventidvalue {}", eventid);
		Map<String, Object> dataMap = ExcelReader.readAllRow(sheetName, scenario);
		log.info("dataMap {}" + dataMap);
		eventrespmemContent = new String(Files.readAllBytes(
				Paths.get("src/test/resources/jsonPayloads/McIntegrationService/MCIProv.json")));
		eventresponsecontent = new JSONObject(eventrespmemContent);
		String payload = JsonUpdateUtil.eventresponseadd(eventresponsecontent,
				eventid, dataMap);
		Serenity.getCurrentSession().put(Constant.EVENT_ID_VALUE_JSON_PATH, eventid);
		Response immediateResponse = rest().given().contentType(Constant.CONTENTTYPE)
				.header("Content-Type", Constant.CONTENTTYPE).auth().basic(PropLoader.props.apply("username"), PropLoader.props.apply("password")).when()
				.log().all().body(payload).post(memevntrespuri);
		log.info(immediateResponse.getBody().asString());

	}
	
	
}


