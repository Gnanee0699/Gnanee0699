package com.caretrix.mc.steps.dho.serviceauth;

import static net.serenitybdd.rest.SerenityRest.rest;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.awaitility.Awaitility;
import org.awaitility.Duration;

import com.jayway.jsonpath.JsonPath;
import com.mc.TestUtils.Constant;
import com.mc.TestUtils.PropLoader;

import cucumber.api.java.en.Then;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import net.minidev.json.JSONArray;
import net.serenitybdd.core.Serenity;

public class SATemplateEngineStepsValidation {

    private static final Logger log = LogManager.getLogger(SATemplateEngineStepsValidation.class);

    @Then("^Validate DHo Payload and MC Payload for object \"([^\"]*)\"$")
    public void validate_Status_code_for_the_Service_Auth_Initiator_event(String scenario) throws Throwable {
        String dhoeventuri = PropLoader.props.apply("mcapihostname") + PropLoader.props.apply("dhomcsentpayload")
            + Serenity.getCurrentSession().get(Constant.CASEID);
        log.info("dho event url :" + dhoeventuri);

        Awaitility.with().pollInterval(Duration.ONE_SECOND.multiply(1)).and().with()
                .pollDelay(Duration.ONE_SECOND.multiply(1)).await().timeout(Duration.ONE_SECOND.multiply(10))
                .until(() -> isStatus(dhoeventuri));

        Response response = rest().given().contentType(Constant.CONTENTTYPE)
                .header("Content-Type", Constant.CONTENTTYPE).when().get(dhoeventuri);
        // Assert.equal
        String responseBody = response.getBody().prettyPrint();

        log.info("resppnseBody:" + responseBody);

        //assertEquals(true, validateFieldValues(response.getBody().asString(), scenario));
        validateFieldValues(response.getBody().asString(), scenario);

    }

    private Boolean isStatus(String url) {
        Response response = RestAssured.given().when().get(url);
        return response.then().extract().statusCode() == 200;
    }

    @SuppressWarnings("unchecked")
    private void validateFieldValues(String response, String scenario) {
        Map<String, Map<Object, Object>> dataMap;
        dataMap = (Map<String, Map<Object, Object>>) Serenity.getCurrentSession().get(Constant.DATA_MAP);
        List<String> dataList = new ArrayList<>();
        List<String> valueList = new ArrayList<>();
        for (Entry<String, Map<Object, Object>> mainmapentry : dataMap.entrySet()) {
            try {
                // log.info("dataMap" + dataMap);
                Map<Object, Object> map = null;
                if (mainmapentry.getKey().contains(scenario)) {
                    map = mainmapentry.getValue();
                }
                String dhoValue = "";
                String mcValue = "";
              
                for (Map.Entry<Object, Object> entry : map.entrySet()) {
                    if (entry.getKey() != null && entry.getKey().equals("ExpectedField")) {
                        if (entry.getValue() != null) {
                            List<String> list = JsonPath.parse(response).read(entry.getValue().toString());
                            if (!list.isEmpty()) {
                                dhoValue = list.get(0).toString();
                                dataList.add(list.get(0).toString());
                            }
                        }
                    } else if (entry.getKey() != null && entry.getKey().equals("ExpectedValue")) {
                        if (entry.getValue() != null) {
                            mcValue = entry.getValue().toString();
                            valueList.add(entry.getValue().toString());
                        }
                    }

                }
               // if (!dhoValue.isEmpty() && !mcValue.isEmpty() && !dhoValue.equals(mcValue)) {
                  //  return false;
             //   }

            } catch (Exception e) {
                log.info(e, e);
            }
        }
        log.info("dataList" + dataList);
        log.info("valueList" + valueList);
        //return true;
        assertEquals(valueList,dataList);
    }
    @Then("^Capture MC Payload for secondary Keys ProcedureCodeModifier object \"([^\"]*)\"$")
    public void capture_ProcedureCodeModifier_for_SAInitiator_events(String scenario) throws Throwable {
        String dhoeventuri = PropLoader.props.apply("mcapihostname") + PropLoader.props.apply("dhomcsentpayload")
            + Serenity.getCurrentSession().get(Constant.CASEID);
        log.info("dho event url :" + dhoeventuri);

        Awaitility.with().pollInterval(Duration.ONE_SECOND.multiply(2)).and().with()
                .pollDelay(Duration.ONE_SECOND.multiply(5)).await().timeout(Duration.ONE_SECOND.multiply(30))
                .until(() -> isStatus(dhoeventuri));
        
        Response response = rest().given().contentType(Constant.CONTENTTYPE)
                .header("Content-Type", Constant.CONTENTTYPE).when().get(dhoeventuri);
        // Assert.equal
        String responseBody = response.getBody().prettyPrint();
        JSONArray arrProcCodeModID = JsonPath.parse(responseBody).read(Constant.SERVICE_AUTH_LINE1_PROCEDURECODE_MODID);
        String strProcCodeModID= (String) arrProcCodeModID.get(0);
        log.info("responseBody:" + responseBody);
        log.info("strProcCodeModID:" + strProcCodeModID);
        
        if (((String) Serenity.getCurrentSession().get(Constant.REQUEST_TYPE)).contains("Add")) {
            Serenity.getCurrentSession().put(Constant.SA_ADD_LINE1_PROCEDURECODE_MODID, strProcCodeModID);
            log.info("ADD ProcedureCodeModifierID:" + Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_PROCEDURECODE_MODID));
        }else
        {
            Serenity.getCurrentSession().put(Constant.SA_UPDATE_LINE1_PROCEDURECODE_MODID, strProcCodeModID);
            log.info("UPDATE ProcedureCodeModifierID:" + Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE1_PROCEDURECODE_MODID)); 
        }
    }
    @Then("^Validate MC ServiceAuth Values in Response for ProcedureCodeModifier object for \"([^\"]*)\"$")
    public void validate_MC_ProcedureCodeModifierID(String flag) throws Throwable {
        
        log.info("ADD ProcedureCodeModifierID:" + Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_PROCEDURECODE_MODID));
        log.info("UPDATE ProcedureCodeModifierID:" + Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE1_PROCEDURECODE_MODID)); 
        if(flag.contentEquals("Equal"))           
        {           
            assertEquals(Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_PROCEDURECODE_MODID), Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE1_PROCEDURECODE_MODID));   
        }else           
        {
            assertFalse(((String) Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_PROCEDURECODE_MODID)).contentEquals((String) Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE1_PROCEDURECODE_MODID)));  
        }       
    }     
    @Then("^Capture MC Payload for secondary Keys Source ServiceAuth DiagnosisID object \"([^\"]*)\"$")
    public void capture_SADiagnosisID_for_SAInitiator_events(String scenario) throws Throwable {
        String dhoeventuri = PropLoader.props.apply("mcapihostname") + PropLoader.props.apply("dhomcsentpayload")
            + Serenity.getCurrentSession().get(Constant.CASEID);
        log.info("dho event url :" + dhoeventuri);

        Awaitility.with().pollInterval(Duration.ONE_SECOND.multiply(2)).and().with()
                .pollDelay(Duration.ONE_SECOND.multiply(5)).await().timeout(Duration.ONE_SECOND.multiply(30))
                .until(() -> isStatus(dhoeventuri));
        
        Response response = rest().given().contentType(Constant.CONTENTTYPE)
                .header("Content-Type", Constant.CONTENTTYPE).when().get(dhoeventuri);
        // Assert.equal
       //First and Second Provider GDFID s are different
        String responseBody = response.getBody().prettyPrint();
        JSONArray arrSAPrimaryID1 = JsonPath.parse(responseBody).read(Constant.SOURCE_SERVICE_AUTH_PRIMARY_DIAGID_LINE1);
        JSONArray arrSASecondaryID2 = JsonPath.parse(responseBody).read(Constant.SOURCE_SERVICE_AUTH_SECONDARY_DIAGID_LINE1);
        JSONArray arrSATertiaryID3 = JsonPath.parse(responseBody).read(Constant.SOURCE_SERVICE_AUTH_TERTIARY_DIAGID_LINE1);
        JSONArray arrSAOtherID4 = JsonPath.parse(responseBody).read(Constant.SOURCE_SERVICE_AUTH_OTHER_DIAGID_LINE1);
        
        String strSAPrimaryID1= (String) arrSAPrimaryID1.get(0);
        String strSASecondaryID2= (String) arrSASecondaryID2.get(0);
        String strSATertiaryID3= (String) arrSATertiaryID3.get(0);
        String strSAOtherID4= (String) arrSAOtherID4.get(0);
        log.info("responseBody:" + responseBody);
        log.info("strSAPrimaryID1:" + strSAPrimaryID1);
        log.info("strSASecondaryID2:" + strSASecondaryID2);
        log.info("strSATertiaryID3:" + strSATertiaryID3);
        log.info("strSAOtherID4:" + strSAOtherID4);
        
        if (((String) Serenity.getCurrentSession().get(Constant.REQUEST_TYPE)).contains("Add")) {
            Serenity.getCurrentSession().put(Constant.SA_ADD_LINE1_PRIMARYDIAG_ID, strSAPrimaryID1);
            Serenity.getCurrentSession().put(Constant.SA_ADD_LINE1_SECONDARYDIAG_ID, strSASecondaryID2);
            Serenity.getCurrentSession().put(Constant.SA_ADD_LINE1_TERTIARY_ID, strSATertiaryID3);
            Serenity.getCurrentSession().put(Constant.SA_ADD_LINE1_OTHER_ID, strSAOtherID4);
            log.info("ADD SADiagnosisPrimaryID1:" + Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_PRIMARYDIAG_ID));
            log.info("ADD SADiagnosisSecondaryID2:" + Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_SECONDARYDIAG_ID));
            log.info("ADD SADiagnosisTertiaryID3:" + Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_TERTIARY_ID));
            log.info("ADD SADiagnosisOtherID4:" + Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_OTHER_ID));
        }else
        {
        	Serenity.getCurrentSession().put(Constant.SA_UPDATE_LINE1_PRIMARYDIAG_ID, strSAPrimaryID1);
            Serenity.getCurrentSession().put(Constant.SA_UPDATE_LINE1_SECONDARYDIAG_ID, strSASecondaryID2);
            Serenity.getCurrentSession().put(Constant.SA_UPDATE_LINE1_TERTIARY_ID, strSATertiaryID3);
            Serenity.getCurrentSession().put(Constant.SA_UPDATE_LINE1_OTHER_ID, strSAOtherID4);
            log.info("Update SADiagnosisPrimaryID1:" + Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE1_PRIMARYDIAG_ID));
            log.info("Update SADiagnosisSecondaryID2:" + Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE1_SECONDARYDIAG_ID));
            log.info("Update SADiagnosisTertiaryID3:" + Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE1_TERTIARY_ID));
            log.info("Update SADiagnosisOtherID4:" + Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE1_OTHER_ID));
        }
    }
    @Then("^Validate MC ServiceAuth Values in Response for ServiceAuth DiagnosisID object for \"([^\"]*)\"$")
    public void validate_MC_ServiceAuthDiagnosisID(String flag) throws Throwable {
        
              
        if(flag.contentEquals("Equal")) 
        {
          //First and Second Provider GDFID s are different.Same Provider ID for the Add and Update for the same provider
            assertEquals(Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_PRIMARYDIAG_ID), Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE1_PRIMARYDIAG_ID)); 
            assertEquals(Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_SECONDARYDIAG_ID), Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE1_SECONDARYDIAG_ID));
            assertEquals(Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_TERTIARY_ID), Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE1_TERTIARY_ID)); 
            assertEquals(Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_OTHER_ID), Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE1_OTHER_ID));
           
        }else
        {
          //First and Second Provider GDFID s are different and Provider Types are different.So all Provider IDs are Unique for Add and Update for all Providers
            assertFalse(((String) Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_PRIMARYDIAG_ID)).contentEquals((String) Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE1_PRIMARYDIAG_ID))); 
            assertFalse(((String) Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_SECONDARYDIAG_ID)).contentEquals((String) Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE1_SECONDARYDIAG_ID)));
            assertFalse(((String) Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_TERTIARY_ID)).contentEquals((String) Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE1_TERTIARY_ID))); 
            assertFalse(((String) Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_OTHER_ID)).contentEquals((String) Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE1_OTHER_ID)));   
        }
        
    }  
    
    @Then("^Capture MC Payload for secondary Keys Source ServiceAuth ProviderID object \"([^\"]*)\"$")
    public void capture_SourceSAProviderID_for_SAInitiator_events(String scenario) throws Throwable {
        String dhoeventuri = PropLoader.props.apply("mcapihostname") + PropLoader.props.apply("dhomcsentpayload")
            + Serenity.getCurrentSession().get(Constant.CASEID);
        log.info("dho event url :" + dhoeventuri);

        Awaitility.with().pollInterval(Duration.ONE_SECOND.multiply(2)).and().with()
                .pollDelay(Duration.ONE_SECOND.multiply(5)).await().timeout(Duration.ONE_SECOND.multiply(30))
                .until(() -> isStatus(dhoeventuri));
        
        Response response = rest().given().contentType(Constant.CONTENTTYPE)
                .header("Content-Type", Constant.CONTENTTYPE).when().get(dhoeventuri);
        // Assert.equal
       //First and Second Provider GDFID s are different
        String responseBody = response.getBody().prettyPrint();
        JSONArray arrSAProviderID1 = JsonPath.parse(responseBody).read(Constant.SOURCE_SERVICE_AUTH_FIRST_PROVIDER_ID_LINE1);
        JSONArray arrSAProviderID2 = JsonPath.parse(responseBody).read(Constant.SOURCE_SERVICE_AUTH_SECOND_PROVIDER_ID_LINE1);
        String strSAProviderID1= (String) arrSAProviderID1.get(0);
        String strSAProviderID2= (String) arrSAProviderID2.get(0);
        log.info("responseBody:" + responseBody);
        log.info("strSAProviderID1:" + strSAProviderID1);
        log.info("strSAProviderID2:" + strSAProviderID2);
        
        if (((String) Serenity.getCurrentSession().get(Constant.REQUEST_TYPE)).contains("Add")) {
            Serenity.getCurrentSession().put(Constant.SA_ADD_LINE1_FIRST_PROVIDER_ID, strSAProviderID1);
            Serenity.getCurrentSession().put(Constant.SA_ADD_LINE1_SECOND_PROVIDER_ID, strSAProviderID2);
            log.info("ADD SAProviderID1:" + Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_FIRST_PROVIDER_ID));
            log.info("ADD SAProviderID2:" + Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_SECOND_PROVIDER_ID));
        }else
        {
            Serenity.getCurrentSession().put(Constant.SA_UPDATE_LINE1_FIRST_PROVIDER_ID, strSAProviderID1);
            Serenity.getCurrentSession().put(Constant.SA_UPDATE_LINE1_SECOND_PROVIDER_ID, strSAProviderID2);
            log.info("Update SAProviderID1:" + Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE1_FIRST_PROVIDER_ID));
            log.info("Update SAProviderID2:" + Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE1_SECOND_PROVIDER_ID));
        }
    }
    @Then("^Validate MC ServiceAuth Values in Response for ServiceAuth ProviderID object for \"([^\"]*)\"$")
    public void validate_MC_ServiceAuthProviderID(String flag) throws Throwable {
        
        log.info("ADD SAProviderID1:" + Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_FIRST_PROVIDER_ID));
        log.info("ADD SAProviderID2:" + Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_SECOND_PROVIDER_ID)); 
        log.info("Update SAProviderID1:" + Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE1_FIRST_PROVIDER_ID));
        log.info("Update SAProviderID2:" + Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE1_SECOND_PROVIDER_ID));
       
        if(flag.contentEquals("Equal")) 
        {
          //First and Second Provider GDFID s are different.Same Provider ID for the Add and Update for the same provider
            assertEquals(Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_FIRST_PROVIDER_ID), Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE1_FIRST_PROVIDER_ID)); 
            assertEquals(Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_SECOND_PROVIDER_ID), Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE1_SECOND_PROVIDER_ID));
            assertFalse(((String) Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_FIRST_PROVIDER_ID)).contentEquals((String) Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_SECOND_PROVIDER_ID))); 
            assertFalse(((String) Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE1_FIRST_PROVIDER_ID)).contentEquals((String) Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE1_SECOND_PROVIDER_ID)));
        }else
        {
          //First and Second Provider GDFID s are different and Provider Types are different.So all Provider IDs are Unique for Add and Update for all Providers
            assertFalse(((String) Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_FIRST_PROVIDER_ID)).contentEquals((String) Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE1_FIRST_PROVIDER_ID))); 
            assertFalse(((String) Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_FIRST_PROVIDER_ID)).contentEquals((String) Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_SECOND_PROVIDER_ID)));
            assertFalse(((String) Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_FIRST_PROVIDER_ID)).contentEquals((String) Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_SECOND_PROVIDER_ID))); 
            assertFalse(((String) Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE1_FIRST_PROVIDER_ID)).contentEquals((String) Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE1_SECOND_PROVIDER_ID)));   
        }
        
    }
    
    @Then("^Capture MC Payload for secondary Keys Source ServiceAuthProviderLineMapID object \"([^\"]*)\"$")
    public void capture_SourceSAProviderLineMapID_for_SAInitiator_events(String scenario) throws Throwable {
        String dhoeventuri = PropLoader.props.apply("mcapihostname") + PropLoader.props.apply("dhomcsentpayload")
            + Serenity.getCurrentSession().get(Constant.CASEID);
        log.info("dho event url :" + dhoeventuri);

        Awaitility.with().pollInterval(Duration.ONE_SECOND.multiply(2)).and().with()
                .pollDelay(Duration.ONE_SECOND.multiply(5)).await().timeout(Duration.ONE_SECOND.multiply(30))
                .until(() -> isStatus(dhoeventuri));
        
        Response response = rest().given().contentType(Constant.CONTENTTYPE)
                .header("Content-Type", Constant.CONTENTTYPE).when().get(dhoeventuri);
        // Assert.equal
       //First and Second Provider GDFID s are different
        String responseBody = response.getBody().prettyPrint();
        JSONArray arrSAProviderLine1MapID = JsonPath.parse(responseBody).read(Constant.SOURCE_SERVICE_AUTH__PROVIDERLINEMAP_ID_LINE1);
        JSONArray arrSAProviderLine2MapID = JsonPath.parse(responseBody).read(Constant.SOURCE_SERVICE_AUTH__PROVIDERLINEMAP_ID_LINE2);
        String strSAProviderLine1MapID= (String) arrSAProviderLine1MapID.get(0);
        String strSAProviderLine2MapID= (String) arrSAProviderLine2MapID.get(0);
        log.info("responseBody:" + responseBody);
        log.info("strSAProviderLine1MapID:" + strSAProviderLine1MapID);
        log.info("strSAProviderLine2MapID:" + strSAProviderLine2MapID);
        
        if (((String) Serenity.getCurrentSession().get(Constant.REQUEST_TYPE)).contains("Add")) {
            Serenity.getCurrentSession().put(Constant.SA_ADD_LINE1_SAPROVIDERLINEMAPID, strSAProviderLine1MapID);
            Serenity.getCurrentSession().put(Constant.SA_ADD_LINE2_SAPROVIDERLINEMAPID, strSAProviderLine2MapID);
            log.info("ADD SAProviderLine1MapID:" + Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_SAPROVIDERLINEMAPID));
            log.info("ADD SAProviderLine2MapID:" + Serenity.getCurrentSession().get(Constant.SA_ADD_LINE2_SAPROVIDERLINEMAPID));
        }else
        {
            Serenity.getCurrentSession().put(Constant.SA_UPDATE_LINE1_SAPROVIDERLINEMAPID, strSAProviderLine1MapID);
            Serenity.getCurrentSession().put(Constant.SA_UPDATE_LINE2_SAPROVIDERLINEMAPID, strSAProviderLine2MapID);
            log.info("Update SAProviderLine1MapID:" + Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE1_SAPROVIDERLINEMAPID));
            log.info("Update SAProviderLine2MapID:" + Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE2_SAPROVIDERLINEMAPID));
        }
    }
    @Then("^Validate MC ServiceAuth Values in Response for ServiceAuthProviderLineMapID object for \"([^\"]*)\"$")
    public void validate_MC_ServiceAuthProviderLineMapID(String flag) throws Throwable {
        
    	 log.info("ADD SAProviderLine1MapID:" + Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_SAPROVIDERLINEMAPID));
         log.info("ADD SAProviderLine2MapID:" + Serenity.getCurrentSession().get(Constant.SA_ADD_LINE2_SAPROVIDERLINEMAPID));
    
    	log.info("Update SAProviderLine1MapID:" + Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE1_SAPROVIDERLINEMAPID));
        log.info("Update SAProviderLine2MapID:" + Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE2_SAPROVIDERLINEMAPID));
   
               
        if(flag.contentEquals("Equal")) 
        {
          //First and Second Provider GDFID s are different.Same Provider ID for the Add and Update for the same provider
            assertEquals(Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_SAPROVIDERLINEMAPID), Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE1_SAPROVIDERLINEMAPID)); 
            assertEquals(Serenity.getCurrentSession().get(Constant.SA_ADD_LINE2_SAPROVIDERLINEMAPID), Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE2_SAPROVIDERLINEMAPID));
            
        }else
        {
          //First and Second Provider GDFID s are different and Provider Types are different.So all Provider IDs are Unique for Add and Update for all Providers
            assertFalse(((String) Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_SAPROVIDERLINEMAPID)).contentEquals((String) Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE1_SAPROVIDERLINEMAPID))); 
            assertFalse(((String) Serenity.getCurrentSession().get(Constant.SA_ADD_LINE2_SAPROVIDERLINEMAPID)).contentEquals((String) Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE2_SAPROVIDERLINEMAPID)));
            
        }
        
    }

    @Then("^Capture MC Payload for secondary Keys Source ServiceAuthProviderTypeMapID object \"([^\"]*)\"$")
    public void capture_SourceSAProviderTypeMapID_for_SAInitiator_events(String scenario) throws Throwable {
        String dhoeventuri = PropLoader.props.apply("mcapihostname") + PropLoader.props.apply("dhomcsentpayload")
            + Serenity.getCurrentSession().get(Constant.CASEID);
        log.info("dho event url :" + dhoeventuri);

        Awaitility.with().pollInterval(Duration.ONE_SECOND.multiply(2)).and().with()
                .pollDelay(Duration.ONE_SECOND.multiply(5)).await().timeout(Duration.ONE_SECOND.multiply(30))
                .until(() -> isStatus(dhoeventuri));
        
        Response response = rest().given().contentType(Constant.CONTENTTYPE)
                .header("Content-Type", Constant.CONTENTTYPE).when().get(dhoeventuri);
        // Assert.equal
       //First and Second Provider GDFID s are different
        String responseBody = response.getBody().prettyPrint();
        JSONArray arrSAProviderTypeMapID1 = JsonPath.parse(responseBody).read(Constant.SOURCE_SERVICE_AUTH__PROVIDERTYPEMAP_ID1_LINE1);
        JSONArray arrSAProviderTypeMapID2 = JsonPath.parse(responseBody).read(Constant.SOURCE_SERVICE_AUTH__PROVIDERTYPEMAP_ID2_LINE1);
        JSONArray arrSAProviderTypeMapID3 = JsonPath.parse(responseBody).read(Constant.SOURCE_SERVICE_AUTH__PROVIDERTYPEMAP_ID3_LINE1);
        JSONArray arrSAProviderTypeMapID4 = JsonPath.parse(responseBody).read(Constant.SOURCE_SERVICE_AUTH__PROVIDERTYPEMAP_ID1_LINE2);
        JSONArray arrSAProviderTypeMapID5 = JsonPath.parse(responseBody).read(Constant.SOURCE_SERVICE_AUTH__PROVIDERTYPEMAP_ID2_LINE2);
        JSONArray arrSAProviderTypeMapID6 = JsonPath.parse(responseBody).read(Constant.SOURCE_SERVICE_AUTH__PROVIDERTYPEMAP_ID3_LINE2);
        
        String strSAProviderTypeMapID1= (String) arrSAProviderTypeMapID1.get(0);
        String strSAProviderTypeMapID2= (String) arrSAProviderTypeMapID2.get(0);
        String strSAProviderTypeMapID3= (String) arrSAProviderTypeMapID3.get(0);
        String strSAProviderTypeMapID4= (String) arrSAProviderTypeMapID4.get(0);
        String strSAProviderTypeMapID5= (String) arrSAProviderTypeMapID5.get(0);
        String strSAProviderTypeMapID6= (String) arrSAProviderTypeMapID6.get(0);
        log.info("responseBody:" + responseBody);
               
        if (((String) Serenity.getCurrentSession().get(Constant.REQUEST_TYPE)).contains("Add")) {
            Serenity.getCurrentSession().put(Constant.SA_ADD_LINE1_SAPROVIDERTYPEMAPID1, strSAProviderTypeMapID1);
            Serenity.getCurrentSession().put(Constant.SA_ADD_LINE1_SAPROVIDERTYPEMAPID2, strSAProviderTypeMapID2);
            Serenity.getCurrentSession().put(Constant.SA_ADD_LINE1_SAPROVIDERTYPEMAPID3, strSAProviderTypeMapID3);
            Serenity.getCurrentSession().put(Constant.SA_ADD_LINE2_SAPROVIDERTYPEMAPID1, strSAProviderTypeMapID4);
            Serenity.getCurrentSession().put(Constant.SA_ADD_LINE2_SAPROVIDERTYPEMAPID2, strSAProviderTypeMapID5);
            Serenity.getCurrentSession().put(Constant.SA_ADD_LINE2_SAPROVIDERTYPEMAPID3, strSAProviderTypeMapID6);
           
        }
        else
        {
        	Serenity.getCurrentSession().put(Constant.SA_UPDATE_LINE1_SAPROVIDERTYPEMAPID1, strSAProviderTypeMapID1);
            Serenity.getCurrentSession().put(Constant.SA_UPDATE_LINE1_SAPROVIDERTYPEMAPID2, strSAProviderTypeMapID2);
            Serenity.getCurrentSession().put(Constant.SA_UPDATE_LINE1_SAPROVIDERTYPEMAPID3, strSAProviderTypeMapID3);
            Serenity.getCurrentSession().put(Constant.SA_UPDATE_LINE2_SAPROVIDERTYPEMAPID1, strSAProviderTypeMapID4);
            Serenity.getCurrentSession().put(Constant.SA_UPDATE_LINE2_SAPROVIDERTYPEMAPID2, strSAProviderTypeMapID5);
            Serenity.getCurrentSession().put(Constant.SA_UPDATE_LINE2_SAPROVIDERTYPEMAPID3, strSAProviderTypeMapID6);
           }
    }
    @Then("^Validate MC ServiceAuth Values in Response for ServiceAuthProviderTypeMapID object for \"([^\"]*)\"$")
    public void validate_MC_ServiceAuthProviderTypeMapID(String flag) throws Throwable {
        
    	                
        if(flag.contentEquals("Equal")) 
        {
          //First and Second Provider GDFID s are different.Same Provider ID for the Add and Update for the same provider
            assertEquals(Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_SAPROVIDERTYPEMAPID1), Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE1_SAPROVIDERTYPEMAPID1)); 
            assertEquals(Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_SAPROVIDERTYPEMAPID2), Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE1_SAPROVIDERTYPEMAPID2));
            assertEquals(Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_SAPROVIDERTYPEMAPID3), Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE1_SAPROVIDERTYPEMAPID3)); 
            assertEquals(Serenity.getCurrentSession().get(Constant.SA_ADD_LINE2_SAPROVIDERTYPEMAPID1), Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE2_SAPROVIDERTYPEMAPID1));
            assertEquals(Serenity.getCurrentSession().get(Constant.SA_ADD_LINE2_SAPROVIDERTYPEMAPID2), Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE2_SAPROVIDERTYPEMAPID2)); 
            assertEquals(Serenity.getCurrentSession().get(Constant.SA_ADD_LINE2_SAPROVIDERTYPEMAPID3), Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE2_SAPROVIDERTYPEMAPID3));
            
        }else
        {
          //First and Second Provider GDFID s are different and Provider Types are different.So all Provider IDs are Unique for Add and Update for all Providers
            assertFalse(((String) Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_SAPROVIDERTYPEMAPID1)).contentEquals((String) Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE1_SAPROVIDERTYPEMAPID1))); 
            assertFalse(((String) Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_SAPROVIDERTYPEMAPID2)).contentEquals((String) Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE1_SAPROVIDERTYPEMAPID2)));
            assertFalse(((String) Serenity.getCurrentSession().get(Constant.SA_ADD_LINE1_SAPROVIDERTYPEMAPID3)).contentEquals((String) Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE1_SAPROVIDERTYPEMAPID3))); 
            assertFalse(((String) Serenity.getCurrentSession().get(Constant.SA_ADD_LINE2_SAPROVIDERTYPEMAPID1)).contentEquals((String) Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE2_SAPROVIDERTYPEMAPID1)));
            assertFalse(((String) Serenity.getCurrentSession().get(Constant.SA_ADD_LINE2_SAPROVIDERTYPEMAPID2)).contentEquals((String) Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE2_SAPROVIDERTYPEMAPID2))); 
            assertFalse(((String) Serenity.getCurrentSession().get(Constant.SA_ADD_LINE2_SAPROVIDERTYPEMAPID3)).contentEquals((String) Serenity.getCurrentSession().get(Constant.SA_UPDATE_LINE2_SAPROVIDERTYPEMAPID3)));
            
        }
        
    }
}
