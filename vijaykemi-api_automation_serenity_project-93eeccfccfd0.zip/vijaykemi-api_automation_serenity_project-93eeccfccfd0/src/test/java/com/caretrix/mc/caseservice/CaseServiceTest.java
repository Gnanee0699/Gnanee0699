package com.caretrix.mc.caseservice;

import org.junit.runner.RunWith;


import cucumber.api.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import net.thucydides.junit.annotations.Concurrent;
@Concurrent(threads = "4x")
@RunWith(CucumberWithSerenity.class)

@CucumberOptions(features = "src/test/resources/feature/", strict = true,
		tags = { 
				"@CaseService"
				//"@TC_016_CaseID_BusinessFailure"
						}, 
		glue = "com/carecentrix/mc/caseservice")


public class CaseServiceTest {

}
