package com.caretrix.mc.steps.dho.member;

public class temp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		String date = "2021-01-25T08:55:34.927";
		
		String[] second = date.split(":");
		int second2 = Integer.parseInt(second[2].substring(0, 2));
		
		System.out.println(second2+1);
	}

}
