package com.caretrix.mc.steps.mci.statusanddecision;

import com.API.Rest.validations.MedcompassValidations;

import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;

public class StatusAndDecisionStepsValidation 
{
	
	@Steps
	private MedcompassValidations validation = new MedcompassValidations();
				
	@Then ("^Validate Response code for the Status And Decision \"([^\"]*)\"$")
	public void Validate_Response_code_is(String responseCode) throws Throwable {
		validation.validatestatuscode(Integer.parseInt(responseCode));
	}
	
	@Then ("^Validate the Status and Decision response \"([^\"]*)\" and \"([^\"]*)\"$")
	public void Validate_the_field_in_ResponseBody_for_the(String Scenario, String Sheetname) throws Throwable {
		validation.validateResponsebody("OK");
	}
}
