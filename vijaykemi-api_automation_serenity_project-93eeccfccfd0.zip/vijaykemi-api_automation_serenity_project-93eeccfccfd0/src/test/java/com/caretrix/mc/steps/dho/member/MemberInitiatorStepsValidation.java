package com.caretrix.mc.steps.dho.member;

import static io.restassured.RestAssured.given;
import static net.serenitybdd.rest.SerenityRest.rest;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.awaitility.Awaitility;
import org.awaitility.Duration;

import com.API.Rest.validations.MedcompassValidations;
import com.caretrix.medcompass.cucumber.steps.Common;
import com.jayway.jsonpath.JsonPath;
import com.mc.TestUtils.Constant;
import com.mc.TestUtils.PropLoader;

import cucumber.api.java.en.Then;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Steps;

public class MemberInitiatorStepsValidation {

    Common common = new Common();

    private static final Logger log = LogManager.getLogger(MemberInitiatorStepsValidation.class);
    private static final String dhoapihost = PropLoader.props.apply("dhoapihost");
    private static final String dhoevent = PropLoader.props.apply("dhoevent");

    @Steps
    private MedcompassValidations validation = new MedcompassValidations();

    @Then("^Validate Response code for the Member Inititor  \"([^\"]*)\"$")
    public void Validate_Response_code_is(String responseCode) throws Throwable {
        validation.validatestatuscode(Integer.parseInt(responseCode));
    }

    @Then("^Validate the field in Member Inititor ResponseBody for the \"([^\"]*)\" and \"([^\"]*)\"$")
    public void Validate_the_field_in_ResponseBody_for_the(String Scenario, String Sheetname) throws Throwable {
        validation.validateResponsebody("OK");
    }

    @Then("^Validate Status code for the Member Inititor event \"([^\"]*)\"$")
    public void validate_Status_code_for_the_Member_Inititor_event(String eventStatus) throws Throwable {
        // Poll interval of 10 second with an initial delay of 10 seconds and
        // Max timeout after 3 minutes.60 *3=180 seconds
        String dhoeventuri = dhoapihost + dhoevent + Serenity.getCurrentSession().get(Constant.MEMBERGDFID);
        log.info("dho event url :" + dhoeventuri);
        int timeout = Integer.parseInt(PropLoader.props.apply("memberresponsetimeoutseconds"));
        Awaitility.with().pollInterval(Duration.TWO_SECONDS).and().with().pollDelay(Duration.FIVE_SECONDS).await()
                .timeout(Duration.ONE_SECOND.multiply(timeout))
                .untilAsserted(() -> assertThat(
                    JsonPath.parse(JsonPath.parse(given().contentType(ContentType.JSON).when().get(dhoeventuri)
                            .getBody().jsonPath().getList(".").get(0)).jsonString()).read(Constant.TXNSTATUS),
                    containsString(eventStatus)));
        // This is to print the event status response URL in the report
        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).when()
                .get(dhoeventuri);
       Response response=given().contentType(ContentType.JSON).when().get(dhoeventuri);
        
        String EVENT_GUID = (JsonPath.parse(JsonPath.parse(response
                .getBody().jsonPath().getList(".").get(0)).jsonString()).read(Constant.EVENTGUID));
        Serenity.getCurrentSession().put(Constant.EVENTGUID, EVENT_GUID);
    }

    @Then("^Validate Event Status Response Code for the Member Inititor event\"([^\"]*)\"$")
    public void validate_Event_status__response_code_for_the_Member_Inititor_event(String responseCode)
        throws Throwable {
        // Poll interval of 10 second with an initial delay of 10 seconds and
        // Max timeout after 3 minutes.60 *3=180 seconds
        String dhoeventuri = dhoapihost + dhoevent + Serenity.getCurrentSession().get(Constant.MEMBERGDFID);
        log.info("dho event url :" + dhoeventuri);

        Awaitility.with().pollInterval(Duration.ONE_SECOND.multiply(5)).and().with()
                .pollDelay(Duration.ONE_SECOND.multiply(1)).await().timeout(Duration.ONE_SECOND.multiply(10))
                .untilAsserted(() -> assertThat(given().contentType(ContentType.JSON).when().get(dhoeventuri).then()
                        .statusCode(Integer.parseInt(responseCode)))

                );

    }
    
    @Then("^Validate Status code for the New Member event \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void  validate_Status_Code_For_New_Member_Event(String eventStatus, String topicName, String retryFlag, String retryCount){  
    	String dhoeventuri = dhoapihost + dhoevent + Serenity.getCurrentSession().get(Constant.MEMBERGDFID);
        log.info("dho event url :" + dhoeventuri); 
    	int timeout = Integer.parseInt(PropLoader.props.apply("manualretrytimeoutseconds"));
    	Awaitility.with().pollInterval(Duration.TWO_SECONDS).and().with().pollDelay(Duration.ONE_SECOND.multiply(60)).await()
        .timeout(Duration.ONE_SECOND.multiply(timeout))
        .untilAsserted(() -> assertThat(
            JsonPath.parse(JsonPath.parse(given().contentType(ContentType.JSON).when().get(dhoeventuri)
                    .getBody().jsonPath().getList(".").get(0)).jsonString()).read(Constant.TXNSTATUS),
            containsString(eventStatus)));
    	 
    	 Response response=given().contentType(ContentType.JSON).when().get(dhoeventuri);
    	 
    	 assertThat(JsonPath.parse(JsonPath.parse(response
                 .getBody().jsonPath().getList(".").get(0)).jsonString()).read(Constant.TOPICNAME),
         containsString(topicName));
    	 
    	 assertThat(JsonPath.parse(JsonPath.parse(response
                 .getBody().jsonPath().getList(".").get(0)).jsonString()).read(Constant.RETRYFLAG).toString(),
         containsString(retryFlag));
    	 
    	 assertThat(JsonPath.parse(JsonPath.parse(response
                 .getBody().jsonPath().getList(".").get(0)).jsonString()).read(Constant.RETRYCOUNT).toString(),
         containsString(retryCount));
         
}
    
    @Then("^Validate retry has hapenned for the member \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void  validateRetry(String eventStatus, String topicName, String retryCount){  
    	String dhoeventuri = dhoapihost + dhoevent + Serenity.getCurrentSession().get(Constant.MEMBERGDFID);
        log.info("dho event url :" + dhoeventuri); 
    	int timeout = Integer.parseInt(PropLoader.props.apply("manualretrytimeoutseconds"));
    	Awaitility.with().pollInterval(Duration.TWO_SECONDS).and().with().pollDelay(Duration.ONE_SECOND.multiply(60)).await()
        .timeout(Duration.ONE_SECOND.multiply(timeout))
        .untilAsserted(() -> assertThat(
            JsonPath.parse(JsonPath.parse(given().contentType(ContentType.JSON).when().get(dhoeventuri)
                    .getBody().jsonPath().getList(".").get(0)).jsonString()).read(Constant.TXNSTATUS),
            containsString(eventStatus)));
    	 
    	 Response response=given().contentType(ContentType.JSON).when().get(dhoeventuri);
    	 
    	 assertThat(JsonPath.parse(JsonPath.parse(response
                 .getBody().jsonPath().getList(".").get(0)).jsonString()).read(Constant.TOPICNAME),
         containsString(topicName));
    	 
    	    	 
    	 assertThat(JsonPath.parse(JsonPath.parse(response
                 .getBody().jsonPath().getList(".").get(0)).jsonString()).read(Constant.RETRYCOUNT).toString(),
         containsString(retryCount));
         
}
    
    @Then("^Validate Event Status Response Code for the Delete Member Inititor event\"([^\"]*)\"$")
    public void validate_Event_status__response_code_for_the_delete_Member_Inititor_event(String responseCode) throws Throwable {
        // Poll interval of 10 second with an initial delay of 10 seconds and
                // Max timeout after 3 minutes.60 *3=180 seconds
                String dhoeventuri = PropLoader.props.apply("dhoapihost") + PropLoader.props.apply("dhodeleteevent")+Serenity.getCurrentSession().get(Constant.MEMBERGDFID);
                log.info("dho event url :" + dhoeventuri);
                
                Awaitility.with().pollInterval(Duration.ONE_SECOND.multiply(5)).and().with().pollDelay(Duration.ONE_SECOND.multiply(1))
                  .await().timeout(Duration.ONE_SECOND.multiply(10)).untilAsserted(()-> assertThat
                  (
                          given()
                          .contentType(ContentType.JSON)
                          .when()
                          .delete(dhoeventuri)
                          .then().statusCode(Integer.parseInt(responseCode))
                  )               
                 
                
              );
                
    }
    
    

    }