package com.caretrix.mc.regression;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import net.thucydides.junit.annotations.Concurrent;

@Concurrent(threads = "4x")
@RunWith(CucumberWithSerenity.class)

@CucumberOptions(features = "src/test/resources/feature/", strict = true, tags = { "@Regression"

}, glue = {
    "com/carecentrix/mc/caseservice",
    "com/carecentrix/mc/steps/dho/member",
    "com/carecentrix/mc/steps/dho/provider",
    "com/carecentrix/mc/steps/dho/serviceauth" })

public class RegressionTest {

}
