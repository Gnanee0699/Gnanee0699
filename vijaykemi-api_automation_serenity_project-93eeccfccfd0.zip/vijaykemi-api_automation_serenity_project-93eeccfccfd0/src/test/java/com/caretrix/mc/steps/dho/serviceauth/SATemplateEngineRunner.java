package com.caretrix.mc.steps.dho.serviceauth;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import net.thucydides.junit.annotations.Concurrent;

@Concurrent(threads = "4x")
@RunWith(CucumberWithSerenity.class)

@CucumberOptions(features = "src/test/resources/feature/", strict = true,
    tags = { "@DHOServiceAuthInitiatorJsonTemplate" }, glue = "com/carecentrix/mc/steps/dho/serviceauth/")
public class SATemplateEngineRunner {}
