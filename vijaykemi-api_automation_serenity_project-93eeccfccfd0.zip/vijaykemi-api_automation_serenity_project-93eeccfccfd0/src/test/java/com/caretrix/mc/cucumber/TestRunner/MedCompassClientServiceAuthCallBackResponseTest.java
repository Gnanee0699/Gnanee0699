package com.caretrix.mc.cucumber.TestRunner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import net.thucydides.junit.annotations.Concurrent;

@Concurrent(threads = "4X")
//@UseTestDataFrom("")
@RunWith(CucumberWithSerenity.class)

@CucumberOptions(features = "src/test/resources/feature/", strict = true, tags = {

		"@MedCompassServiceAuthE2ECallBack"
	//	"@ServiceAuthTranslationAndDefaultValidation"
	//	"@TC_002_ServiceAuthE2ECallBackwithNewMemberandProvider"
}, glue = "com/carecentrix/medcompass/cucumber/steps")

public class MedCompassClientServiceAuthCallBackResponseTest {

}
