package com.caretrix.mc.testutils.test;

import java.io.IOException;
import java.util.Map;

import org.junit.Test;

import com.mc.TestUtils.ExcelReader;

public class ExcelReaderTest {
	
	@Test
	public void readAllRow() throws IOException {
		
		Map<String,Map<String, String>> map=ExcelReader.readAllRows("/src/test/resources/testdata/Member_MedCompass_Inputsheet.xlsx","MemberData");
		//System.out.println("map=" +map);
	}

}
