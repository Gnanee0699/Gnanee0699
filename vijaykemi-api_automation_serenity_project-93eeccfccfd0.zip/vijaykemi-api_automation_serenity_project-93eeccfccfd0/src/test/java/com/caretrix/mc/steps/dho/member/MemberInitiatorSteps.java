package com.caretrix.mc.steps.dho.member;

import static io.restassured.RestAssured.given;
import static net.serenitybdd.rest.SerenityRest.rest;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.awaitility.Awaitility;
import org.awaitility.Duration;
import org.json.JSONObject;

import com.API.Rest.validations.MedcompassValidations;
import com.jayway.jsonpath.JsonPath;
import com.mc.TestUtils.Constant;
import com.mc.TestUtils.ExcelTestData;
import com.mc.TestUtils.JsonUpdateUtil;
import com.mc.TestUtils.PropLoader;
import com.mc.setup.SetupHeaders;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Steps;

public class MemberInitiatorSteps {

    private static final Logger log = LogManager.getLogger(MemberInitiatorSteps.class);

    private static final String dhoMemberJsonTemplatePath = "src/test/resources/jsonPayloads/dho/member/DHOMember.json";

    Map<String, Map<String, String>> dataMap;

    @Steps
    private MedcompassValidations validation = new MedcompassValidations();

    @Given("^Member Add event to MC resulting from a Service Auth event$")
    public void setup_proxy_for_a_Member_Request() throws Throwable {
        dataMap = ExcelTestData.getTestDataBySheet(PropLoader.props.apply(Constant.DHO_MEMBER_EXCEL_PATH),
            Constant.DHO_MEMBER_SHEET_NAME);
        Serenity.getCurrentSession().put(Constant.DATA_MAP, dataMap);
        SetupHeaders.initialSetupDHOMemberInitiator();
    }

    @Given("^Transaction details from UDH resulting from a MemberProvSA Add event$")
    public void setup_proxy_for_a_Member_GET_Request() throws Throwable {
        dataMap = ExcelTestData.getTestDataBySheet(PropLoader.props.apply(Constant.DHO_MEMBER_EXCEL_PATH),
            Constant.DHO_MEMBER_Details_SHEET_NAME);
        Serenity.getCurrentSession().put(Constant.DATA_MAP, dataMap);
        SetupHeaders.initialSetupDHOMemberInitiator();
    }

    @When("^Member add request triggered without MedCompassID such that \"([^\"]*)\"$")
    public void memberInitiator(String scenario) throws Throwable {
        String gdfid = UUID.randomUUID().toString();
        String payload = getMemberPayLoad(scenario);
        payload = JsonPath.parse(payload).set(Constant.MEMBERGDFID, gdfid).jsonString();
        Serenity.getCurrentSession().put(Constant.MEMBERGDFID, gdfid);

        String strRequestType = JsonPath.parse(payload).read(Constant.DHO_REQUEST_TYPE);
        Serenity.getCurrentSession().put(Constant.REQUEST_TYPE, strRequestType);

        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
                .basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password)).when()
                .log().all().body(payload).post(PropLoader.props.apply("memberadd"));

    }

   @When("^MemberProvSA getUDHapi request triggered for the \"([^\"]*)\"$")
	public void membergetUDHapi(String scenario) throws Throwable {

		Response RESP = rest().given().contentType(Constant.CONTENTTYPE)
			.header("Content-Type",Constant.CONTENTTYPE)
			.auth().basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password))
			.when().log().all()
			.get(PropLoader.props.apply("getUDHapidetails")+dataMap.get(scenario).get("GDFID"));
	
	//	Serenity.getCurrentSession().put(Constant.UDHPAYLOAD, RESP.asString());
			log.info("Response is ********** "+RESP.asString());
	
			if (dataMap.get(scenario).get("Transaction").equalsIgnoreCase("Member")||dataMap.get(scenario).get("Transaction").equalsIgnoreCase("Provider")){
							
			String UdhCreatedTimeStamp = RESP.then().extract().jsonPath().getString("UdhCreatedTimeStamp");
			String UdhUpdatedTimeStamp = RESP.then().extract().jsonPath().getString("UdhUpdatedTimeStamp");
			
		String[] second = UdhCreatedTimeStamp.split(":");
		int UdhCreatedTimeStampsecond2 = Integer.parseInt(second[1]);
		
		String[] UdhUpdatedTimeStampsecond = UdhUpdatedTimeStamp.split(":");
		int UdhUpdatedTimeStampsecond2 = Integer.parseInt(UdhUpdatedTimeStampsecond[1]);
		
		int NewSecondcreated=UdhCreatedTimeStampsecond2+1;
		int NewSecondUpdated=UdhUpdatedTimeStampsecond2+1;
		log.info(NewSecondcreated);
		log.info(NewSecondUpdated);
		
		String newUdhCreatedTimeStamp = second[0]+":"+NewSecondcreated+":"+second[2];
		String newUdhUpdatedTimeStamp = UdhUpdatedTimeStampsecond[0]+":"+NewSecondUpdated+":"+UdhUpdatedTimeStampsecond[2];
		
		JSONObject newpayload = new JSONObject(RESP.asString());
		newpayload = JsonUpdateUtil.updateJson(newpayload, "UdhCreatedTimeStamp", newUdhCreatedTimeStamp);
		newpayload = JsonUpdateUtil.updateJson(newpayload, "UdhUpdatedTimeStamp", newUdhUpdatedTimeStamp);
		log.info("Final payload"+newpayload.toString());
		
		Serenity.getCurrentSession().put(Constant.UDHPAYLOAD, newpayload.toString());
			}
			else {
				Serenity.getCurrentSession().put(Constant.UDHPAYLOAD, RESP.asString());
			}
		
	}

    @When("^MemberProvSA Add request triggered for the \"([^\"]*)\"$")
    public void memberAddMEMPROVSA(String scenario) throws Throwable {

        String Endpoint;
        Serenity.getCurrentSession().get(Constant.UDHPAYLOAD);
        log.info("New Value is --------" + Serenity.getCurrentSession().get(Constant.UDHPAYLOAD));
        String payload = (String) Serenity.getCurrentSession().get(Constant.UDHPAYLOAD);
        log.info("Payload is ---+ " + payload);

        if (dataMap.get(scenario).get("Transaction").equalsIgnoreCase("Member")) {
            Endpoint = PropLoader.props.apply("memberadd");
        } else if (dataMap.get(scenario).get("Transaction").equalsIgnoreCase("Provider")) {
            Endpoint = PropLoader.props.apply("provideraddapi");
        } else {
            Endpoint = PropLoader.props.apply("dhoaddserviceauth");
        }

        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
                .basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password)).when()
                .log().all().body(payload).post(Endpoint);

    }

    @When("^Member getapi request triggered for the \"([^\"]*)\"$")
    public void membergetapi(String scenario) throws Throwable {

        String Endpoint;
        if (dataMap.get(scenario).get("Transaction").equalsIgnoreCase("Member")) {
            Endpoint = PropLoader.props.apply("getapimemberdetails") + dataMap.get(scenario).get("GDFID");
        } else if (dataMap.get(scenario).get("Transaction").equalsIgnoreCase("Provider")) {
            Endpoint = PropLoader.props.apply("getapiproviderdetails") + dataMap.get(scenario).get("GDFID");
        } else {
            Endpoint = PropLoader.props.apply("getapiproviderdetails") + dataMap.get(scenario).get("GDFID");
        }

        Serenity.getCurrentSession().get(Constant.UDHPAYLOAD);
        log.info("New Value is --------" + Serenity.getCurrentSession().get(Constant.UDHPAYLOAD));

        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
                .basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password)).when()
                .log().all().get(Endpoint);

    }

    @Then("^Validate Response code 200$")
    public void Validate_Response_code_200_is() throws Throwable {
        validation.validatestatuscode(200);
    }

    @Then("^Validate Response code 404$")
    public void Validate_Response_code_404() throws Throwable {
        validation.validatestatuscode(404);
    }

    @Then("^Validate UDH Response \"([^\"]*)\"$")
    public void validate_UDH_MemberProvider(String scenario) throws Throwable {

        assertEquals(dataMap.get(scenario).get("GDFID"), Serenity.getCurrentSession().get(Constant.UDHRESPGDFID));

    }

    @Then("^Validate Event Status Response Code for the MemberProvider Initiator event \"([^\"]*)\"$")
    public void validate_Status_code_for_the_Provider_Initiator_event(String scenario) throws Throwable {

        String eventStatus = "PROCESSED_SUCCESS";
        String dhoeventuri = PropLoader.props.apply("dhoapihost") + PropLoader.props.apply("dhoevent")
            + dataMap.get(scenario).get("GDFID");
        log.info("dho event url :" + dhoeventuri);
        int timeout = Integer.parseInt(PropLoader.props.apply("providerresponsetimeoutseconds"));
        Awaitility.with().pollInterval(Duration.FIVE_SECONDS).and().with().pollDelay(Duration.ONE_SECOND.multiply(5))
                .await().timeout(Duration.ONE_SECOND.multiply(timeout))
                .untilAsserted(() -> assertThat(
                    JsonPath.parse(JsonPath.parse(given().contentType(ContentType.JSON).when().get(dhoeventuri)
                            .getBody().jsonPath().getList(".").get(0)).jsonString()).read(Constant.TXNSTATUS),
                    containsString(eventStatus))

                );
        String txnStatus = JsonPath.parse(JsonPath.parse(
            given().contentType(ContentType.JSON).when().get(dhoeventuri).getBody().jsonPath().getList(".").get(0))
                .jsonString()).read(Constant.TXNSTATUS);
        log.info("TXN_STAT_DESC:" + txnStatus);
        // This is to print the event status response URL in the report
        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).when()
                .get(dhoeventuri);

    }

    @Given("^Member Add request already triggered from UDH and failed for mc client validation \"([^\"]*)\"$")
    public void member_add_request_already_triggered_from_udh(String scenario) throws Throwable {
        dataMap = ExcelTestData.getTestDataBySheet(PropLoader.props.apply(Constant.DHO_MEMBER_EXCEL_PATH),
            Constant.DHO_MEMBER_SHEET_NAME);
        Serenity.getCurrentSession().put(Constant.DATA_MAP, dataMap);
        SetupHeaders.initialSetupDHOMemberInitiator();
        String gdfid = UUID.randomUUID().toString();
        String payload = getMemberPayLoad(scenario);
        payload = JsonPath.parse(payload).set(Constant.MEMBERGDFID, gdfid).jsonString();
        // payload =JsonPath.parse(payload).set(Constant.DHO_REQUEST_TYPE,"ADD").jsonString();
        Serenity.getCurrentSession().put(Constant.MEMBERGDFID, gdfid);
        log.info("member add URL", PropLoader.props.apply("memberadd"));
        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
                .basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password)).when()
                .log().all().body(payload).post(PropLoader.props.apply("memberadd"));
    }

    @When("^Update member request from SA Initiator is triggered for Member with MedCompassID such that \"([^\"]*)\"$")
    public void updateMemberRequest(String scenario) throws Throwable {
        String payload = getMemberPayLoad(scenario);
        payload = JsonPath.parse(payload)
                .set(Constant.MEMBERGDFID, Serenity.getCurrentSession().get(Constant.MEMBERGDFID)).jsonString();
        payload = JsonPath.parse(payload).set(Constant.DHO_REQUEST_TYPE, "Modify").jsonString();
        String strRequestType = JsonPath.parse(payload).read(Constant.DHO_REQUEST_TYPE);
        Serenity.getCurrentSession().put(Constant.REQUEST_TYPE, strRequestType);
        log.info("member add URL", PropLoader.props.apply("memberupdate"));
        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
                .basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password)).when()
                .log().all().body(payload).post(PropLoader.props.apply("memberupdate"));

    }

    @Given("^A new member is created in core systems AND the new member data is replicated in the UDH AND UDH published a member add event$")
    public void udh_publish_member_add_event() throws Throwable {
        dataMap = ExcelTestData.getTestDataBySheet(PropLoader.props.apply(Constant.DHO_MEMBER_EXCEL_PATH),
            Constant.DHO_MEMBER_SHEET_NAME);
        Serenity.getCurrentSession().put(Constant.DATA_MAP, dataMap);
        SetupHeaders.initialSetupDHOMemberInitiator();
    }

    @When("^Add message from UDH is triggered with Member without a MedCompassID \"([^\"]*)\"$")
    public void add_member_triggered_from_udh(String scenario) throws Throwable {
        String gdfid = UUID.randomUUID().toString();
        String payload = getMemberPayLoad(scenario);
        payload = JsonPath.parse(payload).set(Constant.MEMBERGDFID, gdfid).jsonString();
        Serenity.getCurrentSession().put(Constant.MEMBERGDFID, gdfid);
        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
                .basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password)).when()
                .log().all().body(payload).post(PropLoader.props.apply("memberupdate"));

    }

    @Given("^Member Add or Update event to MC is unsuccessful and the retry count is not maxed$")
    public void setup_proxy_for_a_Member_Retry_Request() throws Throwable {
        dataMap = ExcelTestData.getTestDataBySheet(PropLoader.props.apply(Constant.DHO_MEMBER_EXCEL_PATH),
            Constant.DHO_MEMBER_SHEET_NAME);
        Serenity.getCurrentSession().put(Constant.DATA_MAP, dataMap);
        SetupHeaders.initialSetupDHOMemberInitiator();
    }

    @When("^Member Add or update request from MCI Monitor retry is triggered \"([^\"]*)\"$")
    public void memberInitiatorRetry(String scenario) throws Throwable {
        String gdfid = UUID.randomUUID().toString();
        String payload = getMemberPayLoad(scenario);
        payload = JsonPath.parse(payload).set(Constant.MEMBERGDFID, gdfid).jsonString();
        Serenity.getCurrentSession().put(Constant.MEMBERGDFID, gdfid);
        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
                .basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password)).when()
                .log().all().body(payload).post(PropLoader.props.apply("memberretry"));

    }

    @When("^Member Update request triggered such that \"([^\"]*)\"$")
    public void memberInitiatorUpdate(String scenario) throws Throwable {
        String gdfid = UUID.randomUUID().toString();
        String payload = getMemberPayLoad(scenario);
        payload = JsonPath.parse(payload).set(Constant.MEMBERGDFID, gdfid).jsonString();
        Serenity.getCurrentSession().put(Constant.MEMBERGDFID, gdfid);
        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
                .basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password)).when()
                .log().all().body(payload).post(PropLoader.props.apply("memberupdate"));

    }

    @Given("^Member Add request already triggered from MCI Monitor retry failed \"([^\"]*)\"$")
    public void member_addretry_request_already_triggered(String scenario) throws Throwable {
        dataMap = ExcelTestData.getTestDataBySheet(PropLoader.props.apply(Constant.DHO_MEMBER_EXCEL_PATH),
            Constant.DHO_MEMBER_SHEET_NAME);
        Serenity.getCurrentSession().put(Constant.DATA_MAP, dataMap);
        SetupHeaders.initialSetup("dhoapihost");
        String gdfid = UUID.randomUUID().toString();
        String payload = getMemberPayLoad(scenario);
        payload = JsonPath.parse(payload).set(Constant.MEMBERGDFID, gdfid).jsonString();
        Serenity.getCurrentSession().put(Constant.MEMBERGDFID, gdfid);
        log.info("member retry URL", PropLoader.props.apply("memberretry"));
        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
                .basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password)).when()
                .log().all().body(payload).post(PropLoader.props.apply("memberretry"));
    }

    @When("^Update Member request from UDH is triggered \"([^\"]*)\"$")
    public void updateMemberRequestAddtriggered(String scenario) throws Throwable {
        String payload = getMemberPayLoad(scenario);
        payload = JsonPath.parse(payload)
                .set(Constant.MEMBERGDFID, Serenity.getCurrentSession().get(Constant.MEMBERGDFID)).jsonString();
        payload = JsonPath.parse(payload).set(Constant.DHO_REQUEST_TYPE, "Modify").jsonString();
        log.info("provider add URL", PropLoader.props.apply("memberupdate"));
        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
                .basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password)).when()
                .log().all().body(payload).post(PropLoader.props.apply("memberupdate"));

    }

    @When("^Manual Retry is triggered for the member")
    public void triggerManualRetry() {

        String dhomanualretruri = PropLoader.props.apply("dhoapihost") + PropLoader.props.apply("manualretryevent")
            + Serenity.getCurrentSession().get(Constant.MEMBERGDFID) + Constant.EVENT_ID_DB
            + Serenity.getCurrentSession().get(Constant.EVENTGUID);
        log.info("dho Mnaul Retry event url :" + dhomanualretruri);
        String payload = "{}";
        payload = JsonPath.parse(payload).jsonString();
        // This is to print the event status response URL in the report
        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
                .basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password)).when()
                .log().all().body(payload).post(dhomanualretruri).then().assertThat().statusCode(200);
    }

    @When("^Status of the member is changed to \"([^\"]*)\"$")
    public void statusChange(String eventStatus) {

        String statuschangeuri = PropLoader.props.apply("dhoapihost") + PropLoader.props.apply("dhoupdateeventdb")
            + Serenity.getCurrentSession().get(Constant.MEMBERGDFID) + Constant.SERVICEATH_STATUS_DB + eventStatus;
        log.info("StatusChange Endpoint :" + statuschangeuri);
        String payload = "{}";
        payload = JsonPath.parse(payload).jsonString();
        // This is to print the event status response URL in the report
        rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).auth()
                .basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password)).when()
                .log().all().body(payload).put(statuschangeuri).then().assertThat().statusCode(200);
    }

    private String getMemberPayLoad(String scenario) throws IOException {
        Map<String, Object> scenarioDataMap = new HashMap<>(dataMap.get(scenario));
        String jsonTemplatePayload = new String(Files.readAllBytes(Paths.get(dhoMemberJsonTemplatePath)));
        String payload = JsonUpdateUtil.buildJsonRequest(jsonTemplatePayload, scenarioDataMap, "DHOMember");
        return payload;
    }

}
