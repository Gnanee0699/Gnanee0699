package com.mc.TestUtils;

public class Constant {

    // Test data from Excel file column names

    public static final String MemData_Sht_InputField = "InputField";

    public static final String STATUS_CODE = "StatusCode";
    public static final String EXCEL_FILE_PATH = "excelFilePath";

    public static final String DHO_MEMBER_EXCEL_PATH = "dhomemberexcel";

    public static final String DHO_PROVIDER_EXCEL_PATH = "dhoproviderexcel";

    public static final String DHO_SERVICE_AUTH_EXCEL_PATH = "dhoserviceauthexcel";

    public static final String STATUS_AND_DECISION_EXCEL_PATH = "statusanddecisionexcel";

    public static final String CASE_SERVICE_EXCEL_PATH = "caseserviceexcel";
    
    public static final String BI_CLINICALTEMPLATE_EXCEL_PATH = "biclinicaltemplateexcel";

    public static final String MC_CLIENT_SHEET_NAME = "MemberData";

    public static final String DHO_MEMBER_SHEET_NAME = "DHOMember";
    public static final String DHO_MEMBER_Details_SHEET_NAME = "DHOMemberGDF";
    public static final String DHO_MEMBER_TEMPLATE_SHEET_NAME = "DHOMemberTemplateEngine";

    public static final String DHO_PROVIDER_SHEET_NAME = "DHOProvider";
    public static final String DHO_PROVIDER_TEMPLATE_SHEET_NAME = "DHOProviderTemplateEngine";

    public static final String DHO_SERVICE_AUTH_SHEET_NAME = "DHOServiceAuth";

    public static final String DHO_SERVICE_AUTH_TEMPLATE_SHEET_NAME = "DHOServiceAuthTemplateEngine";

    public static final String MemberE2ECallBackResponse_SHEET_NAME = "MemberCallBack";

    public static final String STATUS_AND_DECISION_SHEET_NAME = "StatusAndDecision";

    public static final String CASE_SERVICE_SHEET_NAME = "CaseServiceSheet";
    
    public static final String BI_CLINICALTEMPLATE_SHEET_NAME = "BIClinicalTemplatesheet";

    public static final String QA_APT_HOST_NAME = "mcapihostname";

    public static final String DATA_MAP = "dataMap";

    public static final String MemData_Sht_Data_InputValue = "InputValue";
    public static final String MemData_Sht_Data_ExpectedField = "ExpectedField";
    public static final String MemData_Sht_Data_ExpectedValue = "ExpectedValue";
    public static final String CONTENTTYPE = "application/json";
    public static final String RowstobeDeleted = "RowstobeDeleted";
    public static final String TestScenario = "TestScenario";

    // ****************************************************************************************************
    public static final String EVENT_ID_VALUE = "eventidvalue";
    public static final String SOURCE_MEMBER_ID = "sourcememberid";
    public static final String MEMBER = "member";
    public static final String PROVIDER = "provider";
    public static final String SERVICEAUTH = "serviceauth";
    public static final String CONTENT_TYPE = "application/json";

    public static final String UNUSED = "unused";
    public static final String USED = "used";
    public static final String ALL = "all";

    public static final String UUID = "UUID";

    public static final String RANDOM_NUMBER = "Random Number";

    public static final String SA_HAVING_MEMBER_PROVIDER_SHEET = "serviceauthhavingmemprov";

    public static final String SOURCE_SERVICE_AUTH_ID = "sourceserviceauthid";

    public static final String EVENT_ID_VALUE_JSON_PATH = "$.eventidvalue";
    public static final String SOURCE_PROVIDER_ID_JSON_PATH = "$..sourceproviderid";
    public static final String SOURCE_MEMBER_ID_JSON_PATH = "$..sourcememberid";

    public static final String Statuscode = "Statuscode";

    public static final String GDFID = "$.GDFID";
    
    public static final String UDHGDFID = "$.gdfId";
    
    public static final String UDHRESPGDFID = "UDHRESPGDFID";
    
    public static final String MEMBERGDFID = "$..GDFID";
    
    public static final String UDHPAYLOAD = "UDHPAYLOAD";
    
    public static final String newUdhCreatedTimeStamp = "newUdhCreatedTimeStamp";
    public static final String newUdhUpdatedTimeStamp = "newUdhUpdatedTimeStamp";
    public static final String PROVIDERGDFID = "$.GDFID";
    public static final String PROVIDERGDFID1 = "$.GDFID1";

    public static final String CASEIDJSON = "$..caseId";
    
    public static final String PAYLOADCASEID =  "$.payload.caseId";
      
    public static final String CASESERVICELINENUMBER = "$..caseServiceLineNumber";
    
    public static final String CASESERVICELINENUMBERS = "$..caseServiceLine[i].caseServiceLineNumber";

    public static final String CASEID = "CASEID";
    
    public static final String EVENTGUID = "$.EVENT_GUID";

    public static final String TxRequestType = "$.TxRequestType";
    
    public static final String TXNSTATUS = "$.TXN_STAT_DESC";
    
    public static final String BI_CLINTEMP_FILENAME = "$.FILE_SENT_NM";
    
    public static final String BI_CLINTEMP_FILESENTNAME = "FileSentName";
    
    public static final String BI_CLINTEMP_LN_GDFID = "$.LN_GDF_ID";
    
    public static final String BI_CLINTEMP_STATUS = "$.STAT_DESC";
    
    public static final String BI_CLINTEMP_SUCCESS_FLAG = "$.SUCCESS_FLAG";

    public static final String TOPICNAME = "$.EVENT_TOPIC_NM";
    
    public static final String RETRYCOUNT = "$.RETRY_CNT";
    
    public static final String RETRYFLAG = "$.RETRY_FLAG";
    
    public static final String EventCreatedTS = "$.EVENT_CREATED_TS";
    
    public static final String DHO_SA_PROVIDERGDFID = "$..providerGdfId";
    
    public static final String DHO_SA_MEMBERGDFID = "$..memberGdfId";
    
    public static final String SA_PROVIDERGDFID = "PROVIDER";
    public static final String SA_PROVIDERGDFID1 = "PROVIDER1";
    
    public static final String SA_MEMBERGDFID = "MEMBER";
    
    public static final String SOURCEMEMBER_LOBInsurance = "$..sourcememberlobinsuranceid";
    
    public static final String SOURCEMEMBER_LOBInsuranceID = "sourcememberlobinsuranceid";
    //Member Legal
    public static final String SOURCEMEMBER_LEGAL_ID = "$..memberlegal[0].sourcememberlegalid";
    
    public static final String ADD_MEMBER_LEGAL_ID = "AddMemberLegalID";

    public static final String UPDATE_MEMBER_LEGAL_ID = "UpdateMemberLegalID";
    //Provider Speciality
    public static final String PROVIDER_SPECIALITY_ID = "$..providerspecialty[0].sourceproviderspecialtyid";
    
    public static final String ADD_PROVIDER_SPECIALITY_ID = "AddProviderSpecialtyid";

    public static final String UPDATE_PROVIDER_SPECIALITY_ID = "UpdateProviderSpecialtyid";    
    // Diagnosis

    public static final String DIAGNOSIS_ID = "$..serviceauthdiagnosis[i].sourceserviceauthdiagnosisid";

    public static final String DIAG_SOURCE_SERVICE_AUTH_ID = "$..serviceauthdiagnosis[i].sourceserviceauthid";

    // Service Line

    public static final int maxServiceAuthLines = 3;

    public static final int maxProvidersPerLine = 3;

    // SERVICE LINE SERVICE AUTH ID

    public static final String LINE_SOURCE_SERVICE_AUTH_ID = "$..serviceauthline[i].sourceserviceauthid";

    // SERVICE LINE AUTH ID

    public static final String SOURCE_SERVICE_AUTH_LINE_ID = "$..serviceauthline[i].sourceserviceauthlineid";

    public static final String SOURCE_SERVICE_AUTH_LINE_ID_1 = "$..serviceauthline[0].sourceserviceauthlineid";

    public static final String SOURCE_SERVICE_AUTH_LINE_ID_2 = "$..serviceauthline[1].sourceserviceauthlineid";

    public static final String SOURCE_SERVICE_AUTH_LINE_ID_3 = "$..serviceauthline[2].sourceserviceauthlineid";

    // SERVICE AUTH MODIFIERS

    public static final String SOURCE_SERVICE_AUTH_LINE_ID_MOD =
        "$..serviceauthline[i].serviceauthprocedurecodemodifier.sourceserviceauthprocedurecodemodifierid";
    
    public static final String SERVICE_AUTH_LINE1_PROCEDURECODE_MODID =
            "$..serviceauthline[0].serviceauthprocedurecodemodifier.sourceserviceauthprocedurecodemodifierid";
    
    public static final String SA_ADD_LINE1_PROCEDURECODE_MODID =
            "AddLine1ProcedureModID";
    
    public static final String SA_UPDATE_LINE1_PROCEDURECODE_MODID =
            "UpdateLine1ProcedureModID";
    
    public static final String SOURCE_SERVICE_AUTH_LINE_ID_MOD_1_LINE =
        "$..serviceauthline[i].serviceauthprocedurecodemodifier.sourceserviceauthlineid";

    // Provider IDS
    public static final String SOURCE_SERVICE_AUTH_PROVIDER_ID =
        "$..serviceauthprovider[i].sourceserviceauthproviderid";

    // PROVIDER SERVICE AUTH ID
    public static final String PROV_SOURCE_SERVICE_AUTH_ID = "$..serviceauthprovider[i].sourceserviceauthid";

    // PROVIDER SERVICE AUTH LINE IDS
    public static final String SOURCE_SERVICE_AUTH_PROVIDER_LINE_MAP =
        "$..serviceauthprovider[i].serviceauthproviderserviceauthlinemap[0].sourceserviceauthproviderserviceauthlinemapid";
    
    public static final String SOURCE_SERVICE_AUTH__PROVIDERLINEMAP_ID_LINE1 = "$..serviceauthprovider[0].serviceauthproviderserviceauthlinemap[0].sourceserviceauthproviderserviceauthlinemapid";
    public static final String SOURCE_SERVICE_AUTH__PROVIDERLINEMAP_ID_LINE2 = "$..serviceauthprovider[1].serviceauthproviderserviceauthlinemap[0].sourceserviceauthproviderserviceauthlinemapid";
    public static final String SA_ADD_LINE1_SAPROVIDERLINEMAPID = "SAAddLine1sourceserviceauthproviderserviceauthlinemapid";
    public static final String SA_ADD_LINE2_SAPROVIDERLINEMAPID = "SAAddLine2sourceserviceauthproviderserviceauthlinemapid";
    public static final String SA_UPDATE_LINE1_SAPROVIDERLINEMAPID = "SAUpdateLine1sourceserviceauthproviderserviceauthlinemapid";
    public static final String SA_UPDATE_LINE2_SAPROVIDERLINEMAPID = "SAUpdateLine2sourceserviceauthproviderserviceauthlinemapid";

    // PROVIDER SERIVCE AUTH LINE PROVIDER IDs
    public static final String SOURCE_SERVICE_AUTH_PROVIDER_ID_LINE =
        "$..serviceauthprovider[i].serviceauthproviderserviceauthlinemap[0].sourceserviceauthproviderid";

    // PROVIDER SERVICE LINE ID MAPPING
    public static final String SOURCE_SERVICE_AUTH_PROVIDER_ID_1_LINE_ID_1 =
        "$..serviceauthprovider[0].serviceauthproviderserviceauthlinemap[0].sourceserviceauthlineid";

    public static final String SOURCE_SERVICE_AUTH_PROVIDER_ID_2_LINE_ID_1 =
        "$..serviceauthprovider[1].serviceauthproviderserviceauthlinemap[0].sourceserviceauthlineid";

    public static final String SOURCE_SERVICE_AUTH_PROVIDER_ID_3_LINE_ID_1 =
        "$..serviceauthprovider[2].serviceauthproviderserviceauthlinemap[0].sourceserviceauthlineid";

    public static final String SOURCE_SERVICE_AUTH_PROVIDER_ID_4_LINE_ID_2 =
        "$..serviceauthprovider[3].serviceauthproviderserviceauthlinemap[0].sourceserviceauthlineid";

    public static final String SOURCE_SERVICE_AUTH_PROVIDER_ID_5_LINE_ID_2 =
        "$..serviceauthprovider[4].serviceauthproviderserviceauthlinemap[0].sourceserviceauthlineid";

    public static final String SOURCE_SERVICE_AUTH_PROVIDER_ID_6_LINE_ID_2 =
        "$..serviceauthprovider[5].serviceauthproviderserviceauthlinemap[0].sourceserviceauthlineid";

    public static final String SOURCE_SERVICE_AUTH_PROVIDER_ID_7_LINE_ID_3 =
        "$..serviceauthprovider[6].serviceauthproviderserviceauthlinemap[0].sourceserviceauthlineid";

    public static final String SOURCE_SERVICE_AUTH_PROVIDER_ID_8_LINE_ID_3 =
        "$..serviceauthprovider[7].serviceauthproviderserviceauthlinemap[0].sourceserviceauthlineid";

    public static final String SOURCE_SERVICE_AUTH_PROVIDER_ID_9_LINE_ID_3 =
        "$..serviceauthprovider[8].serviceauthproviderserviceauthlinemap[0].sourceserviceauthlineid";

    // PROVIDER SERVICE AUTH MAPIDS

    public static final String SOURCE_SERVICE_AUTH_PROVIDER_TYPE_MAP =
        "$..serviceauthprovider[i].serviceauthproviderserviceauthprovidertypemap[0].sourceserviceauthproviderserviceauthprovidertypemapid";
    public static final String SOURCE_SERVICE_AUTH__PROVIDERTYPEMAP_ID1_LINE1 = "$..serviceauthprovider[0].serviceauthproviderserviceauthprovidertypemap[0].sourceserviceauthproviderserviceauthprovidertypemapid";
    public static final String SOURCE_SERVICE_AUTH__PROVIDERTYPEMAP_ID2_LINE1 = "$..serviceauthprovider[0].serviceauthproviderserviceauthprovidertypemap[1].sourceserviceauthproviderserviceauthprovidertypemapid";
    public static final String SOURCE_SERVICE_AUTH__PROVIDERTYPEMAP_ID3_LINE1 = "$..serviceauthprovider[0].serviceauthproviderserviceauthprovidertypemap[2].sourceserviceauthproviderserviceauthprovidertypemapid";
    public static final String SOURCE_SERVICE_AUTH__PROVIDERTYPEMAP_ID1_LINE2 = "$..serviceauthprovider[1].serviceauthproviderserviceauthprovidertypemap[0].sourceserviceauthproviderserviceauthprovidertypemapid";
    public static final String SOURCE_SERVICE_AUTH__PROVIDERTYPEMAP_ID2_LINE2 = "$..serviceauthprovider[1].serviceauthproviderserviceauthprovidertypemap[1].sourceserviceauthproviderserviceauthprovidertypemapid";
    public static final String SOURCE_SERVICE_AUTH__PROVIDERTYPEMAP_ID3_LINE2 = "$..serviceauthprovider[1].serviceauthproviderserviceauthprovidertypemap[2].sourceserviceauthproviderserviceauthprovidertypemapid";
    public static final String SA_ADD_LINE1_SAPROVIDERTYPEMAPID1 = "ADDLINE1SAPROVIDERTYPEMAPID1";
    public static final String SA_ADD_LINE1_SAPROVIDERTYPEMAPID2 = "ADDLINE1SAPROVIDERTYPEMAPID2"; 
    public static final String SA_ADD_LINE1_SAPROVIDERTYPEMAPID3 = "ADDLINE1SAPROVIDERTYPEMAPID3";
    public static final String SA_ADD_LINE2_SAPROVIDERTYPEMAPID1 = "ADDLINE2SAPROVIDERTYPEMAPID1";
    public static final String SA_ADD_LINE2_SAPROVIDERTYPEMAPID2 = "ADDLINE2SAPROVIDERTYPEMAPID2";
    public static final String SA_ADD_LINE2_SAPROVIDERTYPEMAPID3 = "ADDLINE2SAPROVIDERTYPEMAPID3";
    
    public static final String SA_UPDATE_LINE1_SAPROVIDERTYPEMAPID1 = "UPDATELINE1SAPROVIDERTYPEMAPID1";
    public static final String SA_UPDATE_LINE1_SAPROVIDERTYPEMAPID2 = "UPDATELINE1SAPROVIDERTYPEMAPID2"; 
    public static final String SA_UPDATE_LINE1_SAPROVIDERTYPEMAPID3 = "UPDATELINE1SAPROVIDERTYPEMAPID3";
    public static final String SA_UPDATE_LINE2_SAPROVIDERTYPEMAPID1 = "UPDATELINE2SAPROVIDERTYPEMAPID1";
    public static final String SA_UPDATE_LINE2_SAPROVIDERTYPEMAPID2 = "UPDATELINE2SAPROVIDERTYPEMAPID2";
    public static final String SA_UPDATE_LINE2_SAPROVIDERTYPEMAPID3 = "UPDATELINE2SAPROVIDERTYPEMAPID3";

    //SA DIAGNOSISID
    public static final String SOURCE_SERVICE_AUTH_PRIMARY_DIAGID_LINE1 ="$..serviceauthdiagnosis[0].sourceserviceauthdiagnosisid"; 
    
    public static final String SOURCE_SERVICE_AUTH_SECONDARY_DIAGID_LINE1 ="$..serviceauthdiagnosis[2].sourceserviceauthdiagnosisid";
    
    public static final String SOURCE_SERVICE_AUTH_TERTIARY_DIAGID_LINE1 ="$..serviceauthdiagnosis[3].sourceserviceauthdiagnosisid"; 
    
    public static final String SOURCE_SERVICE_AUTH_OTHER_DIAGID_LINE1 ="$..serviceauthdiagnosis[1].sourceserviceauthdiagnosisid";
    
    public static final String SA_ADD_LINE1_PRIMARYDIAG_ID ="AddLine1SAPrimaryDiagID";
    
    public static final String SA_ADD_LINE1_SECONDARYDIAG_ID ="AddLine1SASecondaryDiagID"; 
    
    public static final String SA_ADD_LINE1_TERTIARY_ID ="AddLine1SATertiaryDiagID";
    
    public static final String SA_ADD_LINE1_OTHER_ID ="AddLine1SAOtherDiagID"; 
    
    public static final String SA_UPDATE_LINE1_PRIMARYDIAG_ID ="UpdateLine1SAPrimaryDiagID";
    
    public static final String SA_UPDATE_LINE1_SECONDARYDIAG_ID ="UpdateLine1SASecondaryDiagID"; 
    
    public static final String SA_UPDATE_LINE1_TERTIARY_ID ="UpdateLine1SATertiaryDiagID";
    
    public static final String SA_UPDATE_LINE1_OTHER_ID ="UpdateLine1SAOtherDiagID"; 
    // PROVIDER SERVICE AUTH ID MAP
    public static final String SOURCE_SERVICE_AUTH_PROVIDER_ID_TYPE_MAP =
        "$..serviceauthprovider[i].serviceauthproviderserviceauthprovidertypemap[0].sourceserviceauthproviderid";
    
    public static final String SOURCE_SERVICE_AUTH_FIRST_PROVIDER_ID_LINE1 ="$..serviceauthprovider[0].sourceserviceauthproviderid"; 
 
    public static final String SOURCE_SERVICE_AUTH_SECOND_PROVIDER_ID_LINE1 ="$..serviceauthprovider[1].sourceserviceauthproviderid";
    
    public static final String SA_ADD_LINE1_FIRST_PROVIDER_ID ="AddLine1SA1stProviderID";
    
    public static final String SA_ADD_LINE1_SECOND_PROVIDER_ID ="AddLine1SA2ndProviderID"; 
    
    public static final String SA_UPDATE_LINE1_FIRST_PROVIDER_ID ="UpdateLine1SA1stProviderID";
    
    public static final String SA_UPDATE_LINE1_SECOND_PROVIDER_ID ="UpdateLine1SA2ndProviderID"; 
    
    
    public static final int POLL_INTERVAL = 1;

    public static final int POLL_DELAY = 2;

    public static final int TIME_OUT_SECONDS = 2;

    public static final int ERR_OBJ_LIST_SIZE = 0;

    // CaseID
    public static final int CASETransactionID1 = 1;
    public static final int CASEAppID1 = 4;
    public static final String CASEIDLines = "1";
    public static final String CASEIDcolor = "one";
    public static final String CASELineNbr1 = "001";
    public static final String CASEsvctxid1 = "1";
    public static final String CASEIDcolor1 = "RED";
    public static final int CASEIDplan1 = 1;
    public static final int CASEIDIntakeId1 = 1;
    public static final int CASEIDpatientNumber1 = 1;
    public static final int CASEIDprovId1 = 1;
    public static final Long CASEID1 = 0L;

    public static final String CaseID_TransactionID_Line1 = "serviceRequests[0].ccxTransactionId";
    public static final String CaseID_ApplicationID_Line1 = "serviceRequests[0].applicationId";
    public static final String CaseID_TransactionID_All = "$..serviceRequests[i].ccxTransactionId";
    public static final String CaseID_Linestatus = "serviceRequests[0].caseServiceLineStatus";
    public static final String CaseID_Eligible = "serviceRequests[0].isEligibleToSendToMedCompass";
    public static final String CaseID_HeaderlvlStatus = "HIGH_LVL_STAT_TYPE_CD[0]";
    public static final String CaseID_DetailedvlStatus = "DTL_LVL_STAT_TYPE_CD[0]";
    public static final String CaseID_LineStatusDB = "STAT_TYPE_CD[0]";
    public static final String CaseID_CaseType = "CASE_TYPE_CD[0]";
    public static final String CaseID_CatID = "$..serviceCatId";
    public static final String CaseID_clinicalrvwMode = "CLINICAL_RVW_MODE_CD[0]";
    
    public static final String CaseID_svctxid1 = "serviceRequests[0].ccxServiceTransactionId";
    public static final String CaseID_ccxCaseId1 = "serviceRequests[0].ccxCaseId";
    public static final String CaseID_IntakeId1 = "serviceRequests[0].ccxServiceLineIntakeId";
    public static final String CaseID_PlanId1 = "serviceRequests[0].ccxServiceLinePlanId";
    public static final String CaseID_patientNumber1 = "serviceRequests[0].patientNumber";
    public static final String CaseID_provId1 = "serviceRequests[0].provId";
    public static final String CaseID_colorCd1 = "serviceRequests[0].colorCd";
    public static final String CaseID_caseLnnbr1 = "serviceRequests[0].ccxCaseLnNbr";
    public static final String CaseID_caseLinestatus1 = "serviceRequests[0].caseLineStatus";
    public static final String CaseID_AuthCategory = "serviceRequests[0].caseServiceLineAuthCategory";
    public static final String CaseID_ccxCaseLnId1 = "serviceRequests[0].ccxCaseLnId";
    
    public static final String CaseID_EligibilityResolved = "serviceRequests[0].svcEligibilityReviewFailResolveCd";
    public static final String CaseID_BusinessFailResolved = "serviceRequests[0].businessFailureReviewResolutionCd";
    public static final String CaseID_clinicalRvwFailFlag = "serviceRequests[0].clinicalReviewFailOverrideFlag";
    public static final String CaseID_clinicalRvwResolved = "serviceRequests[0].clinicalReviewFailOverrideUser";
    public static final String CaseID_adminRvwFailFlag = "serviceRequests[0].adminReviewFailOverrideFlag";
    public static final String CaseID_adminRvwResolved = "serviceRequests[0].adminReviewFailOverrideUser";
    public static final String Case_reassign_deletefields = "requestType,serviceRequests[0].serviceCatId,serviceRequests[0].serviceTypeCode,serviceRequests[0].serviceCode,serviceRequests[0].uomCode,serviceRequests[0].businessFailureReviewFlag,serviceRequests[0].headerEligibilityReviewFailFlag,serviceRequests[0].noAdmitFlag,serviceRequests[0].svcNoAdmitFlag,serviceRequests[0].adminReviewFaillFlag,serviceRequests[0].svcEndDate,serviceRequests[0].svcStrtDate,serviceRequests[0].primaryDiagnosisCode,serviceRequests[0].approvedNumberOfUnits,serviceRequests[0].autoApproveCd,serviceRequests[0].ccxAuthorizationid,serviceRequests[0].clinicalReviewFailFlag,serviceRequests[0].svcEligibilityReviewFailFlag,serviceRequests[0].headerEligibilityReviewFailResolveCd,serviceRequests[0].healthPlanReviewFailFlag,serviceRequests[0].readOnlyFlag,serviceRequests[0].staffingFailFlag,serviceRequests[0].serviceAuthLineNbr,serviceRequests[0].caseLineStatus,serviceRequests[0].hcpcCode,serviceRequests[0].svcEscalationFlag";
    
    

    public static final String CaseID_Res_Applid = "serviceRequests[i].applicationId";
    public static final String CaseID_Res_TxnID = "serviceRequests[i].ccxTransactionId";
    public static final String CaseID_Res_ccxCaseLnId = "serviceRequests[i].ccxCaseLnId";
    public static final String CaseID_Res_ccxCaseLnNbr = "serviceRequests[i].ccxCaseLnNbr";
    public static final String CaseID_Res_ccxCaseId = "serviceRequests[i].ccxCaseId";

    public static final String CaseID_ResDB_CaseAll = "$..CCX_CASE_ID";
    public static final String CaseID_ResDB_ColorAll = "$..COLOR_CD";
    public static final String CaseID_ResDB_CasID = "CCX_CASE_ID[i]";
    public static final String CaseID_ResDB_LNNBR = "CCX_CASE_LN_NBR[i]";
    public static final String CaseID_ResDB_LNID = "CCX_CASE_LN_ID[i]";

    // STATUS CODES

    public static final int STATUS_CODE_200 = 200;
    public static final int STATUS_CODE_400 = 400;

    public static final String DHO_REQUEST_TYPE = "$.TxRequestType";
    
    public static final String REQUEST_TYPE = "RequestType";

    public static final String username = "username";

    public static final String password = "password";

    // caseservice

    public static final int maxCaseServiceLines = 6;

    public static final int RANDOM_NO_MIN = 40000000;

    public static final int RANDOM_NO_MAX = 49999999;

    public static final String CASE_CCX_TXN_ID = "ccxTxnId";

    public static final String CASE_$_0_CCX_TXN_ID = "serviceRequests[0].ccxTransactionId";

    public static final String CASE_APP_ID = "applicationId";

    public static final String CASE_$_0_APP_ID = "serviceRequests[0].applicationId";
    
    public static final String EVENT_ID_DB= "&eventId=";

    public static final String CASE_SERVICE_HOSTNAME = "caseservicehostname";
    public static final String CASE_API_HOSTNAME = "mcapihostname";

    public static final String CASE_DB_URI = "/caseservice/ccx/auth?appTrxId=";

    public static final String CASE_DB_APP_ID = "&applicationId=";
    public static final String SERVICEATH_STATUS_DB = "&status=";

    public static final String CASE_$_0_TXN_NO_ADMIT_FLAG = "TXN_NO_ADMIT_FLAG[0]";

    public static final String CASE_$_0_ELIG_RVW_FAIL_FLAG = "ELIG_RVW_FAIL_FLAG[0]";
    public static final String CASE_$_0_COLOR_CD = "COLOR_CD[0]";
    public static final String CASE_$_0_BUS_RVW_FAIL_FLAG = "BUS_RVW_FAIL_FLAG[0]";
    public static final String CASE_$_0_CCX_CASE_LN_ID = "CCX_CASE_LN_ID[0]";
    public static final String CASE_$_0_CLINICAL_RVW_FAIL_FLAG = "CLINICAL_RVW_FAIL_FLAG[0]";
    public static final String CASE_$_0_ADMIN_RVW_FAIL_FLAG = "ADMIN_RVW_FAIL_FLAG[0]";
    public static final String CASE_$_0_BUS_RVW_FAIL_RSLVD_CD = "BUS_RVW_FAIL_RSLVD_CD[0]";
    public static final String CASE_$_0_HP_RVW_FAIL_FLAG = "HP_RVW_FAIL_FLAG[0]";
    public static final String CASE_$_0_CLINICAL_RVW_OVRD_FLAG = "CLINICAL_RVW_FAIL_OVRD_FLAG[0]";
    public static final String CASE_$_0_ADMIN_RVW_OVRD_FLAG = "ADMIN_RVW_FAIL_OVRD_FLAG[0]";
    public static final String CASE_$_0_ELIG_RVW_RSLVD_FLAG = "ELIG_RVW_FAIL_RSLVD_CD[0]";
    
}
