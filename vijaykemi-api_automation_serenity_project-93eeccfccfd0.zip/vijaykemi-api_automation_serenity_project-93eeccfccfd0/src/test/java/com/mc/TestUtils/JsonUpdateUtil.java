package com.mc.TestUtils;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;

import net.serenitybdd.core.Serenity;

public class JsonUpdateUtil {

    private static final Logger log = LogManager.getLogger(JsonUpdateUtil.class);

    Random random = new Random();

    public JsonUpdateUtil() {}

    public static String buildJsonRequest(String payload, Map<String, Object> map, String app) throws IOException {

        DocumentContext doc = JsonPath.parse(payload);
        String newPayload = payload;
        String noOfLines = null;

        for (Map.Entry<String, Object> entry : map.entrySet()) {
            try {
                if (entry.getValue() != null && entry.getValue().equals(Constant.UUID)) {
                    doc = JsonPath.parse(newPayload).set(entry.getKey(), UUID.randomUUID().toString());
                } else if (entry.getValue() != null && entry.getValue().equals(Constant.RANDOM_NUMBER)) {
                    doc = JsonPath.parse(newPayload).set(entry.getKey(),
                        getRandomNumberInts(Constant.RANDOM_NO_MIN, Constant.RANDOM_NO_MAX));
                } else if (entry.getKey() != null && entry.getKey().equals("NoOfLines")) {
                    noOfLines = entry.getValue().toString();
                } else if (entry.getKey() != null && entry.getValue().equals("null")) {
                    doc = JsonPath.parse(newPayload).set(entry.getKey(), null);
                } else {
                    doc = JsonPath.parse(newPayload).set(entry.getKey(), entry.getValue());
                }
                newPayload = doc.jsonString();
            } catch (Exception e) {
                // log.warn(e, e);
            }
        }
        if (noOfLines != null && app.equalsIgnoreCase("CaseService")) {
            deleteCaseServiceLine(doc, noOfLines);
        } else if (noOfLines != null && app.contains("DHOServiceAuth")) {
            deleteDHOLine(doc, noOfLines);
        }
        return doc.jsonString();
    }

    @Deprecated
    public static String buildJsonRequestpro(String payload, Map<String, Object> map, String deletefields)
        throws IOException {

        log.info("new payload {}", payload);
        DocumentContext doc = JsonPath.parse(payload);
        String newPayload = payload;
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            try {
                if (entry.getValue() != null && entry.getValue().equals(Constant.UUID)) {
                    doc = JsonPath.parse(newPayload).set(entry.getKey(), UUID.randomUUID().toString());
                } else {
                    doc = JsonPath.parse(newPayload).set(entry.getKey(), entry.getValue());
                }
                newPayload = doc.jsonString();
            } catch (Exception e) {
                log.info(e, e);
            }
        }

        if (deletefields != "NONE") {
            String[] arrSplit = deletefields.split(",");
            for (int i = 0; i < arrSplit.length; i++) {
                // System.out.println("Rows to be deleted"+arrSplit[i]);
                log.info("Rows to be deleted" + arrSplit[i]);

                doc.delete(arrSplit[i]);
            }
        }
        newPayload = doc.jsonString();
        log.info("new payload {}", newPayload);
        return newPayload;
    }

    public static String buildJsonRequestNew(String payload, Map<Object, Object> map, String deletefields)
        throws IOException {

        log.info("map =", map);
        DocumentContext doc = JsonPath.parse(payload);
        String newPayload = payload;
        String noOfLines = null;
        for (Map.Entry<Object, Object> entry : map.entrySet()) {
            try {
                if (entry.getValue() != null && entry.getValue().equals(Constant.UUID)) {
                    doc = JsonPath.parse(newPayload).set(entry.getKey().toString(), UUID.randomUUID().toString());
                } else if (entry.getValue() != null && entry.getValue().equals(Constant.RANDOM_NUMBER)) {
                    doc = JsonPath.parse(newPayload).set(entry.getKey().toString(),
                        getRandomNumberInts(Constant.RANDOM_NO_MIN, Constant.RANDOM_NO_MAX));
                } else if (entry.getKey() != null && entry.getKey().equals("NoOfLines")) {
                    noOfLines = entry.getValue().toString();
                } else if (entry.getKey() != null && entry.getValue().equals("null")) {
                    doc = JsonPath.parse(newPayload).set(entry.getKey().toString(), null);
                } else {
                    doc = JsonPath.parse(newPayload).set(entry.getKey().toString(), entry.getValue());
                }
                newPayload = doc.jsonString();
            } catch (Exception e) {
                log.info(e, e);
            }
        }
        if (noOfLines != null && deletefields.equalsIgnoreCase("CaseService")) {
            deleteCaseServiceLine(doc, noOfLines);
        } else if (deletefields != "NONE") {
            String[] arrSplit = deletefields.split(",");
            for (int i = 0; i < arrSplit.length; i++) {
                // System.out.println("Rows to be deleted"+arrSplit[i]);
                log.info("Rows to be deleted" + arrSplit[i]);

                doc.delete(arrSplit[i]);
            }
        }
        newPayload = doc.jsonString();
        log.info("new payload {}", newPayload);
        return newPayload;
    }

    public static String buildDHOJsonRequest(String payload, Map<Object, Object> map) throws IOException {

        DocumentContext doc = JsonPath.parse(payload);
        String key = "";
        String value = "";
        String newPayload = payload;
        for (Map.Entry<Object, Object> entry : map.entrySet()) {
            try {
                if (entry.getKey() != null && entry.getKey().equals("InputField")) {
                    if (entry.getValue() != null) {
                        key = entry.getValue().toString();
                    }
                } else if (entry.getKey() != null && entry.getKey().equals("InputValue")) {
                    if (entry.getValue() != null) {
                        value = entry.getValue().toString();
                    }
                }
                if (!key.isEmpty() && !value.isEmpty()) {
                    doc = JsonPath.parse(newPayload).set(key, value);
                    key = "";
                    value = "";
                    newPayload = doc.jsonString();
                }

            } catch (Exception e) {
                log.info(e, e);
            }
        }
        newPayload = doc.jsonString();
        return newPayload;
    }

    public static String buildServiceAuthRequest(JSONObject payload, String sourceServiceAuthId,
        Map<String, Object> map) throws IOException {

        DocumentContext doc;
        Map<String, String> mapIds = generateServiceAuthKeys();
        mapIds.put(Constant.SOURCE_SERVICE_AUTH_ID, sourceServiceAuthId);
        String newPayload = payload.toString();
        doc = JsonPath.parse(newPayload);
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            try {

                if (entry.getValue() != null && ((entry.getValue().equals(Constant.UNUSED))
                    || (entry.getValue().equals(Constant.ALL)) || (entry.getValue().equals(Constant.USED)))) {
                    doc = JsonPath.parse(newPayload).set(entry.getKey(), mapIds.get(Constant.SOURCE_SERVICE_AUTH_ID));

                } else if (entry.getValue() != null && entry.getValue().equals(Constant.UUID)) {
                    doc = JsonPath.parse(newPayload).set(entry.getKey(), UUID.randomUUID().toString());
                } else if (entry.getValue() != null && entry.getValue().equals(Constant.SOURCE_SERVICE_AUTH_ID)) {
                    doc = JsonPath.parse(newPayload).set(entry.getKey(), mapIds.get(Constant.SOURCE_SERVICE_AUTH_ID));
                } else if (entry.getValue() != null && mapIds.containsKey(entry.getValue())) {
                    doc = JsonPath.parse(newPayload).set(entry.getKey(), mapIds.get(entry.getValue()));
                } else {
                    doc = JsonPath.parse(newPayload).set(entry.getKey(), entry.getValue());
                }
                newPayload = doc.jsonString();
            } catch (Exception e) {
                log.info(e, e);
            }
        }
        doc = JsonPath.parse(newPayload).set(Constant.EVENT_ID_VALUE_JSON_PATH, sourceServiceAuthId);
        doc = setDiagnosisIds(doc, mapIds);
        doc = setSALineIds(doc, mapIds);
        doc = setProviderIds(doc, mapIds);
        deleteLine(doc, map.get("NoOfLines").toString());
        newPayload = doc.jsonString();
        log.info("new payload {} ", newPayload);
        return newPayload;
    }

    public static String buildServiceAuthRequestAdd(JSONObject payload, String sourceServiceAuthId,
        Map<String, Object> map) throws IOException {

        DocumentContext doc;
        Map<String, String> mapIds = generateServiceAuthKeys();
        mapIds.put(Constant.SOURCE_SERVICE_AUTH_ID, sourceServiceAuthId);
        String newPayload = payload.toString();
        doc = JsonPath.parse(newPayload);
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            try {

                if (entry.getValue() != null && ((entry.getValue().equals(Constant.UNUSED))
                    || (entry.getValue().equals(Constant.ALL)) || (entry.getValue().equals(Constant.USED)))) {
                    doc = JsonPath.parse(newPayload).set(entry.getKey(), mapIds.get(Constant.SOURCE_SERVICE_AUTH_ID));

                } else if (entry.getValue() != null && entry.getValue().equals(Constant.UUID)) {
                    doc = JsonPath.parse(newPayload).set(entry.getKey(), UUID.randomUUID().toString());
                } else if (entry.getValue() != null && entry.getValue().equals(Constant.SOURCE_SERVICE_AUTH_ID)) {
                    doc = JsonPath.parse(newPayload).set(entry.getKey(), mapIds.get(Constant.SOURCE_SERVICE_AUTH_ID));
                } else if (entry.getValue() != null && mapIds.containsKey(entry.getValue())) {
                    doc = JsonPath.parse(newPayload).set(entry.getKey(), mapIds.get(entry.getValue()));
                } else {
                    doc = JsonPath.parse(newPayload).set(entry.getKey(), entry.getValue());
                }
                newPayload = doc.jsonString();
            } catch (Exception e) {
                log.info(e, e);
            }
        }
        doc = JsonPath.parse(newPayload).set(Constant.EVENT_ID_VALUE_JSON_PATH, sourceServiceAuthId);
        doc = setDiagnosisIds(doc, mapIds);
        doc = setSALineIds(doc, mapIds);
        doc = setProviderIds(doc, mapIds);
        deleteLine(doc, map.get("NoOfLines").toString());
        deleteDiagLine(doc, map.get("NoOfDiagnosis").toString());

        // System.out.println("value of row to be deleted is --"+map.get("RowstobeDeleted").toString()+"--");
        if ((map.get("RowstobeDeleted").toString() != "") && (map.get("RowstobeDeleted").toString() != "NONE")) {
            String[] arrSplit = map.get("RowstobeDeleted").toString().split(",");
            for (int i = 0; i < arrSplit.length; i++) {
                log.info("Rows to be deleted" + arrSplit[i]);

                doc.delete(arrSplit[i]);
            }
        }

        newPayload = doc.jsonString();
        log.info("new payload {} ", newPayload);
        return newPayload;
    }

    public static String eventresponseadd(JSONObject payload, String sourceServiceAuthId, Map<String, Object> map)
        throws IOException {

        DocumentContext doc;

        Map<String, String> mapIds = generateServiceAuthKeys();
        mapIds.put(Constant.SOURCE_SERVICE_AUTH_ID, sourceServiceAuthId);

        String newPayload = payload.toString();
        doc = JsonPath.parse(newPayload);

        for (Map.Entry<String, Object> entry : map.entrySet()) {
            try {

                if (entry.getValue() != null && ((entry.getValue().equals(Constant.UNUSED))
                    || (entry.getValue().equals(Constant.ALL)) || (entry.getValue().equals(Constant.USED)))) {
                    doc = JsonPath.parse(newPayload).set(entry.getKey(), mapIds.get(Constant.SOURCE_SERVICE_AUTH_ID));

                } else if (entry.getValue() != null && entry.getValue().equals(Constant.UUID)) {
                    doc = JsonPath.parse(newPayload).set(entry.getKey(), UUID.randomUUID().toString());
                } else if (entry.getValue() != null && entry.getValue().equals(Constant.SOURCE_SERVICE_AUTH_ID)) {
                    doc = JsonPath.parse(newPayload).set(entry.getKey(), mapIds.get(Constant.SOURCE_SERVICE_AUTH_ID));
                } else if (entry.getValue() != null && mapIds.containsKey(entry.getValue())) {
                    doc = JsonPath.parse(newPayload).set(entry.getKey(), mapIds.get(entry.getValue()));
                } else {
                    doc = JsonPath.parse(newPayload).set(entry.getKey(), entry.getValue());
                }
                newPayload = doc.jsonString();
            } catch (Exception e) {
                log.info(e, e);
            }
        }

        String statuscode = map.get("StatusCode").toString();
        Serenity.getCurrentSession().put(Constant.Statuscode, statuscode);

        newPayload = doc.jsonString();
        log.info("new payload {} ", newPayload);
        return newPayload;
    }

    public static String buildServiceAuthRequestUPD(JSONObject payload, String sourceServiceAuthId,
        Map<String, Object> map) throws IOException {

        DocumentContext doc;
        Map<String, String> mapIds = generateServiceAuthKeysupd();
        mapIds.put(Constant.SOURCE_SERVICE_AUTH_ID, sourceServiceAuthId);
        String newPayload = payload.toString();
        doc = JsonPath.parse(newPayload);
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            try {

                if (entry.getValue() != null && ((entry.getValue().equals(Constant.UNUSED))
                    || (entry.getValue().equals(Constant.ALL)) || (entry.getValue().equals(Constant.USED)))) {
                    doc = JsonPath.parse(newPayload).set(entry.getKey(), mapIds.get(Constant.SOURCE_SERVICE_AUTH_ID));

                } else if (entry.getValue() != null && entry.getValue().equals(Constant.UUID)) {
                    doc = JsonPath.parse(newPayload).set(entry.getKey(), UUID.randomUUID().toString());
                } else if (entry.getValue() != null && entry.getValue().equals(Constant.SOURCE_SERVICE_AUTH_ID)) {
                    doc = JsonPath.parse(newPayload).set(entry.getKey(), mapIds.get(Constant.SOURCE_SERVICE_AUTH_ID));
                } else if (entry.getValue() != null && mapIds.containsKey(entry.getValue())) {
                    doc = JsonPath.parse(newPayload).set(entry.getKey(), mapIds.get(entry.getValue()));
                } else {
                    doc = JsonPath.parse(newPayload).set(entry.getKey(), entry.getValue());
                }
                newPayload = doc.jsonString();
            } catch (Exception e) {
                log.info(e, e);
            }
        }
        // doc=JsonPath.parse(newPayload).set(Constant.EVENT_ID_VALUE_JSON_PATH,sourceServiceAuthId);
        String eventid01 = UUID.randomUUID().toString();
        Serenity.getCurrentSession().put(Constant.EVENT_ID_VALUE_JSON_PATH, eventid01);
        doc = JsonPath.parse(newPayload).set(Constant.EVENT_ID_VALUE_JSON_PATH, eventid01);
        doc = setDiagnosisIdsupd(doc, mapIds);
        doc = setSALineIdsupd(doc, mapIds);
        doc = setProviderIdsupd(doc, mapIds);
        deleteLine(doc, map.get("NoOfLines").toString());
        deleteDiagLine(doc, map.get("NoOfDiagnosis").toString());

        if ((map.get("RowstobeDeleted").toString() != "") && (map.get("RowstobeDeleted").toString() != "NONE")) {
            String[] arrSplit = map.get("RowstobeDeleted").toString().split(",");
            for (int i = 0; i < arrSplit.length; i++) {
                log.info("Rows to be deleted" + arrSplit[i]);

                doc.delete(arrSplit[i]);
            }
        }

        newPayload = doc.jsonString();
        log.info("new payload {} ", newPayload);
        return newPayload;
    }

    public static void deleteLine(DocumentContext doc, String noOfLines) {
        int iNoOfLines = new Double(Double.parseDouble(noOfLines)).intValue();
        int noOfLinesToBeDeleted = Constant.maxServiceAuthLines - iNoOfLines;

        if (iNoOfLines < Constant.maxServiceAuthLines && iNoOfLines >= 1) {
            int maxProviderArrayCount = Constant.maxServiceAuthLines * Constant.maxProvidersPerLine - 1;
            for (int i = noOfLinesToBeDeleted; i >= 1; i--) {
                String serviceAuthLineJsonPath = "$..serviceauthline[" + i + "]";
                doc.delete(serviceAuthLineJsonPath);
                for (int j = 0; j < Constant.maxProvidersPerLine; j++) {
                    String serviceAuthProviderArrayJsonPath = "$..serviceauthprovider[" + maxProviderArrayCount + "]";
                    doc.delete(serviceAuthProviderArrayJsonPath);
                    maxProviderArrayCount = maxProviderArrayCount - 1;
                }

            }
        }
    }

    private static void deleteDHOLine(DocumentContext doc, String noOfLines) {
        int iNoOfLines = new Double(Double.parseDouble(noOfLines)).intValue();
        int noOfLinesToBeDeleted = Constant.maxServiceAuthLines - iNoOfLines;
        if (iNoOfLines < Constant.maxServiceAuthLines && iNoOfLines >= 1) {
            for (int i = noOfLinesToBeDeleted; i >= 1; i--) {
                String serviceAuthLineJsonPath = "$..caseServiceLine[" + i + "]";
                doc.delete(serviceAuthLineJsonPath);
            }
        }
    }

    private static void deleteCaseServiceLine(DocumentContext doc, String noOfLines) {
        int iNoOfLines = new Double(Double.parseDouble(noOfLines)).intValue();
        int noOfLinesToBeDeleted = Constant.maxCaseServiceLines - iNoOfLines;
        if (iNoOfLines < Constant.maxCaseServiceLines && iNoOfLines >= 1) {
            for (int i = noOfLinesToBeDeleted; i >= 1; i--) {
                String caseServiceLineJsonPath = "$..serviceRequests[" + i + "]";
                doc.delete(caseServiceLineJsonPath);
            }
        }
    }

    public static void deleteDiagLine(DocumentContext doc, String noOfLines) {
        int iNoOfLines = new Double(Double.parseDouble(noOfLines)).intValue();
        for (int j = 4; j >= iNoOfLines; j--) {
            String serviceAuthDiagnosisArrayJsonPath = "$..serviceauthdiagnosis[" + j + "]";
            doc.delete(serviceAuthDiagnosisArrayJsonPath);
            log.info("Diagnosis objects to be removed  ", serviceAuthDiagnosisArrayJsonPath);
        }
    }

    private static Map<String, String> generateServiceAuthKeys() {
        Map<String, String> keys = new HashMap<>();
        for (int i = 0; i <= 2; i++) {
            String lineSourcerServiceAuthId = Constant.SOURCE_SERVICE_AUTH_LINE_ID.replace("[i]", "[" + i + "]");
            String AUTH_ID = UUID.randomUUID().toString();
            Serenity.getCurrentSession().put(Constant.SOURCE_SERVICE_AUTH_LINE_ID.replace("[i]", "[" + i + "]"),
                AUTH_ID);
            keys.put(lineSourcerServiceAuthId, AUTH_ID);

        }
        for (int j = 0; j < 9; j++) {
            String sourceServiceAuthProviderId = Constant.SOURCE_SERVICE_AUTH_PROVIDER_ID.replace("[i]", "[" + j + "]");
            String SOSRCAUTH_ID = UUID.randomUUID().toString();
            Serenity.getCurrentSession().put(Constant.SOURCE_SERVICE_AUTH_PROVIDER_ID.replace("[i]", "[" + j + "]"),
                SOSRCAUTH_ID);

            keys.put(sourceServiceAuthProviderId, SOSRCAUTH_ID);
        }
        return keys;
    }

    private static Map<String, String> generateServiceAuthKeysupd() {
        Map<String, String> keys = new HashMap<>();

        for (int i = 0; i <= 2; i++) {
            String lineSourcerServiceAuthId = Constant.SOURCE_SERVICE_AUTH_LINE_ID.replace("[i]", "[" + i + "]");
            String AUTH_ID = (String) Serenity.getCurrentSession()
                    .get(Constant.SOURCE_SERVICE_AUTH_LINE_ID.replace("[i]", "[" + i + "]"));
            keys.put(lineSourcerServiceAuthId, AUTH_ID);

        }
        for (int j = 0; j < 9; j++) {
            String sourceServiceAuthProviderId = Constant.SOURCE_SERVICE_AUTH_PROVIDER_ID.replace("[i]", "[" + j + "]");
            String SOSRCAUTH_ID = (String) Serenity.getCurrentSession()
                    .get(Constant.SOURCE_SERVICE_AUTH_PROVIDER_ID.replace("[i]", "[" + j + "]"));
            keys.put(sourceServiceAuthProviderId, SOSRCAUTH_ID);
        }
        return keys;
    }

    private static DocumentContext setDiagnosisIds(DocumentContext doc, Map<String, String> map) {

        for (int i = 0; i < 4; i++) {
            String diagSourceServiceAuthId = Constant.DIAG_SOURCE_SERVICE_AUTH_ID.replace("[i]", "[" + i + "]");
            doc =
                JsonPath.parse(doc.jsonString()).set(diagSourceServiceAuthId, map.get(Constant.SOURCE_SERVICE_AUTH_ID));

            String sourceDiagnosisId = Constant.DIAGNOSIS_ID.replace("[i]", "[" + i + "]");

            String diagnosiscde = UUID.randomUUID().toString();
            Serenity.getCurrentSession().put(sourceDiagnosisId, diagnosiscde);
            doc = JsonPath.parse(doc.jsonString()).set(sourceDiagnosisId, diagnosiscde);
        }
        return doc;
    }

    private static DocumentContext setDiagnosisIdsupd(DocumentContext doc, Map<String, String> map) {

        for (int i = 0; i < 4; i++) {
            String diagSourceServiceAuthId = Constant.DIAG_SOURCE_SERVICE_AUTH_ID.replace("[i]", "[" + i + "]");
            doc =
                JsonPath.parse(doc.jsonString()).set(diagSourceServiceAuthId, map.get(Constant.SOURCE_SERVICE_AUTH_ID));

            String sourceDiagnosisId = Constant.DIAGNOSIS_ID.replace("[i]", "[" + i + "]");

            String diagnosiscde = (String) Serenity.getCurrentSession().get(sourceDiagnosisId);
            Serenity.getCurrentSession().put(sourceDiagnosisId, diagnosiscde);
            doc = JsonPath.parse(doc.jsonString()).set(sourceDiagnosisId, diagnosiscde);
        }
        return doc;
    }

    private static DocumentContext setSALineIds(DocumentContext doc, Map<String, String> map) {

        for (int i = 0; i <= 2; i++) {
            String lineSourcerServiceAuthId = Constant.LINE_SOURCE_SERVICE_AUTH_ID.replace("[i]", "[" + i + "]");
            doc = JsonPath.parse(doc.jsonString()).set(lineSourcerServiceAuthId,
                map.get(Constant.SOURCE_SERVICE_AUTH_ID));

            String sourceServiceAuthLineId = Constant.SOURCE_SERVICE_AUTH_LINE_ID.replace("[i]", "[" + i + "]");

            doc = JsonPath.parse(doc.jsonString()).set(sourceServiceAuthLineId, map.get(sourceServiceAuthLineId));

            String sourceServiceAuthLineIdModId =
                Constant.SOURCE_SERVICE_AUTH_LINE_ID_MOD_1_LINE.replace("[i]", "[" + i + "]");

            doc = JsonPath.parse(doc.jsonString()).set(sourceServiceAuthLineIdModId, map.get(sourceServiceAuthLineId));

            String sourceSerivceAuthLineIdMod = Constant.SOURCE_SERVICE_AUTH_LINE_ID_MOD.replace("[i]", "[" + i + "]");

            String srcSrvcAuthLnModId = UUID.randomUUID().toString();
            Serenity.getCurrentSession().put(sourceSerivceAuthLineIdMod, srcSrvcAuthLnModId);

            doc = JsonPath.parse(doc.jsonString()).set(sourceSerivceAuthLineIdMod, srcSrvcAuthLnModId);
        }
        return doc;
    }

    private static DocumentContext setSALineIdsupd(DocumentContext doc, Map<String, String> map) {

        for (int i = 0; i <= 2; i++) {
            String lineSourcerServiceAuthId = Constant.LINE_SOURCE_SERVICE_AUTH_ID.replace("[i]", "[" + i + "]");
            doc = JsonPath.parse(doc.jsonString()).set(lineSourcerServiceAuthId,
                map.get(Constant.SOURCE_SERVICE_AUTH_ID));

            String sourceServiceAuthLineId = Constant.SOURCE_SERVICE_AUTH_LINE_ID.replace("[i]", "[" + i + "]");

            doc = JsonPath.parse(doc.jsonString()).set(sourceServiceAuthLineId, map.get(sourceServiceAuthLineId));

            String sourceServiceAuthLineIdModId =
                Constant.SOURCE_SERVICE_AUTH_LINE_ID_MOD_1_LINE.replace("[i]", "[" + i + "]");

            doc = JsonPath.parse(doc.jsonString()).set(sourceServiceAuthLineIdModId, map.get(sourceServiceAuthLineId));

            String sourceSerivceAuthLineIdMod = Constant.SOURCE_SERVICE_AUTH_LINE_ID_MOD.replace("[i]", "[" + i + "]");

            String srcSrvcAuthLnModId = (String) Serenity.getCurrentSession().get(sourceSerivceAuthLineIdMod);

            doc = JsonPath.parse(doc.jsonString()).set(sourceSerivceAuthLineIdMod, srcSrvcAuthLnModId);
        }
        return doc;
    }

    private static DocumentContext setProviderIds(DocumentContext doc, Map<String, String> map) {

        for (int i = 0; i < 9; i++) {
            String sourceServiceAuthProviderId = Constant.SOURCE_SERVICE_AUTH_PROVIDER_ID.replace("[i]", "[" + i + "]");
            doc =
                JsonPath.parse(doc.jsonString()).set(sourceServiceAuthProviderId, map.get(sourceServiceAuthProviderId));

            // set serviceauthid
            String provSourceSerivceAuthId = Constant.PROV_SOURCE_SERVICE_AUTH_ID.replace("[i]", "[" + i + "]");
            doc =
                JsonPath.parse(doc.jsonString()).set(provSourceSerivceAuthId, map.get(Constant.SOURCE_SERVICE_AUTH_ID));

            // set provider line map id
            String sourceServiceAuthProviderLineMapId =
                Constant.SOURCE_SERVICE_AUTH_PROVIDER_LINE_MAP.replace("[i]", "[" + i + "]");

            String SOURSRVCAUTPROVLNMP = UUID.randomUUID().toString();
            Serenity.getCurrentSession().put(sourceServiceAuthProviderLineMapId, SOURSRVCAUTPROVLNMP);

            doc = JsonPath.parse(doc.jsonString()).set(sourceServiceAuthProviderLineMapId, SOURSRVCAUTPROVLNMP);

            // set provider line - providerid
            String sourceServiceAuthProviderIdLine =
                Constant.SOURCE_SERVICE_AUTH_PROVIDER_ID_LINE.replace("[i]", "[" + i + "]");
            doc = JsonPath.parse(doc.jsonString()).set(sourceServiceAuthProviderIdLine,
                map.get(sourceServiceAuthProviderId));

            // SET PROVIDER LINE ID - TO DO
            // String
            // sourceServiceAuthProviderIdLineId=Constant.SOURCE_SERVICE_AUTH_PROVIDER_ID_LINE_ID.replace("[i]","["+i+"]"
            // );
            // doc=JsonPath.parse(doc.jsonString()).set(sourceServiceAuthProviderIdLineId,map.get(Constant.SOURCE_SERVICE_AUTH_LINE_ID_1));

            // provider type map id
            String sourceServiceAuthProviderTypeMapId =
                Constant.SOURCE_SERVICE_AUTH_PROVIDER_TYPE_MAP.replace("[i]", "[" + i + "]");

            String SRCSRVCATPROVTYPMP = UUID.randomUUID().toString();
            Serenity.getCurrentSession().put(sourceServiceAuthProviderTypeMapId, SRCSRVCATPROVTYPMP);

            doc = JsonPath.parse(doc.jsonString()).set(sourceServiceAuthProviderTypeMapId, SRCSRVCATPROVTYPMP);

            // provider type - provider id
            String sourceServiceAuthProviderIdTypeMap =
                Constant.SOURCE_SERVICE_AUTH_PROVIDER_ID_TYPE_MAP.replace("[i]", "[" + i + "]");
            doc = JsonPath.parse(doc.jsonString()).set(sourceServiceAuthProviderIdTypeMap,
                map.get(sourceServiceAuthProviderId));

        }

        // SET PROVIDER LINE ID

        doc = JsonPath.parse(doc.jsonString()).set(Constant.SOURCE_SERVICE_AUTH_PROVIDER_ID_1_LINE_ID_1,
            map.get(Constant.SOURCE_SERVICE_AUTH_LINE_ID_1));

        doc = JsonPath.parse(doc.jsonString()).set(Constant.SOURCE_SERVICE_AUTH_PROVIDER_ID_2_LINE_ID_1,
            map.get(Constant.SOURCE_SERVICE_AUTH_LINE_ID_1));

        doc = JsonPath.parse(doc.jsonString()).set(Constant.SOURCE_SERVICE_AUTH_PROVIDER_ID_3_LINE_ID_1,
            map.get(Constant.SOURCE_SERVICE_AUTH_LINE_ID_1));

        doc = JsonPath.parse(doc.jsonString()).set(Constant.SOURCE_SERVICE_AUTH_PROVIDER_ID_4_LINE_ID_2,
            map.get(Constant.SOURCE_SERVICE_AUTH_LINE_ID_2));

        doc = JsonPath.parse(doc.jsonString()).set(Constant.SOURCE_SERVICE_AUTH_PROVIDER_ID_5_LINE_ID_2,
            map.get(Constant.SOURCE_SERVICE_AUTH_LINE_ID_2));

        doc = JsonPath.parse(doc.jsonString()).set(Constant.SOURCE_SERVICE_AUTH_PROVIDER_ID_6_LINE_ID_2,
            map.get(Constant.SOURCE_SERVICE_AUTH_LINE_ID_2));

        doc = JsonPath.parse(doc.jsonString()).set(Constant.SOURCE_SERVICE_AUTH_PROVIDER_ID_7_LINE_ID_3,
            map.get(Constant.SOURCE_SERVICE_AUTH_LINE_ID_3));

        doc = JsonPath.parse(doc.jsonString()).set(Constant.SOURCE_SERVICE_AUTH_PROVIDER_ID_8_LINE_ID_3,
            map.get(Constant.SOURCE_SERVICE_AUTH_LINE_ID_3));

        doc = JsonPath.parse(doc.jsonString()).set(Constant.SOURCE_SERVICE_AUTH_PROVIDER_ID_9_LINE_ID_3,
            map.get(Constant.SOURCE_SERVICE_AUTH_LINE_ID_3));

        return doc;
    }

    private static DocumentContext setProviderIdsupd(DocumentContext doc, Map<String, String> map) {

        for (int i = 0; i < 9; i++) {
            String sourceServiceAuthProviderId = Constant.SOURCE_SERVICE_AUTH_PROVIDER_ID.replace("[i]", "[" + i + "]");
            doc =
                JsonPath.parse(doc.jsonString()).set(sourceServiceAuthProviderId, map.get(sourceServiceAuthProviderId));

            // set serviceauthid
            String provSourceSerivceAuthId = Constant.PROV_SOURCE_SERVICE_AUTH_ID.replace("[i]", "[" + i + "]");
            doc =
                JsonPath.parse(doc.jsonString()).set(provSourceSerivceAuthId, map.get(Constant.SOURCE_SERVICE_AUTH_ID));

            // set provider line map id
            String sourceServiceAuthProviderLineMapId =
                Constant.SOURCE_SERVICE_AUTH_PROVIDER_LINE_MAP.replace("[i]", "[" + i + "]");

            String SOURSRVCAUTPROVLNMP = (String) Serenity.getCurrentSession().get(sourceServiceAuthProviderLineMapId);

            doc = JsonPath.parse(doc.jsonString()).set(sourceServiceAuthProviderLineMapId, SOURSRVCAUTPROVLNMP);

            // set provider line - providerid
            String sourceServiceAuthProviderIdLine =
                Constant.SOURCE_SERVICE_AUTH_PROVIDER_ID_LINE.replace("[i]", "[" + i + "]");
            doc = JsonPath.parse(doc.jsonString()).set(sourceServiceAuthProviderIdLine,
                map.get(sourceServiceAuthProviderId));

            // SET PROVIDER LINE ID - TO DO
            // String
            // sourceServiceAuthProviderIdLineId=Constant.SOURCE_SERVICE_AUTH_PROVIDER_ID_LINE_ID.replace("[i]","["+i+"]"
            // );
            // doc=JsonPath.parse(doc.jsonString()).set(sourceServiceAuthProviderIdLineId,map.get(Constant.SOURCE_SERVICE_AUTH_LINE_ID_1));

            // provider type map id
            String sourceServiceAuthProviderTypeMapId =
                Constant.SOURCE_SERVICE_AUTH_PROVIDER_TYPE_MAP.replace("[i]", "[" + i + "]");

            String SRCSRVCATPROVTYPMP = (String) Serenity.getCurrentSession().get(sourceServiceAuthProviderTypeMapId);

            doc = JsonPath.parse(doc.jsonString()).set(sourceServiceAuthProviderTypeMapId, SRCSRVCATPROVTYPMP);

            // provider type - provider id
            String sourceServiceAuthProviderIdTypeMap =
                Constant.SOURCE_SERVICE_AUTH_PROVIDER_ID_TYPE_MAP.replace("[i]", "[" + i + "]");
            doc = JsonPath.parse(doc.jsonString()).set(sourceServiceAuthProviderIdTypeMap,
                map.get(sourceServiceAuthProviderId));

        }

        // SET PROVIDER LINE ID

        doc = JsonPath.parse(doc.jsonString()).set(Constant.SOURCE_SERVICE_AUTH_PROVIDER_ID_1_LINE_ID_1,
            map.get(Constant.SOURCE_SERVICE_AUTH_LINE_ID_1));

        doc = JsonPath.parse(doc.jsonString()).set(Constant.SOURCE_SERVICE_AUTH_PROVIDER_ID_2_LINE_ID_1,
            map.get(Constant.SOURCE_SERVICE_AUTH_LINE_ID_1));

        doc = JsonPath.parse(doc.jsonString()).set(Constant.SOURCE_SERVICE_AUTH_PROVIDER_ID_3_LINE_ID_1,
            map.get(Constant.SOURCE_SERVICE_AUTH_LINE_ID_1));

        doc = JsonPath.parse(doc.jsonString()).set(Constant.SOURCE_SERVICE_AUTH_PROVIDER_ID_4_LINE_ID_2,
            map.get(Constant.SOURCE_SERVICE_AUTH_LINE_ID_2));

        doc = JsonPath.parse(doc.jsonString()).set(Constant.SOURCE_SERVICE_AUTH_PROVIDER_ID_5_LINE_ID_2,
            map.get(Constant.SOURCE_SERVICE_AUTH_LINE_ID_2));

        doc = JsonPath.parse(doc.jsonString()).set(Constant.SOURCE_SERVICE_AUTH_PROVIDER_ID_6_LINE_ID_2,
            map.get(Constant.SOURCE_SERVICE_AUTH_LINE_ID_2));

        doc = JsonPath.parse(doc.jsonString()).set(Constant.SOURCE_SERVICE_AUTH_PROVIDER_ID_7_LINE_ID_3,
            map.get(Constant.SOURCE_SERVICE_AUTH_LINE_ID_3));

        doc = JsonPath.parse(doc.jsonString()).set(Constant.SOURCE_SERVICE_AUTH_PROVIDER_ID_8_LINE_ID_3,
            map.get(Constant.SOURCE_SERVICE_AUTH_LINE_ID_3));

        doc = JsonPath.parse(doc.jsonString()).set(Constant.SOURCE_SERVICE_AUTH_PROVIDER_ID_9_LINE_ID_3,
            map.get(Constant.SOURCE_SERVICE_AUTH_LINE_ID_3));

        return doc;
    }

    public static JSONObject updateJson(JSONObject obj, String keyString, String newValue) throws Exception {

        Iterator<String> iterator = obj.keys();
        String key = null;
        while (iterator.hasNext()) {
            key = iterator.next();
            // if the key is a string, then update the value
            if ((obj.optJSONArray(key) == null) && (obj.optJSONObject(key) == null)) {
                if (key.equals(keyString)) {
                    obj.put(key, newValue);
                    return obj;
                }

            }
            // if it's jsonobject
            if (obj.optJSONObject(key) != null) {
                updateJson(obj.getJSONObject(key), keyString, newValue);
            }
            // if it's jsonarray
            if (obj.optJSONArray(key) != null) {
                JSONArray jArray = obj.getJSONArray(key);
                for (int i = 0; i < jArray.length(); i++) {
                    updateJson(jArray.getJSONObject(i), keyString, newValue);
                }
            }
        }
        return obj;
    }

    public static JSONObject updateAllJsonField(JSONObject obj, String keyString, String newValue) throws Exception {

        Iterator<String> iterator = obj.keys();
        String key = null;
        while (iterator.hasNext()) {
            key = iterator.next();
            // if the key is a string, then update the value
            if ((obj.optJSONArray(key) == null) && (obj.optJSONObject(key) == null)) {
                if (key.equals(keyString)) {
                    obj.put(key, newValue);
                }
            }
            // if it's jsonobject
            if (obj.optJSONObject(key) != null) {
                updateAllJsonField(obj.getJSONObject(key), keyString, newValue);
            }
            // if it's jsonarray
            if (obj.optJSONArray(key) != null) {
                JSONArray jArray = obj.getJSONArray(key);
                for (int i = 0; i < jArray.length(); i++) {
                    updateAllJsonField(jArray.getJSONObject(i), keyString, newValue);
                }
            }
        }
        return obj;
    }

    public static JSONObject updateJsonFieldExcel(JSONObject obj, Map<String, Object> map) {
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            try {
                JsonUpdateUtil.updateAllJsonField(obj, entry.getKey(), entry.getValue().toString());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return obj;
    }

    /*
     * To nullify Json array
     */
    public static JSONObject updateJsonArrayObjects(JSONObject obj, String keyString, String newValue)
        throws Exception {

        Iterator<String> iterator = obj.keys();
        String key = null;
        while (iterator.hasNext()) {
            key = iterator.next();
            // if it's jsonobject

            if (obj.optJSONObject(key) != null && key.equals(keyString) && newValue == null) {
                obj.put(key, newValue);
                return obj;
            } else if (obj.optJSONObject(key) != null) {
                updateJsonArrayObjects(obj.getJSONObject(key), keyString, newValue);
            }

            // if it's jsonarray
            if (obj.optJSONArray(key) != null && key.equals(keyString) && newValue == null) {
                obj.put(key, newValue);
                return obj;
            } else if (obj.optJSONArray(key) != null) {
                JSONArray jArray = obj.getJSONArray(key);
                for (int i = 0; i < jArray.length(); i++) {
                    updateJsonArrayObjects(jArray.getJSONObject(i), keyString, newValue);
                }
            }
        }
        return obj;
    }

    public static int getRandomNumberInts(int min, int max) {
        Random random = new Random();
        return random.ints(min, (max + 1)).findFirst().getAsInt();
    }

}