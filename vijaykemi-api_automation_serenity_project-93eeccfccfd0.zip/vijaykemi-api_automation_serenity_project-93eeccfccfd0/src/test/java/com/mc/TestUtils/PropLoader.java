package com.mc.TestUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.function.Function;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.caretrix.medcompass.cucumber.steps.Common;

public class PropLoader {

    Common common = new Common();

    private static Logger logger = LogManager.getLogger(PropLoader.class);
    private Properties properties;
    private File file;
    private InputStream input;

    public PropLoader() throws IOException {
        String path = null;

        try {
            common.env = "Q1";
            common.env = System.getProperty("Env");
            if (common.env == null) {
                path = "src/test/resources/Propertiesfiles/application-q1.properties";

                logger.info("Q1 properties are loaded by default");
            } else {
                switch (common.env) {
                    case "Dev":
                        path = "src/test/resources/Propertiesfiles/application-dev.properties";
                        logger.info("Environment is :" + common.env);
                        break;
                    case "Q1":
                        path = "src/test/resources/Propertiesfiles/application-q1.properties";
                        logger.info("Environment is :" + common.env);

                        break;
                    default:
                        logger.info("Please pass the correct environment value");
                        break;
                }
            }
            file = new File(path);
            input = new FileInputStream(file);
            properties = new Properties();
            properties.load(input);
        } catch (Exception e) {
            e.printStackTrace();
            logger.info("Failed to Load Property File");
            // assertFail("Failed to Load Property File");
        }
    }

    public String propertyReader(String key) {
        return properties.getProperty(key);
    }

    public static Function<String, String> props = (String key) -> {
        try {
            String appValue = new PropLoader().propertyReader(key);
            logger.info("Application Configuration " + key + " value " + "'" + appValue + "'" + " loaded successfully");
            return new PropLoader().propertyReader(key);
        } catch (IOException e) {
            logger.info("No Such variable exists");
            // assertFail("No Such variable exists");
        }
        return null;
    };

}