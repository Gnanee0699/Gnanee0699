package com.mc.TestUtils;

import java.io.IOException;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.caretrix.medcompass.cucumber.steps.Common;
import com.caretrix.medcompass.cucumber.steps.ProviderCallBackResponseSteps;
import com.github.javafaker.Faker;

public class Utils {

	Common common = new Common() ;
	private static final Logger log = LogManager.getLogger(ProviderCallBackResponseSteps.class);
	static Faker faker = new Faker();
    
	 public static Map<String, Object> updatedmap(String sheetname, String scenario, String tctype) throws IOException {
	    	
	 Map<String,Object> dataMap1 = ExcelReader.readAllRow(sheetname,scenario);
			
			if(Common.Tctype.equals("Add")){
				Common.sourceproviderid=ExcelReadWrite.getRandomGenerate(12);
				log.info("source id is -------------", Common.sourceproviderid);
			//	System.out.println("source id is ##########"+ common.sourceproviderid);
				
			dataMap1.replace("$..provider.sourceproviderid", Common.sourceproviderid);
			dataMap1.replace("$..providercontract[0].sourceproviderid", Common.sourceproviderid);
			dataMap1.replace("$..providerpostaladdress[0].sourceproviderid", Common.sourceproviderid);
			dataMap1.replace("$..providerpostaladdress[1].sourceproviderid", Common.sourceproviderid);
			dataMap1.replace("$..providerphonenumber[0].sourceproviderid", Common.sourceproviderid);
			dataMap1.replace("$..providerphonenumber[1].sourceproviderid", Common.sourceproviderid);
			dataMap1.replace("$..provideridentifier[0].sourceproviderid", Common.sourceproviderid);
			dataMap1.replace("$..provideridentifier[1].sourceproviderid", Common.sourceproviderid);
			dataMap1.replace("$..provideridentifier[2].sourceproviderid", Common.sourceproviderid);
			dataMap1.replace("$..provideridentifier[3].sourceproviderid", Common.sourceproviderid);
			dataMap1.replace("$..providernetwork[0].sourceproviderid", Common.sourceproviderid);
			dataMap1.replace("$..providernetwork[1].sourceproviderid", Common.sourceproviderid);
			dataMap1.replace("$..providerspecialty[0].sourceproviderid", Common.sourceproviderid);
			dataMap1.replace("$..providerspecialty[1].sourceproviderid", Common.sourceproviderid);
			
			//	dataMap.replace("$..sourceproviderid", "souoituwodiseref");
			}
		
			dataMap1.put("$..providercontract[0].sourceprovidercontractid", ExcelReadWrite.getRandomGenerate(16));
			dataMap1.put("$..providerpostaladdress[0].sourceproviderpostaladdressid", ExcelReadWrite.getRandomGenerate(16));
			dataMap1.put("$..providerpostaladdress[1].sourceproviderpostaladdressid", ExcelReadWrite.getRandomGenerate(16));
			dataMap1.put("$..providerphonenumber[0].sourceproviderphonenumberid", ExcelReadWrite.getRandomGenerate(16));
			dataMap1.put("$..providerphonenumber[1].sourceproviderphonenumberid", ExcelReadWrite.getRandomGenerate(16));
			dataMap1.put("$..provideridentifier[0].sourceprovideridentifierid", ExcelReadWrite.getRandomGenerate(16));
			dataMap1.put("$..provideridentifier[0].identifiervalue", ExcelReadWrite.getRandomGenerate(18));
			dataMap1.put("$..provideridentifier[1].sourceprovideridentifierid", ExcelReadWrite.getRandomGenerate(16));
			dataMap1.put("$..provideridentifier[1].identifiervalue", ExcelReadWrite.getRandomGenerate(18));
			dataMap1.put("$..provideridentifier[2].sourceprovideridentifierid", ExcelReadWrite.getRandomGenerate(16));
			dataMap1.put("$..provideridentifier[2].identifiervalue", ExcelReadWrite.getRandomGenerate(18));
			dataMap1.put("$..provideridentifier[3].sourceprovideridentifierid", ExcelReadWrite.getRandomGenerate(16));
			dataMap1.put("$..provideridentifier[3].identifiervalue", ExcelReadWrite.getRandomGenerate(18));
			dataMap1.put("$..providernetwork[0].sourceprovidernetworkid", ExcelReadWrite.getRandomGenerate(16));
			dataMap1.put("$..providernetwork[1].sourceprovidernetworkid", ExcelReadWrite.getRandomGenerate(16));
			dataMap1.put("$..providerspecialty[0].sourceproviderspecialtyid", ExcelReadWrite.getRandomGenerate(16));
			dataMap1.put("$..providerspecialty[1].sourceproviderspecialtyid", ExcelReadWrite.getRandomGenerate(16));
			//--update oraganization name tro track
			dataMap1.put("$..provider.organizationname", Common.sourceproviderid);
			log.info("dataMap {}--", dataMap1);
			
			return dataMap1;
		}
		
	 public static Map<String, Object> updatedmapADD(String sheetName, String scenario, String tctype,String sourceid) throws IOException {
			// TODO Auto-generated method stub
	    	
	Map<String,Object> dataMap1 = ExcelReader.readAllRow(sheetName,scenario);
			/*
			if(Common.Tctype.equals("ADDUpdate")){
				Common.sourceproviderid=ExcelReadWrite.getRandomGenerate(12);
				log.info("source id is -------------", Common.sourceproviderid);
			//	System.out.println("source id is ##########"+ common.sourceproviderid);
			*/	
			dataMap1.replace("$..providercontract[0].sourceproviderid", sourceid);
			dataMap1.replace("$..provider.sourceproviderid", sourceid);
			dataMap1.replace("$..providerpostaladdress[0].sourceproviderid", sourceid);
			dataMap1.replace("$..providerpostaladdress[1].sourceproviderid", sourceid);
			dataMap1.replace("$..providerphonenumber[0].sourceproviderid", sourceid);
			dataMap1.replace("$..providerphonenumber[1].sourceproviderid", sourceid);
			dataMap1.replace("$..provideridentifier[0].sourceproviderid", sourceid);
			dataMap1.replace("$..provideridentifier[1].sourceproviderid", sourceid);
			dataMap1.replace("$..provideridentifier[2].sourceproviderid", sourceid);
			dataMap1.replace("$..provideridentifier[3].sourceproviderid", sourceid);
			dataMap1.replace("$..providernetwork[0].sourceproviderid", sourceid);
			dataMap1.replace("$..providernetwork[1].sourceproviderid", sourceid);
			dataMap1.replace("$..providerspecialty[0].sourceproviderid", sourceid);
			dataMap1.replace("$..providerspecialty[1].sourceproviderid", sourceid);
			
			//	dataMap.replace("$..sourceproviderid", "souoituwodiseref");
			//}
			
			dataMap1.put("$..providercontract[0].sourceprovidercontractid", ExcelReadWrite.getRandomGenerate(16));
			dataMap1.put("$..providerpostaladdress[0].sourceproviderpostaladdressid", ExcelReadWrite.getRandomGenerate(16));
			dataMap1.put("$..providerpostaladdress[1].sourceproviderpostaladdressid", ExcelReadWrite.getRandomGenerate(16));
			dataMap1.put("$..providerphonenumber[0].sourceproviderphonenumberid", ExcelReadWrite.getRandomGenerate(16));
			dataMap1.put("$..providerphonenumber[1].sourceproviderphonenumberid", ExcelReadWrite.getRandomGenerate(16));
			dataMap1.put("$..provideridentifier[0].sourceprovideridentifierid", ExcelReadWrite.getRandomGenerate(16));
			dataMap1.put("$..provideridentifier[0].identifiervalue", ExcelReadWrite.getRandomGenerate(18));
			dataMap1.put("$..provideridentifier[1].sourceprovideridentifierid", ExcelReadWrite.getRandomGenerate(16));
			dataMap1.put("$..provideridentifier[1].identifiervalue", ExcelReadWrite.getRandomGenerate(18));
			dataMap1.put("$..provideridentifier[2].sourceprovideridentifierid", ExcelReadWrite.getRandomGenerate(16));
			dataMap1.put("$..provideridentifier[2].identifiervalue", ExcelReadWrite.getRandomGenerate(18));
			dataMap1.put("$..provideridentifier[3].sourceprovideridentifierid", ExcelReadWrite.getRandomGenerate(16));
			dataMap1.put("$..provideridentifier[3].identifiervalue", ExcelReadWrite.getRandomGenerate(18));
			dataMap1.put("$..providernetwork[0].sourceprovidernetworkid", ExcelReadWrite.getRandomGenerate(16));
			dataMap1.put("$..providernetwork[1].sourceprovidernetworkid", ExcelReadWrite.getRandomGenerate(16));
			dataMap1.put("$..providerspecialty[0].sourceproviderspecialtyid", ExcelReadWrite.getRandomGenerate(16));
			dataMap1.put("$..providerspecialty[1].sourceproviderspecialtyid", ExcelReadWrite.getRandomGenerate(16));
			
			//----------Updating oraganisationname for tracking----------------------------------------------------
			dataMap1.replace("$..provider.organizationname", sourceid+" Northshore Hospitals");
			
			//------------------------------------------------------------------------------
			
			log.info("dataMap {}--", dataMap1);
			
			return dataMap1;
		}
	 
	 public static Map<String, Object> updatedmapUPDATE(String sheetName, String scenario, String tctype,String updatefield,String updatefieldvalue,String sourceid) throws IOException {
			// TODO Auto-generated method stub
	    	
	Map<String,Object> dataMap1 = ExcelReader.readAllRow(sheetName,scenario);
	
	dataMap1.replace("$..providercontract[0].sourceproviderid", sourceid);
	dataMap1.replace("$..provider.sourceproviderid", sourceid);
	dataMap1.replace("$..providerpostaladdress[0].sourceproviderid", sourceid);
	dataMap1.replace("$..providerpostaladdress[1].sourceproviderid", sourceid);
	dataMap1.replace("$..providerphonenumber[0].sourceproviderid", sourceid);
	dataMap1.replace("$..providerphonenumber[1].sourceproviderid", sourceid);
	dataMap1.replace("$..provideridentifier[0].sourceproviderid", sourceid);
	dataMap1.replace("$..provideridentifier[1].sourceproviderid", sourceid);
	dataMap1.replace("$..provideridentifier[2].sourceproviderid", sourceid);
	dataMap1.replace("$..provideridentifier[3].sourceproviderid", sourceid);
	dataMap1.replace("$..providernetwork[0].sourceproviderid", sourceid);
	dataMap1.replace("$..providernetwork[1].sourceproviderid", sourceid);
	dataMap1.replace("$..providerspecialty[0].sourceproviderid", sourceid);
	dataMap1.replace("$..providerspecialty[1].sourceproviderid", sourceid);
	
	dataMap1.put("$..providercontract[0].sourceprovidercontractid", ExcelReadWrite.getRandomGenerate(16));
	dataMap1.put("$..providerpostaladdress[0].sourceproviderpostaladdressid", ExcelReadWrite.getRandomGenerate(16));
	dataMap1.put("$..providerpostaladdress[1].sourceproviderpostaladdressid", ExcelReadWrite.getRandomGenerate(16));
	dataMap1.put("$..providerphonenumber[0].sourceproviderphonenumberid", ExcelReadWrite.getRandomGenerate(16));
	dataMap1.put("$..providerphonenumber[1].sourceproviderphonenumberid", ExcelReadWrite.getRandomGenerate(16));
	dataMap1.put("$..provideridentifier[0].sourceprovideridentifierid", ExcelReadWrite.getRandomGenerate(16));
	dataMap1.put("$..provideridentifier[0].identifiervalue", ExcelReadWrite.getRandomGenerate(18));
	dataMap1.put("$..provideridentifier[1].sourceprovideridentifierid", ExcelReadWrite.getRandomGenerate(16));
	dataMap1.put("$..provideridentifier[1].identifiervalue", ExcelReadWrite.getRandomGenerate(18));
	dataMap1.put("$..provideridentifier[2].sourceprovideridentifierid", ExcelReadWrite.getRandomGenerate(16));
	dataMap1.put("$..provideridentifier[2].identifiervalue", ExcelReadWrite.getRandomGenerate(18));
	dataMap1.put("$..provideridentifier[3].sourceprovideridentifierid", ExcelReadWrite.getRandomGenerate(16));
	dataMap1.put("$..provideridentifier[3].identifiervalue", ExcelReadWrite.getRandomGenerate(18));
	dataMap1.put("$..providernetwork[0].sourceprovidernetworkid", ExcelReadWrite.getRandomGenerate(16));
	dataMap1.put("$..providernetwork[1].sourceprovidernetworkid", ExcelReadWrite.getRandomGenerate(16));
	dataMap1.put("$..providerspecialty[0].sourceproviderspecialtyid", ExcelReadWrite.getRandomGenerate(16));
	dataMap1.put("$..providerspecialty[1].sourceproviderspecialtyid", ExcelReadWrite.getRandomGenerate(16));
	//----------Updating oraganisationname for tracking----------------------------------------------------
	dataMap1.replace("$..provider.organizationname", sourceid+" APRIA HEALTHCARE LLC");
	
	//------------------------------------------------------------------------------
	//----------Updating a field----------------------------------------------------
	//dataMap1.put("$..providerphonenumber[0].phonenumber", "2489872345");
	//String phonenumber = faker.name().name();
	//System.out.println("-----------------"+phonenumber);
	//dataMap1.put("$..providerphonenumber[0].phonenumber", updatefield);
	dataMap1.put(updatefield, updatefieldvalue);
	
	//------------------------------------------------------------------------------
	log.info("dataMap {}--", dataMap1);
	
	return dataMap1;
		}
	
}
