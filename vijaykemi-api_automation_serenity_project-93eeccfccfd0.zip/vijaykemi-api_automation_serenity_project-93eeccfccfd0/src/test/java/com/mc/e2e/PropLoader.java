package com.mc.e2e;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.function.Function;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class PropLoader {

    String env = null;

    private static Logger logger = LogManager.getLogger(PropLoader.class);
    private Properties properties;
    private File file;
    private InputStream input;

    public PropLoader() throws IOException {
        String path = null;

        try {
            env = System.getProperty("Env");
            if (env == null) {
                path = "src/test/resources/Propertiesfiles/Q1_common.properties";
                logger.info("Q1 properties are loaded by default");
            } else {
                switch (env) {
                    case "Dev":
                        path = "src/test/resources/Propertiesfiles/Dev_common.properties";
                        logger.info("Environment is  {}", env);
                        break;
                    case "Q1":
                        path = "src/test/resources/Propertiesfiles/Q1_common.properties";
                        logger.info("Environment is {}", env);
                        break;
                    case "Q4":
                        path = "src/test/resources/Propertiesfiles/Q4_common.properties";
                        logger.info("Environment is {}", env);
                        break;
                    default:
                        logger.info("Please pass the correct environment value");
                        break;
                }
            }
            file = new File(path);
            input = new FileInputStream(file);
            properties = new Properties();
            properties.load(input);
        } catch (Exception e) {
            logger.info(e, e);
            logger.info("Failed to Load Property File");
        }
    }

    public String propertyReader(String key) {
        return properties.getProperty(key);
    }

    public static Function<String, String> props = (String key) -> {
        try {
            return new PropLoader().propertyReader(key);
        } catch (IOException e) {
            logger.info("No Such variable exists");
        }
        return null;
    };

}