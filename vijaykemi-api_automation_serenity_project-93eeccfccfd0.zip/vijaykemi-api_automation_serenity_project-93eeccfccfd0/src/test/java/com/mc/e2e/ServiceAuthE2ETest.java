package com.mc.e2e;

import static io.restassured.RestAssured.get;
import static io.restassured.RestAssured.given;
import static java.util.concurrent.TimeUnit.SECONDS;
import static net.serenitybdd.rest.SerenityRest.rest;
import static net.serenitybdd.rest.SerenityRest.setDefaultRequestSpecification;
import static net.serenitybdd.rest.SerenityRest.then;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.testng.Assert.assertEquals;


import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.assertj.core.api.SoftAssertions;
import org.awaitility.Awaitility;
import org.awaitility.Duration;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import com.jayway.jsonpath.JsonPath;
import com.mc.TestUtils.Constant;
import com.mc.TestUtils.PropLoader;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import net.serenitybdd.core.Serenity;

public class ServiceAuthE2ETest extends BaseTestConfig {

    static ExtentTest test;
    static ExtentReports extentReports;
    public SoftAssertions softAssertions;

    String content;
    UUID uuid;
    String sourcememberid = UUID.randomUUID().toString();
    Map<String, Map<String, String>> dataMap;

    @BeforeMethod
    public void init(Method method, Object[] testData,ITestContext context) {
        RestAssured.useRelaxedHTTPSValidation();
        
      
    }

   /* @Override
    public String getTestName() {
        return testName.get();
    }*/

    @Test(dataProvider = "DataProviderMEMPROVSA", dataProviderClass = ExcelReader.class, priority = 0, threadPoolSize = 5)
    public void serviceAuthE2ECaseIdValidation(Map<String, Object> map) {
    	//extentReportUtil.createTest(map.get("TestScenario").toString());
    	
    //softAssertions = new SoftAssertions();
    	
    	System.out.println(map.get("Transaction").toString());
    	System.out.println(map.get("GDFID").toString());
  //  	extentReportUtil.getExtentTest().info(map.get("Transaction").toString());
  //  	extentReportUtil.getExtentTest().info(map.get("GDFID").toString());
    	
    	System.out.println("API ----"+PropLoader.props.apply("dhoapihost"));
    //	extentReportUtil.getExtentTest().info("API ----"+PropLoader.props.apply("dhoapihost"));
    	
    	setDefaultRequestSpecification((new RequestSpecBuilder())
				.setContentType(Constant.CONTENTTYPE)
				.setAccept(Constant.CONTENTTYPE)
				.setBaseUri(PropLoader.props.apply("dhoapihost"))
				.build());
    	
    	Response RESP = rest().given().contentType(Constant.CONTENTTYPE)
    			.header("Content-Type",Constant.CONTENTTYPE)
    			.auth().basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password))
    			.when().log().all()
    			.get(PropLoader.props.apply("getUDHapidetails")+map.get("GDFID").toString());
    	
    		//Serenity.getCurrentSession().put(Constant.UDHPAYLOAD, RESP.asString());
    		System.out.println("Response for "+map.get("Transaction").toString()+" is ********** "+RESP.asString());
    	
    		
    		then().assertThat().statusCode(200);
    		
    //------------------------------------------------------------------------------------------------
    		String Endpoint;
    		Serenity.getCurrentSession().get(Constant.UDHPAYLOAD);
    		System.out.println("New Value is --------"+Serenity.getCurrentSession().get(Constant.UDHPAYLOAD));
    		//String payload = (String) Serenity.getCurrentSession().get(Constant.UDHPAYLOAD);
    		String payload = RESP.asString();
    		System.out.println("Payload is ---+ "+payload);
    		
    		if (((String) map.get("Transaction")).equalsIgnoreCase("Member")){
    			Endpoint = PropLoader.props.apply("memberadd");
    			System.out.println("Endpoint is -----------"+Endpoint);
    		}
    		else if(((String) map.get("Transaction")).equalsIgnoreCase("Provider")) {
    			Endpoint =PropLoader.props.apply("provideraddapi");
    			System.out.println("Endpoint is -----------"+Endpoint);
    		}
    		else {
    			Endpoint = PropLoader.props.apply("dhoaddserviceauth");
    			System.out.println("Endpoint is -----------"+Endpoint);
    		}
    		
    		rest().given().contentType(Constant.CONTENTTYPE)
    			.header("Content-Type",Constant.CONTENTTYPE)
    			.auth().basic(PropLoader.props.apply(Constant.username), PropLoader.props.apply(Constant.password))
    			.when().log().all()
    			.body(payload)
    			.post(Endpoint);
    	
    //--------------------------------------------------------------------------------------------------		
    		
    		String eventStatus = "PROCESSED_SUCCESS";
    		String dhoeventuri = PropLoader.props.apply("dhoapihost") + PropLoader.props.apply("dhoevent")
    				+ map.get("GDFID");
    		System.out.println("dho event url :" + dhoeventuri);
    		int timeout = Integer.parseInt(PropLoader.props.apply("providerresponsetimeoutseconds"));
    		
    		System.out.println("timeout is ------"+PropLoader.props.apply("providerresponsetimeoutseconds"));
    		/*
    		Awaitility.with().pollInterval(Duration.FIVE_SECONDS).and().with().pollDelay(Duration.ONE_SECOND.multiply(5)).await()
            .timeout(Duration.ONE_SECOND.multiply(timeout))
            .untilAsserted(() -> assertThat(
                JsonPath.parse(JsonPath.parse(given().contentType(ContentType.JSON).when().get(dhoeventuri)
                        .getBody().jsonPath().getList(".").get(0)).jsonString()).read(Constant.TXNSTATUS),
                containsString(eventStatus))
            		*/
            		Awaitility.with().pollInterval(5, SECONDS).and().with().pollDelay(5, SECONDS).await()
                    .timeout(100, SECONDS)
                    .untilAsserted(() -> assertThat(
                        JsonPath.parse(JsonPath.parse(given().contentType(ContentType.JSON).when().get(dhoeventuri)
                                .getBody().jsonPath().getList(".").get(0)).jsonString()).read(Constant.TXNSTATUS),
                        containsString(eventStatus))

    );
    		
           

            
            String txnStatus = JsonPath.parse(JsonPath.parse(
                given().contentType(ContentType.JSON).when().get(dhoeventuri).getBody().jsonPath().getList(".").get(0))
                    .jsonString()).read(Constant.TXNSTATUS);
            System.out.println("TXN_STAT_DESC:" + txnStatus);
            // This is to print the event status response URL in the report
            Response RESP2 =  rest().given().contentType(Constant.CONTENTTYPE).header("Content-Type", Constant.CONTENTTYPE).when()
                    .get(dhoeventuri);
            
            System.out.println("GET API Response for "+map.get("Transaction").toString()+" is ********** "+RESP2.asString());
           
    }

    @AfterMethod
    public void tearDown(ITestResult result) {
    	//extentReportUtil.getExtentTest().log(Status.INFO,  "<pre>" + restHandlerPostRequest.printLoggerPostRequest() + "</pre>");
       // extentReportUtil.testResultUpdate(result);
    	System.out.println("END");
    }

}
