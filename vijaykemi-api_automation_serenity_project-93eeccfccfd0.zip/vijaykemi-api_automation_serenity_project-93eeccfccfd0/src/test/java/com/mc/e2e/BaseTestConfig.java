package com.mc.e2e;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.mc.reportUtil.ExtentReportUtil;

public class BaseTestConfig {
    public static ExtentReportUtil extentReportUtil;

    @BeforeSuite
    public void initconfig() {
        extentReportUtil = new ExtentReportUtil("MedCompass Test Automation Report",
                "Automation Test", "XXX", "Windows", "NA");
    }

    @AfterSuite
    public void revokeConfig() {
        extentReportUtil.endReport();
    }
}