package com.mc.e2e;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.testng.annotations.DataProvider;

/**
 * Created by Jeevan on 6/26/2020.
 */

public class ExcelReader {

    private static final Logger log = LogManager.getLogger(ExcelReader.class);

    public static Map<String, Object> readAllRow(String sheetName, String scenario) throws IOException {
        Workbook workbook = null;
        Map<String, Object> dataMap = new HashMap<>();
        String filePath =
            (System.getProperty("user.dir") + "/src/test/resources/testdata/Member_MedCompass_Inputsheet.xlsx");
        log.info("filePath {}", filePath);
        try {
            FileInputStream inputStream = new FileInputStream(new File(filePath));
            workbook = WorkbookFactory.create(inputStream);
            Iterator<Sheet> sheetIterator = workbook.sheetIterator();
            Sheet sheet = null;
            while (sheetIterator.hasNext()) {
                sheet = sheetIterator.next();
                if (sheet.getSheetName().equalsIgnoreCase(sheetName)) {
                    break;
                }
            }
            dataMap = getDataRow(sheet, scenario);
            log.info("dataMap {}", dataMap.size());
            inputStream.close();
            workbook.close();
        } catch (EncryptedDocumentException | IOException e) {
            log.info(e, e);
        } finally {
            if (workbook != null) {
                workbook.close();
            }
        }
        return dataMap;
    }

    private static Map<String, Object> getDataRow(Sheet sheet, String testScenario) {
        Map<String, Object> dataMap = new HashMap<>();
        if (sheet != null) {
            for (int i = 0; i <= sheet.getLastRowNum(); i++) {
                Row headerRow = sheet.getRow(0);
                if (i == 0) {
                    continue;
                } else if (i > 0) {
                    Row dataRow = sheet.getRow(i);
                    if (getCellValue(dataRow.getCell(1)).contains(testScenario)) {
                        for (int j = 1; j < headerRow.getLastCellNum(); j++) {
                            dataMap.put(getCellValue(headerRow.getCell(j)), getCellValue(dataRow.getCell(j)));
                        }
                    } else {
                        continue;
                    }
                    return dataMap;

                }

            }
        }
        return dataMap;
    }

    public static Map<String, Map<Object, Object>> readAllRows(String excelPath, String sheetName) throws IOException {
        Workbook workbook = null;
        Map<String, Map<Object, Object>> dataMap = new HashMap<>();
        String filePath = (excelPath);
        try {
            FileInputStream inputStream = new FileInputStream(new File(filePath));
            workbook = WorkbookFactory.create(inputStream);
            Iterator<Sheet> sheetIterator = workbook.sheetIterator();
            Sheet sheet = null;
            while (sheetIterator.hasNext()) {
                sheet = sheetIterator.next();
                log.info("sheet name {} ", sheet.getSheetName());
                if (sheet.getSheetName().equalsIgnoreCase(sheetName)) {
                    break;
                }
            }
            dataMap = getAllDataRow(sheet);
            inputStream.close();
            workbook.close();
        } catch (Exception e) {
            log.info(e, e);
        } finally {
            if (workbook != null) {
                workbook.close();
            }
        }
        return dataMap;
    }

    @DataProvider(name = "DataProvider", parallel = true)
    public static Object[][] readAllRow(Method m) throws IOException {
        String sheetName = "Yellow";
        List<String> results = new ArrayList<>();
        List<Map<String, Map<Object, Object>>> dataProviderList = new ArrayList<>();
        File[] files = new File(PropLoader.props.apply("E2EDestinationFolderPath")).listFiles();
        System.out.println("files count" +files);
        for (File file : files) {
            if (file.isFile()) {
                results.add(file.getName());
                dataProviderList.add(readAllRows(file.getPath(), sheetName));
            }
        }
        Map<String, Map<Object, Object>> datamap = new HashMap<>();
        for (int i = 0; i < dataProviderList.size(); i++) {
            Iterator<Map.Entry<String, Map<Object, Object>>> iterator = dataProviderList.get(i).entrySet().iterator();
            while (iterator.hasNext()) {
                Map.Entry<String, Map<Object, Object>> entry = iterator.next();
                datamap.put(entry.getKey(), entry.getValue());
            }
        }
        Object[][] dataProvider = new Object[datamap.size()][1];
        Iterator<Map.Entry<String, Map<Object, Object>>> iterator = datamap.entrySet().iterator();
        int i = 0;
        while (iterator.hasNext()) {
            Map.Entry<String, Map<Object, Object>> entry = iterator.next();
            dataProvider[i++][0] = entry.getValue();
        }
        return dataProvider;
    }
    
    @DataProvider(name = "DataProviderMEMPROVSA", parallel = true)
    public static Object[][] readAllRowMPS(Method m) throws IOException {
        String sheetName = "DHOMemberGDF";
        List<String> results = new ArrayList<>();
        List<Map<String, Map<Object, Object>>> dataProviderList = new ArrayList<>();
        File[] files = new File(PropLoader.props.apply("MEMPROVSAGDFPath")).listFiles();
        System.out.println("files count" +files);
        for (File file : files) {
            if (file.isFile()) {
                results.add(file.getName());
                dataProviderList.add(readAllRows(file.getPath(), sheetName));
            }
        }
        Map<String, Map<Object, Object>> datamap = new HashMap<>();
        for (int i = 0; i < dataProviderList.size(); i++) {
            Iterator<Map.Entry<String, Map<Object, Object>>> iterator = dataProviderList.get(i).entrySet().iterator();
            while (iterator.hasNext()) {
                Map.Entry<String, Map<Object, Object>> entry = iterator.next();
                datamap.put(entry.getKey(), entry.getValue());
            }
        }
        Object[][] dataProvider = new Object[datamap.size()][1];
        Iterator<Map.Entry<String, Map<Object, Object>>> iterator = datamap.entrySet().iterator();
        int i = 0;
        while (iterator.hasNext()) {
            Map.Entry<String, Map<Object, Object>> entry = iterator.next();
            dataProvider[i++][0] = entry.getValue();
        }
        return dataProvider;
    }

    private static Map<String, Map<Object, Object>> getAllDataRow(Sheet sheet) {
        Map<Object, Object> dataMap;

        Map<String, Map<Object, Object>> allDataMap = new HashMap<>();
        if (sheet != null) {
            for (int i = 0; i <= sheet.getLastRowNum(); i++) {
                Row headerRow = sheet.getRow(0);
                if (i == 0) {
                    continue;
                } else if (i > 0) {
                    Row dataRow = sheet.getRow(i);
                    String mapKey = "";
                    dataMap = new HashMap<>();
                    for (int j = 1; j < headerRow.getLastCellNum(); j++) {
                        if (getCellValue(headerRow.getCell(j)).contains("TestScenario")) {
                            mapKey = getCellValue(dataRow.getCell(j));
                        }
                        dataMap.put(getCellValue(headerRow.getCell(j)), getCellValue(dataRow.getCell(j)));
                    }
                    allDataMap.put(mapKey, dataMap);
                }

            }
        }
        return allDataMap;
    }

    private static String getCellValue(Cell cell) {
        if (cell != null) {
            switch (cell.getCellType()) {
                case BOOLEAN:
                    return Boolean.toString(cell.getBooleanCellValue());
                case STRING:
                    return cell.getRichStringCellValue().getString();
                case NUMERIC:
                    if (DateUtil.isCellDateFormatted(cell)) {
                        return cell.getDateCellValue().toString();
                    } else {
                        return Double.toString(cell.getNumericCellValue());
                    }
                case BLANK:
                    return "";
                default:
                    return "";
            }
        } else
            return "";
    }

    // #####################################Utility Methods#####################################

    // **********************************************************************************************

}