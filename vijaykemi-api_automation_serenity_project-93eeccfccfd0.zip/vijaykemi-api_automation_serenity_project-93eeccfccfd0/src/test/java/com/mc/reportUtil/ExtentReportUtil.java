package com.mc.reportUtil;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import org.testng.ITestResult;

public class ExtentReportUtil {
    private ExtentHtmlReporter extentHtmlReporter;
    private ExtentReports extentReports;
    private ExtentTest extentTest;

    public ExtentReportUtil(String documentTitle, String reportName, String hostName, String os, String browser) {
        extentHtmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir") + "/test-output/TestReport.html");
        extentHtmlReporter.config().setDocumentTitle(documentTitle);
        extentHtmlReporter.config().setReportName(reportName);
        extentHtmlReporter.config().setTheme(Theme.DARK);
        extentReports = new ExtentReports();
        extentReports.attachReporter(extentHtmlReporter);
        extentReports.setSystemInfo("Hostname", hostName);
        extentReports.setSystemInfo("OS", os);
        extentReports.setSystemInfo("Browser", browser);
    }

    public ExtentTest getExtentTest() {
        return extentTest;
    }


    public void createTest(String testName) {
        extentTest=extentReports.createTest(testName);
    }

    public void testResultUpdate(ITestResult result) {
        if (result.getStatus() == ITestResult.FAILURE) {
            extentTest.log(Status.FAIL, "Test Cases Failed is: " + result.getName());
            extentTest.log(Status.FAIL, "Error /Exception is: " + result.getThrowable());
        } else if (result.getStatus() == ITestResult.SKIP) {
            extentTest.log(Status.SKIP, "Test Cases SKIPPED is: " + result.getName());
        } else if (result.getStatus() == ITestResult.SUCCESS) {
            extentTest.log(Status.PASS, "Test Cases PASSED is: " + result.getName());
          //  extentTest.log(Status.PASS, "Test suites PASSED is: " + result.getInstanceName());
          //  extentTest.log(Status.PASS, "Test step PASSED is: " + result.getStatus());
        }
    }


    public void endReport() {
        extentReports.flush();
    }
}

