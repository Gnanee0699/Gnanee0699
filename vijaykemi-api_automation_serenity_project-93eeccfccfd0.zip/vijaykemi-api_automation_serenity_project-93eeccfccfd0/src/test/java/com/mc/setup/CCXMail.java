package com.mc.setup;

import java.util.ArrayList;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Address;
import javax.mail.Authenticator;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

//import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;



public class CCXMail {

	//private static final Logger log = Logger.getLogger(CCXMail.class);
	// private member veriables
	private String messageText;
	private String addrFrom;
	private String nameFrom;
	private String mailSubject;
	
	private String addrTo="vijayapandian.palani@carecentrix.com";
	private ArrayList<String> nameTo;	
	private ArrayList<String> nameCc;
	private ArrayList<String> addrCc;
	private ArrayList<String> nameBcc;
	private ArrayList<String> addrBcc;
	private ArrayList<String> addrReplyTo;
	private ArrayList<String> nameReplyTo;
	private File attachFile;
	private String mailServer;	
	private javax.mail.Session sesObj;
	private String emailServerName = "";
	private String emailServerUserId = "";
	private String emailServerPassword = "";
	private String authenticationReq = "";
	private String contentType="text/html";
	
	// Ticket #595069 - Password Encryption Changes
	private static final String JASYPT_MASTER_PASS = "JASYPT_MASTER_PASS";
 	private static final String JASYPT_ALGORITHM = "VAR_ALGORITHM";
 	private static final String MAIL_WORD = "mailPassword";
	/**
	 * @return the messageText
	 */
	public String getMessageText() {
		return messageText;
	}
	/**
	 * @param messageText the messageText to set
	 */
	public void setMessageText(String messageText) {
		this.messageText = messageText;
	}
	/**
	 * @return the addrFrom
	 */
	public String getAddrFrom() {
		return addrFrom;
	}
	/**
	 * @param addrFrom the addrFrom to set
	 */
	public void setAddrFrom(String addrFrom) {
		this.addrFrom = addrFrom;
	}
	/**
	 * @return the nameFrom
	 */
	public String getNameFrom() {
		return nameFrom;
	}
	/**
	 * @param nameFrom the nameFrom to set
	 */
	public void setNameFrom(String nameFrom) {
		this.nameFrom = nameFrom;
	}
	/**
	 * @return the mailSubject
	 */
	public String getMailSubject() {
		return mailSubject;
	}
	/**
	 * @param mailSubject the mailSubject to set
	 */
	public void setMailSubject(String mailSubject) {
		this.mailSubject = mailSubject;
	}
	/**
	 * @return the addrTo
	 */
	public String getAddrTo() {
		return addrTo;
	}
	/**
	 * @param addrTo the addrTo to set
	 */
	public void setAddrTo(String addrTo) {
		this.addrTo = addrTo;
	}
	
	/**
	 * @return the nameTo
	 */
	public ArrayList<String> getNameTo() {
		return nameTo;
	}
	/**
	 * @param nameTo the nameTo to set
	 */
	public void setNameTo(ArrayList<String> nameTo) {
		this.nameTo = nameTo;
	}
	/**
	 * @return the nameCc
	 */
	public ArrayList<String> getNameCc() {
		return nameCc;
	}
	/**
	 * @param nameCc the nameCc to set
	 */
	public void setNameCc(ArrayList<String> nameCc) {
		this.nameCc = nameCc;
	}
	/**
	 * @return the addrCc
	 */
	public ArrayList<String> getAddrCc() {
		return addrCc;
	}
	/**
	 * @param addrCc the addrCc to set
	 */
	public void setAddrCc(ArrayList<String> addrCc) {
		this.addrCc = addrCc;
	}
	/**
	 * @return the nameBcc
	 */
	public ArrayList<String> getNameBcc() {
		return nameBcc;
	}
	/**
	 * @param nameBcc the nameBcc to set
	 */
	public void setNameBcc(ArrayList<String> nameBcc) {
		this.nameBcc = nameBcc;
	}
	/**
	 * @return the addrBcc
	 */
	public ArrayList<String> getAddrBcc() {
		return addrBcc;
	}
	/**
	 * @param addrBcc the addrBcc to set
	 */
	public void setAddrBcc(ArrayList<String> addrBcc) {
		this.addrBcc = addrBcc;
	}
	/**
	 * @return the mailServer
	 */
	public String getMailServer() {
		return mailServer;
	}
	/**
	 * @param mailServer the mailServer to set
	 */
	public void setMailServer(String mailServer) {
		this.mailServer = mailServer;
	}
	/**
	 * @return the sesObj
	 */
	public javax.mail.Session getSesObj() {
		return sesObj;
	}
	/**
	 * @param sesObj the sesObj to set
	 */
	public void setSesObj(javax.mail.Session sesObj) {
		this.sesObj = sesObj;
	}
	/**
	 * @return the emailServerName
	 */
	public String getEmailServerName() {
		return emailServerName;
	}
	/**
	 * @param emailServerName the emailServerName to set
	 */
	public void setEmailServerName(String emailServerName) {
		this.emailServerName = emailServerName;
	}
	/**
	 * @return the emailServerUserId
	 */
	public String getEmailServerUserId() {
		return emailServerUserId;
	}
	/**
	 * @param emailServerUserId the emailServerUserId to set
	 */
	public void setEmailServerUserId(String emailServerUserId) {
		this.emailServerUserId = emailServerUserId;
	}
	/**
	 * @return the emailServerPassword
	 */
	public String getEmailServerPassword() {
		return emailServerPassword;
	}
	/**
	 * @param emailServerPassword the emailServerPassword to set
	 */
	public void setEmailServerPassword(String emailServerPassword) {
		this.emailServerPassword = emailServerPassword;
	} 
	/**
	 * This method send mail to set addresses
	 * This function needs to set following member variables
	 * messageText, mailSubject, addrFrom, nameFrom, addrTo, nameTo
	 * @param   void
	 * @exception Exception
	 */
	public void sendMail() throws Exception{
		try{
			// setting properties for getting session
			Properties propObj = new Properties();
			/**
			 * Properties for MailServer
			 */
			Session sesObj = null;
		//	Properties props = new Properties();
			// Ticket #595069 - Password Encryption Changes
		//	props.load(CCXUtils.class.getClassLoader().getResourceAsStream(CCXUtils.SECURITY_PROPERTY_FILE_NAME));
			
			FileInputStream fn = new FileInputStream(
					System.getProperty("user.dir") + "\\src\\test\\resources\\Propertiesfiles\\security.properties");
			
			propObj.load(fn);
			
			emailServerName = propObj.getProperty("mailHost");			
			authenticationReq = propObj.getProperty("mailAuthenticationReq","FALSE");
		//	log.debug(new StringBuilder("mass smtp host= ").append(emailServerName));
				propObj.put("mail.smtp.host",emailServerName);
			
					
				sesObj =  Session.getInstance(propObj);
			//	log.debug("session created without authentication ");
			//	log.info("session created without authentication ");
			
				// Creating new message
				MimeMessage msg = new MimeMessage(sesObj);
				Address fromAddr = null;
				// setting mail subject
				if(mailSubject == null)
					msg.setSubject("None");
				else
					msg.setSubject(mailSubject);
									
				if(nameFrom != null && !nameFrom.equals(""))
					fromAddr = new InternetAddress(addrFrom, nameFrom);
				else
					fromAddr = new InternetAddress(addrFrom);
				
				msg.setFrom(fromAddr);
				//log.debug(new StringBuilder("subject and from address set ").append(fromAddr));
				
				if(addrTo!=null)
				{
					//Address toAddr[] = new InternetAddress[addrTo.size()];
					for(int iter=0; iter < 1; iter++)
					{
						String strName = "";
						if(nameTo != null)
						{
							if(iter < nameTo.size())
							{
								strName = (String)nameTo.get(iter);
							}
						}		
						//toAddr[iter]= new InternetAddress((String)addrTo.get(iter), strName);
					}
					
					//msg.addRecipients(javax.mail.Message.RecipientType.TO, toAddr);
					msg.addRecipients(javax.mail.Message.RecipientType.TO, addrTo);
				//	log.debug(new StringBuilder("to address set in SendMail").append(addrTo));
					
				}					
				//log.debug("to address set ");
				if(addrCc!=null){
					Address ccAddr[] = new InternetAddress[addrCc.size()];
					for(int iter=0; iter < addrCc.size(); iter++){
						String strName = "";
						if(nameCc != null){
							if(iter < nameCc.size()){
								strName = (String)nameCc.get(iter);
							}
						}
						ccAddr[iter]= new InternetAddress((String)addrCc.get(iter), strName);
					}
					msg.addRecipients(javax.mail.Message.RecipientType.CC, ccAddr);
				//	log.debug(new StringBuilder("CC address set in SendMail").append(addrCc));
				}
				if(addrBcc!=null){
					Address bccAddr[] = new InternetAddress[addrBcc.size()];
					for(int iter=0; iter < addrBcc.size(); iter++){
						String strName = "";
						if(nameBcc != null){
							if(iter < nameBcc.size()){
								strName = (String)nameBcc.get(iter);
							}
						}
						bccAddr[iter]= new InternetAddress((String)addrBcc.get(iter), strName);
					//	log.debug(new StringBuilder("iter :").append(bccAddr[iter]));
					}
					msg.addRecipients(javax.mail.Message.RecipientType.BCC, bccAddr);
				//	log.debug(new StringBuilder("Bcc address set ").append(addrBcc));
				}
				if(addrReplyTo!=null){
					Address replyAddTo[] = new InternetAddress[addrReplyTo.size()];
					for(int iter=0; iter < addrReplyTo.size(); iter++){
						String strName = "";
						if(nameReplyTo != null){
							if(iter < nameReplyTo.size()){
								strName = (String)nameReplyTo.get(iter);
							}
						}
						replyAddTo[iter]= new InternetAddress((String)addrReplyTo.get(iter), strName);
					//	log.debug(new StringBuilder("iter :").append(replyAddTo[iter]));
					}
					msg.setReplyTo(replyAddTo);
				//	log.debug(new StringBuilder("Reply to address set ").append(addrReplyTo));
				}
				
				
				if (attachFile != null)
				{	
					// create the message part 
					MimeBodyPart messageBodyPart = 
					  new MimeBodyPart();
	
					//fill message
					messageBodyPart.setContent(messageText, contentType);
	
					Multipart multipart = new MimeMultipart();
					multipart.addBodyPart(messageBodyPart);
	
						messageBodyPart = new MimeBodyPart();
						DataSource source = new FileDataSource(attachFile);
						messageBodyPart.setDataHandler(new DataHandler(source));
						messageBodyPart.setFileName(source.getName());
						multipart.addBodyPart(messageBodyPart);
					
					// Put parts in message
					msg.setContent(multipart);
				//	log.debug("files attached");
				}else
				{
					msg.setContent(messageText, contentType);
				}				
			//	log.debug("sending mail in sendMail");
				Transport.send(msg);
			//	log.debug("Mail sent in sendMail");
		}catch(Exception excep){
			//CCXLogger.log.error("mail could not be sent. ",excep);
		//	throw new CcxException("Could not send error mail");
		}
	}
	/**
	* SimpleAuthenticator is used to do simple authentication
	* when the SMTP server requires it.
	*/
	private class SMTPAuthenticator extends javax.mail.Authenticator{
		public PasswordAuthentication getPasswordAuthentication(){
			String username="";
			String password="";
			try{
			//	log.debug(new StringBuilder("server: ").append(emailServerName));
			//	log.debug(new StringBuilder("username: ").append(emailServerUserId));					
				return new PasswordAuthentication(emailServerUserId, emailServerPassword);
			}catch (Exception e){					
			//	CCXLogger.log.error("Exception in getPasswordAuthentication :",e);
				return new PasswordAuthentication(username, password);
			}
		}
	}
	/**
	 * @return the attachFile
	 */
	public File getAttachFile() {
		return attachFile;
	}
	/**
	 * @param attachFile the attachFile to set
	 */
	public void setAttachFile(File attachFile) {
		this.attachFile = attachFile;
	}
	/**
	 * @return the addrReplyTo
	 */
	public ArrayList<String> getAddrReplyTo() {
		return addrReplyTo;
	}
	/**
	 * @param addrReplyTo the addrReplyTo to set
	 */
	public void setAddrReplyTo(ArrayList<String> addrReplyTo) {
		this.addrReplyTo = addrReplyTo;
	}
	
	public String getContentType() {
		return contentType;
	}
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}
	
	/**
	 * This method is to get the encrypted password from the Cache
	 * @return encrypt password
	 */
	
	/*
	public String getEmailPassword(){

		//CCXLogger.log.info("Entering getEmailPassword method");
		
		String emailPassword = RuleFlowPropertiesCache.getRuleFlowProperties().get(MAIL_WORD);
		if(emailPassword == null){
			try {	

				StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
				String masterPwd = System.getenv(JASYPT_MASTER_PASS); // Getting the environment variables
				if(masterPwd != null){
					encryptor.setPassword(masterPwd); 				
				}else{
				//	CCXLogger.log.info("Env var are not avaialble : " + JASYPT_MASTER_PASS);
				}

				String algorithm = System.getenv(JASYPT_ALGORITHM); // Getting the environment variables
				if(algorithm != null){
					encryptor.setAlgorithm(algorithm);
				}else{
				//	CCXLogger.log.info("Env var are not avaialble : " + JASYPT_ALGORITHM);
				}

				//encryptor
			//	Properties encryptProps = new EncryptableProperties(encryptor);
			//	encryptProps.load(CCXUtils.class.getClassLoader().getResourceAsStream(CCXUtils.SECURITY_PROPERTY_FILE_NAME));
				emailPassword = encryptProps.getProperty(MAIL_WORD);

			} catch (Exception e) {
			//	CCXLogger.log.error("error in getting encrypted password properties:",e);
			}

		}		
	//	CCXLogger.log.info("Exit getEmailPassword method");
		
		return emailPassword;
	}
*/

}