package com.mc.setup;

import static net.serenitybdd.rest.SerenityRest.setDefaultRequestSpecification;

import com.mc.TestUtils.Constant;
import com.mc.TestUtils.PropLoader;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;

public class SetupHeaders {
	
	
	public static void setupRestAssuredDefaultsMedCompassMember() throws InterruptedException {

		// Write code here that turns the phrase above into concrete actions
		RestAssured.useRelaxedHTTPSValidation();
		
		setDefaultRequestSpecification((new RequestSpecBuilder())
				
				.setContentType(Constant.CONTENTTYPE)
				.setAccept(Constant.CONTENTTYPE)
				.setBaseUri(PropLoader.props.apply("mcapihostname"))
				.build());
		}
	public static void setupRestAssuredDefaultsMedCompassProvider() throws InterruptedException {

		// Write code here that turns the phrase above into concrete actions
		RestAssured.useRelaxedHTTPSValidation();
		setDefaultRequestSpecification((new RequestSpecBuilder())
				
				.setContentType(Constant.CONTENTTYPE)
				.setAccept(Constant.CONTENTTYPE)
				.setBaseUri(PropLoader.props.apply("mcapihostname"))
				.build());
		}
	public static void setupRestAssuredDefaultsMedCompassServAuth() throws InterruptedException {

		// Write code here that turns the phrase above into concrete actions
		RestAssured.useRelaxedHTTPSValidation();
		
		setDefaultRequestSpecification((new RequestSpecBuilder())
				
				.setContentType(Constant.CONTENTTYPE)
				.setAccept(Constant.CONTENTTYPE)
				.setBaseUri(PropLoader.props.apply("mcapihostname"))
				.build());
		}
	
	public static void initialSetupDHOMemberInitiator() throws InterruptedException {
		RestAssured.useRelaxedHTTPSValidation();
		setDefaultRequestSpecification((new RequestSpecBuilder())
				.setContentType(Constant.CONTENTTYPE)
				.setAccept(Constant.CONTENTTYPE)
				.setBaseUri(PropLoader.props.apply("dhoapihost"))
				.build());
	}
	
	
	public static void initialSetupDHOProviderInitiator() throws InterruptedException {
		RestAssured.useRelaxedHTTPSValidation();
		setDefaultRequestSpecification((new RequestSpecBuilder())
				.setContentType(Constant.CONTENTTYPE)
				.setAccept(Constant.CONTENTTYPE)
				.setBaseUri(PropLoader.props.apply("dhoapihost"))
				.build());
	}
	
	public static void initialSetupServiceAuth() throws InterruptedException {
		RestAssured.useRelaxedHTTPSValidation();
		setDefaultRequestSpecification((new RequestSpecBuilder())
				.setContentType(Constant.CONTENTTYPE)
				.setAccept(Constant.CONTENTTYPE)
				.setBaseUri(PropLoader.props.apply("mcapihostname"))
				.build());
	}
	
	public static void initialSetupEventResp() throws InterruptedException {
		RestAssured.useRelaxedHTTPSValidation();
		setDefaultRequestSpecification((new RequestSpecBuilder())
				.setContentType(Constant.CONTENTTYPE)
				.setAccept(Constant.CONTENTTYPE)
				.setBaseUri(PropLoader.props.apply("mcevntresphostname"))
				.build());
	}
	
	public static void initialSetupDHOProviderMcIntegration() {
		RestAssured.useRelaxedHTTPSValidation();
		setDefaultRequestSpecification((new RequestSpecBuilder())
				.setContentType(Constant.CONTENTTYPE)
				.setAccept(Constant.CONTENTTYPE)
				.setBaseUri(PropLoader.props.apply("mciapihostname"))
				.build());
		
	}
	public static void initialSetupDHOMemberMcIntegration() {
		RestAssured.useRelaxedHTTPSValidation();
		setDefaultRequestSpecification((new RequestSpecBuilder())
				.setContentType(Constant.CONTENTTYPE)
				.setAccept(Constant.CONTENTTYPE)
				.setBaseUri(PropLoader.props.apply("mciapihostname"))
				.build());
		
		
	}
	public static void initialSetupMCIemberMcIntegration() {
		RestAssured.useRelaxedHTTPSValidation();
		setDefaultRequestSpecification((new RequestSpecBuilder())
				.setContentType(Constant.CONTENTTYPE)
				.setAccept(Constant.CONTENTTYPE)
				.setBaseUri(PropLoader.props.apply("memberapihost"))
				.build());
		
	}


	public static void initialSetupMCIProviderMcIntegration() {
		RestAssured.useRelaxedHTTPSValidation();
		setDefaultRequestSpecification((new RequestSpecBuilder())
				.setContentType(Constant.CONTENTTYPE)
				.setAccept(Constant.CONTENTTYPE)
				.setBaseUri(PropLoader.props.apply("providerapihost"))
				.build());
		
	}
	
	public static void initialSetupDHORequest() throws InterruptedException {
		RestAssured.useRelaxedHTTPSValidation();
		setDefaultRequestSpecification((new RequestSpecBuilder())
				.setContentType(Constant.CONTENTTYPE)
				.setAccept(Constant.CONTENTTYPE)
				.setBaseUri(PropLoader.props.apply("dhoapihost"))
				.build());
	}
	
	public static void initialSetup(String hostname) throws InterruptedException {
		RestAssured.useRelaxedHTTPSValidation();
		setDefaultRequestSpecification((new RequestSpecBuilder())
				.setContentType(Constant.CONTENTTYPE)
				.setAccept(Constant.CONTENTTYPE)
				.setBaseUri(PropLoader.props.apply(hostname))
				.build());
	}

}
