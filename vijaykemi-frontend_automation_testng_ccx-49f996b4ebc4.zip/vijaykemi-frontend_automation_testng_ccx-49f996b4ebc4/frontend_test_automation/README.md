# Frontend Test Automation:

Frontend Test Automation is a datadriven framework build using Selenium WebDriver, TestNG, Winium, Sikuli and various other open source tools.<p>

## BitBucket:
* **Repo Link: **
	<a href="https://bitbucket/projects/QAT/repos/frontend-test-automation/browse" target="_blank">https://bitbucket/projects/QAT/repos/frontend-test-automation/browse</a><p>


## Branching Standard:

* **Master:**<br>
	* Managed with production version of code.<br>
	* Release and hotfix branches will be constantly merged into master as soon as they are promoted to production.<br>
	* This should be manually done by the dev leads.<br><P>

* **Release:**<br>
	* Create a Release branch from Master.<br><p>
	
* **Feature:**<br>
	* Create a feature branch from a release or hotfix branch to make changes on the developers machine and check in the changes.<br>
	* Branch name should be <Networkid>-<DA Number>, EX: Feature/RRVIVEK-DA-960<br>
	* Create a pull request to merge the changes from feature branch to Development or hotfix branchs.<br><p>



## Jenkins CI/CD:

*  **Build Pipeline:** <a href="https://dev-jenkins.ccx.carecentrix.com/job/frontend-test-automation/" target="_blank">https://dev-jenkins.ccx.carecentrix.com/job/frontend-test-automation/</a>
<p>
* **Parameters:**<br>
	* *Environment*<br>
		* Auto, Q1, Q2, Q3, Q4, Q5<br>
		<b>Note:</b> Prod is not included intentionally<br><p>
	* *TestMachine*<br>
		* Any, QNCRASLKWS001, QNCRASLKWS002, QNCRASLKWS003, QNCRASLKWS004, QNCRASLKWS005, QNCRASLKWS006, QNCRASLKWS007, QNCRASLKWS008, QNCRASLKWS009, QNCRASLKWS010, QNCRASLKWS011<br>
		<b>Note:</b> QNCRASLKWS011 is available for onshore only<p>

##### Automation Engineer: 
* <a href="mailto:mani.rai@carecentrix.com">Mani Rai</a>
* <a href="mailto:salman.jawahirali@carecentrix.com">Salman Jawahirali</a>