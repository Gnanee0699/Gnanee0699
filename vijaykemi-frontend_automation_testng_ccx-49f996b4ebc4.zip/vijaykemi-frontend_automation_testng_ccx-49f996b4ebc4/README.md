# APPLICATION / PROCESS NAME:

#### [Source Code] (Update the repo link)

#### PURPOSE OF THIS REPOSITORY:

## BRANCHING STANDARDS: (UPDATE THE BRANCHING MODEL FOLLOWED BY THE THIS PROJECT, ONE OF THE EXAMPLE GIVEN IS AS GIVEN BELOW)
* **Master:**
	* Managed with production version of code. 
	* Release and hotfix branches will be constantly merged into master as soon as they are promoted to production. 
	* This should be manually done by the dev leads.

* **Hotfix:**
	* Create a hot fix branch from Master for e-fixes or off-cycle releases.
	* Branch name should be yymmdd, EX: **Hotfix/201229** (December 29th 2020)
	
* **Development:**
	* Create a Development branch from Master.
	
* **Feature:**
	* Create a feature branch from a release or hotfix branch to make changes on the developers machine and check in the changes.
	* Branch name should be <Networkid>-<DA Number>, EX: **Feature/RRVIVEK-DA-960**
	* Create a pull request to merge the changes from feature branch to Development or hotfix branchs.

## JENKINS CI/CD:

*  **BUILD PIPELINE:**
	*  **[BUILD JOB]** **(update the link)**

*  **DEPLOYMENT PIPELINE:**
	* **[Dev Deployment Job]** **(update the link)**
		* **Deployment Location** -  (update the path)
	* **[QA Deployment Job]** **(update the link)**
		* **Deployment Location** -  (update the path)
	* **[PROD Deployment Job]** **(update the link)**
		* **Deployment Location** -  (update the path)
		
* **DEPLOYMENT DASHBOARD:**
	* **[Dashbaord]** **(update the link)**